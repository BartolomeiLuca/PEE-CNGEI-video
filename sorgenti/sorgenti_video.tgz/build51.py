import sys,os,re,shutil,subprocess,glob
sys.path.insert(0,'/home/claude/work/titlecard')
from cards import T
V='/home/claude/work/vid/out/'
M={2:'Ds/video_Dashboard',3:'02s/video_2',4:'03s/video_3',6:'05s/video_05s',7:'07c/video_07',8:'06s/video_06',9:'07s/video_7',10:'08s/video_08s',11:'11n/video_11n',12:'09s/video_09',13:'44s/video_44s',14:'45s/video_45',15:'11s/video_11',16:'12s/video_12s',17:'13s/video_13',18:'14s/video_14',19:'15s/video_15',20:'16s/video_16',21:'46s/video_46',22:'21c/video_21',23:'18s/video_18s',24:'19s/video_19s',25:'20s/video_20',26:'21s/video_21',27:'22s/video_22',28:'23s/video_23',29:'24s/video_24',30:'25s/video_25',31:'26/video_26',32:'27/video_27',33:'28s/video_28',34:'29s/video_33',35:'30s/video_30',36:'31s/video_31',37:'32s/video_32',38:'33s/video_33',39:'34s/video_34',40:'35s/video_35',41:'36s/video_36',42:'37s/video_37',43:'38s/video_38',44:'44n/video_44n',45:'45n/video_45n',46:'46n/video_46n',47:'47n/video_47n',48:'48n/video_48n',49:'41s/video_41s',50:'42s/video_46',51:'43s/video_43s'}
def fn(n):
    t=T[n].replace('’',"'").replace(':',' -')
    for a,b in [('à','a'),('è','e'),('é','e'),('ì','i'),('ò','o'),('ù','u')]: t=t.replace(a,b)
    return '%02d - %s'%(n,t)
OUT='/home/claude/work/final51/'
for n in range(int(sys.argv[1]),int(sys.argv[2])+1):
    name=fn(n); dst=OUT+name+'.mp4'
    if os.path.exists(dst) and os.path.getsize(dst)>1e6: continue
    if n in (1,5):
        old=glob.glob('/home/claude/work/final_titled/%02d - *.mp4'%n)[0]; shutil.copy(old,dst)
        for v in glob.glob('/home/claude/work/final_titled/sottotitoli/%02d*'%n):
            shutil.copy(v,OUT+'sottotitoli/'+os.path.basename(v).replace(os.path.basename(v)[:2],'%02d'%n,1))
        continue
    src=V+M[n]+'.mp4'
    mus='/home/claude/work/vid/audio/music%s.mp3'%('A' if n%2 else 'B')
    subprocess.run(['python3','/home/claude/work/titlecard/addcard2.py',str(n),src,dst,mus],check=True)
    base=V+M[n]
    for suf,o in [('.vtt','.vtt'),('.chapters.vtt','.chapters.vtt')]:
        if os.path.exists(base+suf): shutil.copy(base+suf,OUT+'sottotitoli/'+name+o)
    print(n,'ok',flush=True)
