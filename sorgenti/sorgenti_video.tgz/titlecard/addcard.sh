#!/bin/bash
# addcard.sh N src.mp4 dst.mp4 musicfile
N=$1; SRC=$2; DST=$3; MUS=$4
python3 /home/claude/work/titlecard/cards.py $N /tmp/card_$N.png
ffmpeg -y -loglevel error -loop 1 -framerate 25 -t 10 -i /tmp/card_$N.png -ss 0 -t 10 -i $MUS \
 -vf "fade=t=in:st=0:d=0.6,fade=t=out:st=9.4:d=0.6,format=yuv420p" \
 -af "aformat=sample_rates=44100:channel_layouts=mono,afade=t=in:st=0:d=0.6,afade=t=out:st=9.2:d=0.8,volume=0.9" \
 -c:v libx264 -preset veryfast -crf 20 -r 25 -c:a aac -ar 44100 -ac 1 -b:a 128k -shortest /tmp/card_$N.mp4
ffmpeg -y -loglevel error -i /tmp/card_$N.mp4 -i "$SRC" -filter_complex "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]" -map "[v]" -map "[a]" -c:v libx264 -preset veryfast -crf 20 -r 25 -pix_fmt yuv420p -c:a aac -ar 44100 -ac 1 -b:a 128k -movflags +faststart "$DST"
