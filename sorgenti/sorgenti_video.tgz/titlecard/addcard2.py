import sys, subprocess, re, os, tempfile
sys.path.insert(0,'/home/claude/work/titlecard')
from cards import card
n=int(sys.argv[1]); src=sys.argv[2]; dst=sys.argv[3]; mus=sys.argv[4]
tmp=tempfile.mkdtemp(prefix='tc')
png=f'{tmp}/c.png'; card(n,png)
cardmp4=f'{tmp}/card.mp4'
subprocess.run(['ffmpeg','-y','-loglevel','error','-loop','1','-framerate','25','-t','10','-i',png,'-t','10','-i',mus,
 '-vf','fade=t=in:st=0:d=0.6,fade=t=out:st=9.4:d=0.6,format=yuv420p',
 '-af','aformat=sample_rates=44100:channel_layouts=mono,afade=t=in:st=0:d=0.6,afade=t=out:st=9.2:d=0.8',
 '-c:v','libx264','-preset','veryfast','-crf','20','-profile:v','high','-level','4.0','-r','25','-video_track_timescale','12800',
 '-c:a','aac','-ar','44100','-ac','1','-b:a','160k','-shortest',cardmp4],check=True)
# chapters source
meta=subprocess.run(['ffmpeg','-loglevel','error','-i',src,'-f','ffmetadata','-'],capture_output=True,text=True).stdout
out=[';FFMETADATA1']
out+= ['[CHAPTER]','TIMEBASE=1/1000','START=0','END=10000','title=Titolo']
# parse chapters
for m in re.finditer(r'\[CHAPTER\]\s*TIMEBASE=1/(\d+)\s*START=(\d+)\s*END=(\d+)\s*title=(.*)',meta):
    tb=int(m.group(1)); s=int(int(m.group(2))*1000/tb)+10000; e=int(int(m.group(3))*1000/tb)+10000
    out+=['[CHAPTER]','TIMEBASE=1/1000',f'START={s}',f'END={e}',f'title={m.group(4)}']
open(f'{tmp}/meta.txt','w').write('\n'.join(out)+'\n')
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',cardmp4,'-i',src,'-i',f'{tmp}/meta.txt','-filter_complex','[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]','-map','[v]','-map','[a]','-map_metadata','2','-map_chapters','2','-c:v','libx264','-preset','veryfast','-crf','21','-r','25','-pix_fmt','yuv420p','-c:a','aac','-ar','44100','-ac','1','-b:a','160k','-movflags','+faststart',dst],check=True)
