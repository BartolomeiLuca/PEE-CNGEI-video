import sys, subprocess, os, re
from PIL import Image, ImageDraw, ImageFont
T={1:"Da dove si parte: panoramica dell’app",2:"La Dashboard",3:"Account, accesso e password",4:"Creare il primo progetto",5:"Salvataggio, archivio degli anni e copie di sicurezza",6:"Telefono, tablet, testo formattato e guida",7:"Il ciclo: cos’è, a cosa serve, come si crea",8:"La mia unità e il mio contesto",9:"Il mio staff",10:"Come osservo: KOS 2.0 e griglia osservativa",11:"Crea le tue attività osservative",12:"Scheda di osservazione dei percorsi e griglia",13:"Osservazione individuale e osservazione condivisa",14:"Confronto e sintesi",15:"Lettura del gruppo e Priorità",16:"Le tre Branche a confronto",17:"Obiettivi e indicatori",18:"Percorso: strumenti del metodo e tempi",19:"Percorso: attività, spunti e sette caratteristiche",20:"Ordinare le attività e Visione d’insieme",21:"Progettazione condivisa con lo staff",22:"Percorso Formativo: staff e Capo Gruppo",23:"Il mio anno e i cicli",24:"Calendario e attività",25:"Elenco dell’anno",26:"Chi, quando, referenti",27:"Logistica e viaggio",28:"Pasti, materiali e spesa",29:"Cassa, costi e quota",30:"Durante, sicurezza e piano B",31:"Costruire la giornata",32:"Foglio del giorno, circolare e stampe",33:"Uscite ed eventi: creare e organizzare",34:"L’anno di solito",35:"Verifica delle attività",36:"Valutazione finale",37:"Numeri dell’anno",38:"Spese mese per mese",39:"Verifica dell’anno",40:"Condividi con lo staff",41:"Lavorare in due",42:"Controllo e invio",43:"Cerca e archivio nazionale",44:"Progetto Personale: dalla Sezione 1 alla 3",45:"Progetto Personale: verifica e valutazione",46:"Progetto Personale: gli invii",47:"La revisione: dal lato di chi compila",48:"La revisione: dal lato di chi rivede",49:"Osservazione degli adulti: il mio staff",50:"Eventi per gli adulti",51:"Capo Gruppo: Capi Unità e Check degli adulti"}
def grp(n):
    for a,b,g in [(1,7,"Per iniziare"),(8,9,"Capire"),(10,16,"Osservare"),(17,23,"Progettare"),(24,34,"Calendario e realizzazione"),(35,39,"Misurare"),(40,43,"Condividere"),(44,46,"Progetto Personale"),(47,48,"La revisione (solo PP)"),(49,51,"Staff e Capo Gruppo")]:
        if a<=n<=b: return g
def card(n,path):
    W,H=1920,1080
    im=Image.new('RGB',(W,H),(31,92,64)); d=ImageDraw.Draw(im)
    for y in range(H):  # gradiente leggero
        c=int(8*y/H); d.line([(0,y),(W,y)],fill=(31-c,92-c*2,64-c))
    d.rectangle([0,H-14,W,H],fill=(232,168,0))
    logo=Image.open('/home/claude/work/titlecard/logo_round.png').convert('RGBA').resize((130,130),Image.LANCZOS)
    im.paste(logo,(120,112),logo)
    F=lambda s,b=True: ImageFont.truetype('/usr/share/fonts/truetype/google-fonts/Poppins-%s.ttf'%('Bold' if b else 'Regular'),s)
    d.text((270,125),"PEE CNGEI",font=F(52),fill='white'); d.text((270,190),"Video tutorial",font=F(30,False),fill=(210,235,220))
    d.text((120,380),grp(n).upper(),font=F(34),fill=(232,168,0))
    d.text((120,440),"%d"%n,font=F(150),fill=(255,255,255))
    # titolo a capo
    t=T[n]; f=F(72); words=t.split(); lines=[]; cur=''
    for w in words:
        if d.textlength((cur+' '+w).strip(),font=f)>1500 and cur: lines.append(cur); cur=w
        else: cur=(cur+' '+w).strip()
    lines.append(cur)
    y=640
    for l in lines: d.text((120,y),l,font=f,fill='white'); y+=92
    im.save(path)
if __name__=='__main__':
    card(int(sys.argv[1]),sys.argv[2])
