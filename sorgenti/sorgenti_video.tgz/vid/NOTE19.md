# Video 19 (audio/19s) creation ids
b01 XmJuMlMBfo, b02 mEN5ByshJQ, b03 O6hGSIUynm, b04 0eLtzL9TfW, b05 mEN5B3JhJQ, b06 jUp4KoRLD0, b07 aF31InZfSh, b08 u5ALvVHQLD, b09 JNmAgk8Oq4, b10 ovyFpcJ829, b11 s7dN1bRl8e, b12 gOBix1hSXO, b13 O6hGSSMynm, b14 lJX6rjGgv9, b15 Eb2jhCquuO
b05 nuovo: nV1obhpYQD (testo corretto su Questo ciclo/Tutto l'anno)
