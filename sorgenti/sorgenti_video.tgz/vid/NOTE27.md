# Video 27 - stato (4 nov)
Audio in audio/27/b01..b09.mp3 (voce 459). Docs reali in docs27/ e PNG 200dpi in docs27png/ (giorno-1, ttg-1, ttx-1..3, circw-1/2, circp-1/2).
Tempi parola (sec nel file) chiave:
b02: Esporta 1.44 | elenco 5.2 | TuttoCampoWord 7.08 | QuestaGiornata 9.12 | TTgiornata 10.32 | TTcampo 12.16 (Word 13.84 Excel 14.48) | Menu 15.36 | Materiali 17.36 | Quota 18.4 | Circolare 19.68 (PDF 21.6) | TuttoDiTutto 22.67 | Stampa 24.56 | Li vediamo 26.08
b03: due pulsanti 2.48 | Excel 3.64 | Foglio 4.48 | Scegliamo 6.72 | scarica doc 8.16 | titolo 9.68 | TT colori 11.72 | scheda 14.08 | percorsi 15.84 | pasti 20.52 | personalizzato 22.36 | stampare 25.08
b04: scegli TTgiornata 1.76 | griglia 4.16 | campo 7.04 | Excel 9.96 | righe mezz'ora 13.68 | comodo 17.08
b05: circolare 0 | Ritrovo 2.24 | Scrivi luogo 7.6 | ora ritrovo 10.32 | rientro 12.88 | apri Circolare 15.4
b06: referente 0 | apertura 2.64 | Proponi 6.96 (cit 7.76, frase 9.44) | tua 11.68 | Scriviamo 15.2
b07: riepilogo 0 | Cosa portano 8.16 | Scegli voce 9.84 (Uniforme 12.16) | Proponi lista 14.24 | Ogni riga 15.84 | Pattuglia 17.6 (Bussola 19.72 Cartina 20.48) | Da lasciare 21.28 (Cellulare 23.36) | Quota 25.88
b08: Prepara msg 1.64 | telefono 6.32 | scarica 9.92 | Word 11.28 | Ecco doc 13.92 | PDF 21.04 | stesso 25.6
b09: Stampa 2.72 | Tutto di tutto 8.32 | Ricap 17.84 | prossimo 24.28 | Grazie 27.48
Musica B. circ27.mjs = CIT/FRASE/TEL.
