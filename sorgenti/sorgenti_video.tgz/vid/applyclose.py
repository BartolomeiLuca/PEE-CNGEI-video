import json,os,subprocess,sys,shutil,re
from fixclose import plan,dur
G='audio/closing_grazie.mp3'
def run(*a): subprocess.run(['ffmpeg','-v','error','-y']+list(a),check=True)
def apply(n,last,textfile=None):
    tf=textfile or f'texts{n[:2]}.json'; T=json.load(open(tf)); a=f'audio/{n}/{last}.mp3'
    orig=f'audio/{n}/orig_{last}.mp3'
    if not os.path.exists(orig): shutil.copy(a,orig)
    p=plan(orig,T[last])
    if not p: print(n,'niente da fare'); return
    c0=p['cut0']; keep_end=c0[0]+0.15
    run('-i',orig,'-t',str(keep_end),'-ar','44100','-ac','1','/tmp/c_a.wav')
    parts=['/tmp/c_a.wav']
    run('-f','lavfi','-t','0.45','-i','anullsrc=r=44100:cl=mono','/tmp/c_gap.wav'); parts.append('/tmp/c_gap.wav')
    if p['hasG']:
        c1=p['cut1']; run('-ss',str(c1[1]-0.02),'-i',orig,'-ar','44100','-ac','1','/tmp/c_b.wav'); parts.append('/tmp/c_b.wav')
    else:
        run('-i',G,'-ar','44100','-ac','1','/tmp/c_b.wav'); parts.append('/tmp/c_b.wav')
    open('/tmp/c_list.txt','w').write(''.join(f"file '{x}'\n" for x in parts))
    run('-f','concat','-safe','0','-i','/tmp/c_list.txt','-c:a','libmp3lame','-q:a','2',a)
    S=p['S']; keep=[s for i,s in enumerate(S) if i<p['i0']]; 
    tail=[s for s in S[p['i0']+1:] if re.match(r'Grazie',s)] or ['Grazie, e a presto.']
    T[last]=' '.join(keep+tail); json.dump(T,open(tf,'w'),ensure_ascii=False,indent=1)
    print(n,last,'ok',round(dur(orig),1),'->',round(dur(a),1))
if __name__=='__main__':
    for x in sys.argv[1:]:
        n,last=x.split(':'); apply(n,last)
