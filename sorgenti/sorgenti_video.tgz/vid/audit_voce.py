import json,subprocess,sys,os,numpy as np
LEAD=0.12; SR=16000
cache={}
def load(f):
    if f in cache: return cache[f]
    r=subprocess.run(['ffmpeg','-v','error','-i',f,'-ac','1','-ar',str(SR),'-f','f32le','-'],capture_output=True)
    a=np.frombuffer(r.stdout,dtype=np.float32); cache[f]=a; return a
def rms(a,t,w=0.03):
    i=int(max(0,(t-w/2))*SR); j=int((t+w/2)*SR); x=a[i:j]
    return float(np.sqrt(np.mean(x**2))) if len(x) else 0.0
def ref(a):
    n=int(0.05*SR); k=len(a)//n
    if k<2: return 1e-6
    r=np.sqrt(np.mean(a[:k*n].reshape(k,n)**2,axis=1)); return float(np.percentile(r,85))+1e-9
def audit(d,n):
    tl=json.load(open(f'out/{d}/timeline.json')); log=tl['log']
    total=log[-1]['t']/1000+log[-1]['dur']+2.0
    ev=[]; issues=[]
    for b in log:
        f=f'audio/{n}/{b["id"]}.mp3'
        if not os.path.exists(f): issues.append((b['id'],'manca audio'));continue
        a=load(f); dur=len(a)/SR; R=ref(a)
        segs=b.get('segs')
        if not segs:
            ev.append((b['t']/1000+LEAD, b['t']/1000+LEAD+dur, b['id'],0)); continue
        for k,sg in enumerate(segs):
            st=max(0,sg['s']-0.03); last=(k==len(segs)-1)
            en=dur if last else sg['s']+sg['len']-0.03
            s0=sg['t']/1000+LEAD
            ev.append((s0, s0+(en-st), b['id'],k))
            if not last:
                e=rms(a,en,0.04); lv=e/R
                nxt=segs[k+1]; gap=(nxt['t']/1000+LEAD)-(s0+(en-st)); tv=s0+(en-st)
                if lv>0.35 and (gap>0.15 or gap<-0.05): issues.append((b['id'],f'VOCE SPEZZATA a {tv:.1f}s nel video: parola tagliata con {"pausa" if gap>0 else "sovrapposizione"} di {abs(gap):.2f}s (seg {k}→{k+1})'))
                elif gap>0.6: issues.append((b['id'],f'pausa lunga {gap:.1f}s a {tv:.1f}s nel video (seg {k}→{k+1}, taglio su pausa)'))
    ev.sort()
    for i in range(len(ev)-1):
        if ev[i][2]!=ev[i+1][2]:
            ov=ev[i][1]-ev[i+1][0]
            if ov>0.25: issues.append((ev[i][2],f'la voce di {ev[i][2]} finisce {ov:.1f}s dopo l\'inizio di {ev[i+1][2]}'))
    if ev and ev[-1][1]>total-0.3: issues.append(('fine',f'voce finale oltre la durata ({ev[-1][1]:.1f}>{total:.1f})'))
    return total,issues
if __name__=='__main__':
    maps=[('01s','01s'),('02s','02s'),('03s','03s'),('04s','04s'),('05s','05s'),('06s','06s'),('07s','07s'),('08s','08s'),('09s','09s'),('11s','11s'),('12s','12s'),('13s','13s'),('14s','14s'),('15s','15s'),('16s','16s'),('19s','19s'),('20s','20s'),('21s','21s'),('22s','22s'),('23s','23s'),('24s','24s'),('25s','25s'),('26','26'),('27','27'),('28s','28s'),('29s','29s'),('30s','30s'),('31s','31s'),('32s','32s'),('33s','33s'),('34s','34s'),('35s','35s'),('36s','36s'),('37s','37s'),('38s','38s'),('39s','39s'),('40s','40s'),('41s','41s'),('42s','42s'),('43s','43s'),('44s','44s'),('45s','45s'),('46s','46s'),('Ds','Ds')]
    out={}
    for d,n in maps:
        try: tot,iss=audit(d,n)
        except Exception as e: print(d,'ERRORE',e); continue
        out[d]=iss; print(f'== {d} ({tot:.0f}s): {len(iss)} segnalazioni')
        for b,m in iss: print('   ',b,m)
    json.dump(out,open('audit_voce.json','w'),ensure_ascii=False,indent=1)
