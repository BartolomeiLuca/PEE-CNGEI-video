// Dati della circolare del video 27 (gli stessi digitati nel video e usati per i documenti)
export const CIT = '«Un’avventura è soltanto un disagio considerato nel modo giusto.» (G. K. Chesterton)';
export const FRASE = 'Esploratori ed Esploratrici, zaino in spalla! Sabato comincia la Riunione di apertura: servirà tutta la forza delle vostre Pattuglie.';
export const TEL = '333 1234567';
