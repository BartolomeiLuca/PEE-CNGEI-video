# PEE CNGEI — Controllo automatico della voce nei video (10 novembre 2026)

Metodo: per ogni video segmentato ho ricostruito la traccia voce dai file originali e dai tempi della registrazione, e ho cercato (1) parole tagliate a metà con pausa o sovrapposizione, (2) pause lunghe dentro una frase, (3) sovrapposizioni tra beat, (4) voce che finisce oltre la durata, (5) file video più corto del previsto. Tempi = secondi nel video finito.

**Esito:** video 1–18 e 29, 31–46, Dashboard: nessuna interruzione (voce in un solo pezzo per beat). Problemi nei video **19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 30**. **Video 23: il file è più corto di 40 s** rispetto al previsto (405 s invece di 445): la registrazione si ferma prima e manca la parte finale.

Causa: nei video a segmenti il taglio tra una frase e l'altra è calcolato con stime delle parole; quando cade dentro una parola e l'azione sullo schermo arriva in ritardo, la voce si ferma e riprende. Rimedio senza crediti: nel rimontaggio spostare il taglio sul silenzio più vicino. Non si cambia la voce.

Non rilevabile con questo controllo: tono (video 32), pronunce (PEE, CNGEI, Lupette, «pipette» nel 14), inquadrature sbagliate. Sono nelle segnalazioni manuali di Luca.

## Video 19s — 2 segnalazioni
- b02 pausa lunga 0.6s a 26.9s nel video (seg 1→2, taglio su pausa)
- b10 VOCE SPEZZATA a 262.5s nel video: parola tagliata con pausa di 0.97s (seg 4→5)

## Video 20s — 3 segnalazioni
- b10 VOCE SPEZZATA a 116.6s nel video: parola tagliata con pausa di 0.17s (seg 1→2)
- b11 VOCE SPEZZATA a 129.2s nel video: parola tagliata con pausa di 0.35s (seg 0→1)
- b14 pausa lunga 0.6s a 166.2s nel video (seg 2→3, taglio su pausa)

## Video 21s — 4 segnalazioni
- b02 pausa lunga 0.8s a 20.0s nel video (seg 1→2, taglio su pausa)
- b02 VOCE SPEZZATA a 25.0s nel video: parola tagliata con pausa di 0.24s (seg 3→4)
- b08 pausa lunga 0.7s a 87.4s nel video (seg 0→1, taglio su pausa)
- b14 VOCE SPEZZATA a 149.4s nel video: parola tagliata con pausa di 1.81s (seg 2→3)

## Video 22s — 6 segnalazioni
- b02 VOCE SPEZZATA a 31.7s nel video: parola tagliata con pausa di 0.65s (seg 1→2)
- b02 VOCE SPEZZATA a 34.3s nel video: parola tagliata con pausa di 0.44s (seg 2→3)
- b07 VOCE SPEZZATA a 108.9s nel video: parola tagliata con pausa di 0.17s (seg 0→1)
- b12 VOCE SPEZZATA a 183.9s nel video: parola tagliata con pausa di 0.31s (seg 2→3)
- b18 pausa lunga 0.8s a 288.6s nel video (seg 0→1, taglio su pausa)
- b20 pausa lunga 1.6s a 339.7s nel video (seg 2→3, taglio su pausa)

## Video 23s — 7 segnalazioni
- b02 pausa lunga 0.8s a 31.0s nel video (seg 2→3, taglio su pausa)
- b05 VOCE SPEZZATA a 97.2s nel video: parola tagliata con pausa di 0.24s (seg 2→3)
- b11 VOCE SPEZZATA a 204.1s nel video: parola tagliata con pausa di 0.44s (seg 0→1)
- b17 VOCE SPEZZATA a 321.3s nel video: parola tagliata con pausa di 0.35s (seg 1→2)
- b19 VOCE SPEZZATA a 350.3s nel video: parola tagliata con pausa di 0.21s (seg 0→1)
- b20 VOCE SPEZZATA a 373.6s nel video: parola tagliata con pausa di 1.04s (seg 2→3)
- b20 pausa lunga 1.4s a 384.4s nel video (seg 4→5, taglio su pausa)

## Video 24s — 5 segnalazioni
- b02 VOCE SPEZZATA a 46.4s nel video: parola tagliata con pausa di 0.99s (seg 6→7)
- b03 VOCE SPEZZATA a 76.9s nel video: parola tagliata con pausa di 1.82s (seg 7→8)
- b06 VOCE SPEZZATA a 121.5s nel video: parola tagliata con pausa di 0.36s (seg 1→2)
- b08 VOCE SPEZZATA a 167.1s nel video: parola tagliata con pausa di 0.35s (seg 0→1)
- b08 VOCE SPEZZATA a 177.3s nel video: parola tagliata con pausa di 0.22s (seg 2→3)

## Video 25s — 12 segnalazioni
- b02 VOCE SPEZZATA a 24.9s nel video: parola tagliata con pausa di 0.78s (seg 0→1)
- b02 VOCE SPEZZATA a 30.4s nel video: parola tagliata con pausa di 0.29s (seg 1→2)
- b02 VOCE SPEZZATA a 43.1s nel video: parola tagliata con pausa di 0.32s (seg 3→4)
- b03 VOCE SPEZZATA a 92.8s nel video: parola tagliata con pausa di 0.39s (seg 7→8)
- b04 pausa lunga 0.8s a 99.1s nel video (seg 0→1, taglio su pausa)
- b04 pausa lunga 0.8s a 103.3s nel video (seg 1→2, taglio su pausa)
- b04 VOCE SPEZZATA a 106.7s nel video: parola tagliata con pausa di 1.18s (seg 2→3)
- b04 VOCE SPEZZATA a 119.0s nel video: parola tagliata con pausa di 0.68s (seg 6→7)
- b05 VOCE SPEZZATA a 143.9s nel video: parola tagliata con pausa di 0.67s (seg 2→3)
- b06 VOCE SPEZZATA a 174.5s nel video: parola tagliata con pausa di 1.52s (seg 2→3)
- b10 pausa lunga 1.3s a 272.3s nel video (seg 0→1, taglio su pausa)
- b10 VOCE SPEZZATA a 299.3s nel video: parola tagliata con pausa di 1.72s (seg 7→8)

## Video 26 — 13 segnalazioni
- b02 pausa lunga 2.3s a 32.9s nel video (seg 0→1, taglio su pausa)
- b03 pausa lunga 1.1s a 101.5s nel video (seg 3→4, taglio su pausa)
- b04 pausa lunga 0.9s a 116.9s nel video (seg 0→1, taglio su pausa)
- b04 pausa lunga 2.0s a 137.7s nel video (seg 4→5, taglio su pausa)
- b06 pausa lunga 1.8s a 170.0s nel video (seg 0→1, taglio su pausa)
- b06 VOCE SPEZZATA a 197.6s nel video: parola tagliata con pausa di 0.63s (seg 7→8)
- b07 pausa lunga 1.2s a 219.7s nel video (seg 1→2, taglio su pausa)
- b07 pausa lunga 0.9s a 231.5s nel video (seg 4→5, taglio su pausa)
- b08 pausa lunga 1.4s a 247.2s nel video (seg 0→1, taglio su pausa)
- b09 pausa lunga 0.8s a 284.5s nel video (seg 1→2, taglio su pausa)
- b09 VOCE SPEZZATA a 299.9s nel video: parola tagliata con pausa di 0.98s (seg 5→6)
- b10 pausa lunga 1.7s a 343.7s nel video (seg 4→5, taglio su pausa)
- b11 VOCE SPEZZATA a 360.5s nel video: parola tagliata con pausa di 0.25s (seg 0→1)

## Video 27 — 4 segnalazioni
- b04 VOCE SPEZZATA a 94.0s nel video: parola tagliata con pausa di 0.73s (seg 4→5)
- b05 VOCE SPEZZATA a 115.4s nel video: parola tagliata con pausa di 0.92s (seg 2→3)
- b07 pausa lunga 1.9s a 170.5s nel video (seg 5→6, taglio su pausa)
- b08 pausa lunga 1.2s a 207.9s nel video (seg 8→9, taglio su pausa)

## Video 28s — 12 segnalazioni
- b02 VOCE SPEZZATA a 21.4s nel video: parola tagliata con pausa di 0.40s (seg 0→1)
- b02 VOCE SPEZZATA a 24.6s nel video: parola tagliata con pausa di 0.48s (seg 1→2)
- b02 VOCE SPEZZATA a 31.6s nel video: parola tagliata con pausa di 1.54s (seg 3→4)
- b02 pausa lunga 0.7s a 44.7s nel video (seg 6→7, taglio su pausa)
- b06 pausa lunga 1.4s a 96.8s nel video (seg 2→3, taglio su pausa)
- b06 pausa lunga 0.6s a 101.3s nel video (seg 3→4, taglio su pausa)
- b07 pausa lunga 0.9s a 118.1s nel video (seg 0→1, taglio su pausa)
- b07 VOCE SPEZZATA a 131.9s nel video: parola tagliata con pausa di 1.09s (seg 5→6)
- b08 VOCE SPEZZATA a 150.7s nel video: parola tagliata con pausa di 0.53s (seg 1→2)
- b09 pausa lunga 1.4s a 165.4s nel video (seg 1→2, taglio su pausa)
- b09 pausa lunga 1.4s a 177.7s nel video (seg 4→5, taglio su pausa)
- b10 VOCE SPEZZATA a 185.6s nel video: parola tagliata con pausa di 0.43s (seg 0→1)

## Video 30s — 3 segnalazioni
- b05 pausa lunga 0.9s a 65.4s nel video (seg 1→2, taglio su pausa)
- b05 pausa lunga 1.6s a 70.7s nel video (seg 2→3, taglio su pausa)
- b07 pausa lunga 1.8s a 94.7s nel video (seg 1→2, taglio su pausa)
