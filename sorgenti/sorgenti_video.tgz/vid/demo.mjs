// Unità di esempio per i video: Reparto «Aquila», Branca E, anno 2026-27
export function demoData(db, email='anna@x.it'){
  const u = db.addUser(email, 'password123', 'Anna Verdi');
  db.t.pee_profili.push({user_id:u.id, nome:'Anna Verdi', ruolo:'cu', branca:'E', sezione:'Pesaro', gruppo:'1', area_rcdf:'altoadriatico', dashboard:{}});
  const att = (t, d, aid, lancio) => ({aid, testo:t, link:'', lancio:lancio||('Presentiamo «'+t+'» con una breve storia.'), sviluppo:'', conclusione:'', vBene:'', vMigl:'', vAgg:'', ax:d?{data:d}:{}});
  const us = (id, t, d, mod, extra) => Object.assign({id, cr:+id.replace(/\D/g,'')+1, testo:t, modello:mod||'sede', ax:{data:d, durata:mod==='bivacco'?'piu':'giorno', pres:{ad:[]}, luogo:{}}, prog:{}, hid:{}, own:{}}, extra||{});
  const pri = (a, p, d, al) => ({ambito:a, necessita:'', percorso:p, obiettivi:[0], idr:[0], tempistica:'', tDal:d, tAl:al});
  const uscite = {
    r1: us('r1', 'Riunione di apertura', '2026-11-07', 'sede', {prog:{b1:{k:'att', g:1, ord:1, dur:45, pid:'P1', aid:'a1', f:['lsc','mat','sic','ben','pb']}}}),
    r2: us('r2', 'Riunione di pattuglia', '2026-11-21', 'sede'),
    u1: us('u1', 'Uscita al fiume', '2026-11-29', 'giorno'),
    b1: us('b1', 'Bivacco di gennaio', '2027-01-16', 'bivacco'),
  };
  uscite.b1.ax.dataFine = '2027-01-17';
  const data = {v:1, MODE:'giovani', FASCIA:'E', UNIT_NAME:'Reparto Aquila', pris:{P1:true, C1:true},
    scheda:{tipoProgetto:'AN', annoScout:'2026-27', ciclo:{nome:'I trimestre', dal:'2026-10', al:'2026-12'}, uscite,
      priorita:[pri('P','P1','2026-10','2026-12'), pri('C','C1','2026-10','2026-12')],
      pp:{sezione:'Pesaro', gruppo:'1', staffTab:[{ruolo:'CU', nome:'Anna Verdi', mail:'anna@x.it'}]},
      percorsiExtra:[
        {prioritaIdx:0, percorsoId:'P1', ambito:'P', strumSel:{'Gioco':''}, attivita:[att('Gioco di presentazione','2026-11-07','a1'), att('Orientiamoci con la mappa','','a2'), att('Costruiamo il nostro angolo di pattuglia','','a3'), att('Cucina a fuoco','','a4')]},
        {prioritaIdx:1, percorsoId:'C1', ambito:'C', strumSel:{'Gioco':''}, attivita:[att('Il consiglio di pattuglia','','c1'), att('Regole del nostro Reparto','','c2'), att('Gioco cooperativo','','c3')]}
      ]}};
  const a = {id:'p1', user_id:u.id, anno:2026, titolo:'Programmazione Annuale 2026-27 · Reparto Aquila', meta:{mode:'giovani', fascia:'E', tipo:'AN', nome:'Reparto Aquila'}, data, created_at:'2026-10-12T09:00:00Z', updated_at:'2026-11-02T09:00:00Z'};
  if(process.env.DEMO13){ data.scheda.priorita[0].tAl='2027-03'; data.scheda.priorita[1].tAl='2027-03'; data.scheda.percorsiExtra.forEach(p => { p.strumSel = {}; }); data.scheda.ciclo = {nome:'I semestre', dal:'2026-10', al:'2027-03'}; data.pris.S1 = true; data.scheda.priorita.push(pri('S','S1','2026-10','2026-12')); }
  db.t.pee_archivi.push(a);
  if(process.env.DEMO3){ for (const [id,f,nm] of [['p2','L','Branco Seeonee'],['p3','R','Compagnia Orion']]) { const c = JSON.parse(JSON.stringify(a)); c.id=id; c.titolo='Programmazione Annuale 2026-27 · '+nm; c.meta.fascia=f; c.meta.nome=nm; c.data.FASCIA=f; c.data.UNIT_NAME=nm; c.updated_at='2026-11-01T09:00:00Z'; db.t.pee_archivi.push(c); } }
  return {u, a};
}
