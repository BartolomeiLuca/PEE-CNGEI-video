import { demoData } from './demo.mjs';
export function demo01(db){
  const {u, a} = demoData(db);
  const g = db.addUser('giulia@x.it', 'password123', 'Giulia Rossi');
  db.t.pee_profili.push({user_id:g.id, nome:'Giulia Rossi', ruolo:'cu', branca:'E', sezione:'Pesaro', gruppo:'1', area_rcdf:'altoadriatico', dashboard:{}});
  const d2 = JSON.parse(JSON.stringify(a.data)); d2.UNIT_NAME = 'Reparto Delfini';
  const p2 = {id:'p2', user_id:g.id, anno:2026, titolo:'Programmazione Annuale 2026-27 · Reparto Delfini', meta:{mode:'giovani', fascia:'E', tipo:'AN', nome:'Reparto Delfini'}, data:d2, created_at:'2026-10-14T09:00:00Z', updated_at:'2026-11-03T09:00:00Z'};
  db.t.pee_archivi.push(p2);
  db.t.pee_membri.push({id:'m2', archivio_id:'p2', owner_id:g.id, email:'anna@x.it', ruolo:'collaboratore', visto_il:null, email_prima:null, created_at:'2026-11-03T09:00:00Z'});
  return {u, a};
}
