import { demoData } from './demo.mjs';
export function demo04(db){
  const {u, a} = demoData(db);
  const d0 = JSON.parse(JSON.stringify(a.data)); d0.UNIT_NAME = 'Reparto Aquila';
  db.t.pee_archivi.push({id:'p3', user_id:u.id, anno:2025, titolo:'Programmazione Annuale 2025-26 · Reparto Aquila', meta:{mode:'giovani', fascia:'E', tipo:'AN', nome:'Reparto Aquila'}, data:d0, created_at:'2025-10-08T09:00:00Z', updated_at:'2026-06-20T09:00:00Z'});
  return {u, a};
}
