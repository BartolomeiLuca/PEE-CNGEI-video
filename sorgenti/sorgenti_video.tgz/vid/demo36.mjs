import { demoData } from './demo.mjs';
export function demo36(db){
  const {u, a} = demoData(db);
  const m = db.addUser('marco@x.it', 'password123', 'Marco Neri');
  db.t.pee_profili.push({user_id:m.id, nome:'Marco Neri', ruolo:'cu', branca:'E', sezione:'Pesaro', gruppo:'1', area_rcdf:'altoadriatico', dashboard:{}});
  const s = a.data.scheda; s.pp.prog = 'cond';
  s.pp.staffTab = [{ruolo:'CU', nome:'Anna Verdi', mail:'anna@x.it'}, {ruolo:'VCU', nome:'Marco Neri', mail:'marco@x.it'}];
  s.percorsiExtra[0].attivita[0].aff = 'Marco Neri'; s.percorsiExtra[0].attivita[1].aff = 'Anna Verdi';
  db.t.pee_membri.push({id:'m1', archivio_id:'p1', owner_id:u.id, email:'marco@x.it', ruolo:'collaboratore', visto_il:null, email_prima:null, created_at:'2026-11-02T09:00:00Z'});
  return {u, m, a};
}
