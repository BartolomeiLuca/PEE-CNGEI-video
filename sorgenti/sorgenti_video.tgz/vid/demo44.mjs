import { demo36 } from './demo36.mjs';
export function demo44(db){
  const r = demo36(db); const s = r.a.data.scheda;
  const T = Date.parse('2026-11-02T10:00:00Z');
  s.mv = {on:true, by:{
    'marco@x.it':{nome:'Marco Neri', v:{P1:7, P2:3, P4:3}, note:{}, at:{P1:T, P2:T, P4:T+9000000}}},
    dec:{P4:{v:7, chi:'Anna Verdi', at:Date.parse('2026-11-02T10:30:00Z')}}};
  return r;
}
