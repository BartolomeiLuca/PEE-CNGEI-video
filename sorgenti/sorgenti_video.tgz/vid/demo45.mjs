import { demo36 } from './demo36.mjs';
export function demo45(db){
  const r = demo36(db); const s = r.a.data.scheda;
  const T = Date.parse('2026-11-02T10:00:00Z');
  s.mv = {on:true, by:{'anna@x.it':{nome:'Anna Verdi', v:{P1:7, P2:8, P3:5, P4:7, P5:5, C1:6, C2:4, S1:5}, note:{P2:'Con i più piccoli è sempre paziente'}, at:{P1:T, P2:T, P3:T, P4:T, P5:T, C1:T, C2:T, S1:T}}, 'marco@x.it':{nome:'Marco Neri', v:{P1:7, P2:3, P3:5, P4:3, P5:'n', C1:6, C2:4, S1:5}, note:{P2:'Nelle ultime due uscite non ha gestito la frustrazione'}, at:{P1:T, P2:T, P3:T, P4:T+7200000, P5:T, C1:T, C2:T, S1:T}}}, dec:{P4:{v:7, chi:'Anna Verdi', at:T+3600000}}, log:[]};
  return r;
}
