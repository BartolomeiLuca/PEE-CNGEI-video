import { demo45 } from './demo45.mjs';
export function demo46(db){
  const r = demo45(db); const s = r.a.data.scheda; const T = Date.parse('2026-11-02T11:00:00Z');
  s.mv.by['anna@x.it'] = {nome:'Anna Verdi', v:{P1:7, P2:8, P3:6, P4:8, P5:5, C1:6, C2:7, S1:5}, note:{P2:'Sabato, nel gioco a squadre, ha aiutato i più piccoli a calmarsi'}, at:{P1:T,P2:T,P3:T,P4:T+9000000,P5:T,C1:T,C2:T,S1:T}};
  s.mv.dec = {P4:{v:7, chi:'Anna Verdi', at:Date.parse('2026-11-02T10:30:00Z')}};
  return r;
}
