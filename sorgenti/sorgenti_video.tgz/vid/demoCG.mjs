import { demoData } from './demo.mjs';
// Progetto di Capo Gruppo: eventi per gli adulti (staff CG)
export function demoCG(db){
  const {u, a} = demoData(db, 'elena@x.it');
  u.nome = 'Elena Rossi';
  const pr = db.t.pee_profili.find(p => p.user_id === u.id); if(pr){ pr.nome = 'Elena Rossi'; pr.ruolo = 'cg'; }
  const base = a.data.scheda.uscite;
  const mk = (id, t, d, mod, extra) => { const x = JSON.parse(JSON.stringify(base.r2)); x.id = id; x.cr = +id.replace(/\D/g,'') + 10; x.testo = t; x.modello = mod; x.ax.data = d; x.ax.durata = mod === 'bivacco' ? 'piu' : 'giorno'; x.prog = {}; return Object.assign(x, extra || {}); };
  const us = { e1: mk('e1', 'Riunione dei Capi Unità', '2026-11-14', 'sede'), e2: mk('e2', 'Uscita formativa dei Capi', '2026-12-06', 'giorno'), e3: mk('e3', 'Bivacco dei Capi Gruppo', '2027-02-13', 'bivacco') };
  us.e3.ax.dataFine = '2027-02-14';
  a.data.MODE = 'staff'; a.data.STAFF_RUOLO = 'CG'; a.data.UNIT_NAME = 'Gruppo Pesaro 1';
  a.data.FASCIA = null; a.data.STAFF_TYPE = 'staff';
  a.data.scheda.uscite = us; a.data.scheda.priorita = []; a.data.scheda.percorsiExtra = []; a.data.pris = {};
  a.data.scheda.pp.staffTab = [{ruolo:'CG', nome:'Elena Rossi', mail:'elena@x.it'}];
  a.titolo = 'Programmazione formativa annuale 2026-27 · Gruppo Pesaro 1';
  a.meta = {mode:'staff', tipo:'AN', nome:'Gruppo Pesaro 1', ruolo:'CG'};
  // Capi Unità osservati (Fase 1)
  const names = ['Anna Verdi', 'Marco Neri', 'Paola Conti'];
  a.data.STAFF_MEMBERS = names;
  a.data.staffProfiles = {'Anna Verdi':{ruolo:'CU', eta:'34', formazione:'wb', link:{mail:'anna@x.it', nome:'Anna Verdi'}}, 'Marco Neri':{ruolo:'CU', eta:'29', formazione:'tdm', link:{mail:'marco@x.it', nome:'Marco Neri'}}, 'Paola Conti':{ruolo:'CU', eta:'41', formazione:'base', link:{mail:'paola@x.it', nome:'Paola Conti'}}};
  const ids = ['P1','P2','P3','P4','P5','P6','P7','C1','C2','C3','C4','C5','C6','C7','S1','S2','S3','S4','S5','S6'];
  const mk2 = f => { const o = {}; ids.forEach((id, i) => { o[id] = f(i); }); return o; };
  a.data.staffObs = {'Anna Verdi': mk2(i => [7,6,8,5,7,6,4,8,7,6,5,7,6,5,4,6,5,7,6,5][i]), 'Marco Neri': mk2(i => [5,4,6,3,5,4,3,6,5,4,3,5,4,3,2,4,3,5,4,3][i]), 'Paola Conti': mk2(i => [8,7,7,6,8,7,6,7,8,7,6,6,7,6,5,6,7,6,5,6][i])};
  a.data.CURRENT_MEMBER = 'Anna Verdi';
  return {u, a};
}
