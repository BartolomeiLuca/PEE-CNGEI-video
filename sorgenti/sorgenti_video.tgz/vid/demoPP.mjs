import { demoData } from './demo.mjs';
export function demoPP(db){
  const {u, a} = demoData(db);
  const pp = JSON.parse(JSON.stringify(a.data));
  pp.obs = {P1:3,P2:6,P3:5,P4:4,P5:7,P6:5,C1:2,C2:5}; pp.scheda.tipoProgetto = 'PP'; pp.scheda.pp = {nome:'Anna Verdi', sezione:'Pesaro', gruppo:'1'};
  const row = {id:'pp1', user_id:u.id, anno:2026, titolo:'Progetto Personale 2026-27 · Anna Verdi', meta:{mode:'giovani', fascia:'E', tipo:'PP', nome:'Reparto Aquila'}, data:pp, created_at:'2026-10-14T09:00:00Z', updated_at:'2026-11-03T09:00:00Z'};
  db.t.pee_archivi.push(row);
  return {u, a, row};
}
