#!/bin/bash
# uso: dl.sh <subdir>  (legge da stdin righe "bNN URL")
mkdir -p audio/$1; cd audio/$1
while read id url; do [ -z "$id" ] && continue; curl -sS -o $id.mp3 "$url" & done
wait
for f in b*.mp3; do echo $f $(ffprobe -v error -show_entries format=duration -of csv=p=0 $f); done | tr '\n' ' '
