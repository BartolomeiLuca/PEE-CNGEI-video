const m = await import(process.argv[2]);
for (const b of m.beats) console.log(b.id, '|', b.scene||'', '|', (b.say||'').length ? b.say : '(no say)', '\n');
