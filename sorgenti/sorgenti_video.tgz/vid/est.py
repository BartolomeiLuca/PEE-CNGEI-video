import sys,json,re,subprocess
# uso: est.py <subdir> <texts.json> bNN "parola1" "parola2" ...  -> stima inizio parola (s)
def dur(p): return float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',p],capture_output=True,text=True).stdout)
def words(t): return re.findall(r"\S+",t)
def est(sub,texts,b,keys):
    t=json.load(open(texts))[b]; w=words(t); d=dur(f'audio/{sub}/{b}.mp3')-0.5
    # peso: lunghezza + 1.5 per pausa dopo punteggiatura
    wt=[len(re.sub(r'\W','',x))+ (7 if x[-1] in '.:' else 3 if x[-1] in ',;' else 0)+1 for x in w]
    tot=sum(wt); acc=0; st=[]
    for x,y in zip(w,wt): st.append(min(acc/tot*d*1.06,d)); acc+=y
    for k in keys:
        for i,x in enumerate(w):
            if k.lower() in x.lower(): print(f'{b} "{k}" ~{st[i]:.2f}s'); break
        else: print('nf',k)
if __name__=='__main__': est(sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4:])
