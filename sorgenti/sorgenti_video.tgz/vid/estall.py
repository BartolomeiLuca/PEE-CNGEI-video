import sys,json,re
from est import dur,words
def run(sub,texts,b):
    t=json.load(open(texts))[b]; w=words(t); d=dur(f'audio/{sub}/{b}.mp3')-0.5
    wt=[len(re.sub(r'\W','',x))+(7 if x[-1] in '.:' else 3 if x[-1] in ',;' else 0)+1 for x in w]
    tot=sum(wt); acc=0; out=[]
    for x,y in zip(w,wt): out.append(f'{x}@{min(acc/tot*d*1.06,d):.1f}'); acc+=y
    print(b,' '.join(out))
for b in sys.argv[3:]: run(sys.argv[1],sys.argv[2],b)
