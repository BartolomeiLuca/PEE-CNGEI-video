import json,re,subprocess,sys,os,glob
def dur(p): return float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',p],capture_output=True,text=True).stdout)
def silences(p,db=-32,md=0.18):
    r=subprocess.run(['ffmpeg','-i',p,'-af',f'silencedetect=noise={db}dB:d={md}','-f','null','-'],capture_output=True,text=True).stderr
    s=[float(x) for x in re.findall(r'silence_start: ([\d.]+)',r)]; e=[float(x) for x in re.findall(r'silence_end: ([\d.]+)',r)]
    return list(zip(s,e[:len(s)]))
def sentences(t): return [x.strip() for x in re.split(r'(?<=[.!?])\s+',t) if x.strip()]
def wt(x): 
    w=re.findall(r'\S+',x); return sum(len(re.sub(r'\W','',a))+1+(7 if a[-1] in '.:' else 3 if a[-1] in ',;' else 0) for a in w)
def plan(audio,text,pat=r'prossimo video|prossimo passo'):
    S=sentences(text); D=dur(audio); sil=[x for x in silences(audio) if x[0]>0.3 and x[1]<D-0.2]
    W=[wt(s) for s in S]; tot=sum(W); acc=0; est=[]
    for w in W: acc+=w; est.append(acc/tot*(D-0.6))
    idx=[i for i,s in enumerate(S) if re.search(pat,s)]
    if not idx: return None
    i0=idx[0]; hasG=any(re.match(r'Grazie',s) for s in S[i0+1:])
    def snap(est_t):
        best=min(sil,key=lambda x:abs((x[0]+x[1])/2-est_t)) if sil else None
        return best,(abs((best[0]+best[1])/2-est_t) if best else 9)
    b0,e0=snap(est[i0-1])  # confine fine frase precedente
    res={'S':S,'i0':i0,'hasG':hasG,'D':D,'cut0':b0,'err0':e0}
    if hasG:
        ig=[i for i,s in enumerate(S) if re.match(r'Grazie',s)][0]
        b1,e1=snap(est[ig-1]); res.update(cut1=b1,err1=e1)
    return res
if __name__=='__main__':
    for n,last in [a.split(':') for a in sys.argv[1:]]:
        t=json.load(open(f'texts{n[:2]}.json'))[last]; a=f'audio/{n}/{last}.mp3'
        p=plan(a,t)
        if not p: print(n,'nessuna frase'); continue
        print(n,last,'D=%.1f'%p['D'],'hasG',p['hasG'],'cut0',tuple(round(x,2) for x in p['cut0']),'err0 %.2f'%p['err0'],('cut1',tuple(round(x,2) for x in p['cut1']),'err1 %.2f'%p['err1']) if p['hasG'] else '')
