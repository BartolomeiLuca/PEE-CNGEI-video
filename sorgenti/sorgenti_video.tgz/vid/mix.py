import json,subprocess,sys,os
d=sys.argv[1]; n=sys.argv[2]; music=sys.argv[3]; outname=sys.argv[4]
sys.path.insert(0,'.'); from tools import marker
tl=json.load(open(f'{d}/timeline.json')); Tm=marker(f'{d}/raw.webm'); log=tl['log']
aud=f'audio/{n}/'
from fixclose import silences,dur as adur
last=log[-1]
_la=aud+last['id']+'.mp3'; _ad=adur(_la) if os.path.exists(_la) else last['dur']
total=last['t']/1000+(min(last['dur'],_ad+0.4) if 'segs' not in last else last['dur'])+2.0
SEGS=[]
for b in log:
    if 'segs' in b:
        for sg in b['segs']: SEGS.append((b['id'],sg))
    else: SEGS.append((b['id'],None))
LEAD=0.12
SNAP={}
def snapb(bid,x):
    if bid not in SNAP: SNAP[bid]=[((a+b)/2,b-a) for a,b in silences(aud+bid+'.mp3',db=-32,md=0.05)]
    c=[m for m,l in SNAP[bid] if abs(m-x)<=0.38]
    return min(c,key=lambda m:abs(m-x)) if c else x

# musica in loop con dissolvenza
subprocess.run(['ffmpeg','-v','error','-y','-i',music,'-i',music,'-i',music,'-i',music,'-filter_complex','[0][1]acrossfade=d=6[a];[a][2]acrossfade=d=6[b];[b][3]acrossfade=d=6[c]','-map','[c]',f'{d}/musicloop.wav'],check=True)
ins=[]; fc=[]; labs=[]
bi=[x for x in log]
for i,(bid,sg) in enumerate(SEGS):
    f=aud+bid+'.mp3'; ins+=['-i',f]
    if sg is None:
        b=[x for x in log if x['id']==bid][0]; ms=int((b['t']/1000+LEAD)*1000)
        fc.append(f'[{i+1}:a]aresample=44100,adelay={ms}|{ms},apad[v{i}]')
    else:
        ms=int((sg['t']/1000+LEAD)*1000); st=max(0,snapb(bid,sg['s'])-0.02) if sg['s']>0.05 else 0; en=snapb(bid,sg['s']+sg['len'])-0.02
        isl=(sg is [s for (b2,s) in SEGS if b2==bid][-1])
        tr=f'atrim=start={st}' if isl else f'atrim=start={st}:end={en}'
        fc.append(f'[{i+1}:a]{tr},asetpts=PTS-STARTPTS,aresample=44100,afade=t=in:d=0.02,adelay={ms}|{ms},apad[v{i}]')
    labs.append(f'[v{i}]')
k=len(SEGS); ins+=['-i',f'{d}/musicloop.wav']
fc.append(''.join(labs)+f'amix=inputs={k}:normalize=0:duration=longest,volume=1.6,atrim=0:{total}[voice]')
fc.append('[voice]asplit=2[vo][sc]')
fc.append(f'[{k+1}:a]aresample=44100,volume=0.30,afade=t=in:d=3,atrim=0:{total},afade=t=out:st={total-3}:d=3[mus]')
fc.append('[mus][sc]sidechaincompress=threshold=0.02:ratio=8:attack=40:release=600[musd]')
fc.append('[vo][musd]amix=inputs=2:normalize=0,alimiter=limit=0.95[aout]')
subprocess.run(['ffmpeg','-v','error','-y','-ss',str(Tm),'-t',str(total),'-i',f'{d}/raw.webm']+ins+['-filter_complex',';'.join(fc),'-map','0:v','-map','[aout]','-vf','scale=1920:1080,fps=25','-c:v','libx264','-preset','veryfast','-crf','26','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart',outname],check=True)
# sottotitoli e capitoli
def ts(t):
    h=int(t//3600); m=int(t%3600//60); s=t%60; return f'{h:02d}:{m:02d}:{s:06.3f}'
SUBS=[('/luˈpette/','Lupette'),('Pi E E','PEE'),('Ci Enne Jay','CNGEI'),('Jason','JSON'),('Kos due punto zero','KOS 2.0'),('Kos','KOS')]
def sub(t):
    for a,b in SUBS: t=t.replace(a,b)
    return t
meta={m['id']:dict(m,say=sub(m['say'])) for m in tl['meta']}
CH=json.load(open(f'{d}/chapters.json')) if os.path.exists(f'{d}/chapters.json') else {}
for k,m in meta.items(): m['scene']=CH.get(k) if CH else m['scene']
v=['WEBVTT','']; ch=['WEBVTT','']
cur=None
for b in log:
    s=b['t']/1000+LEAD; e=s+b['dur']
    v+= [f"{ts(s)} --> {ts(e)}", meta[b['id']]['say'], '']
    if meta[b['id']]['scene']:
        if cur: ch+=[f"{ts(cur[0])} --> {ts(s)}", cur[1], '']
        cur=(s, meta[b['id']]['scene'])
if cur: ch+=[f"{ts(cur[0])} --> {ts(total)}", cur[1], '']
open(outname.replace('.mp4','.vtt'),'w').write('\n'.join(v)); open(outname.replace('.mp4','.chapters.vtt'),'w').write('\n'.join(ch))
print('durata',round(total,1),'s')

# capitoli nel file mp4 (metadata) 
chs=[]; cur=None
for b in log:
    t=b['t']/1000+LEAD; sc=meta[b['id']]['scene']
    if sc:
        if cur: chs.append((cur[0],t,cur[1]))
        cur=(t,sc)
if cur: chs.append((cur[0],total,cur[1]))
if chs: chs[0]=(0.0,)+chs[0][1:]
with open(f'{d}/chap.ffmeta','w') as f:
    f.write(';FFMETADATA1\n')
    for a,b,t in chs: f.write(f'[CHAPTER]\nTIMEBASE=1/1000\nSTART={int(a*1000)}\nEND={int(b*1000)}\ntitle={t}\n')
tmp=outname+'.tmp.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-i',outname,'-i',f'{d}/chap.ffmeta','-map_metadata','1','-map_chapters','1','-c','copy','-movflags','+faststart',tmp],check=True); os.replace(tmp,outname)
print('capitoli',len(chs))
