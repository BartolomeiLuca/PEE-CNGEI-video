const m = await import(process.argv[2]); const c = {};
m.beats.forEach((b, i) => { c[b.id] = b.scene || (i === m.beats.length - 1 ? 'Riepilogo' : b.id); });
console.log(JSON.stringify(c));
process.exit(0);
