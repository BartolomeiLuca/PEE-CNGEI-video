// Video 1: panoramica
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'01s', title:'Panoramica dell’app', caption:'PEE CNGEI · Per iniziare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts01.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";

const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const OC = s => "return [...document.querySelectorAll('header [onclick*=\"" + s + "\"], [onclick*=\"" + s + "\"]')].find(e => e.offsetParent)";
const HB = async (R, id, sel, a, b) => { await tg(R, id, OC(sel)); await R.move('#' + id, {ms:500, scroll:false}); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4000); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'La pagina dei progetti', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => shGoHome()); await sleep(1800); await top(R); await tg(R, 'hpt', OC('shGoHome')); await R.move('#hpt', {ms:500, scroll:false}); await R.at(4.2); await H(R, '#hpt'); await R.at(9.8); await R.hlOff();
     await tg(R, 'hit', LB('^I tuoi progetti$')); await R.at(11.0); await H(R, '#hit'); await R.at(12.3); await R.hlOff();
     await tg(R, 'hnp', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /Nuovo progetto/.test(b.innerText))"); await R.move('#hnp', {ms:500, scroll:false}); await R.at(13.3); await H(R, '#hnp'); await R.at(15.6); await R.hlOff();
     await R.at(23.9);
     await tg(R, 'hsc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /Scarica i miei progetti/.test(b.innerText))"); await scr(R, 'hsc'); await R.move('#hsc', {ms:500, scroll:false}); await R.at(24.9); await H(R, '#hsc'); await R.at(29.0); await R.hlOff();
     await tg(R, 'hap', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua$/.test(b.innerText.trim()))"); await scr(R, 'hap'); await R.move('#hap', {ms:500, scroll:false}); await R.at(29.6); await H(R, '#hap'); await R.at(30.3); await RS(R); await ck(R, '#hap', {ms:50}); await R.hlOff(); await sleep(2000); await R.F.evaluate(() => { try{ shOpen('p1', 0); }catch(e){} }); await sleep(3000); await R.F.evaluate(() => { try{ shDash(); }catch(e){} }); await sleep(1000); }} ]),
sb('b03', 'La barra in alto', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { try{ shDash(); }catch(e){} document.querySelectorAll('.sh-top').forEach(e => e.remove()); }); await sleep(1500); await top(R);
     await R.F.evaluate(() => { const st = document.createElement('style'); st.textContent = '.hdr-actions{display:none !important}'; document.head.appendChild(st); }); await tg(R, 'htt', "return document.querySelector('header')"); await R.at(2.3); await H(R, '#htt'); await R.at(5.0); await R.hlOff();
     await tg(R, 'hsv', OC('saveData')); await R.at(5.6); await H(R, '#hsv'); await R.at(10.6); await R.hlOff();
     await HB(R, 'hbp', 'shGoHome', 11.2, 14.4);
     await tg(R, 'hbg', OC('shGuide')); await R.move('#hbg', {ms:500, scroll:false}); await R.at(14.7); await H(R, '#hbg'); await sleep(200); await R.at(15.2); await ck(R, '#hbg', {ms:50}); await R.hlOff(); await R.at(17.2); await R.F.evaluate(() => { try{ modalClose(); }catch(e){} }); await sleep(500);
     await HB(R, 'hbs', 'fbOpen', 17.7, 21.8);
     await tg(R, 'hbl', OC('shSearch')); await R.move('#hbl', {ms:500, scroll:false}); await R.at(22.1); await H(R, '#hbl'); await R.at(22.8); await ck(R, '#hbl', {ms:50}); await R.hlOff(); await R.at(25.8); await R.F.evaluate(() => { try{ shSearchClose(); }catch(e){} }); await sleep(500);
     await tg(R, 'hbo', OC('clOpenHist')); await R.move('#hbo', {ms:500, scroll:false}); await R.at(26.4); await H(R, '#hbo'); await R.at(26.9); await ck(R, '#hbo', {ms:50}); await R.hlOff(); await R.at(31.2); await R.F.evaluate(() => { try{ clClose(); }catch(e){} }); await sleep(500);
     await HB(R, 'hba', 'zoomApp', 31.6, 34.8);
     await HB(R, 'hbn', 'shProfileOpen', 35.0, 35.8); }} ]),
sb('b04', 'Il menu a sinistra', [
  {t:0, run: async R => { await R.hlOff(); await RS(R); await top(R);
     await tg(R, 'mdb', SB('shDash()')); await R.move('#mdb', {ms:500, scroll:false}); await R.at(3.8); await H(R, '#mdb'); await R.at(5.4); await R.hlOff();
     for (const [g, a, b] of [['Capire', 5.5, 10.0], ['Osservare', 10.0, 20.4], ['Progettare', 20.5, 27.3], ['Realizzare', 27.4, 32.5], ['Misurare', 32.5, 40.7], ['Conservare', 40.8, 43.0], ['Condividere', 43.1, 47.4]]) {
       await tg(R, 'mg' + g, SB("shGrp('" + g + "')")); await scr(R, 'mg' + g); await R.move('#mg' + g, {ms:500, scroll:false}); await R.at(a); await H(R, '#mg' + g); await sleep(250); await ck(R, '#mg' + g, {ms:50}); await sleep(500); await R.at(b); await R.hlOff(); await RS(R); }
  }} ]),
sb('b05', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
