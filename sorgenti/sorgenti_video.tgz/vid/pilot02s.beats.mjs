// Video 2: account
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'02s', title:'Account, accesso e password', caption:'PEE CNGEI · Per iniziare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts02.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";

const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CLQ = s => "return [...document.querySelectorAll('#cl-ov " + s + "')].find(e => e.offsetParent)";
const CLH = async (R, id, css, a, b) => { await tg(R, id, CLQ(css)); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const CLT = async (R, id, css, a, text, n = 8) => { await tg(R, id, CLQ(css)); await R.move('#' + id, {ms:500, scroll:false}); await R.at(a); await H(R, '#' + id); await sleep(300); await RS(R); await ck(R, css, {ms:50}); await TY(R, css, text, n); };
const TABB = (t) => "return [...document.querySelectorAll('#cl-ov .cl-tab')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(t) + ")";
const CLB = (t) => "return [...document.querySelectorAll('#cl-ov button')].find(e => e.offsetParent && e.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4000); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Accedere', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(900, 140, 800);
     await R.at(21.2); await R.F.evaluate(() => clShow('login')); await sleep(700);
     await CLH(R, 'ctb', '.cl-tabs', 22.6, 24.4);
     await tg(R, 'cta', TABB('Accedi')); await R.at(24.6); await H(R, '#cta'); await R.at(25.1); await R.hlOff();
     await tg(R, 'ctc', TABB('Crea account')); await R.at(25.2); await H(R, '#ctc'); await R.at(26.2); await R.hlOff();
     await tg(R, 'cta2', TABB('Accedi')); await R.at(26.3); await H(R, '#cta2'); await R.at(27.4); await R.hlOff();
     await CLT(R, 'cem', '#cl-email', 27.7, 'anna@esempio.it', 15); await R.hlOff();
     await CLT(R, 'cpw', '#cl-pw', 29.2, 'passwordprova', 13);
     await tg(R, 'cey', "return document.querySelector('#cl-ov [onclick*=clPwEye]')"); await R.move('#cey', {ms:500, scroll:false}); await R.at(30.6); await H(R, '#cey'); await R.at(32.0); await R.hlOff(); await ck(R, '#cey', {ms:50});
     await R.at(33.6); await ck(R, '#cey', {ms:50});
     await tg(R, 'cgo', "return document.getElementById('cl-go')"); await R.at(34.1); await H(R, '#cgo'); }} ]),
sb('b03', 'Creare un account', [
  {t:0, run: async R => { await R.hlOff(); await RS(R);
     await tg(R, 'ctc', TABB('Crea account')); await R.move('#ctc', {ms:500, scroll:false}); await R.at(1.9); await H(R, '#ctc'); await sleep(200); await ck(R, '#ctc', {ms:50}); await R.hlOff(); await sleep(800);
     await CLT(R, 'cnm', '#cl-nome', 5.0, 'Anna Verdi', 10); await R.hlOff();
     await CLT(R, 'cem', '#cl-email', 6.2, 'anna@esempio.it', 15); await R.hlOff();
     await CLT(R, 'cpw', '#cl-pw', 7.0, 'passwordprova', 13); await R.at(9.6); await R.hlOff();
     await CLT(R, 'cp2', '#cl-pw2', 9.8, 'passwordprova', 13); await R.at(12.6); await R.hlOff();
     await tg(R, 'cgo', "return document.getElementById('cl-go')"); await R.move('#cgo', {ms:500, scroll:false}); await R.at(13.5); await H(R, '#cgo'); await R.at(15.4); await R.hlOff();
     await tg(R, 'cno', "return [...document.querySelectorAll('#cl-ov .cl-note')].filter(e => e.offsetParent).pop()"); await scr(R, 'cno'); await R.at(16.4); await H(R, '#cno'); await R.at(28.4); await R.hlOff(); }} ]),
sb('b04', 'Password dimenticata e cambio email', [
  {t:0, run: async R => { await R.hlOff(); await RS(R);
     await tg(R, 'cta', TABB('Accedi')); await R.move('#cta', {ms:500, scroll:false}); await R.at(1.9); await ck(R, '#cta', {ms:50}); await sleep(700);
     await tg(R, 'cfd', CLB('Password dimenticata')); await R.move('#cfd', {ms:500, scroll:false}); await R.at(3.0); await H(R, '#cfd'); await R.at(3.9); await RS(R); await ck(R, '#cfd', {ms:50}); await R.hlOff(); await sleep(800);
     await CLT(R, 'cem', '#cl-email', 4.9, 'anna@esempio.it', 15); await R.hlOff();
     await tg(R, 'cgo', "return document.getElementById('cl-go')"); await R.move('#cgo', {ms:500, scroll:false}); await R.at(6.2); await H(R, '#cgo'); await R.at(8.2); await R.hlOff();
     await R.at(14.6); await R.F.evaluate(() => { try{ CL.recovery = true; clShow('recovery'); }catch(e){} }); await sleep(700);
     await CLT(R, 'cpw', '#cl-pw', 17.0, 'nuovapassword1', 14); await R.hlOff();
     await CLT(R, 'cp2', '#cl-pw2', 18.7, 'nuovapassword1', 14); await R.at(19.9); await R.hlOff();
     await tg(R, 'cgo', "return document.getElementById('cl-go')"); await R.at(20.2); await H(R, '#cgo'); await R.at(21.4); await R.hlOff();
     await R.at(23.9); await R.F.evaluate(() => { try{ CL.recovery = false; clShow('email'); }catch(e){} }); await sleep(700);
     await CLT(R, 'cnn', '#cl-newmail', 26.0, 'anna.verdi@esempio.it', 18); await R.hlOff();
     await tg(R, 'cgo', "return document.getElementById('cl-go')"); await R.move('#cgo', {ms:500, scroll:false}); await R.at(28.0); await H(R, '#cgo'); await R.at(29.6); await R.hlOff();
     await tg(R, 'cmn', "return [...document.querySelectorAll('#cl-ov .cl-note')].find(e => e.offsetParent)"); await R.at(29.8); await H(R, '#cmn'); await R.at(35.8); await R.hlOff(); }} ]),
sb('b05', 'Il profilo', [
  {t:0, run: async R => { await R.hlOff(); await RS(R); await R.F.evaluate(() => { try{ clClose(); }catch(e){} }); await sleep(600);
     await tg(R, 'hpn', "return document.querySelector('[onclick*=\"shProfileOpen\"]')"); await R.move('#hpn', {ms:600, scroll:false}); await R.at(2.0); await H(R, '#hpn'); await R.at(3.4); await ck(R, '#hpn', {ms:50}); await R.hlOff(); await sleep(1500);
     await tg(R, 'pnm', LB('^Nome e cognome', 1)); await R.at(5.0); await H(R, '#pnm'); await R.at(9.8); await R.hlOff();
     await tg(R, 'prl', LB('^Il tuo ruolo', 0)); await scr(R, 'prl'); await R.at(10.3); await H(R, '#prl'); await R.at(11.5); await R.hlOff();
     for (const [t, a, b] of [['^Capo Unità$', 11.6, 12.4], ['^Vice Capo Unità$', 12.5, 13.5], ['^Capo Gruppo$', 13.6, 14.4], ['^Commissario di Sezione$', 14.5, 16.0], ['^Senior in Servizio$', 16.1, 17.4], ['^Adulto in formazione$', 17.5, 18.8]]) { await tg(R, 'prr', "const t = " + JSON.stringify(t.replace(/[\^$]/g, '')) + "; return [...document.querySelectorAll('label')].find(e => e.offsetParent && e.innerText.trim() === t)"); await R.at(a); await H(R, '#prr'); await R.at(b); await R.hlOff(); }
     await tg(R, 'pbr', LB('^Branca$', 0)); await scr(R, 'pbr'); await R.at(19.2); await H(R, '#pbr'); await R.at(22.3); await R.hlOff();
     await tg(R, 'pse', LB('^Sezione$', 1)); await scr(R, 'pse'); await R.at(23.9); await H(R, '#pse'); await R.at(26.0); await R.hlOff(); }} ]),
sb('b06', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
