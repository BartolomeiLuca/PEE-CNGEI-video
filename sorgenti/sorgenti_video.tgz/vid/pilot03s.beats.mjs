// Video 3: primo progetto
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'03s', title:'Creare il primo progetto', caption:'PEE CNGEI · Per iniziare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts03.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const ID = (id, R) => tg(R, 'x' + id, "return document.getElementById('" + id + "')");
const HI = async (R, id, a, b) => { await tg(R, 'x' + id, "return document.getElementById('" + id + "')"); await R.at(a); await H(R, '#x' + id); await R.at(b); await R.hlOff(); await RS(R); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4000); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Nuovo progetto e Tipo', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => shGoHome()); await sleep(1500); await top(R);
     await tg(R, 'hnp', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /Nuovo progetto/.test(b.innerText))"); await R.move('#hnp', {ms:600, scroll:false}); await R.at(1.9); await H(R, '#hnp'); await R.at(2.8); await RS(R); await ck(R, '#hnp', {ms:50}); await R.hlOff(); await sleep(900);
     await HI(R, 'sh-dlg-t', 4.0, 5.2);
     await tg(R, 'tlg', "return [...document.querySelectorAll('#sh-dlg legend')].find(e => /Tipo/.test(e.innerText))"); await R.at(6.4); await H(R, '#tlg'); await R.at(7.3); await R.hlOff();
     await HI(R, 'sh-lbl-pp', 7.4, 14.0); await HI(R, 'sh-lbl-an', 14.2, 19.0);
     await R.move('#sh-lbl-an', {ms:500, scroll:false}); await R.at(22.9); await ck(R, '#sh-lbl-an', {ms:50}); }} ]),
sb('b03', 'Veste, Branca, anno e nome', [
  {t:0, run: async R => { await R.hlOff(); await RS(R);
     await tg(R, 'lgv', "return [...document.querySelectorAll('#sh-dlg legend')].find(e => /veste/.test(e.innerText))"); await R.at(1.3); await H(R, '#lgv'); await R.at(2.7); await R.hlOff();
     await R.at(3.3); await R.selOpen('#sh-nru', {fast:true});
     for (const [n, at] of [['Capo Unità', 5.5], ['Vice Capo Unità', 6.4], ['Capo Gruppo', 7.6], ['Commissario', 8.6], ['Senior', 10.3], ['Adulto', 11.7]]) { await R.at(at); await R.selHover(n, 400); }
     await R.at(13.6); await R.selPick('#sh-nru', (R.menu || []).find(t => /^Capo Unità/.test(t)) || 'Capo Unità', true);
     await R.at(16.0); await R.selOpen('#sh-nbr', {fast:true});
     for (const [n, at] of [['L ·', 17.2], ['E ·', 18.4], ['R ·', 20.6]]) { await R.at(at); await R.selHover(n, 400); }
     await R.at(22.2); await R.selPick('#sh-nbr', (R.menu || []).find(t => /^E ·/.test(t)) || 'E', true);
     await HI(R, 'sh-nas', 23.3, 24.6);
     await R.at(24.8); await R.selOpen('#sh-nas', {fast:true});
     for (const [n, at] of [['2026-27', 25.4], ['2025-26', 27.8], ['2027-28', 28.7]]) { await R.at(at); await R.selHover(n, 400); }
     await R.at(29.5); await R.selPick('#sh-nas', (R.menu || []).find(t => /^2026-27/.test(t)) || '2026-27', true);
     await tg(R, 'xun', "return document.getElementById('sh-nun')"); await R.move('#xun', {ms:500, scroll:false}); await R.at(30.6); await H(R, '#xun'); await R.at(31.7); await RS(R); await ck(R, '#sh-nun', {ms:50}); await TY(R, '#sh-nun', 'Reparto Delfini', 8); await R.at(34.2);
     await R.at(38.1); await HI(R, 'sh-nhint', 38.1, 44.0); }} ]),
sb('b04', 'Capo Gruppo e Commissario', [
  {t:0, run: async R => { await R.hlOff(); await RS(R);
     await R.at(1.8); await R.selOpen('#sh-nru', {fast:true}); await R.at(2.4); await R.selHover('Capo Gruppo', 400); await R.at(2.9); await R.selPick('#sh-nru', (R.menu || []).find(t => /^Capo Gruppo/.test(t)) || 'Capo Gruppo', true); await sleep(500);
     await tg(R, 'xbr', "return document.getElementById('sh-nbrw') && document.getElementById('sh-nbrw').parentElement"); await R.at(4.3); await H(R, '#xbr'); await R.at(7.0); await R.hlOff(); await RS(R);
     await HI(R, 'sh-lbl-ant', 7.4, 10.8);
     await R.at(11.6); await R.selOpen('#sh-nru', {fast:true}); await R.at(12.4); await R.selHover('Commissario', 400); await R.at(13.4); await R.selPick('#sh-nru', (R.menu || []).find(t => /^Commissario/.test(t)) || 'Commissario', true); await sleep(400);
     await R.at(19.0); await R.selOpen('#sh-nru', {fast:true}); await R.at(21.5); await R.selHover('Capo Unità', 400); await R.at(22.2); await R.selPick('#sh-nru', (R.menu || []).find(t => /^Capo Unità/.test(t)) || 'Capo Unità', true); await sleep(500);
     await R.F.evaluate(() => { const n = document.getElementById('sh-nun'); if(n && !n.value){ n.value = 'Reparto Delfini'; n.dispatchEvent(new Event('input', {bubbles:true})); } }); }} ]),
sb('b05', 'Crea il progetto', [
  {t:0, run: async R => { await R.hlOff(); await RS(R);
     await tg(R, 'xcr', "return document.getElementById('sh-ncre')"); await R.move('#xcr', {ms:500, scroll:false}); await R.at(1.0); await H(R, '#xcr'); await R.at(2.3); await RS(R); await ck(R, '#sh-ncre', {ms:50}); await R.hlOff(); await sleep(1200);
     await tg(R, 'npt', "return document.querySelector('#sh-nprev h2')"); await R.at(5.6); await H(R, '#npt'); await R.at(8.6); await R.hlOff(); await RS(R);
     await tg(R, 'nps', "return document.getElementById('np-src')"); await R.move('#nps', {ms:500, scroll:false}); await R.at(9.0); await H(R, '#nps'); await R.at(10.6); await R.hlOff(); await RS(R);
     await tg(R, 'npl', "return document.querySelector('#sh-nprev .dup-l')"); await R.at(11.2); await H(R, '#npl'); await R.at(15.4); await R.hlOff(); await RS(R);
     await tg(R, 'npz', "return [...document.querySelectorAll('#sh-nprev button')].find(b => /Parto da zero/.test(b.innerText))"); await R.move('#npz', {ms:600, scroll:false}); await R.at(17.6); await H(R, '#npz'); await R.at(18.6); await RS(R); await ck(R, '#npz', {ms:50}); await R.hlOff(); await sleep(3500);
     await R.F.evaluate(() => { try{ shDash(); }catch(e){} }); await sleep(900); await top(R);
     await tg(R, 'xhd', "return [...document.querySelectorAll('#hdr *')].find(e => e.children.length === 0 && /^Branca E/.test(e.textContent.trim()))"); await R.at(28.1); await H(R, '#xhd'); await R.at(35.3); await R.hlOff();
     await tg(R, 'hbp', "return document.querySelector('header [onclick*=shGoHome]')"); await R.move('#hbp', {ms:600, scroll:false}); await R.at(36.9); await H(R, '#hbp'); await R.at(37.6); await RS(R); await ck(R, '#hbp', {ms:50}); await R.hlOff(); await sleep(1200);
     await tg(R, 'hit', LB('^I tuoi progetti$')); await R.at(38.4); await H(R, '#hit'); await R.at(39.3); await R.hlOff();
     await tg(R, 'hco', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua$/.test(b.innerText.trim()))"); await R.move('#hco', {ms:400, scroll:false}); await H(R, '#hco'); }} ]),
sb('b06', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
