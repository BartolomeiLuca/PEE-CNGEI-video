// Video 4: salvataggio e archivio
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'04s', title:'Salvataggio, archivio e copie di sicurezza', caption:'PEE CNGEI · Per iniziare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts04.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BB = (t, n = 0) => "return [...document.querySelectorAll('button')].filter(b => b.offsetParent && b.innerText.trim() === " + JSON.stringify(t) + ")[" + n + "]";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HI = async (R, id, a, b, sel) => { await tg(R, 'x' + id, sel || ("return document.getElementById('" + id + "')")); await R.at(a); await H(R, '#x' + id); await R.at(b); await R.hlOff(); await RS(R); };
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Il salvataggio automatico', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(300);
     await HB(R, 'xsv', "const e = document.querySelector('#save-ind, .save-w'); return e && (e.closest('#save-ind') || e.parentElement)", 4.6, 11.0);
     await R.moveTo(800, 460, 1500); }} ]),
sb('b03', 'Versioni precedenti', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'xhh', "return document.getElementById('hd-hist')"); await R.move('#xhh', {ms:700, scroll:false}); await R.at(1.0); await H(R, '#xhh'); await R.at(7.2); await RS(R); await ck(R, '#hd-hist', {ms:50}); await R.hlOff(); await sleep(900);
     await HB(R, 'xcn', "return document.querySelector('#cl-ov .cl-note')", 8.5, 16.0);
     await R.at(23.7); await ck(R, '#cl-vl', {ms:400}); await TY(R, '#cl-vl', 'Prima della riunione di novembre', 12); await R.at(27.4);
     await tg(R, 'xsm', BS('★ Salva questo momento')); await R.move('#xsm', {ms:300, scroll:false}); await R.at(28.0); await H(R, '#xsm'); await R.at(28.8); await RS(R); await ck(R, '#xsm', {ms:50}); await R.hlOff(); await sleep(1200);
     await HB(R, 'xro', "return [...document.querySelectorAll('#cl-hist .cl-row')][0]", 29.6, 33.0);
     await HB(R, 'xrp', "return [...document.querySelectorAll('#cl-hist .cl-row button')][0]", 34.6, 36.2);
     await HB(R, 'xcm', "return document.querySelector('#cl-ov .cl-note')", 36.4, 43.4); }} ]),
sb('b04', 'L’archivio per anno', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { try{ clClose(); }catch(e){} }); await sleep(500);
     await tg(R, 'xpj', "return [...document.querySelectorAll('.hd-lnk')].find(b => b.offsetParent && b.innerText.trim() === 'Progetti')"); await R.move('#xpj', {ms:600, scroll:false}); await R.at(2.3); await H(R, '#xpj'); await R.at(2.9); await RS(R); await ck(R, '#xpj', {ms:50}); await R.hlOff(); await sleep(1500);
     await HB(R, 'xvh', "return document.querySelector('.sh-vh')", 7.3, 12.3);
     await HB(R, 'xay', "return document.querySelectorAll('.sh-anh')[0]", 14.4, 19.4);
     await HB(R, 'xay2', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /Nuovo ciclo/.test(b.innerText))", 19.7, 21.4);
     await HB(R, 'xbd', "return [...document.querySelectorAll('.sh-pr')][0]", 27.3, 33.4);
     await HB(R, 'xap', BB('Apri', 0), 35.3, 36.2);
     await HB(R, 'xco', BB('Continua', 0), 36.4, 38.2);
     await HB(R, 'xbr', "const b = [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim() === 'Rinomina'); return b && b.parentElement", 38.5, 41.6); }} ]),
sb('b05', 'Duplicare in un nuovo anno', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'xdu', BB('Duplica', 0)); await R.move('#xdu', {ms:600, scroll:false}); await R.at(3.0); await H(R, '#xdu'); await R.at(3.8); await RS(R); await ck(R, '#xdu', {ms:50}); await R.hlOff(); await sleep(1000);
     await HB(R, 'xdl', "return document.querySelector('label[for=dup-y]')", 8.0, 9.6);
     await R.at(9.8); await R.selOpen('#dup-y', {fast:true});
     await R.at(10.1); await R.selHover('2026-27 (stesso anno)', 300); await R.at(11.5); await R.selHover('2027-28 (anno successivo)', 300);
     await R.at(13.0); await R.selPick('#dup-y', '2027-28 (anno successivo)', true); await sleep(300);
     await HB(R, 'xdh', "return document.getElementById('dup-h')", 14.6, 25.4);
     const ys = [[30.0, 31.5], [31.6, 32.6], [32.7, 34.9], [35.0, 36.2], [36.3, 37.1], [37.2, 38.9]];
     for (let i = 0; i < ys.length; i++) await HB(R, 'xdc' + i, "return document.querySelectorAll('.dup-c')[" + i + "].closest('label') || document.querySelectorAll('.dup-c')[" + i + "].parentElement", ys[i][0], ys[i][1]);
     await tg(R, 'xsa', BS('Seleziona tutto')); await R.move('#xsa', {ms:400, scroll:false}); await R.at(39.2); await H(R, '#xsa'); await R.at(40.7); await R.hlOff(); await RS(R);
     await tg(R, 'xds', BS('Deseleziona tutto')); await R.move('#xds', {ms:400, scroll:false}); await R.at(41.5); await H(R, '#xds'); await R.at(42.9); await RS(R); await ck(R, '#xds', {ms:50}); await R.hlOff(); await sleep(300);
     for (const [i, t] of [[0, 46.6], [1, 47.6], [2, 49.0]]) { await tg(R, 'xk' + i, "const c = document.querySelectorAll('.dup-c')[" + i + "]; return c.closest('label') || c.parentElement"); await R.move('#xk' + i, {ms:400, scroll:false}); await R.at(t); await ck(R, '#xk' + i, {ms:50}); await RS(R); }
     await tg(R, 'xcc', BS('Crea la copia')); await R.move('#xcc', {ms:500, scroll:false}); await R.at(53.1); await H(R, '#xcc'); await R.at(54.1); await RS(R); await ck(R, '#xcc', {ms:50}); await R.hlOff(); await sleep(2500);
     await HB(R, 'xnc', "return document.querySelectorAll('.sh-anh')[0]", 55.4, 59.0); }} ]),
sb('b06', 'Elimina e cestino', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { window.confirm = () => true; });
     await tg(R, 'xel', BB('Elimina', 0)); await R.move('#xel', {ms:600, scroll:false}); await R.at(2.8); await H(R, '#xel'); await R.at(3.5); await RS(R); await ck(R, '#xel', {ms:50}); await R.hlOff(); await sleep(2500);
     await tg(R, 'xtr', "return document.querySelector('details.sh-trash summary')"); await scr(R, 'xtr'); await R.at(11.5); await H(R, '#xtr'); await R.at(13.4); await R.hlOff();
     await R.at(14.0); await RS(R); await ck(R, 'details.sh-trash summary', {ms:500}); await sleep(600);
     await tg(R, 'xtd0', "return document.querySelector('details.sh-trash .sh-pr')"); await scr(R, 'xtd0'); await RS(R);
     await HB(R, 'xtd', "return document.querySelector('details.sh-trash .sh-pr')", 15.0, 22.6);
     await HB(R, 'xrc', BS('Recupera'), 23.8, 25.4);
     await R.at(25.7); await tg(R, 'xrc2', BS('Recupera')); await R.move('#xrc2', {ms:400, scroll:false}); await ck(R, '#xrc2', {ms:50}); await sleep(2500);
     await R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'})); await sleep(800); }} ]),
sb('b07', 'Copia di sicurezza', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'xsc', BS('Scarica i miei progetti')); await scr(R, 'xsc'); await R.move('#xsc', {ms:500, scroll:false}); await R.at(4.4); await H(R, '#xsc'); await R.at(7.3); await RS(R); await ck(R, '#xsc', {ms:50}); await R.hlOff(); await sleep(1500);
     await R.at(8.0); await tg(R, 'xtt', "return [...document.querySelectorAll('body *')].find(e => e.children.length === 0 && /^Ho scaricato/.test(e.textContent.trim()))"); await R.at(8.3); await H(R, '#xtt'); await R.at(11.5); await R.hlOff(); }} ]),
sb('b08', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
