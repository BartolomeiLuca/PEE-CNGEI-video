// Video 5: dispositivi, testo, guida
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'05s', title:'Telefono, tablet, testo formattato e guida', caption:'PEE CNGEI · Per iniziare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts05.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Computer, tablet e telefono', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(900, 500, 800);
     await R.at(13.6); await VP(R, 820); await sleep(900);
     await tg(R, 'xhb', "return document.getElementById('sh-hb')"); await R.move('#xhb', {ms:600, scroll:false}); await R.at(17.3); await H(R, '#xhb'); await R.at(20.9); await RS(R); await R.at(21.4); await ck(R, '#sh-hb', {ms:50}); await R.hlOff();
     await R.at(24.3); await R.F.evaluate(() => { try{ shDrawer(false); }catch(e){} }); await sleep(300);
     await R.at(24.8); await VP(R, 390); await sleep(900); await R.F.evaluate(() => { try{ shDash(); }catch(e){} const b = document.getElementById('sh-bb'); if(b){ b.style.display = 'none'; void b.offsetHeight; b.style.display = ''; } window.scrollBy(0, 3); setTimeout(() => window.scrollBy(0, -3), 100); }); await sleep(900);
     await R.F.evaluate(() => window.scrollTo(0, 0)); await sleep(500); console.log('BBB', JSON.stringify(await R.F.evaluate(() => { const b = document.querySelector('.sh-bbb'); const p = b && b.parentElement; const r = p && p.getBoundingClientRect(); return [window.innerWidth, window.innerHeight, r && [r.x, r.y, r.width, r.height], p && getComputedStyle(p).position, p && p.className]; }))); for (const [i, t0, t1] of [[0, 30.5, 31.3], [1, 31.4, 32.2], [2, 32.3, 33.0], [3, 33.1, 33.7]]) { await tg(R, 'xbb' + i, "return document.querySelectorAll('.sh-bbb')[" + i + "]"); await R.at(t0); await R.move('#xbb' + i, {ms:450, scroll:false}); await R.at(t1); }
     await R.move('#xbb3', {ms:300, scroll:false}); await R.at(34.2); await ck(R, '#xbb3', {ms:50});
     await R.at(44.3); await R.F.evaluate(() => { try{ shSheetClose(); }catch(e){} }); await sleep(300);
     await R.at(55.4); await VP(R, 1440); await sleep(900); }} ]),
sb('b03', 'La dimensione del testo', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'xzm', "return document.querySelector('.hd-zoom')"); await R.move('#xzm', {ms:700, scroll:false}); await R.at(3.1); await H(R, '#xzm'); await R.at(5.4); await RS(R);
     for (const t of [5.6, 10.8, 12.3, 15.6]) { await R.at(t); await ck(R, '.hd-zoom', {ms:120}); if(t === 5.6) await R.hlOff(); }
     await sleep(1200); }} ]),
sb('b04', 'Il testo formattato', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { try{ clClose(); }catch(e){} });
     await tg(R, 'xmg', "return [...document.querySelectorAll('#sh-side .sh-gh')].find(e => e.offsetParent && /Misurare/i.test(e.innerText))"); await R.move('#xmg', {ms:600, scroll:false}); await R.at(9.4); await RS(R); await ck(R, '#xmg', {ms:50}); await sleep(700);
     await tg(R, 'xvf', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && /^Valutazione finale/.test(e.innerText.trim()))"); await R.move('#xvf', {ms:500, scroll:false}); await R.at(10.0); await RS(R); await ck(R, '#xvf', {ms:50}); await sleep(1500); await dq(R);
     await tg(R, 'xed', "return [...document.querySelectorAll('.rt-ed')].filter(e => e.offsetParent)[0]"); await scr(R, 'xed'); await R.move('#xed', {ms:600, scroll:false}); await R.at(11.4); await RS(R); await ck(R, '.rt-ed', {ms:50}); await sleep(500);
     await HB(R, 'xbar', "return document.getElementById('rt-bar')", 13.6, 15.2);
     await R.at(15.5); await R.P.keyboard.type('Il Reparto ha lavorato bene sulla cooperazione e sulla fiducia.', {delay:38});
     await R.at(18.5); await SELW(R, 'cooperazione'); await RTB(R, 'b', 19.0, 19.8); await R.move('#rt-bar button[data-rt=b]', {ms:300, scroll:false}); await R.at(19.9); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy);
     await R.at(21.3); await SELW(R, 'fiducia'); await R.move('#rt-bar button[data-rt=i]', {ms:500, scroll:false}); await R.at(23.5); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy);
     await R.at(24.8); await SELW(R, 'Reparto'); await R.move('#rt-bar button[data-rt=u]', {ms:500, scroll:false}); await R.at(25.9); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy);
     await R.at(26.8); await SELW(R, 'bene'); await R.move('#rt-bar button[data-rt=L]', {ms:400, scroll:false}); await R.at(27.6); await R.P.mouse.click(R.cx, R.cy);
     await R.at(27.9); await SELW(R, ' ha '); await R.move('#rt-bar button[data-rt=S]', {ms:300, scroll:false}); await R.at(28.4); await R.P.mouse.click(R.cx, R.cy);
     await R.at(31.4); await R.F.evaluate(() => { const ed = document.querySelector('.rt-ed'); ed.focus(); const s = getSelection(); s.selectAllChildren(ed); s.collapseToEnd(); }); await R.P.keyboard.press('Enter'); await sleep(600);
     await RMV(R, 'ul'); await R.at(35.4); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type('Più autonomia nelle pattuglie', {delay:35}); await R.P.keyboard.press('Enter');
     await RMV(R, 'ol'); await R.at(38.3); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type('Rivedere i ruoli', {delay:35});
     await RMV(R, 'x'); await R.at(40.9); await R.P.mouse.click(R.cx, R.cy);
     await R.at(46.8); await SELW(R, 'Il'); await R.P.keyboard.press('Control+b'); await R.at(47.8); await R.P.keyboard.press('Control+i'); await R.at(48.3); await R.P.keyboard.press('Control+u'); await sleep(800); }} ]),
sb('b05', 'Guida, FAQ e Suggerimenti', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const a=[...document.querySelectorAll('.hd-lnk')].find(b => b.offsetParent && b.innerText.trim()==='Progetti'); if(a) a.click(); }); await sleep(1200); await top(R);
     await tg(R, 'xgd', "return [...document.querySelectorAll('.hd-lnk')].find(b => b.offsetParent && b.innerText.trim() === 'Guida')"); await R.move('#xgd', {ms:600, scroll:false}); await R.at(3.4); await H(R, '#xgd'); await R.at(4.3); await RS(R); await ck(R, '#xgd', {ms:50}); await R.hlOff(); await sleep(900);
     const SMY = rx => "return [...document.querySelectorAll('.modal-overlay.show details.gd-pan > summary')].find(s => " + rx + ".test(s.innerText.trim()))";
     await R.at(6.0); await tg(R, 'xg1', SMY('/^Che cosa puoi fare/')); await R.move('#xg1', {ms:500, scroll:false}); await R.at(7.4); await H(R, '#xg1');
     await R.at(9.1); await tg(R, 'xg2', SMY('/^Progetti d.esempio/')); await R.move('#xg2', {ms:400, scroll:false}); await H(R, '#xg2');
     await R.at(10.45); await tg(R, 'xg3', SMY('/^Video tutorial/')); await R.move('#xg3', {ms:400, scroll:false}); await H(R, '#xg3');
     await R.at(11.55); await tg(R, 'xg4', SMY('/^Domande frequenti/')); await R.move('#xg4', {ms:400, scroll:false}); await H(R, '#xg4');
     await R.at(12.95); await R.move('#xg3', {ms:300, scroll:false}); await RS(R); await ck(R, '#xg3', {ms:50}); await sleep(500);
     await R.hlOff(); await sleep(300);
     await HB(R, 'xvl', "return [...document.querySelectorAll('.modal-overlay.show details.gd-pan')].find(d => /^Video tutorial/.test(d.innerText.trim()))", 14.5, 20.4);
     await R.at(20.6); await tg(R, 'xg3b', SMY('/^Video tutorial/')); await R.move('#xg3b', {ms:300, scroll:false}); await RS(R); await ck(R, '#xg3b', {ms:50}); await sleep(400);
     await tg(R, 'xg4b', SMY('/^Domande frequenti/')); await R.move('#xg4b', {ms:300, scroll:false}); await ck(R, '#xg4b', {ms:50}); await sleep(500); await R.F.evaluate(() => { const e = document.getElementById('xg4b'); e && e.scrollIntoView({block:'start', behavior:'smooth'}); }); await sleep(700);
     await R.at(21.3); await R.hlOff(); await H(R, '#xg4b'); await R.at(22.1); await R.hlOff();
     await HB(R, 'xfg', "return document.querySelector('.modal-overlay.show .faq-mac')", 22.9, 27.5);
     await tg(R, 'xfq', "return document.querySelector('.modal-overlay.show .faq-q')"); await R.move('#xfq', {ms:500, scroll:false}); await R.at(29.4); await H(R, '#xfq'); await R.at(30.7); await R.hlOff(); await RS(R);
     await R.at(30.95); await R.type('.modal-overlay.show .faq-q', 'password', 90); await sleep(600);
     await HB(R, 'xfr', "return [...document.querySelectorAll('.modal-overlay.show details.faq-it')].find(d => d.offsetParent)", 33.0, 37.7);
     await tg(R, 'xcx', "return document.querySelector('.modal-overlay.show .modal-x')"); await R.at(39.9); await R.move('#xcx', {ms:600, scroll:false}); await R.at(40.9); await RS(R); await ck(R, '.modal-overlay.show .modal-x', {ms:50}); await sleep(700);
     await tg(R, 'xsg', "return [...document.querySelectorAll('.hd-lnk')].find(b => b.offsetParent && /Suggerimenti/.test(b.innerText))"); await R.move('#xsg', {ms:600, scroll:false}); await R.at(41.7); await H(R, '#xsg'); await R.at(43.2); await RS(R); await ck(R, '#xsg', {ms:50}); await R.hlOff(); await sleep(1200); }} ]),
sb('b06', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { try{ modalClose(); }catch(e){} }); await sleep(500); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
