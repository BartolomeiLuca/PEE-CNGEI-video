// Video 5: dispositivi, testo, guida
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'06s', title:'La mia unità e il mio contesto', caption:'PEE CNGEI · Capire'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts06.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const FLD = i => "return [...document.querySelectorAll('#main-app input:not([type=hidden]),#main-app select,#main-app textarea')].filter(e => e.offsetParent)[" + i + "]";
const FLP = i => "const e = [...document.querySelectorAll('#main-app input:not([type=hidden]),#main-app select,#main-app textarea')].filter(e => e.offsetParent)[" + i + "]; return e && e.parentElement";
const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const TYF = async (R, i, text, a) => { await tg(R, 'xtf', FLD(i)); await R.move('#xtf', {ms:text.length <= 3 ? 150 : 400, scroll:false}); await R.at(a); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); if(text.length <= 3) await R.F.fill('#xtf', text); else { await R.F.fill('#xtf', ''); await R.P.keyboard.type(text, {delay:38}); } await RS(R); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'La mia unità', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'xcp', "return [...document.querySelectorAll('#sh-side .sh-gh')].find(e => e.offsetParent && /Capire/i.test(e.innerText))"); await R.move('#xcp', {ms:400, scroll:false}); await R.at(0.15); await RS(R); await ck(R, '#xcp', {ms:50}); await sleep(500);
     await NAVI(R, 'La mia unità', 0.9);
     await HB(R, 'xch', LB('^Chi compila$'), 2.3, 3.4);
     await HB(R, 'xf0', FLP(0), 4.3, 5.6); await HB(R, 'xf1', FLP(1), 5.7, 7.4);
     await tg(R, 'xgs', FLD(2)); await HB(R, 'xf2', FLP(2), 7.6, 8.7);
     await R.selOpen('#xgs', {fast:true});
     await R.at(10.1); await R.selHover('Monogruppo', 400); await R.at(12.8); await R.selHover('Gruppo 1', 300); await R.at(13.2); await R.selHover('Gruppo 20', 300);
     await R.at(13.9); await R.selPick('#xgs', 'Gruppo 1', true);
     await HB(R, 'xf3', FLP(3), 15.3, 18.3);
     await HB(R, 'xnm', inner('Numeri dell.Unità'), 19.3, 20.6);
     await TYF(R, 4, '24', 21.3); await TYF(R, 5, '14', 24.2); await TYF(R, 6, '10', 24.7);
     await HB(R, 'xpa', LB('^Per anno di Reparto$'), 25.6, 26.6);
     await TYF(R, 7, '8', 26.8); await TYF(R, 8, '7', 27.5); await TYF(R, 9, '5', 28.3); await TYF(R, 10, '4', 29.0);
     await HB(R, 'xnt', LB('^Solo numeri'), 31.4, 36.0); await sleep(500); }} ]),
sb('b03', 'Come funziona', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'xtd', LEAF('^Come funziona — ')); await R.move('.tutorial-hdr:visible', {ms:600, scroll:false}); await R.at(1.3); await H(R, '.tutorial-hdr:visible'); await R.at(2.5); await R.hlOff(); await RS(R); await ck(R, '.tutorial-hdr:visible', {ms:50}); await sleep(600);
     await HB(R, 'xl0', LIT('Cosa fare'), 3.4, 4.5); await HB(R, 'xl1', LIT('Cosa si aspettano'), 4.6, 14.9); await HB(R, 'xl2', LIT('Per compilare bene', 0), 15.1, 23.7); await HB(R, 'xl3', LIT('Per compilare bene', 1), 23.9, 28.9);
     await HB(R, 'xfl', "return [...document.querySelectorAll('.faq-lk')].find(e => e.offsetParent)", 29.2, 32.0); await sleep(500); }} ]),
sb('b04', 'Il mio contesto', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await NAVI(R, 'Il mio contesto', 0.6); await R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); }); await sleep(300);
     await tg(R, 'xtd', LEAF('^Come funziona — ')); await R.move('.tutorial-hdr:visible', {ms:600, scroll:false}); await R.at(3.4); await RS(R); await ck(R, '.tutorial-hdr:visible', {ms:50}); await sleep(600);
     await HB(R, 'xl0', LIT('Cosa fare'), 5.0, 12.2);
     await HB(R, 'xt0', FLP(0).replace('return e && e.parentElement', 'return e'), 13.5, 15.0);
     await TYF(R, 0, 'Stazione a dieci minuti, parco vicino alla sede, bosco a cinque chilometri', 16.9);
     await HB(R, 'xsd', inner('^Sede della Sezione'), 22.8, 24.6);
     await HB(R, 'xs0', FLD(1), 25.0, 25.8); await HB(R, 'xs1', FLD(2), 25.9, 28.2); await HB(R, 'xs2', FLD(3), 28.8, 29.5); await HB(R, 'xs3', FLD(4), 29.6, 30.6); await HB(R, 'xs4', FLD(5), 30.8, 32.0);
     await HB(R, 'xcs', inner('^Contesto Sezione e Gruppo'), 32.9, 35.4);
     await TYF(R, 6, 'Staff di quattro adulti, due con esperienza di Reparto', 38.6);
     await top(R); await HB(R, 'xl2', LIT('Per compilare bene', 0), 42.4, 47.9); await sleep(500); }} ]),
sb('b05', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
