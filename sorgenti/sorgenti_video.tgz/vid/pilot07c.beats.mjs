// Video Dashboard
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'07c', title:'Il ciclo', caption:'PEE CNGEI · Per iniziare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts07c.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";
const DC = c => "return document.querySelector('#panel-dash [data-c=" + c + "]')";
const DB_ = t => "return [...document.querySelectorAll('#panel-dash button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HC = async (R, id, css, a, b) => { await tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")"); await scr(R, id); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const NB = t => "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const toCal = async R => { await R.F.evaluate(() => window.scrollTo(0,0)); await R.move(R.F.locator('#sh-side button.sh-gh', {hasText:'Realizzare'}).first(), {scroll:false, ms:500}); await R.at(21.6); await ck(R, R.F.locator('#sh-side button.sh-gh', {hasText:'Realizzare'}).first(), {ms:50}); await sleep(500); const si = R.F.locator('#sh-side .sh-si[onclick*="shCal"]').first(); await R.move(si, {scroll:false, ms:400}); await ck(R, si, {ms:50}); await sleep(1500); };
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Che cos’è un ciclo', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await HC(R, 'dh1', '#panel-dash h1', 0.2, 0.9);
     await HC(R, 'dsb', '#panel-dash .sh-dh .sub', 1.0, 4.8);
     await tg(R, 'dcol', LF('^Il mio ciclo in un colpo', 0, 1)); await scr(R, 'dcol'); await R.at(5.0); await H(R, '#dcol'); await R.at(9.3); await R.hlOff();
     await top(R); await R.at(20.4); await tg(R, 'dsb2', "return document.querySelector('#panel-dash .sh-dh .sub')"); await H(R, '#dsb2'); await R.at(23.9); await R.hlOff(); }} ]),
sb('b03', 'A che cosa serve', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'dcol', LF('^Il mio ciclo in un colpo', 0, 1)); await scr(R, 'dcol'); await R.at(2.0); await H(R, '#dcol'); await R.at(10.0); await R.hlOff(); await top(R); await tg(R, 'dsb', "return document.querySelector('#panel-dash .sh-dh .sub')"); await R.at(10.4); await H(R, '#dsb'); await R.at(15.0); await R.hlOff(); }} ]),
sb('b04', 'Come si gestisce', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'drn', DB_('Rinomina')); await R.move('#drn', {ms:500, scroll:false}); await R.at(4.0); await H(R, '#drn'); await R.at(6.6); await R.hlOff();
     await tg(R, 'dc2', DB_('Il mio anno')); await R.move('#dc2', {ms:500, scroll:false}); await R.at(8.0); await H(R, '#dc2'); await R.at(9.8); await R.hlOff(); }} ]),
sb('b05', 'I pit stop', [
  {t:0, run: async R => { await R.hlOff(); await RS(R); await top(R); await tg(R, 'dsc', LF('^Prossime scadenze$', 0, 2)); await R.at(1.0); await H(R, '#dsc'); await R.at(7.0); await R.hlOff(); await tg(R, 'dpit', LF('^Primo pit stop', 0, 1)); await scr(R, 'dpit'); await R.at(7.2); await H(R, '#dpit'); await R.at(13.0); await R.hlOff(); await tg(R, 'dpit2', LF('^Secondo pit stop', 0, 1)); await R.at(13.4); await H(R, '#dpit2'); await R.at(15.0); await R.hlOff(); await R.at(21.3); await toCal(R); }},
  {t:25.0, run: async R => { await RS(R); await tg(R, 'cp', "return document.querySelector('.cal-pit')"); await scr(R, 'cp'); await R.at(25.3); await H(R, '#cp'); await R.at(27.2); await R.hlOff(); await tg(R, 'cpf', "return [...document.querySelectorAll('.cal-pit button')].find(b => b.offsetParent && /^Fissalo/.test(b.innerText.trim()))"); await R.move('#cpf', {ms:500, scroll:false}); await R.at(27.5); await H(R, '#cpf'); await R.at(30.9); await R.hlOff(); }},
  {t:31.0, run: async R => { await R.F.evaluate(() => { document.querySelector('#sh-side .sh-si[onclick*="shDash"], #sh-side [onclick*="shDash"]')?.click(); }); await sleep(1200); await top(R); await tg(R, 'dsc3', LF('^Prossime scadenze$', 0, 2)); await R.at(32.1); await H(R, '#dsc3'); await R.at(33.8); await R.hlOff(); }},
 ]),
sb('b06', 'Dall’anno precedente', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'mcap', "return [...document.querySelectorAll('#sh-side button.sh-gh')].find(b => /Capire/i.test(b.innerText))"); await R.move('#mcap', {ms:600, scroll:false}); await R.at(7.0); await H(R, '#mcap'); await R.at(10.0); await R.hlOff(); }} ]),
sb('b07', null, [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'dsg', "return document.querySelector('#panel-dash .sh-seg')"); await R.at(10.4); await H(R, '#dsg'); await R.at(15.0); await R.hlOff(); }} ]),
];
