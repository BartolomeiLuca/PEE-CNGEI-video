// Video 5: dispositivi, testo, guida
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'07s', title:'Il mio staff', caption:'PEE CNGEI · Capire'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts07.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const TBL = "const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent); ";
const ROWT = i => TBL + "return t.querySelectorAll('tbody tr')[" + i + "]";
const CTL = (r, i) => TBL + "return [...t.querySelectorAll('tbody tr')][" + r + "].querySelectorAll('textarea,select,button,input')[" + i + "]";
const CELL = (r, i) => TBL + "return [...t.querySelectorAll('tbody tr')][" + r + "].cells[" + i + "]";
const THX = n => "const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent); return [...t.querySelectorAll('th')].find(h => h.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const HS = (R, x) => R.F.evaluate(x => { const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent); let e = t; while(e && e.scrollWidth <= e.clientWidth + 2) e = e.parentElement; e && e.scrollTo({left:x, behavior:'smooth'}); }, x);
const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const TYR = async (R, i, text, a) => { await tg(R, 'xtf', CTL(1, i)); await R.move('#xtf', {ms:150, scroll:false}); await R.at(a); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); await R.F.fill('#xtf', text); await RS(R); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Come funziona', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'xcp', "return [...document.querySelectorAll('#sh-side .sh-gh')].find(e => e.offsetParent && /Capire/i.test(e.innerText))"); await R.move('#xcp', {ms:400, scroll:false}); await RS(R); await ck(R, '#xcp', {ms:50}); await sleep(400);
     await NAVI(R, 'Il mio staff', 0.5);
     await R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); }); await sleep(300);
     await tg(R, 'xtd', LEAF('^Come funziona — ')); await R.move('.tutorial-hdr:visible', {ms:500, scroll:false}); await R.at(2.8); await H(R, '.tutorial-hdr:visible'); await R.at(3.9); await R.hlOff(); await RS(R); await R.at(4.0); await ck(R, '.tutorial-hdr:visible', {ms:50}); await sleep(600);
     await HB(R, 'xl0', LIT('Cosa fare'), 4.8, 14.4); await HB(R, 'xl1', LIT('Cosa si aspettano'), 14.6, 20.4); await HB(R, 'xl2', LIT('Per compilare bene', 0), 22.1, 29.1); await HB(R, 'xl3', LIT('Per compilare bene', 1), 29.8, 33.7); await sleep(300); }} ]),
sb('b03', 'Come programmi', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { try{ window.confirm = () => true; }catch(e){} const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); });
     await R.F.evaluate(() => window.scrollTo({top:120, behavior:'smooth'})); await sleep(900);
     await HB(R, 'xcm', inner('^Come programmi'), 1.1, 2.8);
     await HB(R, 'xin', BS('Programmazione individuale'), 4.3, 10.8);
     await HB(R, 'xco', BS('Programmazione condivisa'), 11.4, 16.7);
     await R.move('#xco', {ms:300, scroll:false}); await R.at(17.0); await tg(R, 'xco', BS('Programmazione condivisa')); await ck(R, '#xco', {ms:50}); await RS(R); await sleep(800);
     await HB(R, 'xcd', THX('condividi'), 20.1, 21.0);
     await HB(R, 'xtu', CELL(0, 1), 21.7, 24.9);
     await tg(R, 'xar', BS('+ Aggiungi riga')); await R.move('#xar', {ms:500, scroll:false}); await R.at(25.4); await ck(R, '#xar', {ms:50}); await RS(R); await sleep(700);
     await HB(R, 'xcb', "const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent); return t.querySelectorAll('tbody tr')[1].cells[1]", 27.8, 29.4);
     await HB(R, 'xem', THX('email'), 30.5, 31.6);
     await tg(R, 'xin', BS('Programmazione individuale')); await R.move('#xin', {ms:700, scroll:false}); await R.at(36.8); await ck(R, '#xin', {ms:50}); await RS(R); await sleep(800); }} ]),
sb('b04', 'Adulti in staff', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { try{ window.confirm = () => true; }catch(e){} });
     await tg(R, 'xad', inner('^Adulti in staff')); await R.F.evaluate(() => { const e = document.getElementById('xad'); e && e.scrollIntoView({block:'start', behavior:'smooth'}); window.scrollBy(0, -120); }); await sleep(900);
     await HB(R, 'xad2', inner('^Adulti in staff'), 1.3, 2.5);
     await HB(R, 'xal', "const s = [...document.querySelectorAll('#main-app strong, #main-app b')].find(e => e.offsetParent && /Attenzione ai dati personali/.test(e.textContent)); return s && s.parentElement", 8.0, 29.9);
     await HB(R, 'xr2', ROWT(1), 30.6, 32.8);
     await tg(R, 'xup', CTL(1, 0)); await R.move('#xup', {ms:500, scroll:false}); await R.at(34.0); await ck(R, '#xup', {ms:50}); await sleep(500); await tg(R, 'xdn', "const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent); return t.querySelectorAll('tbody tr')[0].querySelectorAll('button')[1]"); await R.move('#xdn', {ms:300, scroll:false}); await R.at(34.9); await ck(R, '#xdn', {ms:50}); await RS(R); await sleep(400);
     await tg(R, 'xrs', CTL(1, 2)); await R.move('#xrs', {ms:400, scroll:false}); await R.at(36.1); await H(R, '#xrs'); await R.at(37.2); await R.hlOff(); await RS(R); await tg(R, 'xrs', CTL(1, 2));
     await R.at(37.4); await R.selOpen('#xrs', {fast:true}); await R.at(39.0); await R.selHover('Altro…', 300); await R.at(39.6); await R.selPick('#xrs', 'VCU', true); await RS(R);
     await TYR(R, 3, 'Marco Rossi', 40.4); await TYR(R, 4, 'marco@x.it', 41.0); await TYR(R, 5, '347 1234567', 41.8);
     await tg(R, 'xag', CTL(1, 6)); await R.move('#xag', {ms:200, scroll:false}); await R.at(42.8); await R.F.selectOption('#xag', {label:'24'}); await RS(R);
     await R.at(43.8); await HS(R, 330);
     await HB(R, 'xh1', THX('formazione'), 46.4, 47.2); await HB(R, 'xh2', THX('caratteristiche'), 47.2, 48.9);
     await R.at(48.9); await HS(R, 600);
     await HB(R, 'xh3', THX('professioni'), 49.0, 50.9); await HB(R, 'xh4', THX('ruoli passati'), 51.1, 52.0);
     await R.at(52.0); await HS(R, 800);
     await HB(R, 'xh5', THX('disponibilit'), 52.1, 53.1); await HB(R, 'xh6', THX('varie'), 53.2, 56.8);
     await tg(R, 'xdl', "const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent); const b = [...t.querySelectorAll('tbody tr')][1].querySelector('button:last-of-type'); return [...t.querySelectorAll('tbody tr')][1].querySelector('td:last-child button')"); await R.move('#xdl', {ms:600, scroll:false}); await R.at(58.6); await H(R, '#xdl'); await R.at(59.4); await R.hlOff(); await RS(R); await ck(R, '#xdl', {ms:50}); await sleep(500);
     await tg(R, 'xar', BS('+ Aggiungi riga')); await R.move('#xar', {ms:500, scroll:false}); await R.at(60.1); await H(R, '#xar'); await sleep(500); await R.hlOff(); await RS(R); }} ]),
sb('b05', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'})); await R.moveTo(760, 520, 1200); }} ]),
];
