// Video 5: dispositivi, testo, guida
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'08s', title:'Come osservo: il KOS 2.0 e la griglia osservativa', caption:'PEE CNGEI · Osservare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts08.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const LFP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const KSUM = "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Apri le attività del KOS/.test(s.innerText))";
const KCB = i => "const d = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Apri le attività del KOS/.test(s.innerText)).parentElement; return d.querySelectorAll('input[type=checkbox]')[" + i + "]";
const TAP = p => "const e = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + ")); return e && e.parentElement";
const CSC = async (R, id, blk = 'center') => { await R.F.evaluate(([id, blk]) => { const e = document.getElementById(id); e && e.scrollIntoView({block:blk, behavior:'smooth'}); }, [id, blk]); await sleep(800); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Come funziona', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'xcp', "return [...document.querySelectorAll('#sh-side .sh-gh')].find(e => e.offsetParent && /Osservare/i.test(e.innerText))"); await R.move('#xcp', {ms:400, scroll:false}); await RS(R); await ck(R, '#xcp', {ms:50}); await sleep(400);
     await NAVI(R, 'Come osservo', 0.4);
     await R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); }); await sleep(300);
     await tg(R, 'xtd', LEAF('^Come funziona — ')); await R.move('.tutorial-hdr:visible', {ms:500, scroll:false}); await R.at(2.8); await H(R, '.tutorial-hdr:visible'); await R.at(3.9); await R.hlOff(); await RS(R); await R.at(4.0); await ck(R, '.tutorial-hdr:visible', {ms:50}); await sleep(600);
     await HB(R, 'xl0', LIT('Cosa fare'), 4.8, 12.8); await HB(R, 'xl1', LIT('Cosa si aspettano'), 13.3, 22.9); await HB(R, 'xl2', LIT('Per compilare bene', 0), 24.0, 33.3); await HB(R, 'xl3', LIT('Per compilare bene', 1), 34.0, 40.7); await sleep(300); }} ]),
sb('b03', 'Tipo di osservazione e gruppo osservato', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); });
     await sleep(500); await R.F.evaluate(() => window.scrollTo({top:120, behavior:'smooth'})); await sleep(800);
     await HB(R, 'xtp', inner('^Tipo di osservazione'), 1.0, 2.5);
     await HB(R, 'xin', BS('Osservazione individuale'), 2.6, 6.9); await HB(R, 'xco', BS('Osservazione condivisa'), 7.2, 12.8);
     await HB(R, 'xq', LFP('^Il gruppo osservato corrisponde', 1), 16.2, 21.6);
     await tg(R, 'xpa', "return [...document.querySelectorAll('#main-app label')].find(e => e.offsetParent && /In parte/.test(e.innerText))"); await R.move('#xpa', {ms:600, scroll:false}); await R.at(22.2); await R.hlOff(); await R.at(24.3); await ck(R, '#xpa', {ms:50}); await RS(R); await sleep(700);
     await HB(R, 'xlm', LFP('^Limiti dell.osservazione', 1), 25.6, 31.5);
     await HB(R, 'xpt', "const e = [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && /pit-stop/.test(x.textContent)); return e", 37.1, 41.0); await sleep(300); }} ]),
sb('b04', 'Il percorso osservativo del KOS 2.0', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'xks', KSUM); await CSC(R, 'xks', 'center'); await R.move('#xks', {ms:500, scroll:false}); await R.at(3.4); await ck(R, '#xks', {ms:50}); await sleep(700);
     await R.F.evaluate(() => { const e = document.getElementById('xks'); e && e.scrollIntoView({block:'start', behavior:'smooth'}); window.scrollBy(0, -90); }); await sleep(700);
     await HB(R, 'xch', LFP('Il KOS è fatto di 3 incontri', 1), 4.4, 11.4);
     await HB(R, 'xob', LFP('Non è obbligatorio fare tutto', 1), 17.7, 38.0);
     await tg(R, 'xi1', LFP('^Incontro 1 · una riunione in sede', 1)); await CSC(R, 'xi1', 'start'); await R.F.evaluate(() => window.scrollBy(0, -120)); await sleep(500);
     await HB(R, 'xi1b', LFP('^Incontro 1 · una riunione in sede', 1), 38.9, 40.5);
     await HB(R, 'xm1', LFP('^Chi sono', 1), 40.6, 45.0);
     await tg(R, 'xcs', "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Come si svolge/.test(s.innerText))"); await R.move('#xcs', {ms:600, scroll:false}); await R.at(46.0); await ck(R, '#xcs', {ms:50}); await RS(R); await sleep(600);
     await HB(R, 'xcb', "const s = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Come si svolge/.test(s.innerText)); return s && s.parentElement", 47.3, 50.6);
     await tg(R, 'xpp', LFP('Percorso Promessa · profondo', 1)); await CSC(R, 'xpp', 'center');
     await HB(R, 'xpp2', LFP('Percorso Promessa · profondo', 1), 53.7, 56.7);
     await tg(R, 'xc1', KCB(1)); await R.move('#xc1', {ms:500, scroll:false}); await R.at(57.9); await ck(R, '#xc1', {ms:50}); await RS(R);
     await tg(R, 'xc2', KCB(2)); await R.move('#xc2', {ms:300, scroll:false}); await R.at(59.2); await ck(R, '#xc2', {ms:50}); await RS(R); await sleep(500); }} ]),
sb('b05', 'Tecniche per osservare meglio', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'xtc', "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Tecniche per osservare/.test(s.innerText))"); await CSC(R, 'xtc', 'center'); await R.move('#xtc', {ms:600, scroll:false}); await R.at(1.4); await H(R, '#xtc'); await R.at(3.2); await R.hlOff(); await R.at(4.9); await ck(R, '#xtc', {ms:50}); await RS(R); await sleep(600);
     await R.F.evaluate(() => { const e = document.querySelector('[data-oid]'); }); 
     await tg(R, 'xtb', "const s = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Tecniche per osservare/.test(s.innerText)); return s && s.parentElement"); await CSC(R, 'xtb', 'start'); await R.F.evaluate(() => window.scrollBy(0, -100)); await sleep(400);
     await HB(R, 'xtb2', "const s = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Tecniche per osservare/.test(s.innerText)); return s && s.parentElement", 5.7, 29.9); await sleep(300); }} ]),
sb('b06', 'La tabella delle occasioni osservative', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'xtt', "return [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Attività \\/ incontro/.test(t.innerText))"); await CSC(R, 'xtt', 'center'); await R.move('#xtt', {ms:500, scroll:false});
     await HB(R, 'xtt2', "return [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Attività \\/ incontro/.test(t.innerText))", 2.2, 4.4);
     const TH2 = n => "const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Attività \\/ incontro/.test(t.innerText)); return [...t.querySelectorAll('th')].find(h => h.innerText.trim().startsWith(" + JSON.stringify(n) + "))";
     await HB(R, 'xt1', TH2('Data'), 5.9, 6.5); await HB(R, 'xt2', TH2('Contesto'), 6.6, 7.3); await HB(R, 'xt3', TH2('Chi ha osservato'), 7.4, 8.6); await HB(R, 'xt4', TH2('Note'), 8.7, 9.4); await HB(R, 'xt5', TH2('Cosa hai osservato'), 9.5, 14.4);
     await HB(R, 'xcd', "const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Attività \\/ incontro/.test(t.innerText)); const r = t.querySelectorAll('tbody tr')[0]; return r && r.cells[r.cells.length - 1]", 14.6, 20.6);
     await tg(R, 'xdt', "return [...document.querySelectorAll('#main-app table input[type=date]')][0]"); await R.move('#xdt', {ms:500, scroll:false}); await R.at(21.5); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); await R.F.fill('#xdt', '2026-08-10'); await RS(R); await sleep(500);
     await HB(R, 'xwr', LFP('anteriori al 1° settembre', 1), 25.0, 29.9);
     await tg(R, 'xsl', "const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Attività \\/ incontro/.test(t.innerText)); return t.querySelector('tbody select')"); await R.move('#xsl', {ms:400, scroll:false}); await R.at(30.9); await R.selOpen('#xsl', {fast:true});
     await R.at(32.2); await R.selHover('Anna Verdi', 300); await R.at(33.1); await R.selHover('Tutto lo staff', 300); await R.at(34.3); await R.selHover('Altro…', 300); await R.at(34.9); await R.selPick('#xsl', 'Tutto lo staff', true); await RS(R);
     await tg(R, 'xad', BS('+ Aggiungi attività')); await CSC(R, 'xad', 'center'); await R.move('#xad', {ms:500, scroll:false}); await R.at(38.3); await H(R, '#xad'); await R.at(39.8); await R.hlOff(); await ck(R, '#xad', {ms:50}); await RS(R); await sleep(700);
     await tg(R, 'xnm', "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith('Attività o incontro'))"); await R.move('#xnm', {ms:300, scroll:false}); await R.at(40.4); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type('Gioco di conoscenza', {delay:38}); await RS(R); await sleep(300);
     await tg(R, 'xnw', BTN('+ Nuova attività osservativa')); await CSC(R, 'xnw', 'center'); await R.move('#xnw', {ms:600, scroll:false}); await R.at(45.6); await H(R, '#xnw'); await R.at(51.0); await R.hlOff(); }} ]),
sb('b07', 'Condizioni e criteri', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'xcn', LFP('cosa può aver influito', 1)); await CSC(R, 'xcn', 'center');
     await HB(R, 'xcn2', LFP('cosa può aver influito', 1), 0.9, 2.8);
     await tg(R, 'xta', "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith('In quali condizioni'))"); await R.move('#xta', {ms:400, scroll:false}); await R.at(3.0); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type('Staff al completo, clima sereno; due ragazzi assenti al secondo incontro', {delay:36}); await RS(R);
     await HB(R, 'xcr', LFP('^Criteri di compilazione', 1), 10.1, 14.2); await sleep(300); }} ]),
sb('b08', 'La griglia osservativa', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'})); await R.moveTo(760, 420, 800);
     await NAVI(R, 'Sviluppo Personale', 12.1);
     await tg(R, 'xp8', LFP('^Rispetto e consapevolezza di sé stessi', 1)); await R.move('#xp8', {ms:600, scroll:false}); await R.at(15.0); await ck(R, '#xp8', {ms:50}); await RS(R); await sleep(900);
     await tg(R, 'xp8b', LFP('^Rispetto e consapevolezza di sé stessi', 1)); await CSC(R, 'xp8b', 'start'); await R.F.evaluate(() => window.scrollBy(0, -80)); await RS(R); await sleep(300);
     await HB(R, 'xsc', LFP('^Scala da 1 a 10', 1), 18.1, 19.3);
     await HB(R, 'xgh', LEAF('^GRIGLIA OSSERVATIVA'), 19.8, 21.0);
     await HB(R, 'xat', LFP('Attività: Chi sono', 0), 21.9, 23.5);
     await HB(R, 'xfo', TAP('Che cosa osservi in questa attività'), 23.6, 28.2);
     await HB(R, 'xpo', TAP('Che cosa hai visto fare al gruppo'), 29.8, 31.9); await HB(R, 'xmi', TAP('Quali comportamenti vorresti'), 32.0, 33.5); await HB(R, 'xno', TAP('Solo se rilevante'), 33.8, 36.3);
     await HB(R, 'xcard', "const e = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith('Che cosa osservi in questa attività')); let c = e; for(let i = 0; i < 5 && c; i++){ c = c.parentElement; if(c && getComputedStyle(c).borderLeftWidth !== '0px' && c.querySelectorAll('textarea').length >= 4) return c; } return e.parentElement.parentElement", 36.6, 42.0);
     await HB(R, 'xg2', LEAF('^GRIGLIA OSSERVATIVA'), 42.4, 47.3);
     await tg(R, 'xdl', "return document.getElementById('gr-dl-btn2')"); await CSC(R, 'xdl', 'end'); await R.move('#xdl', {ms:700, scroll:false}); await R.at(49.3); await H(R, '#xdl'); await R.at(60.0); await R.hlOff(); await RS(R); await sleep(300); }} ]),
sb('b09', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'})); await R.moveTo(760, 520, 1200); }} ]),
];
