// Video 9
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'09s', title:'La scheda di osservazione dei percorsi e la griglia', caption:'PEE CNGEI · Osservare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts09.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const LFP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const KSUM = "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText))";
const KCB = i => "const d = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText)).parentElement; return d.querySelectorAll('input[type=checkbox]')[" + i + "]";
const TAP = p => "const e = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + ")); return e && e.parentElement";
const CSC = async (R, id, blk = 'center') => { await R.F.evaluate(([id, blk]) => { const e = document.getElementById(id); e && e.scrollIntoView({block:blk, behavior:'smooth'}); }, [id, blk]); await sleep(800); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500);
  await F.evaluate(() => shGrp('Osservare')); await sleep(500);
  await F.evaluate(() => { [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && /Come osservo/.test(e.innerText)).click(); }); await sleep(1800);
  await F.evaluate(() => { const d = [...document.querySelectorAll('#main-app summary')].find(e => e.offsetParent && /Percorso osservativo/.test(e.innerText)); d.click(); }); await sleep(400);
  await F.evaluate(() => { const d = [...document.querySelectorAll('#main-app summary')].find(e => e.offsetParent && /Percorso osservativo/.test(e.innerText)).parentElement; const c = d.querySelectorAll('input[type=checkbox]'); c[1].click(); c[2].click(); }); await sleep(800);
  await F.evaluate(() => shDash()); await sleep(1500); }
const CARDH = id => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && c.querySelector('.pc-hdr')";
const CARDQ = (id, sel) => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && c.querySelector(" + JSON.stringify(sel) + ")";
const SBI = nm => "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")";
const SUMC = (id, rx) => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && [...c.querySelectorAll('summary')].find(s => new RegExp(" + JSON.stringify(rx) + ").test(s.innerText))";
const OPENC = async (R, id, t) => { await tg(R, 'xch', CARDH(id)); await CSC(R, 'xch', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await sleep(300); await R.move('#xch', {ms:500, scroll:false}); await R.at(t); await ck(R, '#xch', {ms:50}); await RS(R); await sleep(800); };
const CLOSEBOX = R => R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); });
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Come funziona e contatori', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'xcp', "return [...document.querySelectorAll('#sh-side .sh-gh')].find(e => e.offsetParent && /Osservare/i.test(e.innerText))"); await R.move('#xcp', {ms:300, scroll:false}); await RS(R); await ck(R, '#xcp', {ms:50}); await sleep(300);
     await NAVI(R, 'Sviluppo Personale', 0.3);
     await CLOSEBOX(R); await sleep(300);
     await tg(R, 'xtd', LEAF('^Come funziona — ')); await R.move('.tutorial-hdr:visible', {ms:400, scroll:false}); await R.at(3.4); await H(R, '.tutorial-hdr:visible'); await R.at(4.4); await R.hlOff(); await RS(R); await R.at(4.5); await ck(R, '.tutorial-hdr:visible', {ms:50}); await sleep(600);
     await HB(R, 'xl0', LFP('^Per ogni percorso scegli un livello', 1), 5.5, 19.0); await HB(R, 'xl1', LFP('^Non hai abbastanza elementi', 1), 19.9, 26.4); await HB(R, 'xl2', LFP('^Apri la scheda del percorso', 1), 26.9, 30.8); await HB(R, 'xl3', LFP('^I percorsi segnati dal KOS', 1), 31.4, 38.0);
     await CLOSEBOX(R); await sleep(500); await top(R); await sleep(500);
     await HB(R, 'xcn', LFP('^Percorsi osservati', 1), 38.9, 44.5);
     await HB(R, 'xoc', LFP('^Occasioni osservative:', 1), 44.9, 52.4); await sleep(300); }} ]),
sb('b03', 'Un percorso senza attività', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(400);
     await OPENC(R, 'card-P1', 4.2);
     await HB(R, 'xsc', LFP('^Scala da 1 a 10', 1), 5.5, 8.6);
     await HB(R, 'xem', "return document.querySelector('#card-P1 .gr-empty')", 9.0, 19.5);
     await HB(R, 'xal2', CARDQ('card-P1', '.gr-in'), 21.8, 27.5); await sleep(300); }} ]),
sb('b04', 'Un percorso con le attività', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xp1', CARDH('card-P1')); await R.F.evaluate(() => { const h = document.querySelector('#card-P1 .pc-hdr'); h && h.click(); }); await sleep(400); await RS(R);
     await OPENC(R, 'card-P8', 3.9);
     await tg(R, 'xs6', CARDQ('card-P8', '.sc-n[title^="6"]')); await R.move('#xs6', {ms:500, scroll:false}); await R.at(8.0); await ck(R, '#xs6', {ms:50}); await RS(R); await sleep(500);
     await HB(R, 'xgh', "const c = document.getElementById('card-P8'); return [...c.querySelectorAll('*')].find(x => x.children.length === 0 && /^GRIGLIA OSSERVATIVA/i.test(x.textContent.trim()))", 10.1, 11.5);
     await HB(R, 'xat', "const c = document.getElementById('card-P8'); return [...c.querySelectorAll('b')].find(x => /Attività/.test(x.textContent)).parentElement", 12.7, 14.4);
     await HB(R, 'xfo', TAP('Che cosa osservi in questa attività'), 15.1, 18.8);
     await tg(R, 'xsp', SUMC('card-P8', 'Scegli tra gli spunti')); await R.move('#xsp', {ms:500, scroll:false}); await R.at(20.3); await H(R, '#xsp'); await R.at(22.4); await R.hlOff(); await ck(R, '#xsp', {ms:50}); await RS(R); await sleep(600);
     const SP = (w) => "const l = [...document.querySelectorAll('#card-P8 label')].find(x => " + JSON.stringify(w) + " && x.innerText.indexOf(" + JSON.stringify(w) + ") >= 0); return l";
     await HB(R, 'xq1', SP('Accuratezza'), 23.6, 25.6); await HB(R, 'xq2', SP('Reazioni'), 25.7, 28.2); await HB(R, 'xq3', SP('Naturalezza'), 28.3, 30.2); await HB(R, 'xq4', SP('Coerenza'), 30.3, 32.3);
     await tg(R, 'xa1', SP('Accuratezza')); await R.move('#xa1', {ms:300, scroll:false}); await R.at(32.5); await ck(R, '#xa1', {ms:50}); await RS(R);
     await tg(R, 'xa2', SP('Reazioni')); await R.move('#xa2', {ms:300, scroll:false}); await R.at(33.0); await ck(R, '#xa2', {ms:50}); await RS(R); await sleep(400);
     await tg(R, 'xpo', TAP('Che cosa hai visto fare al gruppo')); await CSC(R, 'xpo', 'center'); await R.move('#xpo', {ms:400, scroll:false}); await R.at(34.9); await H(R, '#xpo'); await R.at(36.8); await R.hlOff();
     await tg(R, 'xpt', "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith('Che cosa hai visto fare al gruppo'))"); await R.at(37.1); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type('Si presentano con naturalezza e ascoltano gli altri', {delay:36}); await RS(R);
     await HB(R, 'xmi', TAP('Quali comportamenti vorresti'), 44.3, 48.3); await HB(R, 'xno', TAP('Solo se rilevante'), 48.7, 51.6); await sleep(300); }} ]),
sb('b05', 'Obiettivi, indicatori e cosa osservare', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xob', LEAF('^Obiettivi del percorso')); await CSC(R, 'xob', 'start'); await R.F.evaluate(() => window.scrollBy(0, -120)); await sleep(500);
     await HB(R, 'xob2', LB('^Obiettivi del percorso', 1), 4.2, 5.6);
     await HB(R, 'xin', LB('^Indicatori di risultato', 1), 5.8, 6.8);
     await tg(R, 'xco', SUMC('card-P8', 'Cosa osservare')); await CSC(R, 'xco', 'center'); await R.move('#xco', {ms:500, scroll:false}); await R.at(6.9); await H(R, '#xco'); await R.at(7.8); await R.hlOff(); await ck(R, '#xco', {ms:50}); await RS(R); await sleep(700);
     await HB(R, 'xcb', "const s = [...document.querySelectorAll('#card-P8 summary')].find(s => /Cosa osservare/.test(s.innerText)); return s && s.parentElement", 9.0, 14.6);
     await HB(R, 'xdo', LFP('^Dove osservarla nel KOS 2.0', 0), 14.9, 21.8); await sleep(300); }} ]),
sb('b06', 'Comunitario e Spirituale', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xnx', BS('Sviluppo Comunitario')); await CSC(R, 'xnx', 'center'); await R.move('#xnx', {ms:500, scroll:false}); await R.at(3.5); await H(R, '#xnx'); await R.at(5.2); await R.hlOff(); await R.at(5.4); await ck(R, '#xnx', {ms:50}); await RS(R); await sleep(1300); await dq(R);
     await top(R); await sleep(600);
     await HB(R, 'xc1', "return document.querySelector('#card-C1')", 6.7, 9.3);
     await tg(R, 'xns', SBI('Sviluppo Spirituale')); await R.move('#xns', {ms:500, scroll:false}); await R.at(9.9); await ck(R, '#xns', {ms:50}); await RS(R); await sleep(1300); await dq(R); await top(R); await sleep(500);
     await HB(R, 'xs1', "return document.querySelector('#card-S1')", 10.8, 12.6);
     await HB(R, 'xi1', SBI('Sviluppo Personale'), 13.4, 14.4); await HB(R, 'xi2', SBI('Sviluppo Comunitario'), 14.5, 15.8); await HB(R, 'xi3', SBI('Sviluppo Spirituale'), 15.9, 17.0);
     await OPENC(R, 'card-S1', 17.3);
     await HB(R, 'xg', "const c = document.getElementById('card-S1'); return [...c.querySelectorAll('*')].find(x => x.children.length === 0 && /^GRIGLIA OSSERVATIVA/i.test(x.textContent.trim()))", 17.8, 21.8); await sleep(300); }} ]),
sb('b07', 'Ricapitolando', [
  {t:0, run: async R => { await R.hlOff();
     await HB(R, 'xsc', LFP('^Scala da 1 a 10', 1), 1.0, 5.5);
     await HB(R, 'xg2', "const c = document.getElementById('card-S1'); return [...c.querySelectorAll('*')].find(x => x.children.length === 0 && /^GRIGLIA OSSERVATIVA/i.test(x.textContent.trim()))", 6.2, 16.4);
     await tg(R, 'xwd', BS('↓ Scarica la Scheda')); await CSC(R, 'xwd', 'end'); await R.move('#xwd', {ms:600, scroll:false}); await R.at(17.3); await H(R, '#xwd'); await R.at(23.9); await R.hlOff(); await RS(R);
     await tg(R, 'xdl', "return document.getElementById('gr-dl-btn2')"); await R.move('#xdl', {ms:500, scroll:false}); await R.at(24.9); await H(R, '#xdl'); await R.at(29.0); await R.hlOff(); await RS(R);
     await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
