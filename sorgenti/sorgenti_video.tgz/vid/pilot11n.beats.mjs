// Video 11 (nuovo): Crea le tue attività osservative
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'11n', title:'Crea le tue attività osservative', caption:'PEE CNGEI · Osservare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts11n.json', import.meta.url)));
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});

const W = R => R.P.frames().find(f => f.url() === 'about:srcdoc');
const S = async (R, nome, fn) => { try { await fn(); } catch(e) { console.log('S✗', nome, String(e).slice(0, 140)); } };
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 600, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await sleep(120); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); await sleep(o.after ?? 500); };
// evidenzia un elemento dentro il percorso guidato (riquadro annidato)
const wtag = (R, id, body) => W(R).evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(!el) return ''; if(!el.id) el.id = id; el.scrollIntoView({block:'nearest', behavior:'instant'}); return el.id; }, [id, body]);
const wh = async (R, id, body, a, b) => { const rid = await wtag(R, id, body); if(!rid) console.log('W✗', id); await R.at(a); if(rid) await R.hl({sel:'#' + rid, w:true}); await R.at(b); await R.hlOff(); };
// elementi dell'app (fuori dal percorso guidato)
const ftag = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]);
const fh = async (R, id, body, a, b, scroll = true) => { const ok = await ftag(R, id, body); if(!ok) console.log('F✗', id); if(ok && scroll) await R.F.evaluate(id => document.getElementById(id).scrollIntoView({block:'center', behavior:'smooth'}), id); await R.at(a); if(ok) await R.hl('#' + id); await R.at(b); await R.hlOff(); };
const LEAFA = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const SM = (scope, rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll(" + JSON.stringify(scope) + ")].filter(x => x.offsetParent && r.test(x.textContent.trim())); c.sort((a, b) => a.textContent.length - b.textContent.length); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const WTXT = (sel, rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); let e = [...document.querySelectorAll(" + JSON.stringify(sel) + ")].find(x => x.offsetParent && r.test(x.innerText)); for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const NEXT = R => ck(R, W(R).locator('#wnext'), {ms:500});
const OPT = (R, t) => ck(R, W(R).locator('#wbody .opt', {hasText:t}).first(), {ms:700});

export async function open(F){
  await F.evaluate(() => shOpen('p1', 0)); await sleep(4500);
  await F.evaluate(() => { gGo('1a'); window._ctxF = 'occ'; if(window.shSync) shSync(); }); await sleep(1800);
  await F.evaluate(() => window.scrollTo(0, 0));
}

export const beats = [
  sb('b01', 'Dove si trova', [{t:0, run: async R => {
    await R.hlOff(); await R.moveTo(760, 420, 600);
    await S(R, 'side', async () => { await R.at(5.3); await R.hl('#sh-side .sh-si.on, #sh-side [onclick*="1a"]'); await R.at(8.0); await R.hlOff(); });
    await S(R, 'box', async () => { await ftag(R, 'xbox', SM('#main-app h4', '^Crea le tue attività osservative', 1)); await R.at(13.6); await R.F.evaluate(() => document.getElementById('xbox').scrollIntoView({block:'start', behavior:'smooth'})); await sleep(900); await R.hl('#xbox'); await R.at(21.8); await R.hlOff(); });
    await S(R, 'nuova', async () => { await ftag(R, 'xnew', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim().startsWith('+ Nuova attività osservativa'))"); await R.at(22.6); await R.hl('#xnew'); await R.move('#xnew', {ms:700, scroll:false}); await R.at(26.4); await R.hlOff(); });
  }}]),

  sb('b02', 'Da dove parti', [{t:0, run: async R => {
    await S(R, 'apri', async () => { await ck(R, '#xnew', {ms:500, after:200}); await sleep(2200); if(!W(R)){ console.log('apri: click non ha aperto, uso la funzione'); await R.F.evaluate(() => ossWizOpen('')); await sleep(2500); } });
    await S(R, 'fasi', async () => { await wh(R, 'wf', "return document.getElementById('wfasi')", 3.2, 13.1); });
    await S(R, 'qui', async () => { await wh(R, 'wq', "return document.querySelector('#wbody .qui')", 14.5, 17.4); });
    await S(R, 'strade', async () => { await wh(R, 'wo', "return document.querySelector('#wbody .opts')", 17.9, 25.4); });
    await S(R, 'domanda', async () => { await R.at(25.8); await OPT(R, 'Ho una domanda sul gruppo'); });
    await S(R, 'avanti1', async () => { await R.at(27.3); await NEXT(R); });
    await S(R, 'periodo', async () => { await wh(R, 'wp', "return document.querySelector('#wbody .opts')", 28.0, 32.9); await R.at(33.3); await OPT(R, 'Tra i due pit stop'); });
  }}]),

  sb('b03', 'La domanda sul gruppo', [{t:0, run: async R => {
    await S(R, 'avanti2', async () => { await NEXT(R); });
    await S(R, 'scrivi', async () => { await R.at(1.0); const ta = W(R).locator('#wbody textarea').first(); await R.move(ta, {ms:500, scroll:false}); await sleep(100); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type('Quando nessuno guida il gioco, chi prende l’iniziativa o aspettano tutti?', {delay:78}); });
    await S(R, 'giudicare', async () => { await wh(R, 'wg', WTXT('#wbody .box', 'non giudicare le persone'), 9.3, 15.0); });
    await S(R, 'capito', async () => { await wh(R, 'wc', WTXT('#wbody .box', 'Ho capito questo'), 15.1, 20.2); });
    await S(R, 'altri', async () => { await wh(R, 'wa', SM('#wbody *', '^altri capi si chiedono', 1), 20.3, 26.2); });
    await S(R, 'torto', async () => { await wh(R, 'wt', WTXT('#wbody .box', 'E se avessi torto'), 26.3, 31.7); });
    await S(R, 'avanti3', async () => { await R.at(32.0); await NEXT(R); await R.at(33.8); await OPT(R, 'come stanno con gli altri'); });
  }}]),

  sb('b04', 'Il percorso', [{t:0, run: async R => {
    await S(R, 'avanti4', async () => { await NEXT(R); });
    await S(R, 'scelgo', async () => { await R.at(3.2); await R.move(W(R).locator('#wbody .prc').first(), {ms:600, scroll:false}); await R.at(5.6); await ck(R, W(R).locator('#wbody .prc').first().locator('button'), {ms:400}); });
    await S(R, 'avanti5', async () => { await R.at(8.7); await NEXT(R); });
    await S(R, 'altri', async () => { await wh(R, 'wal', "return document.querySelector('#wbody .plist') || document.querySelector('#wbody .box')", 9.5, 18.8); });
    await S(R, 'continuo', async () => { await R.at(19.0); await ck(R, W(R).locator('#wbody button', {hasText:'Va bene così'}).first(), {ms:500}); });
  }}]),

  sb('b05', 'Il focus', [{t:0, run: async R => {
    await S(R, 'avanti5b', async () => { await NEXT(R); });
    await S(R, 'frasi', async () => { await wh(R, 'wpr', "return document.querySelector('#wbody .pronta')", 8.9, 13.3); });
    await S(R, 'uso', async () => { await R.at(13.9); await ck(R, W(R).locator('.pronta button', {hasText:'Uso questa'}).first(), {ms:600}); });
    await S(R, 'aggiungi', async () => { await R.at(16.3); await ck(R, W(R).locator('#wbody .btn-primary', {hasText:'Aggiungi questo focus'}).first(), {ms:500}); });
    await S(R, 'lente', async () => { await wh(R, 'wl', "return document.getElementById('wlente')", 18.7, 21.0); });
  }}]),

  sb('b06', 'Durata, chi osserva e strumenti', [{t:0, run: async R => {
    await S(R, 'avanti6', async () => { await NEXT(R); });
    await S(R, 'ora', async () => { await R.at(3.7); await ck(R, W(R).locator('#wbody .pill', {hasText:/^1 ora$/}).first(), {ms:600}); });
    await S(R, 'persone', async () => { await R.at(5.1); const n = W(R).locator('#wbody input[type=number]').first(); await R.move(n, {ms:500, scroll:false}); await sleep(100); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type('20', {delay:120}); });
    await S(R, 'osserva', async () => { await wh(R, 'wos', WTXT('#wbody *', 'CHI OSSERVA', 1), 6.7, 8.7); });
    await S(R, 'avviso', async () => { await wh(R, 'wav', "return document.getElementById('osslive')", 9.0, 20.4); });
    await S(R, 'avanti7', async () => { await R.at(20.6); await NEXT(R); });
    await S(R, 'strumenti', async () => { await wh(R, 'wst', "return document.querySelector('#wbody .stools') || document.querySelector('#wbody .grp')", 23.0, 29.7); });
    await S(R, 'avanti8', async () => { await R.at(30.0); await NEXT(R); });
    await S(R, 'kos', async () => { await wh(R, 'wk', WTXT('#wbody *', 'Nel KOS ci sono', 0), 31.3, 36.8); });
  }}]),

  sb('b07', 'Scrivi l’attività', [{t:0, run: async R => {
    await S(R, 'avanti9', async () => { await NEXT(R); });
    await S(R, 'riepilogo', async () => { await wh(R, 'wri', WTXT('#wbody .sc', 'QUANDO', 0), 1.4, 3.6); });
    await S(R, 'spunti', async () => { await wh(R, 'wsp', WTXT('#wbody *', 'Spunti per cominciare', 1), 3.9, 7.8); });
    await S(R, 'non', async () => { await wh(R, 'wno', WTXT('#wbody *', 'Cosa questa attività non', 0), 8.1, 11.9); });
    await S(R, 'scrivi', async () => {
      await R.at(12.3);
      const els = W(R).locator('#wbody .write input, #wbody .write textarea'); const vals = ['Il gioco senza capo', 'Presento il gioco e dico che per oggi nessuno lo guida.', 'Giocano a squadre; io e lo staff osserviamo senza intervenire.', 'Cerchio finale: ognuno racconta cosa ha fatto.'];
      for(let i = 0; i < 4; i++){ const e = els.nth(i); await R.move(e, {ms:450, scroll:true}); await sleep(80); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type(vals[i].slice(0, i === 0 ? 19 : 7), {delay:45}); if(i > 0) await e.fill(vals[i]); }
    });
    await S(R, 'salva', async () => { await R.at(17.0); await ck(R, W(R).locator('#wbody .btn-primary', {hasText:'Salva l’attività'}).first(), {ms:600, after:1500}); });
    await R.F.evaluate(() => { try{ fbClose(); }catch(e){} });
    await S(R, 'card', async () => { await fh(R, 'xcard', "const e = [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && x.textContent.trim() === 'Il gioco senza capo'); let c = e; for(let i = 0; i < 6 && c; i++){ c = c.parentElement; if(c && c.querySelector('button') && /Pronta/.test(c.innerText)) return c; } return e && e.parentElement", 19.0, 29.5); });
  }}]),

  sb('b08', 'Dalle occasioni alla griglia', [{t:0, run: async R => { await R.F.evaluate(() => { try{ fbClose(); }catch(e){} });
    await S(R, 'btn', async () => { await ftag(R, 'xagg', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim().startsWith('Aggiungi alle occasioni osservative'))"); await R.F.evaluate(() => document.getElementById('xagg').scrollIntoView({block:'center', behavior:'instant'})); await sleep(400); await R.at(1.5); await ck(R, '#xagg', {ms:700, after:1200}); if(!(await R.F.locator('input[type=date]:visible').count())){ console.log('agg: click non ha aperto la finestra', await R.F.evaluate(() => !!document.getElementById('xagg') && document.getElementById('xagg').innerText)); await R.F.evaluate(() => document.getElementById('xagg').click()); await sleep(900); } });
    await S(R, 'data', async () => { await R.at(4.8); const d = R.F.locator('input[type=date]:visible').first(); await R.move(d, {ms:500, scroll:false}); await d.fill('2026-11-08'); });
    await S(R, 'chi', async () => { await fh(R, 'xchi', "return [...document.querySelectorAll('.modal *, #g-modal *')].find(x => x.offsetParent && x.children.length === 0 && /Chi ha osservato/.test(x.textContent))", 5.9, 7.0, false); });
    await S(R, 'perc', async () => { await fh(R, 'xpe', SM('body *', '^Quali percorsi avete osservato', 1), 7.3, 12.5, false); });
    await S(R, 'conferma', async () => { await R.at(13.6); await ck(R, R.F.locator('button', {hasText:/^Conferma$/}).first(), {ms:600, after:1500}); });
    await S(R, 'svolta', async () => { await fh(R, 'xsv', "const e = [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && x.textContent.trim() === 'Svolta'); return e && e.parentElement && e.parentElement.parentElement", 14.8, 16.8); });
    await S(R, 'tabella', async () => { await fh(R, 'xtb', "return [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Attività \\/ incontro/.test(t.innerText))", 17.0, 21.0); });
    await S(R, 'griglia', async () => {
      await R.at(21.3); await ck(R, R.F.locator('#sh-side [onclick]', {hasText:'Sviluppo Comunitario'}).first(), {ms:600, after:1500});
      await R.at(22.6); await ftag(R, 'xlead', SM('#main-app *', '^Leadership collaborativa')); await R.F.evaluate(() => document.getElementById('xlead').scrollIntoView({block:'center', behavior:'smooth'})); await sleep(700); await ck(R, '#xlead', {ms:600, after:900});
      await fh(R, 'xfo', "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && /Che cosa osservi/.test(e.placeholder))", 23.6, 26.0);
    });
    await S(R, 'riepilogo', async () => { await R.at(26.4); await ck(R, R.F.locator('#sh-side [onclick]', {hasText:'Come osservo'}).first(), {ms:600, after:1200}); await fh(R, 'xri', "return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && /^Riepilogo: che cosa hai osservato/.test(x.textContent.trim()))", 27.2, 35.9); });
  }}]),

  sb('b09', 'Cosa puoi farne', [{t:0, run: async R => { await R.F.evaluate(() => { try{ fbClose(); }catch(e){} });
    await S(R, 'azioni', async () => { await fh(R, 'xaz', "const b = [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim() === 'JSON'); return b && b.parentElement", 0.4, 7.4); });
    await S(R, 'togli', async () => { await fh(R, 'xto', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim().startsWith('Togli dalle occasioni osservative'))", 7.8, 11.3, false); });
  }}]),
];
