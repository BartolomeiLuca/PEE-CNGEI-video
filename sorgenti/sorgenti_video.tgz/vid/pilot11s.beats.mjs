// Video 11
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'11s', title:'Lettura del gruppo e Priorità', caption:'PEE CNGEI · Osservare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts11.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const LFP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const KSUM = "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText))";
const KCB = i => "const d = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText)).parentElement; return d.querySelectorAll('input[type=checkbox]')[" + i + "]";
const TAP = p => "const e = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + ")); return e && e.parentElement";
const CSC = async (R, id, blk = 'center') => { await R.F.evaluate(([id, blk]) => { const e = document.getElementById(id); e && e.scrollIntoView({block:blk, behavior:'smooth'}); }, [id, blk]); await sleep(800); };
const CARDH = id => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && c.querySelector('.pc-hdr')";
const CARDQ = (id, sel) => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && c.querySelector(" + JSON.stringify(sel) + ")";
const SBI = nm => "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")";
const SUMC = (id, rx) => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && [...c.querySelectorAll('summary')].find(s => new RegExp(" + JSON.stringify(rx) + ").test(s.innerText))";
const OPENC = async (R, id, t) => { await tg(R, 'xch', CARDH(id)); await CSC(R, 'xch', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await sleep(300); await R.move('#xch', {ms:500, scroll:false}); await R.at(t); await ck(R, '#xch', {ms:50}); await RS(R); await sleep(800); };
const CLOSEBOX = R => R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); });
const FONS = "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /^Fonti/i.test(s.innerText.trim()))";
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500);
  await F.evaluate(() => shGrp('Osservare')); await sleep(500);
  await F.evaluate(() => { [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && /Come osservo/.test(e.innerText)).click(); }); await sleep(1800);
  await F.evaluate(() => { const d = [...document.querySelectorAll('#main-app summary')].find(e => e.offsetParent && /Percorso osservativo/.test(e.innerText)); d.click(); }); await sleep(400);
  await F.evaluate(() => { const d = [...document.querySelectorAll('#main-app summary')].find(e => e.offsetParent && /Percorso osservativo/.test(e.innerText)).parentElement; const c = d.querySelectorAll('input[type=checkbox]'); c[1].click(); c[2].click(); }); await sleep(800);
  await F.evaluate(() => { const v = {P1:3,P2:5,P3:7,P4:2,P5:6,P6:8,P7:4,P8:6,C1:5,C2:3,C3:7,C4:2,C5:6,C6:4,C7:8,C8:5,S1:4,S2:6,S3:9,S4:3,S5:5,S6:2,S7:7,S8:6}; for(const k in v) setObs(k, v[k]); }); await sleep(800);
  await F.evaluate(() => { [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === 'Sviluppo Personale').click(); }); await sleep(1800);
  await F.evaluate(() => toggleCard('P8')); await sleep(700);
  await F.evaluate(() => { const set = (p, v) => { const t = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(p)); if(t){ t.value = v; t.dispatchEvent(new Event('input', {bubbles:true})); } }; set('Che cosa hai visto fare al gruppo', 'Si presentano con naturalezza e ascoltano gli altri'); set('Quali comportamenti vorresti', 'Reagire ai complimenti senza minimizzare'); }); await sleep(900);
  await F.evaluate(() => toggleCard('P8')); await sleep(500);
  await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Lettura del gruppo e Fonti', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'xcp', "return [...document.querySelectorAll('#sh-side .sh-gh')].find(e => e.offsetParent && /Osservare/i.test(e.innerText))"); await R.move('#xcp', {ms:300, scroll:false}); await RS(R); await ck(R, '#xcp', {ms:50}); await sleep(300);
     await NAVI(R, 'Lettura del gruppo', 0.3); await CLOSEBOX(R); await sleep(300);
     await HB(R, 'xti', LFP('^Come siamo messi', 1), 4.0, 13.2);
     await tg(R, 'xtd', LEAF('^Come funziona — ')); await R.move('.tutorial-hdr:visible', {ms:400, scroll:false}); await R.at(15.1); await H(R, '.tutorial-hdr:visible'); await R.at(16.3); await R.hlOff(); await RS(R); await R.at(16.5); await ck(R, '.tutorial-hdr:visible', {ms:50}); await sleep(500);
     await R.at(17.3); await ck(R, '.tutorial-hdr:visible', {ms:50}); await sleep(500);
     await tg(R, 'xfo', FONS); await CSC(R, 'xfo', 'center'); await R.move('#xfo', {ms:400, scroll:false}); await R.at(19.2); await H(R, '#xfo'); await R.at(22.8); await R.hlOff(); await R.at(23.7); await ck(R, '#xfo', {ms:50}); await RS(R); await sleep(700);
     await HB(R, 'xfb', "const s = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /^Fonti/i.test(s.innerText.trim())); return s && s.parentElement", 24.4, 30.4); await sleep(300); }} ]),
sb('b03', 'Profilo e copertura', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xfc', FONS); await R.F.evaluate(() => { const s = document.getElementById('xfc'); if(s && s.parentElement.open) s.click(); }); await RS(R); await sleep(500);
     await tg(R, 'xpf', LB('^Profilo', 2)); await CSC(R, 'xpf', 'center'); await HB(R, 'xpf2', LB('^Profilo', 2), 0.6, 10.8);
     await tg(R, 'xch', "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /^Chiavi di lettura/i.test(s.innerText.trim()))"); await CSC(R, 'xch', 'center'); await R.move('#xch', {ms:500, scroll:false}); await R.at(12.2); await H(R, '#xch'); await R.at(14.4); await R.hlOff(); await ck(R, '#xch', {ms:50}); await RS(R); await sleep(500);
     await tg(R, 'xcv', "return document.querySelector('.rie-radar-title')"); await CSC(R, 'xcv', 'start'); await R.F.evaluate(() => window.scrollBy(0, -60)); await sleep(500);
     await HB(R, 'xcv2', "const t = document.querySelector('.rie-radar-title'); return t && t.parentElement.parentElement", 16.3, 29.4); await sleep(300); }} ]),
sb('b04', 'Dall\u2019osservazione all\u2019azione', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xaz', "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /ALL.AZIONE/i.test(s.innerText))"); await CSC(R, 'xaz', 'center'); await R.move('#xaz', {ms:500, scroll:false}); await R.at(2.0); await H(R, '#xaz'); await R.at(4.8); await R.hlOff(); await R.at(5.2); await ck(R, '#xaz', {ms:50}); await RS(R); await sleep(800);
     await tg(R, 'xaz2', "const s = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /ALL.AZIONE/i.test(s.innerText)); return s && s.parentElement"); await CSC(R, 'xaz2', 'start'); await R.F.evaluate(() => window.scrollBy(0, -80)); await sleep(500);
     await HB(R, 'xaz3', "const s = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /ALL.AZIONE/i.test(s.innerText)); return s && s.parentElement", 6.0, 9.0);
     await HB(R, 'xco', LB('^Corporeità$', 2), 9.6, 10.9);
     await HB(R, 'xcn', LB('^Cosa notare', 1), 11.3, 16.4); await HB(R, 'xat', LB('^Attenzione a', 1), 17.2, 22.3); await HB(R, 'xsp', LB('^Uno spunto', 1), 23.5, 28.4); await sleep(300); }} ]),
sb('b05', 'La tua lettura e Proponi bozza', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xh3', "return [...document.querySelectorAll('#main-app h3')].find(h => /^1\\.3/.test(h.innerText.trim()))"); await CSC(R, 'xh3', 'start'); await R.F.evaluate(() => window.scrollBy(0, -20)); await sleep(500);
     await HB(R, 'xh3b', "return [...document.querySelectorAll('#main-app h3')].find(h => /^1\\.3/.test(h.innerText.trim()))", 0.3, 3.9);
     await HB(R, 'xdi', TAP('Come si relaziona il gruppo'), 4.3, 10.9);
     await tg(R, 'xtb', "return [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Aspetti positivi emersi/.test(t.innerText))"); await CSC(R, 'xtb', 'center');
     await HB(R, 'xtb2', "return [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Aspetti positivi emersi/.test(t.innerText))", 11.4, 16.3);
     await tg(R, 'xbz', "return [...document.querySelectorAll('#main-app .oss-resync')].find(b => b.offsetParent)"); await R.move('#xbz', {ms:600, scroll:false}); await R.at(18.7); await H(R, '#xbz'); await R.at(21.0); await R.hlOff(); await R.at(21.4); await ck(R, '#xbz', {ms:50}); await RS(R); await sleep(900);
     await HB(R, 'xrw', "const t = [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Aspetti positivi emersi/.test(t.innerText)); return t.querySelectorAll('tbody tr')[0]", 23.5, 28.4);
     await tg(R, 'xcr', LFP('^Criteri di compilazione', 1)); await CSC(R, 'xcr', 'center'); await HB(R, 'xcr2', LFP('^Criteri di compilazione', 1), 36.6, 48.6); await sleep(300); }} ]),
sb('b06', 'Priorità', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await NAVI(R, 'Priorità', 0.4); await CLOSEBOX(R); await sleep(300);
     await HB(R, 'xrg', LFP('^Regola PEE', 1), 1.4, 10.4);
     await HB(R, 'xgp', LB('^Sviluppo Personale', 3), 11.1, 15.6);
     const PK = async (id, nm, a) => { await tg(R, id, LFP('^' + nm + '$', 0)); await CSC(R, id, 'center'); await R.move('#' + id, {ms:500, scroll:false}); await R.at(a); await ck(R, '#' + id, {ms:50}); await RS(R); await sleep(600); };
     await PK('xk1', 'Progettualità', 17.9);
     await PK('xk2', 'Valorizzazione delle diversità', 22.9);
     await PK('xk3', 'Vivere le proprie scelte', 26.3);
     await tg(R, 'xpe0', LB('^Perché queste priorità', 1)); await CSC(R, 'xpe0', 'center'); await HB(R, 'xpe', LB('^Perché queste priorità', 1), 29.0, 34.8);
     await tg(R, 'xpt', "const t = [...document.querySelectorAll('#main-app textarea')].find(e => e.placeholder.startsWith('Perché hai scelto proprio')); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t"); await CSC(R, 'xpt', 'center'); await R.move('#xpt', {ms:300, scroll:false}); await R.at(35.2); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type('Sono i percorsi meno emersi del gruppo', {delay:36}); await RS(R); await sleep(300); }} ]),
sb('b07', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
