// Video 12
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'12s', title:'Le tre Branche a confronto', caption:'PEE CNGEI · Osservare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts12.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const LFP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const KSUM = "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Apri le attività del KOS/.test(s.innerText))";
const KCB = i => "const d = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Apri le attività del KOS/.test(s.innerText)).parentElement; return d.querySelectorAll('input[type=checkbox]')[" + i + "]";
const TAP = p => "const e = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + ")); return e && e.parentElement";
const CSC = async (R, id, blk = 'center') => { await R.F.evaluate(([id, blk]) => { const e = document.getElementById(id); e && e.scrollIntoView({block:blk, behavior:'smooth'}); }, [id, blk]); await sleep(800); };
const CARDH = id => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && c.querySelector('.pc-hdr')";
const SUMC = (id, rx) => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && [...c.querySelectorAll('summary')].find(s => new RegExp(" + JSON.stringify(rx) + ").test(s.innerText))";
const CLOSEBOX = R => R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); });
const OPENC = async (R, id, t) => { await tg(R, 'xch', CARDH(id)); await CSC(R, 'xch', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await sleep(300); await R.move('#xch', {ms:500, scroll:false}); await R.at(t); await ck(R, '#xch', {ms:50}); await RS(R); await sleep(800); };
const OPENP = async (R, pid, name, t0, t1) => {
  await R.hlOff(); await top(R);
  const ok = await tg(R, 'xpj', "return [...document.querySelectorAll('a, button')].find(a => a.offsetParent && a.innerText.trim() === 'Progetti')");
  if(ok){ await R.move('#xpj', {ms:500, scroll:false}); await R.at(t0); await ck(R, '#xpj', {ms:50}); await RS(R); await sleep(900);
    const ok2 = await tg(R, 'xpn', "const r = new RegExp(" + JSON.stringify(name) + "); const l = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent)).pop(); let c = l; while(c && !([...c.querySelectorAll('button')].some(b => /^(Apri|Continua)$/.test(b.innerText.trim())))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => /^(Apri|Continua)$/.test(b.innerText.trim()))"); if(ok2){ await CSC(R, 'xpn', 'center'); await R.move('#xpn', {ms:500, scroll:false}); await R.at(t1); await ck(R, '#xpn', {ms:50}); await RS(R); await sleep(1700); await dq(R); return; } }
  await R.F.evaluate(pid => { try{ scheda._p2Seen = true; }catch(e){} shOpen(pid, 0); }, pid); await sleep(3500); };
const GRC = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'La mia unità'); if(!v){ try{ shGrp('Capire'); }catch(e){} } }); await sleep(400); };
const GRP = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'Come osservo'); if(!v){ try{ shGrp('Osservare'); }catch(e){} } }); await sleep(400); };
const KOSOPEN = async (R, t0, t1) => { await tg(R, 'xks', KSUM); await CSC(R, 'xks', 'center'); await R.move('#xks', {ms:500, scroll:false}); await R.at(t0); await H(R, '#xks'); await R.at(t1); await R.hlOff(); await ck(R, '#xks', {ms:50}); await RS(R); await sleep(700); };
const COSA = async (R, tclick, ta, tb, tc, td) => { await tg(R, 'xco', SUMC('card-P1', 'Cosa osservare')); await CSC(R, 'xco', 'center'); await R.move('#xco', {ms:500, scroll:false}); await R.at(tclick); await ck(R, '#xco', {ms:50}); await RS(R); await sleep(700);
  await HB(R, 'xcb', "const s = [...document.querySelectorAll('#card-P1 summary')].find(s => /Cosa osservare/.test(s.innerText)); return s && s.parentElement", ta, tb);
  await HB(R, 'xdo', LFP('^Dove osservarla nel KOS 2.0', 0), tc, td); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Branca E: il Reparto', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await GRP(R);
     await R.move('header.hdr', {ms:600, scroll:false}); await R.at(3.8); await H(R, 'header.hdr'); await R.at(5.6); await R.hlOff();
     await NAVI(R, 'Come osservo', 8.6); await CLOSEBOX(R);
     await KOSOPEN(R, 10.0, 12.2);
     await HB(R, 'xi1', LFP('^Incontro 1 · una riunione in sede', 1), 15.4, 17.0);
     await NAVI(R, 'Sviluppo Personale', 17.9); await CLOSEBOX(R);
     await OPENC(R, 'card-P1', 20.4);
     await COSA(R, 21.6, 22.9, 32.3, 33.1, 39.5); await sleep(300); }} ]),
sb('b03', 'Branca L: il Branco', [
  {t:0.00, run: async R => { await OPENP(R, 'p2', 'Branco Seeonee', 0.4, 1.8); await GRP(R);
     await R.move('header.hdr', {ms:500, scroll:false}); await R.at(4.01); await H(R, 'header.hdr'); await R.at(5.86); await R.hlOff();
     await NAVI(R, 'Come osservo', 8.6); await CLOSEBOX(R);
     await KOSOPEN(R, 10.6, 12.2);
     await HB(R, 'xi1', LFP('^Incontro 1 · una riunione in sede', 1), 13.8, 15.4);
     await NAVI(R, 'Sviluppo Personale', 15.6); await CLOSEBOX(R);
     await OPENC(R, 'card-P1', 16.6);
     await COSA(R, 17.4, 18.3, 28.3, 28.6, 35.0); await sleep(300); }} ]),
sb('b04', 'Branca R: la Compagnia', [
  {t:0, run: async R => { await OPENP(R, 'p3', 'Compagnia Orion', 0.1, 0.9); await GRP(R);
     await R.move('header.hdr', {ms:500, scroll:false}); await R.at(3.8); await H(R, 'header.hdr'); await R.at(5.4); await R.hlOff();
     await NAVI(R, 'Come osservo', 6.0); await CLOSEBOX(R);
     await KOSOPEN(R, 7.6, 9.4);
     await NAVI(R, 'Sviluppo Personale', 9.5); await CLOSEBOX(R);
     await OPENC(R, 'card-P1', 9.9);
     await COSA(R, 10.4, 12.0, 20.3, 20.8, 27.5); await sleep(300); }} ]),
sb('b05', 'Il mio staff', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await GRC(R); await NAVI(R, 'Il mio staff', 0.2); await CLOSEBOX(R); await sleep(400);
     await HB(R, 'xst', "return [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Ruolo/i.test(t.innerText))", 2.1, 7.9);
     await OPENP(R, 'p2', 'Branco Seeonee', 8.2, 8.9); await GRC(R);
     await NAVI(R, 'Il mio staff', 10.0); await CLOSEBOX(R); await sleep(300);
     await HB(R, 'xgi', "return [...document.querySelectorAll('#main-app table th')].find(t => t.offsetParent && /giungla/i.test(t.innerText))", 12.7, 16.4); await sleep(300); }} ]),
sb('b06', 'Ricapitolando', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     const ok = await tg(R, 'xpj', "return [...document.querySelectorAll('a, button')].find(a => a.offsetParent && a.innerText.trim() === 'Progetti')");
     if(ok){ await R.move('#xpj', {ms:600, scroll:false}); await R.at(21.2); await ck(R, '#xpj', {ms:50}); await RS(R); await sleep(1500); }
     await R.moveTo(760, 520, 1200); }} ]),
];
