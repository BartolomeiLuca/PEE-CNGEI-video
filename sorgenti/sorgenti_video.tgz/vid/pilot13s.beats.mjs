// Video 13
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'13s', title:'Obiettivi e indicatori', caption:'PEE CNGEI · Progettare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts13.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const LFP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const KSUM = "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText))";
const KCB = i => "const d = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText)).parentElement; return d.querySelectorAll('input[type=checkbox]')[" + i + "]";
const TAP = p => "const e = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + ")); return e && e.parentElement";
const CSC = async (R, id, blk = 'center') => { await R.F.evaluate(([id, blk]) => { const e = document.getElementById(id); e && e.scrollIntoView({block:blk, behavior:'smooth'}); }, [id, blk]); await sleep(800); };
const CARDH = id => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && c.querySelector('.pc-hdr')";
const SUMC = (id, rx) => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && [...c.querySelectorAll('summary')].find(s => new RegExp(" + JSON.stringify(rx) + ").test(s.innerText))";
const CLOSEBOX = R => R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); });
const OPENC = async (R, id, t) => { await tg(R, 'xch', CARDH(id)); await CSC(R, 'xch', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await sleep(300); await R.move('#xch', {ms:500, scroll:false}); await R.at(t); await ck(R, '#xch', {ms:50}); await RS(R); await sleep(800); };
const OPENP = async (R, pid, name, t0, t1) => {
  await R.hlOff(); await top(R);
  const ok = await tg(R, 'xpj', "return [...document.querySelectorAll('a, button')].find(a => a.offsetParent && a.innerText.trim() === 'Progetti')");
  if(ok){ await R.move('#xpj', {ms:500, scroll:false}); await R.at(t0); await ck(R, '#xpj', {ms:50}); await RS(R); await sleep(900);
    const ok2 = await tg(R, 'xpn', "const r = new RegExp(" + JSON.stringify(name) + "); const l = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent)).pop(); let c = l; while(c && !([...c.querySelectorAll('button')].some(b => /^(Apri|Continua)$/.test(b.innerText.trim())))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => /^(Apri|Continua)$/.test(b.innerText.trim()))"); if(ok2){ await CSC(R, 'xpn', 'center'); await R.move('#xpn', {ms:500, scroll:false}); await R.at(t1); await ck(R, '#xpn', {ms:50}); await RS(R); await sleep(1700); await dq(R); return; } }
  await R.F.evaluate(pid => { try{ scheda._p2Seen = true; }catch(e){} shOpen(pid, 0); }, pid); await sleep(3500); };
const GRC = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'La mia unità'); if(!v){ try{ shGrp('Capire'); }catch(e){} } }); await sleep(400); };
const GRP = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'Come osservo'); if(!v){ try{ shGrp('Osservare'); }catch(e){} } }); await sleep(400); };
const KOSOPEN = async (R, t0, t1) => { await tg(R, 'xks', KSUM); await CSC(R, 'xks', 'center'); await R.move('#xks', {ms:500, scroll:false}); await R.at(t0); await H(R, '#xks'); await R.at(t1); await R.hlOff(); await ck(R, '#xks', {ms:50}); await RS(R); await sleep(700); };
const COSA = async (R, tclick, ta, tb, tc, td) => { await tg(R, 'xco', SUMC('card-P1', 'Cosa osservare')); await CSC(R, 'xco', 'center'); await R.move('#xco', {ms:500, scroll:false}); await R.at(tclick); await ck(R, '#xco', {ms:50}); await RS(R); await sleep(700);
  await HB(R, 'xcb', "const s = [...document.querySelectorAll('#card-P1 summary')].find(s => /Cosa osservare/.test(s.innerText)); return s && s.parentElement", ta, tb);
  await HB(R, 'xdo', LFP('^Dove osservarla nel KOS 2.0', 0), tc, td); };
const GRG = async (R, g, item) => { await R.F.evaluate(([g, item]) => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === item); if(!v){ try{ shGrp(g); }catch(e){} } }, [g, item]); await sleep(400); };
const SELX = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const SUMN = i => "return [...document.querySelectorAll('#main-app details.u-ob > summary')][" + i + "]";
const TYP = async (R, id, tbody, t, text, d = 36) => { await tg(R, id, tbody); await R.move('#' + id, {ms:400, scroll:false}); await R.at(t); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type(text, {delay:d}); await RS(R); await sleep(250); };
const NEED = "const t = [...document.querySelectorAll('#main-app textarea, #main-app input[type=text]')].find(e => e.offsetParent && /Quale necessit/.test(e.placeholder || '')); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const IDRED = "const t = document.querySelector('textarea.idr-ed'); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const IDRCB = i => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const ADAT = i => "return [...document.querySelectorAll('#main-app button')].filter(b => b.offsetParent && /^Adatta/.test(b.innerText.trim()))[" + i + "]";
const BSF = t => "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'La pagina e le tre priorità', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await GRG(R, 'Progettare', 'Obiettivi e indicatori');
     await NAVI(R, 'Obiettivi e indicatori', 0.9);
     await tg(R, 'xtb', "return [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent)"); await R.move('#xtb', {ms:500, scroll:false}); await R.at(4.4); await H(R, '#xtb'); await R.at(5.3); await R.hlOff(); await ck(R, '#xtb', {ms:50}); await RS(R); await sleep(700);
     await HB(R, 'xlg', LFP('^Cosa si aspettano le Linee Guida', 1), 6.4, 13.5);
     await R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); }); await sleep(500);
     await HB(R, 'xpn1', LFP('^Per ciascun Ambito di Sviluppo scegli', 0), 13.9, 17.8);
     await HB(R, 'xpn2', LFP('^Le priorità si scelgono nella Fase 2', 0), 18.0, 28.6);
     await HB(R, 'xp1', "return [...document.querySelectorAll('#main-app details.u-ob')][0]", 31.7, 34.6);
     await HB(R, 'xp2', "return [...document.querySelectorAll('#main-app details.u-ob')][1]", 35.0, 37.4);
     await HB(R, 'xp3', "return [...document.querySelectorAll('#main-app details.u-ob')][2]", 37.6, 41.2); await sleep(300); }} ]),
sb('b03', 'Necessità educativa e obiettivo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(600);
     await tg(R, 'xs1', SUMN(0)); await R.move('#xs1', {ms:600, scroll:false}); await R.at(0.5); await ck(R, '#xs1', {ms:50}); await RS(R); await sleep(900);
     await HB(R, 'xne', LFP('^Necessità educativa$', 1), 2.5, 8.9);
     await TYP(R, 'xnt', NEED, 9.6, 'Servono più occasioni di movimento e di cura di sé', 38);
     await HB(R, 'xob', LFP('^Obiettivo di percorso PEE', 0), 17.0, 20.9);
     await HB(R, 'xo1', IDRCB(0), 25.7, 29.8);
     await tg(R, 'xo2', IDRCB(1)); await R.move('#xo2', {ms:700, scroll:false}); await R.at(32.6); await sleep(200); await R.hlOff(); }} ]),
sb('b04', 'Indicatori di risultato', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xih', LFP('^Indicatori di risultato', 0)); await CSC(R, 'xih', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await sleep(400);
     await HB(R, 'xih', LFP('^Indicatori di risultato', 0), 0.4, 1.6);
     await HB(R, 'xil', IDRCB(4), 2.6, 3.4);
     await HB(R, 'xiw', "return document.getElementById('idr-warn-0')", 15.4, 19.2);
     await tg(R, 'xc2', IDRCB(5)); await R.move('#xc2', {ms:600, scroll:false}); await R.at(22.2); await ck(R, '#xc2', {ms:50}); await RS(R); await sleep(900);
     await tg(R, 'xad', ADAT(1)); await R.move('#xad', {ms:700, scroll:false}); await R.at(29.6); await ck(R, '#xad', {ms:50}); await RS(R); await sleep(900);
     await TYP(R, 'xed', IDRED, 31.2, ' anche all’aperto', 40);
     await tg(R, 'xfa', BSF('Fatto')); await R.move('#xfa', {ms:500, scroll:false}); await R.at(33.8); await ck(R, '#xfa', {ms:50}); await RS(R); await sleep(900);
     await HB(R, 'xtag', LFP('adattato', 0), 35.4, 36.9);
     await tg(R, 'xag', BSF('+ Aggiungi un indicatore tuo')); await R.move('#xag', {ms:600, scroll:false}); await R.at(39.6); await ck(R, '#xag', {ms:50}); await RS(R); await sleep(900);
     await TYP(R, 'xed2', IDRED, 41.2, 'Aiutano chi è nuovo', 30);
     await tg(R, 'xfa2', BSF('Fatto')); await R.move('#xfa2', {ms:500, scroll:false}); await R.at(42.8); await ck(R, '#xfa2', {ms:50}); await RS(R); await sleep(900); await R.moveTo(1000, 520, 800); }} ]),
sb('b05', 'Tempistica', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xtm', LFP('^Tempistica', 1)); await CSC(R, 'xtm', 'center');
     await HB(R, 'xtm', LFP('^Tempistica', 0), 2.3, 8.4);
     await HB(R, 'xtd', SELX(0) .replace('return ', 'return ').replace('[0]', '[0].parentElement'), 9.5, 12.4);
     await HB(R, 'xtw', "return document.getElementById('pri-tw-0')", 17.4, 19.8);
     await tg(R, 'xsy', SELX(3)); await R.selOpen('#xsy', {fast:true}); await R.at(20.4); await R.selHover('2027', 300); await R.selPick('#xsy', '2027', true); await RS(R);
     await tg(R, 'xsm', SELX(2)); await R.selOpen('#xsm', {fast:true}); await R.at(21.2); await R.selPick('#xsm', 'gennaio', true); await RS(R); await sleep(500);
     await HB(R, 'xcb', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /^Allunga il ciclo/.test(b.innerText.trim()))", 24.4, 26.9); await sleep(300); }} ]),
sb('b06', 'Le altre due priorità', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xs2', SUMN(1)); await CSC(R, 'xs2', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await R.move('#xs2', {ms:500, scroll:false}); await R.at(3.9); await ck(R, '#xs2', {ms:50}); await RS(R); await sleep(900);
     await tg(R, 'xs3', SUMN(2)); await CSC(R, 'xs3', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await R.move('#xs3', {ms:500, scroll:false}); await R.at(11.4); await ck(R, '#xs3', {ms:50}); await RS(R); await sleep(900);
     await tg(R, 'xbp', BSF('Percorso Personale')); await CSC(R, 'xbp', 'center'); await R.at(20.6); await H(R, '#xbp'); await R.at(24.2); await R.hlOff();
     await HB(R, 'xbb', BSF('← Priorità'), 24.6, 26.0); }} ]),
sb('b07', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
