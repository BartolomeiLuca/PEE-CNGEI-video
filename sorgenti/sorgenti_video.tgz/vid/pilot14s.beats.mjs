// Video 14
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'14s', title:'Percorso: strumenti del metodo e tempi', caption:'PEE CNGEI · Progettare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts14.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const LFP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const KSUM = "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText))";
const KCB = i => "const d = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText)).parentElement; return d.querySelectorAll('input[type=checkbox]')[" + i + "]";
const TAP = p => "const e = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + ")); return e && e.parentElement";
const CSC = async (R, id, blk = 'center') => { await R.F.evaluate(([id, blk]) => { const e = document.getElementById(id); e && e.scrollIntoView({block:blk, behavior:'smooth'}); }, [id, blk]); await sleep(800); };
const CARDH = id => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && c.querySelector('.pc-hdr')";
const SUMC = (id, rx) => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && [...c.querySelectorAll('summary')].find(s => new RegExp(" + JSON.stringify(rx) + ").test(s.innerText))";
const CLOSEBOX = R => R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); });
const OPENC = async (R, id, t) => { await tg(R, 'xch', CARDH(id)); await CSC(R, 'xch', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await sleep(300); await R.move('#xch', {ms:500, scroll:false}); await R.at(t); await ck(R, '#xch', {ms:50}); await RS(R); await sleep(800); };
const OPENP = async (R, pid, name, t0, t1) => {
  await R.hlOff(); await top(R);
  const ok = await tg(R, 'xpj', "return [...document.querySelectorAll('a, button')].find(a => a.offsetParent && a.innerText.trim() === 'Progetti')");
  if(ok){ await R.move('#xpj', {ms:500, scroll:false}); await R.at(t0); await ck(R, '#xpj', {ms:50}); await RS(R); await sleep(900);
    const ok2 = await tg(R, 'xpn', "const r = new RegExp(" + JSON.stringify(name) + "); const l = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent)).pop(); let c = l; while(c && !([...c.querySelectorAll('button')].some(b => /^(Apri|Continua)$/.test(b.innerText.trim())))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => /^(Apri|Continua)$/.test(b.innerText.trim()))"); if(ok2){ await CSC(R, 'xpn', 'center'); await R.move('#xpn', {ms:500, scroll:false}); await R.at(t1); await ck(R, '#xpn', {ms:50}); await RS(R); await sleep(1700); await dq(R); return; } }
  await R.F.evaluate(pid => { try{ scheda._p2Seen = true; }catch(e){} shOpen(pid, 0); }, pid); await sleep(3500); };
const GRC = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'La mia unità'); if(!v){ try{ shGrp('Capire'); }catch(e){} } }); await sleep(400); };
const GRP = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'Come osservo'); if(!v){ try{ shGrp('Osservare'); }catch(e){} } }); await sleep(400); };
const KOSOPEN = async (R, t0, t1) => { await tg(R, 'xks', KSUM); await CSC(R, 'xks', 'center'); await R.move('#xks', {ms:500, scroll:false}); await R.at(t0); await H(R, '#xks'); await R.at(t1); await R.hlOff(); await ck(R, '#xks', {ms:50}); await RS(R); await sleep(700); };
const COSA = async (R, tclick, ta, tb, tc, td) => { await tg(R, 'xco', SUMC('card-P1', 'Cosa osservare')); await CSC(R, 'xco', 'center'); await R.move('#xco', {ms:500, scroll:false}); await R.at(tclick); await ck(R, '#xco', {ms:50}); await RS(R); await sleep(700);
  await HB(R, 'xcb', "const s = [...document.querySelectorAll('#card-P1 summary')].find(s => /Cosa osservare/.test(s.innerText)); return s && s.parentElement", ta, tb);
  await HB(R, 'xdo', LFP('^Dove osservarla nel KOS 2.0', 0), tc, td); };
const GRG = async (R, g, item) => { await R.F.evaluate(([g, item]) => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === item); if(!v){ try{ shGrp(g); }catch(e){} } }, [g, item]); await sleep(400); };
const SELX = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const SUMN = i => "return [...document.querySelectorAll('#main-app details.u-ob > summary')][" + i + "]";
const TYP = async (R, id, tbody, t, text, d = 36) => { await tg(R, id, tbody); await R.move('#' + id, {ms:400, scroll:false}); await R.at(t); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type(text, {delay:d}); await RS(R); await sleep(250); };
const NEED = "const t = [...document.querySelectorAll('#main-app textarea, #main-app input[type=text]')].find(e => e.offsetParent && /Quale necessit/.test(e.placeholder || '')); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const IDRED = "const t = document.querySelector('textarea.idr-ed'); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const IDRCB = i => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const ADAT = i => "return [...document.querySelectorAll('#main-app button')].filter(b => b.offsetParent && /^Adatta/.test(b.innerText.trim()))[" + i + "]";
const BSF = t => "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ROWX = rx => "return [...document.querySelectorAll('#pc-card-0 tr')].find(r => r.offsetParent && r.cells[0] && new RegExp(" + JSON.stringify(rx) + ").test(r.cells[0].innerText.trim()))";
const SUMS = "return [...document.querySelectorAll('#pc-card-0 summary')].find(s => /Scegli tra gli strumenti/.test(s.innerText))";
const GHD = n => "return [...document.querySelectorAll('#pc-card-0 details div')].find(d => d.children.length === 0 && d.textContent.trim() === " + JSON.stringify(n) + ")";
const ITM = n => "const s = [...document.querySelectorAll('#pc-card-0 details label span')].find(x => x.textContent.trim() === " + JSON.stringify(n) + "); return s && s.parentElement";
const SELT = i => "return document.querySelectorAll('#perc-tm-0 select')[" + i + "]";
const CSI = async (R, id) => { await R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'instant'}); }, id); await sleep(250); };
const GHL = async (R, id, body, a, b) => { await tg(R, id, body); await CSI(R, id); await R.at(a); await H(R, '#' + id); const t0_ = Date.now(); await R.at(b); if(Date.now() - t0_ < 500) await sleep(650); await R.hlOff(); await RS(R); };
const TICK = async (R, id, name, t) => { await tg(R, id, ITM(name)); await CSI(R, id); await R.move('#' + id, {ms:300, scroll:false, dx:0.05}); await R.at(t); await ck(R, '#' + id, {ms:40, dx:0.05}); await RS(R); await sleep(200); };
const OPENS = async (R, t) => { await tg(R, 'xsu', SUMS); await CSC(R, 'xsu', 'start'); await R.F.evaluate(() => window.scrollBy(0, -80)); await sleep(300); await R.move('#xsu', {ms:300, scroll:false}); await R.at(t); await ck(R, '#xsu', {ms:50}); await RS(R); await sleep(300); };
const OPC = async (R, t) => { await tg(R, 'xph', "return document.querySelector('#pc-card-0 .pc-hdr') || document.getElementById('pc-card-0').firstElementChild"); await R.move('#xph', {ms:250, scroll:false}); await R.at(t); await ck(R, '#xph', {ms:40}); await RS(R); await sleep(300); };
const OPENQ = async (R, pid, name, t0, t1) => {
  await R.hlOff(); await top(R);
  const ok = await tg(R, 'xpj', "return [...document.querySelectorAll('a, button')].find(a => a.offsetParent && a.innerText.trim() === 'Progetti')");
  if(ok){ await R.move('#xpj', {ms:400, scroll:false}); await R.at(t0); await ck(R, '#xpj', {ms:40}); await RS(R); await sleep(550);
    const ok2 = await tg(R, 'xpn', "const r = new RegExp(" + JSON.stringify(name) + "); const l = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent)).pop(); let c = l; while(c && !([...c.querySelectorAll('button')].some(b => /^(Apri|Continua)$/.test(b.innerText.trim())))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => /^(Apri|Continua)$/.test(b.innerText.trim()))"); if(ok2){ await R.F.evaluate(() => { const e = document.getElementById('xpn'); e && e.scrollIntoView({block:'center', behavior:'instant'}); }); await sleep(200); await R.move('#xpn', {ms:350, scroll:false}); await R.at(t1); await ck(R, '#xpn', {ms:40}); await RS(R); await sleep(650); return; } }
  await R.F.evaluate(pid => { try{ scheda._p2Seen = true; }catch(e){} shOpen(pid, 0); }, pid); await sleep(2500); };
const GOP = async (R, t) => { const ok = await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === 'Percorso Personale')"); if(ok){ await R.move('#xni', {ms:400, scroll:false}); } await R.at(t); await RS(R); await R.F.evaluate(() => shPerc('P')); await sleep(450); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0.00, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'La pagina del percorso', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await GRG(R, 'Progettare', 'Percorso Personale');
     await NAVI(R, 'Percorso Personale', 1.2);
     await tg(R, 'xtb', "return [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent)"); await R.move('#xtb', {ms:500, scroll:false}); await R.at(4.2); await H(R, '#xtb'); await R.at(4.9); await R.hlOff(); await ck(R, '#xtb', {ms:50}); await RS(R); await sleep(700);
     await HB(R, 'xcf', LFP('^Cosa fare', 1), 5.4, 11.6);
     await HB(R, 'xlg', LFP('^Cosa si aspettano le Linee Guida', 1), 12.1, 22.4);
     await R.at(23.2); await R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); }); await sleep(500);
     await HB(R, 'xmn', LFP('^Il Manuale PEE chiede', 0), 24.8, 33.9);
     await HB(R, 'xpc', "return document.querySelector('#pc-card-0 .pc-hdr') || document.getElementById('pc-card-0').firstElementChild", 34.6, 37.6); await sleep(300); }} ]),
sb('b03', 'Necessità, obiettivi e indicatori', [
  {t:0.00, run: async R => { await R.hlOff();
     await tg(R, 'xph', "return document.querySelector('#pc-card-0 .pc-hdr') || document.getElementById('pc-card-0').firstElementChild"); await R.move('#xph', {ms:500, scroll:false}); await R.at(0.51); await ck(R, '#xph', {ms:50}); await RS(R); await sleep(800);
     await tg(R, 'xr1', ROWX('^Necessità educativa')); await CSC(R, 'xr1', 'center'); await R.at(2.26); await H(R, '#xr1'); await R.at(9.43); await R.hlOff(); await RS(R);
     await tg(R, 'xr2', ROWX('^Obiettivi')); await CSC(R, 'xr2', 'center'); await R.at(10.15); await H(R, '#xr2'); await R.at(15.99); await R.hlOff(); await RS(R);
     await tg(R, 'xr3', ROWX('^Indicatori di risultato')); await CSC(R, 'xr3', 'center'); await R.at(17.02); await H(R, '#xr3'); await R.at(23.17); await R.hlOff(); await RS(R); }} ]),
sb('b04', 'Strumenti del metodo', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xr4', ROWX('^Strumenti del metodo')); await CSC(R, 'xr4', 'center'); await R.at(0.5); await H(R, '#xr4'); await R.at(8.6); await R.hlOff(); await RS(R);
     await OPENS(R, 9.2);
     await GHL(R, 'xg1', GHD('Legge e Promessa'), 16.2, 17.5);
     await GHL(R, 'xg2', GHD('Programmi Progressivi e Stimolanti'), 17.7, 20.0);
     await GHL(R, 'xg3', GHD('Gruppo di Pari'), 20.2, 21.4);
     await GHL(R, 'xg4', GHD('Simbolismo e Tradizioni'), 21.5, 23.1);
     await GHL(R, 'xg5', GHD('Imparare Facendo'), 23.3, 24.6);
     await GHL(R, 'xg6', GHD('Vita all\'Aria Aperta'), 24.8, 26.2);
     await GHL(R, 'xg7', GHD('Servizio'), 26.4, 27.4);
     await TICK(R, 'xt1', 'Consiglio di Pattuglia', 35.6);
     await TICK(R, 'xt2', 'Impresa', 36.9);
     await TICK(R, 'xt3', 'Uscita', 37.9);
     await tg(R, 'xch', "return document.getElementById('strum-sel-0')"); await CSC(R, 'xch', 'start'); await R.F.evaluate(() => window.scrollBy(0, -140)); await sleep(300);
     await R.at(39.4); await H(R, '#xch'); await R.at(40.9); await R.hlOff(); await RS(R);
     await tg(R, 'xcn', SUMS); await R.at(41.0); await H(R, '#xcn'); await sleep(600); await R.hlOff(); await RS(R); }} ]),
sb('b05', 'Tempistiche', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xr5', ROWX('^Tempistiche')); await CSC(R, 'xr5', 'center'); await R.at(0.4); await H(R, '#xr5'); await R.at(1.4); await R.hlOff(); await RS(R);
     await HB(R, 'xsl', "return document.getElementById('perc-tm-0').firstElementChild.parentElement", 1.6, 4.4);
     await HB(R, 'xnt', LFP('^ripresa da', 0), 4.8, 9.6);
     await tg(R, 'xsm', SELT(2)); await R.selOpen('#xsm', {fast:true}); await R.at(15.2); await R.selHover('gennaio', 300); await R.selPick('#xsm', 'gennaio', true); await RS(R); await sleep(400);
     await HB(R, 'xrp', LFP('riprendi da', 0), 20.8, 25.2); await sleep(300); }} ]),
sb('b06', 'Le date restano allineate', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await NAVI(R, 'Obiettivi e indicatori', 8.9);
     await tg(R, 'xs1', SUMN(0)); await R.move('#xs1', {ms:500, scroll:false}); await R.at(11.0); await ck(R, '#xs1', {ms:50}); await RS(R); await sleep(900);
     await tg(R, 'xpt', "return document.getElementById('pri-tm-0').parentElement"); await CSC(R, 'xpt', 'center'); await HB(R, 'xpt', "return document.getElementById('pri-tm-0').parentElement", 12.2, 15.0); await sleep(300); }} ]),
sb('b07', 'Il Branco', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await OPENQ(R, 'p2', 'Branco Seeonee', 3.3, 4.6); await R.F.evaluate(() => { try{ shGrp('Progettare'); }catch(e){} }); await sleep(300);
     await GOP(R, 6.5); await CLOSEBOX(R); await OPC(R, 7.3);
     await OPENS(R, 8.0);
     await GHL(R, 'xi1', ITM('Parole Maestre'), 9.8, 10.8);
     await GHL(R, 'xi2', ITM('Consiglio di Akela (CdA)'), 10.9, 12.2);
     await GHL(R, 'xi3', ITM('Testa di Lupo'), 12.6, 13.5);
     await GHL(R, 'xi4', ITM('Caccia'), 13.7, 14.4);
     await GHL(R, 'xi5', ITM('Vacanze di Branco'), 14.5, 15.8);
     await GHL(R, 'xi6', ITM('Buona Azione'), 16.0, 16.5); }} ]),
sb('b08', 'La Compagnia', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await OPENQ(R, 'p3', 'Compagnia Orion', 0.2, 1.2); await R.F.evaluate(() => { try{ shGrp('Progettare'); }catch(e){} }); await sleep(300);
     await GOP(R, 3.4); await CLOSEBOX(R); await OPC(R, 4.0);
     await OPENS(R, 4.6);
     await GHL(R, 'xj1', ITM('Ronda d\'Azione'), 7.8, 8.8);
     await GHL(R, 'xj2', ITM('Carta di Compagnia'), 9.0, 10.2);
     await GHL(R, 'xj3', ITM('Hike'), 10.3, 10.8);
     await GHL(R, 'xj4', ITM('Estate Rover'), 10.9, 12.0); }} ]),
sb('b09', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
