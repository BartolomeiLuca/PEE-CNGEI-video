// Video 15
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'15s', title:'Percorso: attività, spunti e sette caratteristiche', caption:'PEE CNGEI · Progettare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts15.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const LFP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const KSUM = "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText))";
const KCB = i => "const d = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText)).parentElement; return d.querySelectorAll('input[type=checkbox]')[" + i + "]";
const TAP = p => "const e = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + ")); return e && e.parentElement";
const CSC = async (R, id, blk = 'center') => { await R.F.evaluate(([id, blk]) => { const e = document.getElementById(id); e && e.scrollIntoView({block:blk, behavior:'smooth'}); }, [id, blk]); await sleep(800); };
const CARDH = id => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && c.querySelector('.pc-hdr')";
const SUMC = (id, rx) => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && [...c.querySelectorAll('summary')].find(s => new RegExp(" + JSON.stringify(rx) + ").test(s.innerText))";
const CLOSEBOX = R => R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); });
const OPENC = async (R, id, t) => { await tg(R, 'xch', CARDH(id)); await CSC(R, 'xch', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await sleep(300); await R.move('#xch', {ms:500, scroll:false}); await R.at(t); await ck(R, '#xch', {ms:50}); await RS(R); await sleep(800); };
const OPENP = async (R, pid, name, t0, t1) => {
  await R.hlOff(); await top(R);
  const ok = await tg(R, 'xpj', "return [...document.querySelectorAll('a, button')].find(a => a.offsetParent && a.innerText.trim() === 'Progetti')");
  if(ok){ await R.move('#xpj', {ms:500, scroll:false}); await R.at(t0); await ck(R, '#xpj', {ms:50}); await RS(R); await sleep(900);
    const ok2 = await tg(R, 'xpn', "const r = new RegExp(" + JSON.stringify(name) + "); const l = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent)).pop(); let c = l; while(c && !([...c.querySelectorAll('button')].some(b => /^(Apri|Continua)$/.test(b.innerText.trim())))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => /^(Apri|Continua)$/.test(b.innerText.trim()))"); if(ok2){ await CSC(R, 'xpn', 'center'); await R.move('#xpn', {ms:500, scroll:false}); await R.at(t1); await ck(R, '#xpn', {ms:50}); await RS(R); await sleep(1700); await dq(R); return; } }
  await R.F.evaluate(pid => { try{ scheda._p2Seen = true; }catch(e){} shOpen(pid, 0); }, pid); await sleep(3500); };
const GRC = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'La mia unità'); if(!v){ try{ shGrp('Capire'); }catch(e){} } }); await sleep(400); };
const GRP = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'Come osservo'); if(!v){ try{ shGrp('Osservare'); }catch(e){} } }); await sleep(400); };
const KOSOPEN = async (R, t0, t1) => { await tg(R, 'xks', KSUM); await CSC(R, 'xks', 'center'); await R.move('#xks', {ms:500, scroll:false}); await R.at(t0); await H(R, '#xks'); await R.at(t1); await R.hlOff(); await ck(R, '#xks', {ms:50}); await RS(R); await sleep(700); };
const COSA = async (R, tclick, ta, tb, tc, td) => { await tg(R, 'xco', SUMC('card-P1', 'Cosa osservare')); await CSC(R, 'xco', 'center'); await R.move('#xco', {ms:500, scroll:false}); await R.at(tclick); await ck(R, '#xco', {ms:50}); await RS(R); await sleep(700);
  await HB(R, 'xcb', "const s = [...document.querySelectorAll('#card-P1 summary')].find(s => /Cosa osservare/.test(s.innerText)); return s && s.parentElement", ta, tb);
  await HB(R, 'xdo', LFP('^Dove osservarla nel KOS 2.0', 0), tc, td); };
const GRG = async (R, g, item) => { await R.F.evaluate(([g, item]) => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === item); if(!v){ try{ shGrp(g); }catch(e){} } }, [g, item]); await sleep(400); };
const SELX = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const SUMN = i => "return [...document.querySelectorAll('#main-app details.u-ob > summary')][" + i + "]";
const TYP = async (R, id, tbody, t, text, d = 36) => { await tg(R, id, tbody); await R.move('#' + id, {ms:400, scroll:false}); await R.at(t); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type(text, {delay:d}); await RS(R); await sleep(250); };
const NEED = "const t = [...document.querySelectorAll('#main-app textarea, #main-app input[type=text]')].find(e => e.offsetParent && /Quale necessit/.test(e.placeholder || '')); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const IDRED = "const t = document.querySelector('textarea.idr-ed'); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const IDRCB = i => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const ADAT = i => "return [...document.querySelectorAll('#main-app button')].filter(b => b.offsetParent && /^Adatta/.test(b.innerText.trim()))[" + i + "]";
const BSF = t => "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const SPL = f => "return document.querySelector('#pc-card-0 [onclick*=" + f + "]')";
const BTI = t => "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.includes(" + JSON.stringify(t) + "))";
const MOD = rx => "const r = new RegExp(" + JSON.stringify(rx.replace('^', '^\\d?')) + "); const m = document.getElementById('g-modal'); const c = [...m.querySelectorAll('*')].filter(e => e.children.length <= 1 && r.test(e.textContent.trim())); return c[0]";
const MSEL = i => "return document.getElementById('an-ov').querySelectorAll('select')[" + i + "]";
const ISC = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'instant'}); }, id).then(() => sleep(200));
const MH = async (R, id, body, a, b) => { await tg(R, id, body); await ISC(R, id); await R.at(a); await H(R, '#' + id); const t0_ = Date.now(); await R.at(b); if(Date.now() - t0_ < 450) await sleep(550); await R.hlOff(); await RS(R); };
const MCLOSE = async (R, t, mid = 'g-modal') => { await tg(R, 'xmc', "return document.getElementById('" + mid + "').querySelector('.modal-x')"); await R.move('#xmc', {ms:400, scroll:false}); await R.at(t); await ck(R, '#xmc', {ms:40}); await RS(R); await sleep(500); };
const MOPEN = async (R, id, body, t) => { await tg(R, id, body); await CSC(R, id, 'center'); await R.move('#' + id, {ms:450, scroll:false}); await R.at(t); await ck(R, '#' + id, {ms:40}); await RS(R); await sleep(900); };
const AIN = (ph) => "const t = [...document.querySelectorAll('#att-0-0 textarea')].find(e => (e.placeholder || '').startsWith(" + JSON.stringify(ph) + ")); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const ATA = (rx, up) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#att-0-0 *')].filter(e => e.offsetParent && e.children.length <= 1 && r.test(e.textContent.trim())); const t = c.find(e => !c.some(x => x !== e && e.contains(x))); let e = t; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const NX = (rx) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#att-0-0 *')].filter(e => e.offsetParent && e.children.length <= 1 && r.test(e.textContent.trim())); const t = c.find(e => !c.some(x => x !== e && e.contains(x))); let n = t && t.nextElementSibling; if(n && n.tagName === 'TEXTAREA' && n.nextElementSibling && n.nextElementSibling.classList.contains('rt-ed')) n = n.nextElementSibling; return n";
const TIPL = n => "const s = [...[...document.querySelectorAll('#att-0-0 details')].find(d => d.querySelector(':scope > summary') && /Scegli tra i tipi/.test(d.querySelector(':scope > summary').innerText)).querySelectorAll('label span')].find(x => x.textContent.trim() === " + JSON.stringify(n) + "); return s && s.parentElement";
const TIPH = n => "const d = [...document.querySelectorAll('#att-0-0 summary')].find(s => /Scegli tra i tipi/.test(s.innerText)).parentElement; return [...d.querySelectorAll('div')].find(e => e.children.length === 0 && e.textContent.trim().toLowerCase().startsWith(" + JSON.stringify(n.toLowerCase()) + "))";
const IDL = n => "const s = [...document.querySelectorAll('#att-0-0 label')].find(x => x.innerText.trim().startsWith(" + JSON.stringify(n) + ")); return s";
const CLB = (k, lab) => "const b = [...document.querySelectorAll('#cl3-0-" + k + " button')].find(b => b.innerText.trim() === " + JSON.stringify(lab) + "); return b";
const CLN = k => "const e = document.getElementById('cl3-0-" + k + "'); const t = e.parentElement.parentElement.querySelector('textarea'); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const CLR = k => "return document.getElementById('cl3-0-" + k + "').parentElement.parentElement";
const TICK2 = async (R, id, name, t) => { await tg(R, id, "const s = [...[...document.querySelectorAll('#att-0-0 details')].find(d => d.querySelector(':scope > summary') && /Scegli tra i tipi/.test(d.querySelector(':scope > summary').innerText)).querySelectorAll('label span')].find(x => x.textContent.trim() === " + JSON.stringify(name) + "); return s && s.parentElement"); await R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'instant'}); }, id); await sleep(200); await R.move('#' + id, {ms:400, scroll:false, dx:0.05}); await R.at(t); await ck(R, '#' + id, {ms:40, dx:0.05}); await RS(R); await sleep(300); };
const OPC = async (R, t) => { const closed = await R.F.evaluate(() => document.getElementById('pc-card-0').classList.contains('closed')); await tg(R, 'xph', "return document.querySelector('#pc-card-0 .pc-hdr') || document.getElementById('pc-card-0').firstElementChild"); await R.move('#xph', {ms:250, scroll:false}); await R.at(t); if(closed){ await ck(R, '#xph', {ms:40}); await sleep(700); } await RS(R); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Cerca un’attività', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await GRG(R, 'Progettare', 'Percorso Personale');
     await NAVI(R, 'Percorso Personale', 0.5); await CLOSEBOX(R); await OPC(R, 2.5);
     await tg(R, 'xcb', BTI('Cerca un')); await CSC(R, 'xcb', 'center'); await R.move('#xcb', {ms:500, scroll:false}); await R.at(4.6); await ck(R, '#xcb', {ms:50}); await RS(R); await sleep(1000);
     await MH(R, 'xm1', "return [...document.getElementById('an-ov').querySelectorAll('button')].find(b => b.innerText.trim() === 'Le mie attività')", 8.3, 9.3);
     await MH(R, 'xm2', "return [...document.getElementById('an-ov').querySelectorAll('button')].find(b => b.innerText.trim() === 'Archivio nazionale')", 9.5, 10.8);
     await MH(R, 'xm3', "return document.getElementById('an-ov').querySelector('#an-q')", 11.6, 12.8);
     await MH(R, 'xs0', MSEL(0), 13.6, 14.3); await MH(R, 'xs1', MSEL(1), 14.5, 15.2); await MH(R, 'xs2', MSEL(2), 15.4, 16.1);
     await MH(R, 'xs3', MSEL(3), 16.5, 17.6); await MH(R, 'xs4', MSEL(4), 17.9, 19.2); await MH(R, 'xs5', MSEL(5), 19.5, 20.1); await MH(R, 'xs6', MSEL(6), 20.3, 21.3);
     await MH(R, 'xs7', "return document.getElementById('an-ov').querySelector('label.an-ck')", 22.6, 26.5);
     await MH(R, 'xr1', "return [...document.getElementById('an-ov').querySelectorAll('button')].find(b => b.innerText.trim() === 'Riusa in questo progetto')", 29.4, 31.8);
     await MH(R, 'xr2', "return [...document.getElementById('an-ov').querySelectorAll('button')].find(b => b.innerText.trim() === 'Apri')", 32.8, 33.6);
     await MCLOSE(R, 34.0, 'an-ov'); }} ]),
sb('b03', 'Gli spunti', [
  {t:0, run: async R => { await R.hlOff();
     await MOPEN(R, 'xa1', SPL('attSpuntiOpen'), 4.0);
     await MH(R, 'xl1', MOD('^Lancio$'), 7.4, 8.1); await MH(R, 'xl2', MOD('^Sviluppo$'), 8.2, 8.7); await MH(R, 'xl3', MOD('^Conclusione$'), 8.8, 9.6);
     await MH(R, 'xl4', MOD('^Domande da farti$'), 10.2, 11.0); await MH(R, 'xl5', MOD('^Attenzioni$'), 11.4, 12.1); await MH(R, 'xl6', MOD('^Accorgimenti$'), 12.2, 13.0);
     await MH(R, 'xl7', "const m = document.getElementById('g-modal'); return [...m.querySelectorAll('*')].find(e => e.children.length <= 2 && /^Ambientazione\\./.test(e.textContent.trim()))", 13.4, 15.2);
     await MCLOSE(R, 15.4);
     await MOPEN(R, 'xa2', SPL('protSpuntiOpen'), 16.9);
     await MH(R, 'xp1', MOD('^Domande da farti prima dell’attività$'), 21.8, 23.4);
     await MCLOSE(R, 24.0);
     await MOPEN(R, 'xa3', SPL('tecSpuntiOpen'), 25.6);
     await MH(R, 'xt0', MOD('^Cinque elementi che non possono mancare$'), 30.0, 32.2);
     await MH(R, 'xt1', MOD('^Gradualità$'), 32.8, 33.5); await MH(R, 'xt2', MOD('^Condivisione$'), 33.6, 34.5); await MH(R, 'xt3', MOD('^Praticità$'), 34.6, 35.3); await MH(R, 'xt4', MOD('^Necessità$'), 35.4, 35.9); await MH(R, 'xt5', MOD('^Raggiungibilità$'), 36.1, 37.2);
     await MCLOSE(R, 37.4);
     await tg(R, 'xri', LFP('^Rielaborazione\\.', 1)); await CSC(R, 'xri', 'center'); await R.at(38.8); await H(R, '#xri'); await R.at(53.0); await R.hlOff(); await RS(R); }} ]),
sb('b04', 'Scrivere un’attività', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xat', "return document.querySelector('#att-0-0 > summary')"); await CSC(R, 'xat', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await R.move('#xat', {ms:500, scroll:false}); await R.at(0.9); if(!(await R.F.evaluate(() => document.getElementById('att-0-0').open))){ await ck(R, '#xat', {ms:50}); await sleep(900); } await RS(R);
     await HB(R, 'xhd', "return document.querySelector('#att-0-0 > summary')", 1.7, 9.0);
     await HB(R, 'xhd2', "return document.querySelector('#att-0-0 > summary')", 12.4, 16.1);
     await HB(R, 'xw2', ATA('^Referente dell’attività', 1), 16.6, 18.7);
     await tg(R, 'xsa', "return document.querySelectorAll('#att-0-0 select')[0]"); await R.selOpen('#xsa', {fast:true}); await R.at(19.3); await R.selHover('Anna Verdi', 300); await R.at(20.8); await R.selHover('Un’altra', 300); await R.at(22.6); await R.P.evaluate(() => ST.menuOff()); await RS(R);
     await HB(R, 'xw3', NX('^Titolo dell’attività'), 24.9, 27.3);
     await HB(R, 'xsm', ATA('^Strumenti del Metodo di questa attività', 1), 27.7, 30.6);
     await tg(R, 'xsb', "return document.querySelectorAll('#att-0-0 select')[1]"); await R.selOpen('#xsb', {fast:true}); await R.at(31.2); await R.selHover('Legge', 300); await R.at(32.3); await R.selHover('Promessa', 300); await R.at(33.6); await R.P.evaluate(() => ST.menuOff()); await RS(R);
     await tg(R, 'xtp', "return [...document.querySelectorAll('#att-0-0 summary')].find(s => /Scegli tra i tipi/.test(s.innerText))"); await CSC(R, 'xtp', 'center'); await R.move('#xtp', {ms:500, scroll:false}); await R.at(34.4); await H(R, '#xtp'); await R.at(39.3); await R.hlOff(); await R.at(39.8); await ck(R, '#xtp', {ms:50}); await RS(R); await sleep(700);
     for (const [n, a, b] of [['Gioco', 42.1, 42.6], ['Tecnica', 42.7, 43.3], ['Pattuglia e Reparto', 43.4, 44.9], ['Legge e Promessa', 44.9, 46.3], ['Progressione', 46.4, 47.4], ['Aria aperta', 47.5, 48.4], ['Servizio', 48.5, 49.3], ['Spirito e riflessione', 49.4, 50.9]]) await MH(R, 'xh', TIPH(n), a, b);
     await TICK2(R, 'xk1', 'Gioco a basi', 51.7); await TICK2(R, 'xk2', 'Consiglio di Pattuglia', 53.1);
     await MH(R, 'xla', NX('^Lancio$'), 56.2, 60.6);
     await MH(R, 'xsv', NX('^Sviluppo$'), 60.8, 61.8);
     await TYP(R, 'xts', AIN('Che cosa fanno i ragazzi'), 62.0, 'A squadre cercano gli indizi', 34);
     await MH(R, 'xcn', NX('^Conclusione'), 65.7, 66.9);
     await TYP(R, 'xtc', AIN('Come si chiude'), 67.0, 'Cerchio finale: cosa ho scoperto?', 30); await sleep(300); }} ]),
sb('b05', 'Indicatori specifici', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xpb', ATA('P1 Corporeità', 2)); await CSC(R, 'xpb', 'center'); await HB(R, 'xpb', ATA('P1 Corporeità', 2), 1.0, 5.8);
     await HB(R, 'xco', ATA('^Chi osserva$', 1), 6.3, 9.8);
     await tg(R, 'xis', "return [...document.querySelectorAll('#att-0-0 summary')].find(s => /Indicatori specifici/.test(s.innerText))"); await CSC(R, 'xis', 'center'); await R.move('#xis', {ms:500, scroll:false}); await R.at(10.4); await H(R, '#xis'); await R.at(12.6); await R.hlOff(); if(!(await R.F.evaluate(() => { const d = [...document.querySelectorAll('#att-0-0 details.att-obj, #att-0-0 details')].find(d => /Indicatori specifici/.test((d.querySelector('summary')||{}).innerText||'')); return d.open; }))){ await ck(R, '#xis', {ms:50}); await sleep(800); } await RS(R);
     await tg(R, 'xi1', IDL('Si mettono alla prova')); await CSC(R, 'xi1', 'center'); await R.move('#xi1', {ms:500, scroll:false, dx:0.06}); await R.at(18.9); await ck(R, '#xi1', {ms:50, dx:0.06}); await RS(R); await sleep(800);
     await HB(R, 'xi2', ATA('^Scelti per il percorso', 1), 26.4, 29.4);
     await tg(R, 'xtop', "return [...document.querySelectorAll('#pc-card-0 tr')].find(r => r.offsetParent && r.cells[0] && /^Indicatori di risultato/.test(r.cells[0].innerText.trim()))"); await CSC(R, 'xtop', 'center'); await HB(R, 'xtop', "return [...document.querySelectorAll('#pc-card-0 tr')].find(r => r.offsetParent && r.cells[0] && /^Indicatori di risultato/.test(r.cells[0].innerText.trim()))", 29.8, 34.2);
     await tg(R, 'xoa', "return [...document.querySelectorAll('#att-0-0 .ax-sub')].find(e => /^Osservi anche/.test(e.textContent.trim()))"); await CSC(R, 'xoa', 'center'); await HB(R, 'xoa', "return [...document.querySelectorAll('#att-0-0 .ax-sub')].find(e => /^Osservi anche/.test(e.textContent.trim()))", 35.4, 38.4);
     await tg(R, 'xos', "return [...document.querySelectorAll('#att-0-0 select')].find(s => [...s.options].some(o => /Osserva anche un indicatore/.test(o.text)))"); await R.selOpen('#xos', {fast:true}); await R.at(43.2); await R.P.evaluate(() => ST.menuOff()); await RS(R);
     await HB(R, 'xob', BTI('+ Osserva anche altro'), 44.6, 46.2); }} ]),
sb('b06', 'Aggiungere attività', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xad', BTI('+ Aggiungi attività')); await CSC(R, 'xad', 'center'); await R.move('#xad', {ms:500, scroll:false}); await R.at(5.2); await ck(R, '#xad', {ms:50}); await RS(R); await sleep(1000);
     await tg(R, 'xn5', "const d = document.getElementById('att-0-4'); if(d && !d.open) d.open = true; return d && d.querySelector('summary')"); await CSC(R, 'xn5', 'start'); await sleep(400); await RS(R);
     await tg(R, 'xt5', "const t = document.querySelector('#att-0-4 textarea'); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t"); await CSC(R, 'xt5', 'center'); await R.move('#xt5', {ms:400, scroll:false}); await R.at(10.4); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type('Staffetta dei nodi', {delay:40}); await RS(R); await sleep(400); }} ]),
sb('b07', 'Le sette caratteristiche', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xr7', "return [...document.querySelectorAll('#pc-card-0 tr')].find(r => r.offsetParent && r.cells[0] && /^Le 7 caratteristiche/.test(r.cells[0].innerText.trim()))"); await CSC(R, 'xr7', 'start'); await R.F.evaluate(() => window.scrollBy(0, -80)); await sleep(300);
     await HB(R, 'xr7', "return [...document.querySelectorAll('#pc-card-0 tr')].find(r => r.offsetParent && r.cells[0] && /^Le 7 caratteristiche/.test(r.cells[0].innerText.trim())).cells[0]", 1.3, 7.8);
     for (const [k, a, b] of [['nuova', 8.3, 9.0], ['stimolante', 9.1, 10.1], ['progressiva', 10.2, 11.3], ['costruita', 11.4, 12.5], ['rielaborativa', 12.6, 13.8], ['esperienziale', 13.9, 15.1], ['educativa', 15.2, 16.1]]) await MH(R, 'xcr', CLR(k), a, b);
     await tg(R, 'xcs', CLB('nuova', 'Sì')); await CSC(R, 'xcs', 'center'); await R.move('#xcs', {ms:450, scroll:false}); await R.at(22.8); await ck(R, '#xcs', {ms:40}); await RS(R); await sleep(500);
     await TYP(R, 'xcn1', CLN('nuova'), 24.0, 'Per chi è appena arrivato è la prima volta con la mappa', 28);
     await tg(R, 'xcp', CLB('stimolante', 'In parte')); await CSC(R, 'xcp', 'center'); await R.move('#xcp', {ms:450, scroll:false}); await R.at(29.8); await ck(R, '#xcp', {ms:40}); await RS(R); await sleep(500);
     await TYP(R, 'xcn2', CLN('stimolante'), 31.0, 'Solo due attività su quattro partono da una sfida', 28); await sleep(300); }} ]),
sb('b08', 'In fondo al percorso', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xtl', "return document.querySelector('details.tl-all > summary')"); await CSC(R, 'xtl', 'center'); await R.move('#xtl', {ms:500, scroll:false}); await R.at(0.9); await H(R, '#xtl'); await R.at(2.8); await R.hlOff(); await ck(R, '#xtl', {ms:50}); await RS(R); await sleep(700);
     await HB(R, 'xab', BTI('+ Aggiungi un altro percorso'), 9.6, 14.6);
     await HB(R, 'xvf', BTI('Verifica delle attività'), 16.3, 17.6);
     await HB(R, 'xbo', BTI('← Obiettivi e indicatori'), 19.0, 20.0); }} ]),
sb('b09', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
