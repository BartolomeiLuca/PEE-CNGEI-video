// Video 15
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'16s', title:'Ordinare le attività e Visione d’insieme', caption:'PEE CNGEI · Progettare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts16.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";


const LB = (rx, up = 0) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const BS = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HB = async (R, id, body, a, b) => { await tg(R, id, body); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); await RS(R); };
const VP = (R, w) => R.P.evaluate(w => { const a = document.getElementById('app'); a.style.transition = 'width .8s ease, margin-left .8s ease'; a.style.width = w + 'px'; a.style.marginLeft = ((1440 - w) / 2) + 'px'; }, w);
const SELW = (R, w) => R.F.evaluate(w => { const ed = document.querySelector('.rt-ed'); if(!ed) return false; ed.focus(); const tw = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n; while((n = tw.nextNode())){ const i = n.textContent.indexOf(w); if(i >= 0){ const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return true; } } return false; }, w);
const RMV = async (R, k) => { for (let i = 0; i < 3; i++) { try { await R.move('#rt-bar button[data-rt=' + k + ']', {ms:500, scroll:false}); return; } catch(e) { await R.F.evaluate(() => { try{ const ed = document.querySelector('.rt-ed'); ed.focus(); rtPlace(); }catch(e){} }); await sleep(500); } } };
const RTB = (R, k, a, b) => HB(R, 'xr' + k, "return document.querySelector('#rt-bar button[data-rt=\"" + k + "\"]')", a, b);

const LIT = (rx, n = 0) => "const s = [...document.querySelectorAll('#main-app strong')].filter(e => e.offsetParent && new RegExp(" + JSON.stringify(rx) + ").test(e.textContent)); return s[" + n + "] && s[" + n + "].closest('li')";
const NAVI = async (R, nm, t) => { await tg(R, 'xni', "return [...document.querySelectorAll('#sh-side .sh-si')].find(e => e.offsetParent && e.innerText.trim() === " + JSON.stringify(nm) + ")"); await R.move('#xni', {ms:500, scroll:false}); await R.at(t); await RS(R); await ck(R, '#xni', {ms:50}); await sleep(1300); await dq(R); };
const LFP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const KSUM = "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText))";
const KCB = i => "const d = [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo/.test(s.innerText)).parentElement; return d.querySelectorAll('input[type=checkbox]')[" + i + "]";
const TAP = p => "const e = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + ")); return e && e.parentElement";
const CSC = async (R, id, blk = 'center') => { await R.F.evaluate(([id, blk]) => { const e = document.getElementById(id); e && e.scrollIntoView({block:blk, behavior:'smooth'}); }, [id, blk]); await sleep(800); };
const CARDH = id => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && c.querySelector('.pc-hdr')";
const SUMC = (id, rx) => "const c = document.getElementById(" + JSON.stringify(id) + "); return c && [...c.querySelectorAll('summary')].find(s => new RegExp(" + JSON.stringify(rx) + ").test(s.innerText))";
const CLOSEBOX = R => R.F.evaluate(() => { const h = [...document.querySelectorAll('.tutorial-hdr')].find(e => e.offsetParent); if(h && h.getAttribute('aria-expanded') === 'true') h.click(); });
const OPENC = async (R, id, t) => { await tg(R, 'xch', CARDH(id)); await CSC(R, 'xch', 'start'); await R.F.evaluate(() => window.scrollBy(0, -90)); await sleep(300); await R.move('#xch', {ms:500, scroll:false}); await R.at(t); await ck(R, '#xch', {ms:50}); await RS(R); await sleep(800); };
const OPENP = async (R, pid, name, t0, t1) => {
  await R.hlOff(); await top(R);
  const ok = await tg(R, 'xpj', "return [...document.querySelectorAll('a, button')].find(a => a.offsetParent && a.innerText.trim() === 'Progetti')");
  if(ok){ await R.move('#xpj', {ms:500, scroll:false}); await R.at(t0); await ck(R, '#xpj', {ms:50}); await RS(R); await sleep(900);
    const ok2 = await tg(R, 'xpn', "const r = new RegExp(" + JSON.stringify(name) + "); const l = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent)).pop(); let c = l; while(c && !([...c.querySelectorAll('button')].some(b => /^(Apri|Continua)$/.test(b.innerText.trim())))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => /^(Apri|Continua)$/.test(b.innerText.trim()))"); if(ok2){ await CSC(R, 'xpn', 'center'); await R.move('#xpn', {ms:500, scroll:false}); await R.at(t1); await ck(R, '#xpn', {ms:50}); await RS(R); await sleep(1700); await dq(R); return; } }
  await R.F.evaluate(pid => { try{ scheda._p2Seen = true; }catch(e){} shOpen(pid, 0); }, pid); await sleep(3500); };
const GRC = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'La mia unità'); if(!v){ try{ shGrp('Capire'); }catch(e){} } }); await sleep(400); };
const GRP = async R => { await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === 'Come osservo'); if(!v){ try{ shGrp('Osservare'); }catch(e){} } }); await sleep(400); };
const KOSOPEN = async (R, t0, t1) => { await tg(R, 'xks', KSUM); await CSC(R, 'xks', 'center'); await R.move('#xks', {ms:500, scroll:false}); await R.at(t0); await H(R, '#xks'); await R.at(t1); await R.hlOff(); await ck(R, '#xks', {ms:50}); await RS(R); await sleep(700); };
const COSA = async (R, tclick, ta, tb, tc, td) => { await tg(R, 'xco', SUMC('card-P1', 'Cosa osservare')); await CSC(R, 'xco', 'center'); await R.move('#xco', {ms:500, scroll:false}); await R.at(tclick); await ck(R, '#xco', {ms:50}); await RS(R); await sleep(700);
  await HB(R, 'xcb', "const s = [...document.querySelectorAll('#card-P1 summary')].find(s => /Cosa osservare/.test(s.innerText)); return s && s.parentElement", ta, tb);
  await HB(R, 'xdo', LFP('^Dove osservarla nel KOS 2.0', 0), tc, td); };
const GRG = async (R, g, item) => { await R.F.evaluate(([g, item]) => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && e.innerText.trim() === item); if(!v){ try{ shGrp(g); }catch(e){} } }, [g, item]); await sleep(400); };
const SELX = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const SUMN = i => "return [...document.querySelectorAll('#main-app details.u-ob > summary')][" + i + "]";
const TYP = async (R, id, tbody, t, text, d = 36) => { await tg(R, id, tbody); await R.move('#' + id, {ms:400, scroll:false}); await R.at(t); await R.P.mouse.click(R.cx, R.cy); await R.P.keyboard.type(text, {delay:d}); await RS(R); await sleep(250); };
const NEED = "const t = [...document.querySelectorAll('#main-app textarea, #main-app input[type=text]')].find(e => e.offsetParent && /Quale necessit/.test(e.placeholder || '')); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const IDRED = "const t = document.querySelector('textarea.idr-ed'); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const IDRCB = i => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const ADAT = i => "return [...document.querySelectorAll('#main-app button')].filter(b => b.offsetParent && /^Adatta/.test(b.innerText.trim()))[" + i + "]";
const BSF = t => "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const SPL = f => "return document.querySelector('#pc-card-0 [onclick*=" + f + "]')";
const BTI = t => "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.includes(" + JSON.stringify(t) + "))";
const MOD = rx => "const r = new RegExp(" + JSON.stringify(rx.replace('^', '^\\d?')) + "); const m = document.getElementById('g-modal'); const c = [...m.querySelectorAll('*')].filter(e => e.children.length <= 1 && r.test(e.textContent.trim())); return c[0]";
const MSEL = i => "return document.getElementById('an-ov').querySelectorAll('select')[" + i + "]";
const ISC = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'instant'}); }, id).then(() => sleep(200));
const MH = async (R, id, body, a, b) => { await tg(R, id, body); await ISC(R, id); await R.at(a); await H(R, '#' + id); const t0_ = Date.now(); await R.at(b); if(Date.now() - t0_ < 450) await sleep(550); await R.hlOff(); await RS(R); };
const MCLOSE = async (R, t, mid = 'g-modal') => { await tg(R, 'xmc', "return document.getElementById('" + mid + "').querySelector('.modal-x')"); await R.move('#xmc', {ms:400, scroll:false}); await R.at(t); await ck(R, '#xmc', {ms:40}); await RS(R); await sleep(500); };
const MOPEN = async (R, id, body, t) => { await tg(R, id, body); await CSC(R, id, 'center'); await R.move('#' + id, {ms:450, scroll:false}); await R.at(t); await ck(R, '#' + id, {ms:40}); await RS(R); await sleep(900); };
const AIN = (ph) => "const t = [...document.querySelectorAll('#att-0-0 textarea')].find(e => (e.placeholder || '').startsWith(" + JSON.stringify(ph) + ")); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const ATA = (rx, up) => "const r = new RegExp(" + JSON.stringify(rx) + "); const t = [...document.querySelectorAll('#att-0-0 *')].find(e => e.children.length <= 1 && r.test(e.textContent.trim())); let e = t; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const TIPL = n => "const s = [...[...document.querySelectorAll('#att-0-0 details')].find(d => d.querySelector(':scope > summary') && /Scegli tra i tipi/.test(d.querySelector(':scope > summary').innerText)).querySelectorAll('label span')].find(x => x.textContent.trim() === " + JSON.stringify(n) + "); return s && s.parentElement";
const TIPH = n => "const d = [...document.querySelectorAll('#att-0-0 summary')].find(s => /Scegli tra i tipi/.test(s.innerText)).parentElement; return [...d.querySelectorAll('div')].find(e => e.children.length === 0 && e.textContent.trim().toLowerCase().startsWith(" + JSON.stringify(n.toLowerCase()) + "))";
const IDL = n => "const s = [...document.querySelectorAll('#att-0-0 label')].find(x => x.innerText.trim().startsWith(" + JSON.stringify(n) + ")); return s";
const CLB = (k, lab) => "const b = [...document.querySelectorAll('#cl3-0-" + k + " button')].find(b => b.innerText.trim() === " + JSON.stringify(lab) + "); return b";
const CLN = k => "const e = document.getElementById('cl3-0-" + k + "'); const t = e.parentElement.parentElement.querySelector('textarea'); const n = t && t.nextElementSibling; return (n && n.classList.contains('rt-ed')) ? n : t";
const CLR = k => "return document.getElementById('cl3-0-" + k + "').parentElement.parentElement";
const TICK2 = async (R, id, name, t) => { await tg(R, id, "const s = [...[...document.querySelectorAll('#att-0-0 details')].find(d => d.querySelector(':scope > summary') && /Scegli tra i tipi/.test(d.querySelector(':scope > summary').innerText)).querySelectorAll('label span')].find(x => x.textContent.trim() === " + JSON.stringify(name) + "); return s && s.parentElement"); await R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'instant'}); }, id); await sleep(200); await R.move('#' + id, {ms:400, scroll:false, dx:0.05}); await R.at(t); await ck(R, '#' + id, {ms:40, dx:0.05}); await RS(R); await sleep(300); };
const OPC = async (R, t) => { const closed = await R.F.evaluate(() => document.getElementById('pc-card-0').classList.contains('closed')); await tg(R, 'xph', "return document.querySelector('#pc-card-0 .pc-hdr') || document.getElementById('pc-card-0').firstElementChild"); await R.move('#xph', {ms:250, scroll:false}); await R.at(t); if(closed){ await ck(R, '#xph', {ms:40}); await sleep(700); } await RS(R); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4500); await F.evaluate(() => shDash()); await sleep(1500); }

const VB = i => "return document.querySelector('#panel-pp .vis-bar[data-i=\"" + i + "\"]')";
const VR = i => "return [...document.querySelectorAll('#panel-pp .vis-sc > .vis-r')][" + i + "]";
const VCB = (i, t) => "return [...document.querySelectorAll('#panel-pp .vis-sc > .vis-r')][" + i + "].querySelector('.vis-ctl').querySelectorAll('button')[" + t + "]";
const VSEL = (i, k) => "return [...document.querySelectorAll('#panel-pp .vis-sc > .vis-r')][" + i + "].querySelectorAll('.vis-ctl select')[" + k + "]";
const MVB = i => "return document.querySelector('#att-0-" + i + " .att-mv-dn') || document.querySelector('#att-0-" + i + " .att-mv-up')";
const ARR = (j, k) => "return document.querySelector('#att-0-" + j + " .att-mv-" + k + "')";
const ARW = j => "return document.querySelector('#att-0-" + j + " .att-mv')";
const CLS = R => R.F.evaluate(() => { for(let j = 0; j < 8; j++){ const d = document.getElementById('att-0-' + j); if(d) d.open = false; } });
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Ordinare le attività', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await GRG(R, 'Progettare', 'Percorso Personale');
     await NAVI(R, 'Percorso Personale', 0.5); await CLOSEBOX(R); await OPC(R, 2.2); await CLS(R); await sleep(300);
     await tg(R, 'xa0', "return document.getElementById('att-0-0')"); await CSC(R, 'xa0', 'start'); await R.F.evaluate(() => window.scrollBy(0, -140)); await sleep(500); await RS(R);
     await HB(R, 'xw1', ARW(1), 8.0, 9.8);
     await HB(R, 'xw2', ARR(1, 'dn'), 10.0, 11.8); await HB(R, 'xw3', ARR(1, 'up'), 12.2, 13.9);
     await HB(R, 'xw4', ARW(0), 15.3, 18.8);
     await HB(R, 'xw5', ARW(3), 19.3, 21.2);
     await tg(R, 'xdn', ARR(0, 'dn')); await R.move('#xdn', {ms:600, scroll:false}); await R.at(23.2); await ck(R, '#xdn', {ms:40}); await RS(R); await sleep(600);
     await tg(R, 'xsw', "return document.querySelector('#att-0-0 .att-sumt')"); await HB(R, 'xsw', "return document.querySelector('#att-0-0 .att-sumt')", 27.0, 28.9); await HB(R, 'xnn', "return document.querySelector('#att-0-1 .att-sumt')", 29.6, 32.6);
     await tg(R, 'xup', ARR(0, 'up')); await R.move('#xup', {ms:600, scroll:false}); await R.at(34.0); await ck(R, '#xup', {ms:40}); await RS(R); await sleep(700); }} ]),
sb('b03', 'Togliere e spostare', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'xx', "return document.querySelector('#att-0-3 summary button[title^=\"Elimina\"]')"); await CSC(R, 'xx', 'center'); await HB(R, 'xx', "return document.querySelector('#att-0-3 summary button[title^=\"Elimina\"]')", 3.3, 5.4);
     await tg(R, 'xo', "return document.querySelector('#att-0-1 .att-sumt')"); await CSC(R, 'xo', 'center'); await R.move('#xo', {ms:600, scroll:false, dx:0.3}); await R.at(15.4); await ck(R, '#xo', {ms:40, dx:0.3}); await RS(R); await sleep(700);
     await tg(R, 'xmv', "return [...document.querySelectorAll('#att-0-1 button')].find(b => /Sposta questa/.test(b.innerText))"); await CSC(R, 'xmv', 'center'); await R.move('#xmv', {ms:500, scroll:false}); await R.at(18.6); await H(R, '#xmv'); await R.at(22.6); await R.hlOff(); await ck(R, '#xmv', {ms:40}); await RS(R); await sleep(900);
     await MH(R, 'xc1', "return document.getElementById('amv-c')", 26.1, 28.7); await MH(R, 'xc2', "return document.getElementById('amv-p')", 29.1, 30.3);
     await MH(R, 'xc3', "return [...document.getElementById('g-modal').querySelectorAll('*')].find(e => e.children.length <= 1 && /^Testo, materiali e date restano/.test(e.textContent.trim()))", 31.2, 39.9);
     await tg(R, 'xan', "return [...document.getElementById('g-modal').querySelectorAll('button')].find(b => b.innerText.trim() === 'Annulla')"); await R.move('#xan', {ms:500, scroll:false}); await R.at(40.5); await ck(R, '#xan', {ms:40}); await RS(R); await sleep(600); }} ]),
sb('b04', 'Linea del tempo', [
  {t:0, run: async R => { await R.hlOff(); await CLS(R);
     await tg(R, 'xtl', "return document.querySelector('details.tl-all > summary')"); await CSC(R, 'xtl', 'center'); await R.move('#xtl', {ms:600, scroll:false}); await R.at(1.8); await H(R, '#xtl'); await R.at(3.5); await R.hlOff(); await R.at(3.8); await ck(R, '#xtl', {ms:40}); await RS(R); await sleep(800);
     await HB(R, 'xt7', "return [...document.querySelectorAll('details.tl-all *')].filter(e => e.children.length <= 3 && /^7 nov/.test(e.textContent.trim())).pop()", 9.5, 12.4);
     await HB(R, 'xt8', "return [...document.querySelectorAll('details.tl-all button, details.tl-all a')].find(e => /calendario/.test(e.innerText))", 18.4, 23.4); }} ]),
sb('b05', 'Visione d’insieme', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await GRG(R, 'Progettare', 'Visione d’insieme');
     await NAVI(R, 'Visione d’insieme', 1.0); await sleep(800);
     await HB(R, 'xh1', "return document.querySelector('#panel-pp .vis-rh .vis-t')", 7.2, 9.0);
     await HB(R, 'xr0', VR(0), 9.3, 11.2);
     await HB(R, 'xa1', "return document.querySelectorAll('#panel-pp .vis-amb')[0]", 12.2, 12.9); await HB(R, 'xa2', "return document.querySelectorAll('#panel-pp .vis-amb')[1]", 13.0, 13.8); await HB(R, 'xa3', "return document.querySelectorAll('#panel-pp .vis-amb')[2]", 14.0, 14.9);
     await HB(R, 'xb1', VB(0), 15.3, 19.9);
     await HB(R, 'xv1', "return document.querySelector('#panel-pp .vis-gr i.pit')", 20.4, 25.8); }} ]),
sb('b06', 'Spostare i percorsi', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo(0, 0));
     await tg(R, 'xbar', VB(0)); await R.move('#xbar', {ms:700, scroll:false, dx:0.3}); await R.at(4.4);
     await R.P.mouse.down(); await R.moveTo(R.cx + 69, R.cy, 1800); await R.P.mouse.up(); await RS(R); await sleep(600);
     await tg(R, 'xp1', VCB(0, 0)); await R.move('#xp1', {ms:600, scroll:false}); await R.at(14.5); await ck(R, '#xp1', {ms:40}); await RS(R); await sleep(500);
     await tg(R, 'xp2', VCB(0, 1)); await R.move('#xp2', {ms:500, scroll:false}); await R.at(15.8); await ck(R, '#xp2', {ms:40}); await RS(R); await sleep(500);
     await tg(R, 'xs1', VSEL(0, 0)); await R.selOpen('#xs1', {fast:true}); await R.at(22.0); await R.selHover('ottobre 2026', 400); await R.at(23.2); await R.F.selectOption('#xs1', {label:'ottobre 2026'}); await R.P.evaluate(() => ST.menuOff()); await RS(R); await sleep(500);
     await tg(R, 'xs2', VSEL(0, 1)); await R.selOpen('#xs2', {fast:true}); await R.at(26.0); await R.P.evaluate(() => ST.menuOff()); await RS(R); }} ]),
sb('b07', 'Zoom e segni', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo(0, 0));
     await HB(R, 'xz0', "return document.querySelector('#panel-pp .vis-zm')", 0.6, 4.6);
     await tg(R, 'xzp', "return document.querySelectorAll('#panel-pp .vis-zb')[1]"); await R.move('#xzp', {ms:500, scroll:false}); await R.at(5.0); await ck(R, '#xzp', {ms:40}); await sleep(300); await ck(R, '#xzp', {ms:40}); await RS(R); await sleep(500);
     await tg(R, 'xzt', "return [...document.querySelectorAll('#panel-pp .vis-zt')].find(b => /Tutto/.test(b.innerText))"); await R.move('#xzt', {ms:500, scroll:false}); await R.at(7.4); await ck(R, '#xzt', {ms:40}); await RS(R); await sleep(500);
     await tg(R, 'xro', VR(3)); await CSC(R, 'xro', 'center'); await HB(R, 'xro', VR(3), 9.0, 11.8); await HB(R, 'xus', VR(4), 12.0, 15.6);
     await tg(R, 'xmk', "return document.querySelector('#panel-pp .vis-sc > .vis-r:nth-child(4) .vis-mk')"); await R.move('#xmk', {ms:700, scroll:false}); await R.at(16.8); await sleep(1500);
     await tg(R, 'xlg', "return document.querySelector('#panel-pp .vis-leg')"); await CSC(R, 'xlg', 'center'); await HB(R, 'xlg', "return document.querySelector('#panel-pp .vis-leg')", 19.8, 27.0); }} ]),
sb('b08', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
