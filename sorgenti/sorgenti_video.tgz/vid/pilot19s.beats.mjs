// Video 19 (sincronizzato): Calendario e attività
import { sleep } from './rec.mjs';
export const META = {n:'19s', title:'Calendario e attività', caption:'PEE CNGEI · Calendario e attività'};
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block);
const pg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]);
const tag = (R, id, sc, rx, nth = 0) => pg(R, id, "const r = new RegExp(" + JSON.stringify(rx) + "); return [...document.querySelectorAll(" + JSON.stringify(sc) + ")].filter(b => b.offsetParent && r.test(b.textContent.trim()))[" + nth + "]");
const top = R => R.F.evaluate(() => window.scrollTo(0, 0));
const scr = (R, y) => R.F.evaluate(y => window.scrollTo({top:y, behavior:'smooth'}), y);
// sequenza: ogni elemento viene evidenziato quando la voce lo dice (cursore in anticipo di poco)
const seq = async (R, items, lead = 0.38) => { for(const [w, sel, spec] of items){ await R.at(w - lead); await R.move(sel, {ms:Math.round(lead * 700), scroll:false}); await R.at(w - 0.04); await R.hl(spec || sel); } };
const sb = (id, scene, say, segs, extra = {}) => ({id, scene, say, segs, ...extra});
const NAT = '.cal-row[aria-label*="Natale"]';
const R2 = '.cal-row[data-u="r2"]';
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const dragTo = async (R, tx, ty, ms, n = 14) => { const x0 = R.cx, y0 = R.cy; for(let i = 1; i <= n; i++){ const k = i / n, e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2; const x = x0 + (tx - x0) * e, y = y0 + (ty - y0) * e; await R.P.mouse.move(x, y); R.P.evaluate(([x, y, m]) => ST.cur(x - 7, y - 4, m), [x, y, ms / n]); await sleep(ms / n); } R.cx = tx; R.cy = ty; };

export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(5000); }

export const beats = [
 sb('b01', 'Calendario e attività', 'Benvenuti. In questo video impariamo a usare Calendario e attività, il posto dove si organizza tutto l’anno, evento dopo evento. Ti accompagno passo dopo passo, senza fretta, e ti mostro ogni pulsante di cui parlo.', [
  {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
 sb('b02', 'Dove si trova', 'Cominciamo dal menu a sinistra.', [
  {t:0, run: async R => { await top(R); await R.hl('#sh-side'); }},
  {t:3.2, run: async R => {
    const G = ['Capire','Osservare','Progettare','Realizzare','Misurare','Conservare','Condividere']; const W = [3.88, 4.48, 5.36, 6.4, 7.36, 8.24, 9.28];
    await seq(R, W.map((w, i) => [w, R.F.locator('#sh-side button.sh-gh', {hasText:G[i]}).first(), {sel:'#sh-side button.sh-gh', text:G[i]}]));
  }},
  {t:10.0, run: async R => { const g = R.F.locator('#sh-side button.sh-gh', {hasText:'Realizzare'}).first(); await R.move(g, {ms:700, scroll:false}); await R.hl({sel:'#sh-side button.sh-gh', text:'Realizzare'}); await R.at(11.04); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); }},
  {t:14.4, run: async R => {
    const it = t => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
    await seq(R, [[15.12, it('Calendario e attività'), {sel:'#sh-side .sh-si', text:'Calendario e attività'}], [16.8, it('Elenco dell’anno'), {sel:'#sh-side .sh-si', text:'Elenco dell’anno'}], [18.08, it('Anno tipo'), {sel:'#sh-side .sh-si', text:'Anno tipo'}]]);
  }},
  {t:19.2, run: async R => { const c = R.F.locator('#sh-side .sh-si', {hasText:'Calendario e attività'}).first(); await R.move(c, {ms:700, scroll:false}); await R.hl({sel:'#sh-side .sh-si', text:'Calendario e attività'}); await R.at(20.7); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); }},
 ]),
 sb('b03', 'La pagina del Calendario', 'Ecco la pagina del Calendario. Ha tre parti.', [
  {t:0, run: async R => { await top(R); await R.sleepx(300); }},
  {t:1.84, run: async R => { await R.at(2.0); await R.hl('.cal-add', '.cal-pool', '.cal-mese'); }},
  {t:3.04, run: async R => {
    const bt = t => R.F.locator('.cal-add button', {hasText:t}).first(); const hs = t => ({sel:'.cal-add button', text:t});
    await R.at(3.5); await R.hl('.cal-add');
    await seq(R, [[5.76, bt('Riunione'), hs('Riunione')], [6.48, bt('Uscita'), hs('Uscita')], [7.28, bt('Bivacco'), hs('Bivacco')], [8.08, bt('Campo'), hs('Campo')]], 0.3);
  }},
  {t:8.88, run: async R => { await R.hlOff(); }},
  {t:16.32, run: async R => { await R.at(17.28); await R.hl('.cal-pool'); }},
  {t:19.04, run: async R => { await R.at(19.76); await R.hl('.cal-mese'); }},
 ]),
 sb('b04', 'Da collocare', 'Da collocare raccoglie le attività dei tuoi percorsi che non hanno ancora una data.', [
  {t:0, run: async R => { await R.hl('.cal-pool'); }},
  {t:8.55, run: async R => {
    await pg(R, 'vamb', "const c = document.querySelector('.cal-pool .cal-b[data-aid=\"a2\"]'); return [...c.querySelectorAll('span')].find(s => s.children.length === 0 && /Corporeit/.test(s.textContent))");
    await R.at(8.9); await R.hl('.cal-pool .cal-b[data-aid="a2"]'); await R.at(13.0); await R.hl('#vamb');
  }},
  {t:14.7, run: async R => {
    await tag(R, 'vab1', '.cal-pool .cal-b[data-aid="a2"] button', '^Apri nel percorso'); await tag(R, 'vab2', '.cal-pool .cal-b[data-aid="a2"] button', '^Scarica la scheda');
    await R.at(15.4); await R.hl({sel:'.cal-pool .cal-b[data-aid="a2"] .cal-bt2', all:true});
  }},
  {t:16.0, run: async R => { await R.move('#vab1', {ms:500, scroll:false}); await R.at(16.4); await R.hl('#vab1'); }},
  {t:20.3, run: async R => { await R.move('#vab2', {ms:500, scroll:false}); await R.at(20.8); await R.hl('#vab2'); }},
  {t:24.3, run: async R => { await pg(R, 'vsp', "return document.querySelector('.cal-pool .cal-b[data-aid=\"a2\"] .cal-sel')"); await R.move('#vsp', {ms:550, scroll:false}); await R.at(25.9); await R.hl('#vsp'); }},
 ]),
 sb('b05', 'Gli eventi, mese per mese', 'A destra, gli eventi sono divisi per mese.', [
  {t:0, run: async R => { await R.hl('.cal-mese'); }},
  {t:2.9, run: async R => { await R.at(3.4); await R.hl('.cal-row[data-u="r1"]'); }},
  {t:8.4, run: async R => { await R.move('.cal-leg', {ms:500, scroll:false}); await R.at(9.1); await R.hl('.cal-leg'); }},
  {t:10.9, run: async R => {
    await R.at(11.7); await R.hl('.vis-opt'); await scr(R, 150);
    await tag(R, 'vqc', '.vis-opt button', '^Questo ciclo'); await tag(R, 'vta', '.vis-opt button', '^Tutto l.anno');
    await R.at(12.4); await R.move('#vqc', {ms:900, scroll:false}); await R.at(13.8); await R.hl('#vqc'); await R.at(13.85); await ck(R, '#vqc', {scroll:false, ms:60});
  }},
  {t:16.9, run: async R => {
    await tag(R, 'vta', '.vis-opt button', '^Tutto l.anno');
    await R.move('#vta', {ms:350, scroll:false}); await R.at(17.2); await R.hl('#vta'); await R.at(17.25); await ck(R, '#vta', {scroll:false, ms:60});
  }},
  {t:22.3, run: async R => { await R.hlOff(); }},
  {t:26.4, run: async R => { await R.at(26.7); await R.hl('#vta'); }},
 ]),
 sb('b05a', 'I pit stop', 'Tra gli eventi compaiono anche i pit stop.', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vpit', "return document.querySelector('.cal-pit')"); await R.F.evaluate(() => { const e = document.getElementById('vpit'); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }); await R.sleepx(900); await R.at(1.5); await R.hl('#vpit'); }},
  {t:11.4, run: async R => { await R.at(11.7); await R.hl('#vpit .cal-ty'); }},
  {t:13.5, run: async R => { await tag(R, 'vpf', '.cal-pit .cal-bt2', '^Fissalo'); await tag(R, 'vpn', '.cal-pit .cal-bt2', '^Nascondi'); await R.move('#vpf', {ms:500, scroll:false}); await R.at(14.0); await R.hl('#vpf'); }},
  {t:17.5, run: async R => { await R.move('#vpn', {ms:450, scroll:false}); await R.at(17.9); await R.hl('#vpn'); }},
  {t:19.8, run: async R => { await R.hlOff(); }},
 ]),
 sb('b06', 'Creare una riunione', 'Creiamo una riunione nuova.', [
  {t:0, run: async R => { await scr(R, 0); }},
  {t:1.0, run: async R => { await tag(R, 'vrn', '.cal-add button', 'Riunione'); await R.move('#vrn', {ms:800, scroll:false}); await R.at(2.0); await R.hl('#vrn'); await R.at(2.85); await ck(R, '#vrn', {scroll:false, ms:80}); }},
  {t:3.92, run: async R => { await R.hlOff(); await view(R, '.cal-new', 'center'); await R.at(4.4); await R.hl('.cal-new'); }},
  {t:5.12, run: async R => { await R.at(5.32); await R.hl('.cal-for-f'); }},
  {t:7.4, run: async R => {
    await pg(R, 'vdu', "return document.querySelector('input[name=\"cal-dest\"][value=\"unita\"]').closest('label') || document.querySelector('input[name=\"cal-dest\"][value=\"unita\"]')");
    await pg(R, 'vds', "return document.querySelector('input[name=\"cal-dest\"][value=\"staff\"]').closest('label') || document.querySelector('input[name=\"cal-dest\"][value=\"staff\"]')");
    await R.move('#vdu', {ms:400, scroll:false}); await R.at(7.84); await R.hl('#vdu');
    await R.at(9.0); await R.move('#vds', {ms:450, scroll:false}); await R.at(9.56); await R.hl('#vds');
  }},
  {t:16.48, run: async R => { await R.move('#vdu', {ms:900, scroll:false}); await R.hl('#vdu'); await R.at(18.90); await ck(R, '#vdu', {scroll:false, ms:80}); }},
  {t:20.48, run: async R => { await R.move('#cal-nt', {ms:900, scroll:false}); await R.at(20.96); await R.hl('#cal-nt'); await R.at(22.90); await ck(R, '#cal-nt', {scroll:false, ms:80}); await R.P.keyboard.type('Riunione di Natale', {delay:58}); await R.sleepx(200); }},
 ]),
 sb('b07', 'Data e tipo di attività', 'Poi la data.', [
  {t:0, run: async R => { await R.move('#cal-d1', {ms:800, scroll:false}); await R.at(0.4); await R.hl('#cal-d1'); }},
  {t:6.0, run: async R => { await R.at(7.30); await ck(R, '#cal-d1', {dx:0.12, scroll:false, ms:600}); await R.at(8.88); await R.P.keyboard.type('12122026', {delay:130}); await R.F.fill('#cal-d1', '2026-12-12'); await R.sleepx(200); }},
  {t:11.32, run: async R => {
    await R.move('#cal-tp', {ms:700, scroll:false}); await R.at(11.84); await R.hl('#cal-tp');
    await R.at(13.2); await R.selOpen('#cal-tp', {fast:true});
    const H = [[19.04, 'Riunione di Reparto'], [19.8, 'Uscita di Reparto'], [20.8, 'Bivacco'], [21.76, 'Campo invernale'], [23.2, 'Consiglio di Pattuglia'], [24.16, 'Missione'], [25.04, 'Impresa'], [26.0, 'Hike di Pattuglia'], [26.96, 'Gara'], [27.84, 'Veglia'], [28.72, 'Grande gioco'], [29.84, 'Cerimonia della Promessa'], [32.8, 'Altro']];
    for(const [w, n] of H){ await R.at(w - 0.12); await R.selHover(n, 240); }
    await R.at(37.05); await R.selPick('#cal-tp', 'Grande gioco', true);
  }},
  {t:38.76, run: async R => { await tag(R, 'vcr', '.cal-new button', '^Crea$'); await R.move('#vcr', {ms:700, scroll:false}); await R.hl('#vcr'); await R.at(39.50); await ck(R, '#vcr', {scroll:false, ms:80}); }},
 ]),
 sb('b08', 'L’evento nel calendario', 'La riunione compare subito nel mese di dicembre, già al posto giusto.', [
  {t:0, run: async R => { await view(R, NAT, 'center'); await R.hl(NAT); }},
  {t:4.4, run: async R => { await R.at(5.56); await R.hl({sel:NAT + ' .cal-ra button', all:true}); }},
  {t:6.1, run: async R => { await R.move(NAT + ' .cal-ra button:nth-child(1)', {ms:450, scroll:false}); await R.at(6.68); await R.hl(NAT + ' .cal-ra button:nth-child(1)'); }},
  {t:8.0, run: async R => { await R.move(NAT + ' .cal-ra button:nth-child(2)', {ms:450, scroll:false}); await R.at(8.56); await R.hl(NAT + ' .cal-ra button:nth-child(2)'); }},
  {t:10.2, run: async R => { await R.move(NAT + ' .cal-ra button:nth-child(3)', {ms:450, scroll:false}); await R.at(10.72); await R.hl(NAT + ' .cal-ra button:nth-child(3)'); }},
 ]),
 sb('b09', 'Mettere le attività in un evento', 'Ora portiamo un’attività dentro una riunione.', [
  {t:0, run: async R => { await scr(R, 300); }},
  {t:3.4, run: async R => { await R.at(4.1); await R.hl('.cal-b[data-aid="a2"]'); }},
  {t:5.2, run: async R => {
    await R.move('.cal-b[data-aid="a2"]', {ms:900, scroll:false, dx:0.3, dy:0.3});
    await R.at(5.84); await R.hl('.cal-pool'); await R.at(7.2); await R.hl('.cal-b[data-aid="a2"]');
    await R.at(7.9); await R.P.mouse.down(); await sleep(120);
    const b = await R.box(R2, {scroll:false}); const tx = b.x + b.width * 0.5, ty = b.y + b.height * 0.5;
    await R.at(8.56); await dragTo(R, R.cx + (tx - R.cx) * 0.7, R.cy + (ty - R.cy) * 0.7, 800, 10);
    await R.hl(R2); await dragTo(R, tx, ty, 1100, 10);
    await R.at(10.9); await R.P.mouse.up(); await sleep(300);
  }},
  {t:12.88, run: async R => { await view(R, R2, 'center'); await R.hl(R2); await R.at(14.3); await R.hl(R2 + ' .cal-ap'); }},
  {t:20.0, run: async R => {
    await pg(R, 'vs3', "return document.querySelector('.cal-b[data-aid=\"a3\"] .cal-sel')");
    await view(R, '#vs3', 'center'); await R.sleepx(200); await R.move('#vs3', {ms:800, scroll:false}); await R.at(23.1); await R.hl('#vs3');
    await R.at(24.6); await R.selOpen('#vs3', {fast:true});
    await R.at(27.1); await R.selHover('Riunione · Riunione di apertura', 240);
    await R.at(27.85); await R.selHover('Uscita · Uscita al fiume', 240);
    await R.at(28.5); await R.selHover('Bivacco · Bivacco di gennaio', 240);
    await R.at(29.65); await R.selPick('#vs3', 'Riunione · Riunione di Natale', true);
  }},
 ]),
 sb('b10', 'Aprire un evento', 'Per organizzare davvero un evento, premi Apri.', [
  {t:0, run: async R => { await top(R); const a = '.cal-row[data-u="r1"] .cal-ra .cal-bt2'; await R.move(a, {ms:1700, scroll:true}); await R.at(2.64); await R.hl(a); await R.at(2.85); await ck(R, a, {scroll:false, ms:80}); }},
  {t:5.68, run: async R => { await R.hlOff(); await top(R); await R.at(5.9); await R.hl('.usc-hero'); }},
  {t:11.04, run: async R => {
    await R.at(11.6); await R.hl('#usc-tiles');
    await seq(R, [[13.4, '#usc-tiles > :nth-child(1)'], [14.08, '#usc-tiles > :nth-child(2)'], [15.12, '#usc-tiles > :nth-child(3)'], [16.08, '#usc-tiles > :nth-child(4)'], [17.36, '#usc-tiles > :nth-child(5)']], 0.3);
  }},
  {t:18.72, run: async R => { await R.at(19.4); await R.hl('#usc-tiles'); }},
  {t:20.8, run: async R => { await R.move('#usc-tiles > :nth-child(1)', {ms:700, scroll:false}); await R.at(21.0); await R.hl('#usc-tiles > :nth-child(1)'); await R.at(21.2); await ck(R, '#usc-tiles > :nth-child(1)', {scroll:false, ms:80}); }},
  {t:22.2, run: async R => { await R.at(22.24); await R.hl('#usc-detail'); }},
  {t:27.9, run: async R => { await pg(R, 'vchi', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.textContent.trim() === 'Chiudi')"); await R.move('#vchi', {ms:700, scroll:false}); await R.at(28.88); await R.hl('#vchi'); await R.at(29.52); await ck(R, '#vchi', {scroll:false, ms:80}); }},
 ]),
 sb('b11', 'I moduli dell’evento', 'Più sotto trovi i moduli, uno per argomento.', [
  {t:0, run: async R => { await view(R, '#usc-tabs', 'center'); await R.at(1.12); await R.hl('#usc-tabs'); }},
  {t:2.9, run: async R => {
    await seq(R, [[3.28, '#usc-tab-campo'], [4.36, '#usc-tab-m-chi'], [5.52, '#usc-tab-m-log'], [7.32, '#usc-tab-pasti'], [7.88, '#usc-tab-m-trasp'], [8.68, '#usc-tab-m-loc'], [9.8, '#usc-tab-m-costi'], [10.36, '#usc-tab-m-sic'], [11.24, '#usc-tab-m-ben'], [12.84, '#usc-tab-m-pb'], [13.68, '#usc-tab-m-mat'], [14.56, '#usc-tab-m-circ']], 0.3);
  }},
  {t:16.24, run: async R => { await R.hl('#usc-tabs'); }},
  {t:17.9, run: async R => { await R.move('#usc-tab-m-costi', {ms:900, scroll:false}); await R.hl('#usc-tab-m-costi'); await R.at(19.00); await ck(R, '#usc-tab-m-costi', {scroll:false, ms:80}); }},
  {t:20.0, run: async R => { await R.hlOff(); await view(R, '.usc-modpage', 'center'); await R.at(20.48); await R.hl('.usc-modpage'); }},
  {t:24.96, run: async R => { await pg(R, 'vcl', "return [...document.querySelectorAll('.usc-modpage .ax-lbl')].find(e => e.offsetParent && /^Cassa/i.test(e.textContent.trim()))"); await R.at(25.3); await R.hl('#vcl'); }},
  {t:27.48, run: async R => { await pg(R, 'vrf', "return [...document.querySelectorAll('.usc-modpage select')].find(s => s.offsetParent)"); await R.move('#vrf', {ms:900, scroll:false}); await R.at(28.56); await R.hl('#vrf'); }},
  {t:31.0, run: async R => { await R.move('.usc-mx', {ms:450, scroll:false}); await R.at(31.52); await R.hl('.usc-mx'); }},
 ]),
 sb('b12', 'Sicurezza, Piano B e moduli propri', 'Ogni modulo ha la sua forma.', [
  {t:0, run: async R => { await view(R, '#usc-tabs', 'center'); await R.sleepx(100); await R.move('#usc-tab-m-sic', {ms:1100, scroll:false}); await R.at(2.0); await R.hl('#usc-tab-m-sic'); await R.at(2.00); await ck(R, '#usc-tab-m-sic', {scroll:false, ms:80}); }},
  {t:2.9, run: async R => { await R.hlOff(); await R.at(3.4); await R.hl('.usc-modpage'); }},
  {t:6.4, run: async R => { await view(R, '#usc-tabs', 'center'); await R.move('#usc-tab-m-pb', {ms:800, scroll:false}); await R.at(7.52); await R.hl('#usc-tab-m-pb'); await R.at(7.50); await ck(R, '#usc-tab-m-pb', {scroll:false, ms:80}); }},
  {t:8.4, run: async R => { await R.hlOff(); await R.at(8.72); await R.hl('.usc-modpage'); }},
  {t:14.5, run: async R => { await view(R, '#usc-tabs', 'center'); await R.hlOff(); await R.move('#usc-tabs .usc-tab.add', {ms:900, scroll:false}); await R.at(16.48); await R.hl('#usc-tabs .usc-tab.add'); await R.at(16.52); await ck(R, '#usc-tabs .usc-tab.add', {scroll:false, ms:80}); }},
  {t:18.5, run: async R => { await R.hlOff(); await view(R, '#usc-own-t', 'center'); await R.at(18.72); await R.hl('#usc-own-t', '#usc-own-k', 'button[onclick="uscOwnAdd()"]'); }},
  {t:22.6, run: async R => { await R.move('#usc-own-t', {ms:800, scroll:false}); await R.at(23.40); await ck(R, '#usc-own-t', {scroll:false, ms:80}); await R.at(24.4); await R.P.keyboard.type('Turni di servizio', {delay:52}); await R.sleepx(150); }},
  {t:25.9, run: async R => {
    await R.hl('#usc-own-k'); await R.at(25.9); await R.selOpen('#usc-own-k', {fast:true});
    await R.at(27.34); await R.selHover('Testo', 240); await R.at(27.98); await R.selHover('Lista da spuntare', 240); await R.at(29.15); await R.selPick('#usc-own-k', 'Piccola tabella', true);
  }},
  {t:30.5, run: async R => { await R.move('button[onclick="uscOwnAdd()"]', {ms:800, scroll:false}); await R.hl('button[onclick="uscOwnAdd()"]'); await R.at(31.42); await ck(R, 'button[onclick="uscOwnAdd()"]', {scroll:false, ms:80}); }},
 ]),
 sb('b13', 'La giornata e il Time table', 'Torniamo alla giornata, con la scheda Sabato sette.', [
  {t:0, run: async R => { await R.hlOff(); await R.move('button[onclick="uscTab(1)"]', {ms:1700, scroll:true}); await R.at(2.3); await R.hl('button[onclick="uscTab(1)"]'); await R.at(2.35); await ck(R, 'button[onclick="uscTab(1)"]', {scroll:false, ms:80}); }},
  {t:3.3, run: async R => { await R.hlOff(); await view(R, '.usc-ttcard', 'center'); await R.at(3.76); await R.hl('.usc-ttcard'); }},
  {t:10.6, run: async R => { await R.move('.usc-ttside select', {ms:800, scroll:false}); await R.at(10.88); await R.hl('.usc-ttside select'); await R.at(12.6); await R.selOpen('.usc-ttside select', {fast:true}); }},
  {t:15.6, run: async R => { await R.at(15.9); await R.selHover('07:35', 300); await R.at(16.8); await R.selHover('07:45', 300); await R.at(17.7); await R.selHover('07:55', 300); }},
  {t:19.8, run: async R => { await R.selPick('.usc-ttside select', '08:00', true); await R.sleepx(500); await R.hl('.usc-ttcard'); }},
  {t:23.2, run: async R => { await R.selOpen('.usc-ttside select', {fast:true}); await R.at(24.2); await R.selPick('.usc-ttside select', '07:30', true); await R.sleepx(400); }},
 ]),
 sb('b14', 'Il programma', 'Più in basso c’è il programma. L’attività del percorso è già dentro.', [
  {t:0, run: async R => { await R.hlOff(); await scr(R, 520); await R.at(1.12); await R.hl('.usc-blk'); }},
  {t:4.2, run: async R => {
    await pg(R, 'vua', "return document.querySelectorAll('.usc-blk .usc-ib')[0]"); await pg(R, 'vub', "return document.querySelectorAll('.usc-blk .usc-ib')[1]"); await pg(R, 'vux', "return document.querySelector('.usc-blk .usc-bx')");
    await R.move('#vua', {ms:500, scroll:false}); await R.at(4.84); await R.hl('#vua', '#vub');
    await R.at(6.3); await R.move('#vux', {ms:400, scroll:false}); await R.at(6.64); await R.hl('#vux');
  }},
  {t:7.5, run: async R => { await R.move('.usc-blk .usc-bh', {ms:800, scroll:false, dx:0.4}); await R.at(8.4); await R.hl('.usc-blk'); await R.at(8.8); await ck(R, '.usc-blk .usc-bh', {dx:0.4, ms:60}); }},
  {t:9.84, run: async R => { await R.hl('.usc-blk'); await R.at(13.4); await scr(R, 760); await R.at(18.5); await scr(R, 940); }},
  {t:24.48, run: async R => { await R.hlOff(); await scr(R, 520); await R.at(25.6); await ck(R, '.usc-blk .usc-bh', {dx:0.4, ms:500}); }},
  {t:26.4, run: async R => {
    await view(R, '#usc-drop', 'center'); await R.at(27.2); await R.hl('#usc-pal');
    const T = ['Gioco', 'Pranzo', 'Cerimonia', 'Tempo libero']; const ids = ['vpg', 'vpp', 'vpc', 'vpl'];
    for(let i = 0; i < 4; i++) await pg(R, ids[i], "return [...document.querySelectorAll('#usc-pal [draggable=\"true\"]')].find(e => /^\\s*" + T[i] + "/.test(e.textContent))");
    await seq(R, [[30.0, '#vpg'], [30.8, '#vpp'], [31.6, '#vpc'], [32.48, '#vpl']], 0.4);
  }},
  {t:34.0, run: async R => {
    await pg(R, 'vpg', "return [...document.querySelectorAll('#usc-pal [draggable=\"true\"]')].find(e => /^\\s*Gioco\\s*$/.test(e.textContent))");
    await R.move('#vpg', {ms:500, scroll:false, dx:0.3, dy:0.3}); await R.hl('#vpg'); await R.at(35.0); await R.P.mouse.down(); await sleep(60);
    const b = await R.box('#usc-drop', {scroll:false}); await dragTo(R, b.x + b.width * 0.5, b.y + b.height * 0.5, 600, 6);
    await R.at(36.0); await R.P.mouse.up(); await sleep(300);
  }},
 ]),
 sb('b15', 'Tornare al Calendario', 'Quando hai finito, torna al Calendario dal menu a sinistra, con Calendario e attività.', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tag(R, 'vi0', '#sh-side .sh-si', '^Calendario e attività'); await R.move('#vi0', {ms:1500, scroll:false}); await R.at(3.84); await R.hl('#vi0'); await R.at(4.40); await ck(R, '#vi0', {scroll:false, ms:80}); }},
  {t:5.4, run: async R => { await R.hlOff(); await view(R, R2, 'center'); await R.move(R2 + ' .cal-ra button:nth-child(2)', {ms:500, scroll:false}); await R.at(6.24); await R.hl(R2 + ' .cal-ra button:nth-child(2)'); }},
  {t:12.1, run: async R => { await R.move(R2 + ' .cal-ra button:nth-child(3)', {ms:500, scroll:false}); await R.at(12.72); await R.hl(R2 + ' .cal-ra button:nth-child(3)'); }},
  {t:16.12, run: async R => { await R.hlOff(); }},
 ]),
 sb('b16', 'Salvare e riutilizzare un evento', 'Un evento si può anche salvare e riutilizzare. Apro un evento, e dal menu Esporta scelgo Tutto l’evento JSON: è una copia fedele, che puoi riusare in un altro progetto o in un altro anno. Per riportarlo dentro, nel Calendario c’è il pulsante Carica da file: si crea una copia dell’evento.', [
  {t:0, run: async R => { await R.hlOff(); await top(R); }},
  {t:3.1, run: async R => { await tag(R, 'vap', R2 + ' .cal-ra button', '^Apri'); await R.move('#vap', {ms:400, scroll:false}); await R.at(3.4); await R.hl('#vap'); await R.at(3.8); await ck(R, '#vap', {scroll:false, ms:50}); await R.hlOff(); await R.sleepx(1200); }},
  {t:4.6, run: async R => { await pg(R, 'vesp', "return document.querySelector('details.usc-pm summary')"); await R.F.evaluate(() => { const e = document.getElementById('vesp'); e && e.scrollIntoView({block:'center', behavior:'instant'}); }); await R.move('#vesp', {ms:350, scroll:false}); await R.at(5.0); await R.hl('#vesp'); await R.at(5.5); await ck(R, '#vesp', {scroll:false, ms:50}); await R.hlOff(); }},
  {t:6.3, run: async R => { await tag(R, 'vev', '.usc-pmm button', '^Tutto l.evento JSON'); await R.move('#vev', {ms:350, scroll:false}); await R.at(6.5); await R.hl('#vev'); }},
  {t:12.7, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const d = document.querySelector('details.usc-pm'); if(d) d.open = false; }); await R.F.evaluate(() => { const v = [...document.querySelectorAll('#sh-side .sh-si')].some(e => e.offsetParent && /^Calendario e attività/.test(e.innerText.trim())); if(!v) shGrp('Realizzare'); }); await R.sleepx(300); await tag(R, 'vi1', '#sh-side .sh-si', '^Calendario e attività'); await R.move('#vi1', {ms:400, scroll:false}); await R.at(13.4); await ck(R, '#vi1', {scroll:false, ms:50}); await R.sleepx(800); }},
  {t:14.5, run: async R => { await top(R); await tag(R, 'vcf', '.cal-add button', '^.? ?Carica da file'); await R.move('#vcf', {ms:400, scroll:false}); await R.at(15.9); await R.hl('#vcf'); }},
  {t:19.0, run: async R => { await R.hlOff(); }},
 ]),
];
