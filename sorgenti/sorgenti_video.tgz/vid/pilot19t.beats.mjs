import * as M from './pilot19s.beats.mjs';
export const META = {n:'19t', title:'t', caption:'t'};
export const open = M.open;
const b = M.beats.find(x => x.id === 'b16');
const pre = {id:'b00', scene:'', say:'x', segs:[{t:0, run: async R => { await R.F.evaluate(() => { const b=[...document.querySelectorAll('#sh-side .sh-gh')].find(x=>/realizzare/i.test(x.innerText)); b&&b.click(); }); await R.sleepx(600); await R.F.evaluate(() => { document.querySelector('#sh-side .sh-si[onclick*="shCal"]').click(); }); await R.sleepx(1200); }}]};
export const beats = [pre, b];
