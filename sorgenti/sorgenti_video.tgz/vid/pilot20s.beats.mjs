// Video 20 (sincronizzato): Elenco dell'anno
import { sleep } from './rec.mjs';
export const META = {n:'20s', title:'Elenco dell’anno', caption:'PEE CNGEI · Elenco dell’anno'};
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block);
const pg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]);
const tag = (R, id, sc, rx, nth = 0) => pg(R, id, "const r = new RegExp(" + JSON.stringify(rx) + "); return [...document.querySelectorAll(" + JSON.stringify(sc) + ")].filter(b => b.offsetParent && r.test(b.textContent.trim()))[" + nth + "]");
const top = R => R.F.evaluate(() => window.scrollTo(0, 0));
const seq = async (R, items, lead = 0.38) => { for(const [w, sel, spec] of items){ await R.at(w - lead); await R.move(sel, {ms:Math.round(lead * 700), scroll:false}); await R.at(w - 0.04); await R.hl(spec || sel); } };
const sb = (id, scene, say, segs, extra = {}) => ({id, scene, say, segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const TR = 'table.ele-t tbody tr';
const row = n => TR + ':nth-child(' + n + ')';
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const ELE = 'Elenco dell’anno';

export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(5000); }

export const beats = [
 sb('b01', 'Elenco dell’anno', 'Benvenuti. In questo video vediamo l’Elenco dell’anno.', [
  {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
 sb('b02', 'Dove si trova', 'Lo trovi nel menu a sinistra, nel gruppo Realizzare.', [
  {t:0.5, run: async R => { await R.hl('#sh-side'); }},
  {t:1.5, run: async R => { await R.move(sg(R, 'Realizzare'), {ms:700, scroll:false}); await R.at(2.45); await R.hl({sel:'#sh-side button.sh-gh', text:'Realizzare'}); }},
  {t:3.6, run: async R => { await R.at(4.28); await ck(R, sg(R, 'Realizzare'), {ms:90}); }},
  {t:5.4, run: async R => { await R.move(si(R, ELE), {ms:600, scroll:false}); await R.at(6.14); await R.hl({sel:'#sh-side .sh-si', text:ELE}); await R.at(6.9); await ck(R, si(R, ELE), {ms:90}); }},
 ]),
 sb('b03', 'La pagina', 'In alto, una breve spiegazione dice cosa contiene la pagina.', [
  {t:0, run: async R => { await top(R); await R.sleepx(200); }},
  {t:0.2, run: async R => { await R.move('.sh-dh', {ms:900, scroll:false}); await R.hl('.sh-dh'); }},
 ]),
 sb('b04', 'Le colonne', 'Sotto c’è la tabella, con cinque colonne.', [
  {t:0, run: async R => { await R.hlOff(); await R.move('table.ele-t', {ms:900, scroll:false}); }},
  {t:1.5, run: async R => { await R.at(1.74); await R.hl({sel:'table.ele-t th', all:true}); }},
  {t:2.6, run: async R => {
    const H = [[3.04, 'N.'], [3.84, 'Quando'], [4.64, 'Attività'], [6.0, 'Formato e tipo'], [7.74, 'Ciclo']];
    await seq(R, H.map(([w, h]) => [w, R.F.locator('table.ele-t th', {hasText:h}).first(), {sel:'table.ele-t th', text:h}]));
  }},
  {t:9.0, run: async R => { await R.hlOff(); }},
 ]),
 sb('b05', 'La numerazione', 'Il numero parte da uno e segue l’ordine delle date.', [
  {t:0, run: async R => { await R.move(row(1) + ' td.n', {ms:600, scroll:false}); await R.at(0.95); await R.hl(row(1) + ' td.n'); }},
  {t:3.0, run: async R => { await R.move(row(1), {ms:400, scroll:false}); await R.at(3.5); await R.hl(row(1)); }},
  {t:7.0, run: async R => { await R.move(row(1) + ' td.n', {ms:300, scroll:false}); await R.at(7.2); await R.hl(row(1) + ' td.n'); }},
  {t:7.9, run: async R => { await R.move(row(2), {ms:450, scroll:false}); await R.at(8.3); await R.hl(row(2)); }},
  {t:10.4, run: async R => { await R.move(row(2) + ' td.n', {ms:300, scroll:false}); await R.at(10.94); await R.hl(row(2) + ' td.n'); }},
 ]),
 sb('b06', 'Più giorni', 'Gli eventi che durano più giorni mostrano la data di inizio e quella di fine.', [
  {t:0.8, run: async R => { await R.move(row(4), {ms:700, scroll:false}); await R.at(2.2); await R.hl(row(4)); }},
  {t:3.4, run: async R => { await R.move(row(4) + ' td:nth-child(2)', {ms:300, scroll:false}); await R.at(3.6); await R.hl(row(4) + ' td:nth-child(2)'); }},
 ]),
 sb('b07', 'Aprire un evento', 'Se clicchi su una riga dell’Unità, si apre l’organizzazione di quell’evento.', [
  {t:0, run: async R => { await R.hlOff(); await R.move(row(1), {ms:600, scroll:false}); await R.at(0.9); await R.hl(row(1)); }},
  {t:4.3, run: async R => { await R.at(5.85); await ck(R, row(1), {ms:90}); }},
 ]),
 sb('b08', 'Tornare all’Elenco', 'Ecco la pagina dell’evento.', [
  {t:0.4, run: async R => { await R.hlOff(); await top(R); await R.at(0.8); await R.hl('.usc-hero'); }},
  {t:4.3, run: async R => { await R.hlOff(); await R.at(4.7); await R.hl('#sh-side'); }},
  {t:5.9, run: async R => { await R.move(sg(R, 'Realizzare'), {ms:400, scroll:false}); await R.at(6.72); await R.hl({sel:'#sh-side button.sh-gh', text:'Realizzare'}); }},
  {t:7.25, run: async R => { await R.move(si(R, ELE), {ms:260, scroll:false}); await R.at(7.56); await R.hl({sel:'#sh-side .sh-si', text:ELE}); await R.at(8.45); await ck(R, si(R, ELE), {ms:90}); }},
 ]),
 sb('b09', 'Il filtro Mostra', 'Sopra la tabella ci sono due filtri.', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.sleepx(300); }},
  {t:0.8, run: async R => { await R.move('.bil-flt', {ms:600, scroll:false}); await R.at(1.5); await R.hl('.bil-flt'); }},
  {t:2.2, run: async R => { await R.move('#ele-s', {ms:500, scroll:false}); await R.at(3.6); await R.hl('#ele-s'); }},
  {t:4.0, run: async R => {
    await R.selOpen('#ele-s', {fast:true});
    const H = [[5.12, 'Tutte'], [6.4, 'Solo Unità'], [8.3, 'Solo staff']];
    for(const [w, n] of H){ await R.at(w - 0.12); await R.selHover(n, 240); }
    await R.at(10.5); await R.selPick('#ele-s', 'Solo Unità', true);
  }},
 ]),
 sb('b10', 'Il filtro Formato', 'Il secondo filtro è il Formato.', [
  {t:0, run: async R => { await R.move('#ele-f', {ms:600, scroll:false}); await R.at(1.34); await R.hl('#ele-f'); }},
  {t:1.5, run: async R => {
    await R.selOpen('#ele-f', {fast:true});
    const H = [[2.32, 'Riunioni'], [3.08, 'Uscite'], [3.73, 'Bivacchi'], [4.4, 'Campi']];
    for(const [w, n] of H){ await R.at(w - 0.12); await R.selHover(n, 240); }
    await R.at(5.7); await R.selPick('#ele-f', 'Uscite', true);
  }},
  {t:7.0, run: async R => { await R.at(7.3); await R.hl(TR); }},
  {t:9.6, run: async R => { await R.move(TR + ' td.n', {ms:450, scroll:false}); await R.at(10.4); await R.hl(TR + ' td.n'); }},
  {t:12.6, run: async R => { await R.at(13.0); await R.hl('table.ele-t'); }},
 ]),
 sb('b11', 'Rimettere tutto', 'Per tornare a vedere tutto, rimettiamo Tutte nel primo filtro e Tutti nel secondo.', [
  {t:0, run: async R => { await R.hlOff(); await R.at(0.9); await R.selOpen('#ele-s', {fast:true}); await R.at(2.0); await R.selPick('#ele-s', 'Tutte', true); }},
  {t:3.2, run: async R => { await R.at(3.4); await R.selOpen('#ele-f', {fast:true}); await R.selPick('#ele-f', 'Tutti', true); }},
 ]),
 sb('b12', 'La timeline', 'Con il pulsante Timeline vedi gli stessi eventi lungo i dodici mesi dell’anno scout.', [
  {t:0, run: async R => { await R.hlOff(); await R.move(R.F.locator('.ele-vw button', {hasText:'Timeline'}).first(), {ms:500, scroll:false}); await R.at(0.94); await R.hl({sel:'.ele-vw button', text:'Timeline'}); await R.at(1.1); await ck(R, R.F.locator('.ele-vw button', {hasText:'Timeline'}).first(), {ms:90}); }},
  {t:2.0, run: async R => { await R.hl('.vis-wrap'); }},
  {t:3.3, run: async R => { await R.at(3.44); await R.hl('.vis-hd'); }},
  {t:5.1, run: async R => {
    await pg(R, 'vl1', "return document.querySelectorAll('.vis-wrap .vis-r:not(.vis-rh)')[0]"); await pg(R, 'vl2', "return document.querySelectorAll('.vis-wrap .vis-r:not(.vis-rh)')[1]");
    await R.at(5.2); await R.hl('#vl1', '#vl2');
    await R.at(6.3); await R.move('#vl1', {ms:250, scroll:false}); await R.at(6.52); await R.hl('#vl1');
    await R.at(7.4); await R.move('#vl2', {ms:250, scroll:false}); await R.at(7.6); await R.hl('#vl2');
  }},
  {t:9.2, run: async R => {
    for(const i of [0, 1, 2]) await pg(R, 'vm' + i, "const a = [...document.querySelectorAll('.vis-wrap .vis-mk')].filter(e => { const b = e.getBoundingClientRect(); return b.width > 5 && b.height > 5 && b.top > 200; }); return a[" + i + "]");
    await R.move('#vm0', {ms:600, scroll:false}); await R.at(10.4); await R.hl('#vm0', '#vm1', '#vm2'); }},
  {t:12.6, run: async R => { await R.move('.vis-bar', {ms:600, scroll:false}); await R.at(13.8); await R.hl('.vis-bar'); }},
  {t:14.1, run: async R => { await R.move(R.F.locator('.ele-vw button', {hasText:'Lista'}).first(), {ms:550, scroll:false}); await R.at(15.0); await R.hl({sel:'.ele-vw button', text:'Lista'}); await R.at(15.85); await ck(R, R.F.locator('.ele-vw button', {hasText:'Lista'}).first(), {ms:90}); }},
 ]),
 sb('b13', 'Come cambiano i numeri', 'Ora vediamo cosa succede ai numeri quando si aggiunge un evento.', [
  {t:0, run: async R => { await R.hlOff(); await view(R, 'button:has-text("Vai a Calendario e attività")', 'center'); }},
  {t:4.4, run: async R => { await R.move(R.F.locator('button', {hasText:'Vai a Calendario e attività'}).first(), {ms:800, scroll:false}); await R.at(6.06); await R.hl({sel:'button', text:'Vai a Calendario e attività'}); await R.at(8.6); await ck(R, R.F.locator('button', {hasText:'Vai a Calendario e attività'}).first(), {ms:90}); }},
 ]),
 sb('b14', 'Creare una riunione', 'Creiamo una riunione nuova.', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.sleepx(300); }},
  {t:0.6, run: async R => { await tag(R, 'vrn', '.cal-add button', 'Riunione'); await R.move('#vrn', {ms:700, scroll:false}); await R.at(2.14); await R.hl('#vrn'); await R.at(2.4); await ck(R, '#vrn', {scroll:false, ms:80}); }},
  {t:3.0, run: async R => { await R.hlOff(); await view(R, '.cal-new', 'center'); await R.move('#cal-nt', {ms:450, scroll:false}); await R.at(3.2); await R.hl('#cal-nt'); await R.at(3.8); await ck(R, '#cal-nt', {scroll:false, ms:80}); await R.at(3.9); await R.P.keyboard.type('Riunione', {delay:5}); await R.at(4.5); await R.F.fill('#cal-nt', 'Riunione extra'); }},
  {t:5.0, run: async R => { await R.move('#cal-d1', {ms:450, scroll:false}); await R.at(5.3); await R.hl('#cal-d1'); await R.at(5.9); await ck(R, '#cal-d1', {dx:0.12, scroll:false, ms:350}); await R.at(6.3); await R.P.keyboard.type('14', {delay:40}); await R.at(7.0); await R.F.fill('#cal-d1', '2026-11-14'); }},
  {t:8.3, run: async R => { await tag(R, 'vcr', '.cal-new button', '^Crea$'); await R.move('#vcr', {ms:500, scroll:false}); await R.at(9.0); await R.hl('#vcr'); await R.at(9.55); await ck(R, '#vcr', {scroll:false, ms:80}); }},
 ]),
 sb('b15', 'I numeri scalano', 'Torniamo all’Elenco dell’anno dal menu.', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move(si(R, ELE), {ms:600, scroll:false}); await R.at(0.5); await R.hl({sel:'#sh-side .sh-si', text:ELE}); await R.at(1.5); await ck(R, si(R, ELE), {ms:90}); }},
  {t:2.3, run: async R => { await R.move(row(2), {ms:500, scroll:false}); await R.at(3.2); await R.hl({sel:TR, text:'Riunione extra'}); }},
  {t:4.1, run: async R => { await R.move(row(2) + ' td.n', {ms:300, scroll:false}); await R.at(4.4); await R.hl(row(2) + ' td.n'); }},
  {t:5.0, run: async R => { await R.at(5.3); await R.hl({sel:TR + ' td.n', all:true}); }},
 ]),
 sb('b16', 'Come citare le attività', 'Per questo, nei documenti, conviene citare le attività con numero, data e titolo.', [
  {t:0, run: async R => { await R.move('table.ele-t', {ms:700, scroll:false}); }},
  {t:3.9, run: async R => { await R.hl({sel:TR + ' td.n', all:true}); await R.at(4.6); await R.hl({sel:TR + ' td:nth-child(2)', all:true}); await R.at(5.3); await R.hl({sel:TR + ' td:nth-child(3)', all:true}); }},
  {t:6.2, run: async R => { await R.hl({sel:TR + ' td.n', all:true}); }},
  {t:8.2, run: async R => { await R.hl({sel:TR + ' td:nth-child(2)', all:true}, {sel:TR + ' td:nth-child(3)', all:true}); }},
 ]),
 sb('b17', 'Scaricare l’elenco', 'In fondo alla tabella c’è anche il pulsante Scarica per Excel.', [
  {t:0, run: async R => { await R.hlOff(); await view(R, 'button:has-text("Scarica per Excel")', 'center'); }},
  {t:1.0, run: async R => { await R.move(R.F.locator('button', {hasText:'Scarica per Excel'}).first(), {ms:900, scroll:false}); await R.at(2.4); await R.hl({sel:'button', text:'Scarica per Excel'}); }},
 ]),
 sb('b18', 'Conclusione', 'Con questo abbiamo visto l’Elenco dell’anno.', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(760, 520, 1200); }},
 ]),
];
