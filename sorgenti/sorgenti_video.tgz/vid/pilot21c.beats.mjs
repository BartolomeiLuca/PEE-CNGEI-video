// Video Dashboard
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'21c', title:'Percorso formativo', caption:'PEE CNGEI · Progettare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts21c.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'instant'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'instant'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";
const DC = c => "return document.querySelector('#panel-dash [data-c=" + c + "]')";
const DB_ = t => "return [...document.querySelectorAll('#panel-dash button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HC = async (R, id, css, a, b) => { await tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")"); await scr(R, id); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const Q = css => "return document.querySelector(" + JSON.stringify(css) + ")";
const BT = (css, t) => "return [...document.querySelectorAll(" + JSON.stringify(css) + ")].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const hl = async (R, id, body, a, b, o = {}) => { await tg(R, id, body); if(o.scroll !== false) await scr(R, id); else await R.F.evaluate(id => { const e = document.getElementById(id); if(e){ const r = e.getBoundingClientRect(); if(r.top < 70 || r.bottom > innerHeight - 10) e.scrollIntoView({block:'center', behavior:'instant'}); } }, id); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const clk = async (R, id, body, at, o = {}) => { await tg(R, id, body); await R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'instant'}); }, id); await sleep(250); await R.move('#' + id, {ms:o.ms ?? 500, scroll:false}); await R.at(at); await ck(R, '#' + id, {ms:50}); await sleep(o.w ?? 700); };
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     const si = R.F.locator('#sh-side [onclick*="shPF"]').first(); await R.move(si, {scroll:false, ms:700}); await R.at(5.0); await ck(R, si, {ms:50}); await sleep(1500); await top(R);
     await hl(R, 'pf1', Q('#panel-pp h1'), 6.0, 7.6, {scroll:false});
     await hl(R, 'pf2', Q('#panel-pp .sh-dh .sh-sub'), 7.8, 12.5, {scroll:false});
     await hl(R, 'pf3', Q('#panel-pp .anv-act'), 12.8, 18.0, {scroll:false});
     await hl(R, 'pf4', Q('#panel-pp .pfx h3'), 18.6, 20.6);
     await hl(R, 'pf5', Q('#panel-pp .pfx-cov'), 24.0, 28.0); }} ]),
sb('b03', 'Parto dal mio staff', [
  {t:0, run: async R => { await R.hlOff(); await hl(R, 'pm1', BT('#panel-pp .pfx-m', 'Parto dal mio staff'), 1.1, 2.4);
     await hl(R, 'pe1', LP('^Dall.osservazione vengono', 0), 6.0, 10.0); await R.at(10.2); await hl(R, 'pe2', LP('^Percorso consigliato', 0), 14.6, 20.4);
     await clk(R, 'pcs', BT('#panel-pp button', 'Come si fa'), 20.9, {w:1200});
     await tg(R, 'pmod', Q('#g-modal .sch')); await R.at(22.0); await H(R, '#pmod'); await R.at(27.8); await R.hlOff();
     await R.F.evaluate(() => { try{ modalClose(); }catch(e){} }); await sleep(600);
     await hl(R, 'pat', BT('#panel-pp button', 'Aggiungi tutto'), 29.0, 32.2);
     await hl(R, 'pa1', BT('#panel-pp .mf-cb button', 'Aggiungi al percorso'), 34.8, 36.0);
     await clk(R, 'pat2', BT('#panel-pp button', 'Aggiungi tutto'), 36.1, {w:900}); }} ]),
sb('b04', 'Le altre strade', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'pxs', Q('#panel-pp .pfx-ms2')); await scr(R, 'pxs');
     await clk(R, 'pm2', BT('#panel-pp .pfx-m', 'Parto da un problema'), 2.1, {w:900});
     await hl(R, 'pg', Q('#panel-pp .pfx-g'), 4.2, 6.6);
     await clk(R, 'pq', Q('#panel-pp .pfx-qa:nth-child(2) .pfx-q'), 7.4, {w:1500});
     await hl(R, 'pr', Q('#panel-pp .pfx-res'), 9.2, 10.7, {scroll:false});
     await tg(R, 'pxs', Q('#panel-pp .pfx-ms2')); await scr(R, 'pxs');
     await clk(R, 'pm3', BT('#panel-pp .pfx-m', 'Parto da un tema'), 11.6, {w:900});
     await hl(R, 'pg2', Q('#panel-pp .pfx-g'), 12.2, 13.9);
     await clk(R, 'pm4', BT('#panel-pp .pfx-m', 'Parto dal periodo'), 14.6, {w:900});
     await hl(R, 'pms', Q('#panel-pp .pfx-ms'), 15.9, 17.0, {scroll:false});
     await hl(R, 'phn', Q('#panel-pp .pfx-hint'), 17.4, 21.9, {scroll:false});
     await clk(R, 'pm5', BT('#panel-pp .pfx-m', 'Sorprendimi'), 22.6, {w:1100});
     await hl(R, 'psu', Q('#panel-pp .pfx-sur'), 24.0, 26.6, {scroll:false}); }} ]),
sb('b05', 'Il tuo percorso', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => (document.getElementById('pf-mine') || document.body).scrollIntoView({behavior:'instant', block:'start'})); await R.at(0.5); await hl(R, 'pmh', Q('#pf-mine .pf-rh2'), 0.9, 4.9, {scroll:false});
     await hl(R, 'pc1', Q('#pf-mine .pf-c .pf-h'), 5.4, 8.9, {scroll:false});
     await hl(R, 'pob', Q('#pf-mine .pf-c .gr-f'), 9.0, 13.5, {scroll:false});
     await hl(R, 'pls', Q('#pf-mine .pf-c .pf-lsc'), 13.9, 19.8, {scroll:false});
     await hl(R, 'pfr', Q('#pf-mine .pf-c .pf-a'), 20.2, 21.6, {scroll:false});
     await clk(R, 'pdn', Q('#pf-mine .pf-c .pf-a button[aria-label="Sposta giù"]'), 21.9, {w:700});
     await hl(R, 'ptg', BT('#pf-mine .pf-a button', 'Togli'), 25.0, 26.5, {scroll:false}); }} ]),
sb('b06', 'Dove la fai', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'pev0', Q('#pf-mine .pf-c .pf-ev')); await scr(R, 'pev0');
     await hl(R, 'pev', Q('#pf-mine .pf-c .pf-ev select'), 2.3, 6.4, {scroll:false});
     await tg(R, 'pev', Q('#pf-mine .pf-c .pf-ev select')); await R.move('#pev', {ms:500, scroll:false}); await R.at(7.3);
     const v = await R.F.evaluate(() => [...document.querySelector('#pf-mine .pf-c .pf-ev select').options].find(o => /^Riunione dei Capi/.test(o.text)).value); await R.F.locator('#pf-mine .pf-c .pf-ev select').first().selectOption(v); await sleep(1400);
     await tg(R, 'pev0', Q('#pf-mine .pf-c .pf-ev')); await scr(R, 'pev0');
     await hl(R, 'pop', BT('#pf-mine .pf-ev button', 'Apri nell'), 9.6, 14.6, {scroll:false});
     await clk(R, 'pne', BT('#pf-mine .pf-ev button', '+ Nuovo evento'), 17.2, {w:900});
     await hl(R, 'pnf', Q('#pf-mine .pf-ne'), 19.0, 21.2, {scroll:false});
     await clk(R, 'pan', BT('#pf-mine .pf-ev button', 'Annulla'), 21.3, {w:700});
     await hl(R, 'pvr', Q('#pf-mine .pf-c > label.gr-f:last-of-type'), 22.1, 25.4); }} ]),
sb('b07', 'Aiuti e Word', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'pai', BT('#panel-pp button', 'Aiuti per chi conduce')); await R.move('#pai', {ms:500, scroll:false}); await R.at(1.6); await H(R, '#pai'); await R.at(3.0); await ck(R, '#pai', {ms:50}); await R.hlOff(); await sleep(1100);
     await tg(R, 'pml', Q('#g-modal .sch')); await R.at(3.6); await H(R, '#pml'); await R.at(7.0); await R.hlOff(); await R.F.evaluate(() => { try{ modalClose(); }catch(e){} }); await sleep(600);
     await tg(R, 'pwd', BT('#panel-pp button', 'Scarica il Word')); await R.move('#pwd', {ms:500, scroll:false}); await R.at(8.2); await H(R, '#pwd'); await R.at(15.0); await R.hlOff(); }} ]),
sb('b08', null, [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'pxs', Q('#panel-pp .pfx-ms2')); await scr(R, 'pxs'); await R.at(3.3); await H(R, '#pxs'); await R.at(7.2); await R.hlOff();
     await tg(R, 'pmh', Q('#pf-mine .pf-rh2')); await R.F.evaluate(() => (document.getElementById('pf-mine') || document.body).scrollIntoView({behavior:'smooth', block:'start'})); await R.at(7.8); await H(R, '#pmh'); await R.at(14.0); await R.hlOff(); }} ]),
];
