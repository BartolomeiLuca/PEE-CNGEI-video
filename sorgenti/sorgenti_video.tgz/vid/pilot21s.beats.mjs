// Video 21 (sincronizzato): Chi, quando, referenti
import { sleep } from './rec.mjs';
export const META = {n:'21s', title:'Chi, quando, referenti', caption:'PEE CNGEI · Chi, quando, referenti'};
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block);
const pg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]);
// elemento piu' profondo (visibile) il cui testo corrisponde alla regex, dentro la pagina del modulo
const own = (R, id, rx) => pg(R, id, "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const c = [...m.querySelectorAll('*')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0]");
const top = R => R.F.evaluate(() => window.scrollTo(0, 0));
const sc = (R, y) => R.F.evaluate(y => window.scrollTo(0, y), y);
const sb = (id, scene, say, segs, extra = {}) => ({id, scene, say, segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const MP = '.usc-modpage';
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const chip = (R, t) => R.F.locator(MP + ' .ax-chip', {hasText:t}).first();
const ids = R => R.F.evaluate(() => [...document.querySelectorAll('.usc-modpage')].filter(e => e.offsetParent).forEach(m => [...m.querySelectorAll('select')].forEach((s, i) => { s.id = 'vsel' + i; })));
const R1 = '.cal-row[data-u="r1"]';
const SCR = 600;

export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(5000); await F.evaluate(() => { try{ uscAttInto(0, 1, 'r1', true); }catch(e){} }); await sleep(800); }

export const beats = [
 sb('b01', 'Chi, quando, referenti', 'Benvenuti. In questo video vediamo come si indica chi viene, quando, e chi si occupa di cosa.', [
  {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
 sb('b02', 'Aprire l’evento', 'Partiamo dal menu: Realizzare, Calendario e attività.', [
  {t:0.4, run: async R => { await R.hl('#sh-side'); }},
  {t:0.9, run: async R => { await R.move(sg(R, 'Realizzare'), {ms:450, scroll:false}); await R.at(1.34); await R.hl({sel:'#sh-side button.sh-gh', text:'Realizzare'}); await R.at(1.9); await ck(R, sg(R, 'Realizzare')); }},
  {t:2.0, run: async R => { await R.move(si(R, 'Calendario e attività'), {ms:300, scroll:false}); await R.at(2.3); await R.hl({sel:'#sh-side .sh-si', text:'Calendario e attività'}); await R.at(3.5); await ck(R, si(R, 'Calendario e attività')); }},
  {t:4.1, run: async R => { await R.hlOff(); await top(R); await R.at(4.95); await R.hl(R1); }},
  {t:5.9, run: async R => { await R.move(R1 + ' .cal-ra button:nth-child(1)', {ms:450, scroll:false}); await R.at(6.9); await R.hl(R1 + ' .cal-ra button:nth-child(1)'); await R.at(7.4); await ck(R, R1 + ' .cal-ra button:nth-child(1)'); }},
 ]),
 sb('b03', 'Persone e date', 'Tra i moduli scegli Persone e date.', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.sleepx(300); }},
  {t:0.3, run: async R => { await R.hl('#usc-tabs'); await R.move('#usc-tab-m-chi', {ms:550, scroll:false}); await R.at(1.4); await R.hl('#usc-tab-m-chi'); await R.at(2.4); await ck(R, '#usc-tab-m-chi'); }},
  {t:2.9, run: async R => { await R.hlOff(); await sc(R, SCR); await R.at(3.5); await R.hl(MP + ' .usc-mph'); }},
  {t:5.8, run: async R => { await R.hl(MP + ' .usc-mph .usc-hint'); }},
 ]),
 sb('b04', 'Chi viene e quando', 'La prima parte si chiama Chi viene e quando.', [
  {t:0, run: async R => { await R.hlOff(); await own(R, 'vh1', '^chi viene e quando$'); await R.at(1.5); await R.hl('#vh1'); }},
  {t:3.0, run: async R => { await R.move(R.F.locator(MP + ' .ax-lbl', {hasText:'Presenti'}).first(), {ms:450, scroll:false}); await R.at(3.74); await R.hl({sel:MP + ' .ax-lbl', text:'Presenti'}); }},
 ]),
 sb('b05', 'Gli adulti', 'Sotto Adulti trovi i nomi dello staff. Clicca sul nome di chi viene.', [
  {t:0, run: async R => { await R.hlOff(); await own(R, 'vad', '^adulti$'); await R.at(0.35); await R.hl('#vad'); }},
  {t:1.0, run: async R => { await R.at(1.4); await R.hl(MP + ' .ax-chips'); }},
  {t:4.0, run: async R => { await R.move(chip(R, 'Anna Verdi'), {ms:450, scroll:false}); await R.at(5.26); await R.hl({sel:MP + ' .ax-chip', text:'Anna Verdi'}); await R.at(5.74); await ck(R, chip(R, 'Anna Verdi')); }},
  {t:7.7, run: async R => { await R.at(7.95); await R.hl({sel:MP + ' .ax-chip', text:'Anna Verdi'}); }},
 ]),
 sb('b06', 'Un adulto fuori staff', 'Se viene un adulto che non è nello staff, premi più Altra persona.', [
  {t:0, run: async R => { await R.hlOff(); }},
  {t:2.0, run: async R => {
    const b = R.F.locator(MP + ' button', {hasText:'+ Altra persona'}).first();
    await R.move(b, {ms:550, scroll:false}); await R.at(3.1); await R.hl({sel:MP + ' button', text:'+ Altra persona'});
    await R.at(3.85); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]);
    await R.at(4.5); await R.hlOff(); await R.P.evaluate(t => ST.dlgShow(t), 'Nome della persona');
    await R.at(7.5); const T = 'Marco Neri'; for(let i = 1; i <= T.length; i++){ await R.P.evaluate(x => ST.dlgType(x), T.slice(0, i)); await sleep(55); }
    await R.at(9.45); await R.F.evaluate(v => { window.prompt = () => v; }, T); await R.P.evaluate(() => ST.dlgOff()); await b.click();
  }},
  {t:10.2, run: async R => { await R.at(10.5); await R.hl(MP + ' .ax-chips'); }},
 ]),
 sb('b07', 'Ragazzi in tutto', 'Poi i ragazzi e le ragazze. Con Ragazzi in tutto scegli il numero dal menu.', [
  {t:0, run: async R => { await R.hlOff(); await ids(R); await R.move('#vsel0', {ms:600, scroll:false}); await R.at(2.3); await R.hl('#vsel0'); }},
  {t:3.3, run: async R => { await R.selOpen('#vsel0', {fast:true}); await R.at(4.55); await R.selHover('0', 240); await R.at(4.95); await R.selHover('5', 240); await R.at(5.25); await R.selPick('#vsel0', '14', true); }},
 ]),
 sb('b08', 'Ragazze e ragazzi', 'Poi indichi di cui ragazze, sei, e di cui ragazzi, otto.', [
  {t:0, run: async R => { await ids(R); await R.move('#vsel1', {ms:400, scroll:false}); await R.at(1.0); await R.hl('#vsel1'); await R.at(1.05); await R.selOpen('#vsel1', {fast:true}); await R.selPick('#vsel1', '6', true); }},
  {t:3.0, run: async R => { await ids(R); await R.move('#vsel2', {ms:400, scroll:false}); await R.at(3.4); await R.hl('#vsel2'); await R.at(3.45); await R.selOpen('#vsel2', {fast:true}); await R.selPick('#vsel2', '8', true); }},
 ]),
 sb('b09', 'Quanto dura', 'Quanto dura: In giornata, oppure Più giorni, con pernotto.', [
  {t:0, run: async R => { await R.hlOff(); await own(R, 'vqd', '^quanto dura$'); await R.at(0.1); await R.hl('#vqd'); }},
  {t:1.0, run: async R => { await R.at(1.3); await R.hl({sel:MP + ' .ax-chip', text:'In giornata'}); }},
  {t:2.3, run: async R => { await R.move(chip(R, 'Più giorni'), {ms:350, scroll:false}); await R.at(2.84); await R.hl({sel:MP + ' .ax-chip', text:'Più giorni'}); await R.at(6.2); await ck(R, chip(R, 'Più giorni')); }},
 ]),
 sb('b10', 'La data', 'Torniamo a In giornata, perché è una riunione. Sotto, la data.', [
  {t:0, run: async R => { await R.hlOff(); await R.move(chip(R, 'In giornata'), {ms:400, scroll:false}); await R.at(0.9); await ck(R, chip(R, 'In giornata')); }},
  {t:2.0, run: async R => { await R.move(MP + ' input[type="date"]', {ms:600, scroll:false}); await R.at(4.2); await R.hl(MP + ' input[type="date"]'); }},
 ]),
 sb('b11', 'Documenti dei genitori', 'Se servono documenti da parte dei genitori, spunta questa casella.', [
  {t:0, run: async R => {
    await own(R, 'vdoc', '^servono documenti'); await pg(R, 'vchk', "return [...document.querySelectorAll('.usc-modpage input[type=checkbox]')].filter(e => e.offsetParent)[0]");
    await R.hlOff(); await R.at(0.3); await R.hl('#vdoc');
  }},
  {t:4.0, run: async R => { await R.move('#vchk', {ms:600, scroll:false}); await R.at(5.1); await R.hl('#vchk'); await R.at(5.85); await ck(R, '#vchk'); }},
  {t:6.7, run: async R => { await R.hl('#vdoc'); }},
 ]),
 sb('b12', 'Altri incarichi', 'Sotto, Altri incarichi. Premi più Altro ruolo, scrivi il ruolo e scegli chi lo ricopre.', [
  {t:0, run: async R => { await R.hlOff(); await own(R, 'vinc', '^altri incarichi'); await R.at(0.9); await R.hl('#vinc'); }},
  {t:3.2, run: async R => {
    const b = R.F.locator(MP + ' button', {hasText:'+ Altro ruolo'}).first();
    await R.move(b, {ms:600, scroll:false}); await R.at(4.86); await R.hl({sel:MP + ' button', text:'+ Altro ruolo'}); await R.at(5.55); await ck(R, b);
  }},
  {t:6.0, run: async R => {
    await R.hlOff(); await R.move(MP + ' textarea[placeholder="Altro ruolo"]', {ms:500, scroll:false}); await R.at(6.4); await R.hl(MP + ' textarea[placeholder="Altro ruolo"]');
    await R.at(7.3); await ck(R, MP + ' textarea[placeholder="Altro ruolo"]'); await R.at(7.75); await R.P.keyboard.type('Cas', {delay:30}); await R.at(8.2); await R.F.fill(MP + ' textarea[placeholder="Altro ruolo"]', 'Cassiere');
    await pg(R, 'vrole', "return [...document.querySelectorAll('.ax-refg select')].filter(e => e.offsetParent).pop()");
    await R.at(8.3); await R.selOpen('#vrole', {fast:true}); await R.selPick('#vrole', 'Anna Verdi (CU)', true);
  }},
 ]),
 sb('b14', 'Cose da fare prima', 'Infine, Cose da fare prima. Scrivi il compito, scegli chi se ne occupa e la data.', [
  {t:0, run: async R => { await R.hlOff(); await sc(R, 770); await own(R, 'vcdf', '^cose da fare prima$'); await R.at(0.8); await R.hl('#vcdf'); }},
  {t:1.4, run: async R => {
    await pg(R, 'vta', "return document.querySelector('.usc-modpage textarea[placeholder^=\"es. permesso\"]')");
    await R.move('#vta', {ms:500, scroll:false}); await R.at(2.35); await R.hl('#vta'); await R.at(2.5); await ck(R, '#vta'); await R.at(2.75); await R.P.keyboard.type('Pre', {delay:30}); await R.at(3.2); await R.F.fill('#vta', 'Prenotare la sede');
  }},
  {t:3.3, run: async R => {
    await pg(R, 'vtodo', "return [...document.querySelectorAll('.usc-modpage select')].filter(e => e.offsetParent).pop()");
    await R.move('#vtodo', {ms:350, scroll:false}); await R.at(3.55); await R.hl('#vtodo'); await R.selOpen('#vtodo', {fast:true}); await R.selPick('#vtodo', 'Anna Verdi (CU)', true);
  }},
  {t:5.3, run: async R => {
    await pg(R, 'vdt', "return [...document.querySelectorAll('.usc-modpage input[type=date]')].filter(e => e.offsetParent).pop()");
    await R.move('#vdt', {ms:450, scroll:false}); await R.at(5.9); await R.hl('#vdt'); await R.at(6.0); await ck(R, '#vdt', {dx:0.12}); await R.at(6.4); await R.F.fill('#vdt', '2026-11-06');
  }},
  {t:7.4, run: async R => {
    await pg(R, 'vta', "return document.querySelector('.usc-modpage textarea[placeholder^=\"es. permesso\"]') || [...document.querySelectorAll('.usc-modpage textarea')].filter(e => e.offsetParent).pop()");
    await R.move('#vta', {ms:500, scroll:false}); await R.at(8.28); await R.hl('#vta');
    await pg(R, 'vtodo', "return [...document.querySelectorAll('.usc-modpage select')].filter(e => e.offsetParent).pop()"); await R.move('#vtodo', {ms:350, scroll:false}); await R.at(9.5); await R.hl('#vtodo');
    await pg(R, 'vdt', "return [...document.querySelectorAll('.usc-modpage input[type=date]')].filter(e => e.offsetParent).pop()"); await R.move('#vdt', {ms:350, scroll:false}); await R.at(10.44); await R.hl('#vdt');
  }},
  {t:12.1, run: async R => {
    await pg(R, 'vadd', "return [...document.querySelectorAll('.usc-modpage button')].filter(b => b.offsetParent && /^\\+ Aggiungi$/.test(b.textContent.trim()))[0]");
    await R.move('#vadd', {ms:450, scroll:false}); await R.at(13.0); await R.hl('#vadd'); await R.at(13.5); await ck(R, '#vadd');
  }},
 ]),
 sb('b15', 'Il compito nell’elenco', 'Il compito compare nell’elenco, con il nome di chi se ne occupa e la data.', [
  {t:0, run: async R => {
    await R.hlOff();
    await pg(R, 'vtr', "const t = [...document.querySelectorAll('.usc-modpage textarea')].find(x => x.offsetParent && x.value === 'Prenotare la sede'); return t && (t.parentElement.querySelector('input[type=checkbox]') ? t.parentElement : t.parentElement.parentElement)");
    await R.at(0.15); await R.hl('#vtr');
  }},
  {t:5.0, run: async R => { await pg(R, 'vtc', "const t = [...document.querySelectorAll('.usc-modpage textarea')].find(x => x.offsetParent && x.value === 'Prenotare la sede'); let r = t; for(let k = 0; k < 3 && r; k++, r = r.parentElement){ const cb = r.querySelector('input[type=checkbox]'); if(cb) return cb; } return null"); await R.move('#vtc', {ms:500, scroll:false}); await R.at(5.55); await ck(R, '#vtc'); }},
 ]),
 sb('b16', 'Il referente dei moduli', 'I referenti dei settori si scelgono nei moduli: ogni modulo ha il menu Referente. Puoi indicare anche più persone.', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.sleepx(300); await R.hl('#usc-tabs'); }},
  {t:1.6, run: async R => { await R.move('#usc-tab-m-costi', {ms:450, scroll:false}); await R.at(2.3); await R.hl('#usc-tab-m-costi'); await R.at(2.9); await ck(R, '#usc-tab-m-costi'); }},
  {t:3.2, run: async R => { await R.hlOff(); await sc(R, 560); await R.F.evaluate(() => { const s = [...document.querySelectorAll('.usc-modpage select.ax-pm-s')].find(e => e.offsetParent); if(s) s.id = 'vref'; }); await R.at(4.4); await R.hl('#vref'); }},
  {t:5.6, run: async R => { await R.at(5.9); await R.hl('#usc-tab-m-costi'); }},
  {t:7.3, run: async R => { await R.hlOff(); await R.move('#vref', {ms:350, scroll:false}); await R.at(7.8); await R.selOpen('#vref', {fast:true}); await R.selPick('#vref', 'Anna Verdi (CU)', true); }},
  {t:8.9, run: async R => { await R.F.evaluate(() => { document.querySelectorAll('#vref').forEach(x => x.removeAttribute('id')); const s = [...document.querySelectorAll('.usc-modpage select.ax-pm-s')].find(e => e.offsetParent); if(s) s.id = 'vref'; }); await R.move('#vref', {ms:400, scroll:false}); await R.at(9.8); await R.hl('#vref'); await R.selOpen('#vref', {fast:true}); await R.selPick('#vref', 'Marco Neri', true); }},
 ]),
 sb('b17', 'Referente e Chi la conduce', 'Nelle attività del programma trovi due campi: Referente dell’attività e Chi la conduce.', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.sleepx(300); await R.F.evaluate(() => uscTab(1)); await R.sleepx(600); }},
  {t:0.8, run: async R => { await R.hlOff(); await view(R, '#usc-blocks', 'start'); await R.sleepx(300); await R.F.evaluate(() => { const t = document.querySelector('#usc-blocks .usc-btri'); if(t){ t.id = 'vtri'; } }); await R.move('#vtri', {ms:450, scroll:false}); await R.at(2.4); await ck(R, '#vtri'); await R.sleepx(500);
    await R.F.evaluate(() => { const L = [...document.querySelectorAll('#usc-blocks .usc-mv2')]; const a = L.find(e => /^Referente dell/.test(e.textContent.trim())); const c = L.find(e => /^Chi la conduce/.test(e.textContent.trim())); if(a) a.id = 'vrefatt'; if(c) c.id = 'vcond'; }); await view(R, '#vrefatt', 'center'); }},
  {t:2.9, run: async R => { await R.move('#vrefatt', {ms:450, scroll:false}); await R.at(3.2); await R.hl('#vrefatt'); }},
  {t:8.3, run: async R => { await R.move('#vcond', {ms:450, scroll:false}); await R.at(8.6); await R.hl('#vcond'); }},
 ]),
 sb('b18', 'Lo stesso dei percorsi', 'Se l’attività viene da un Percorso, il referente è lo stesso dei percorsi.', [
  {t:0, run: async R => { await R.hlOff(); await R.move('#vrefatt', {ms:500, scroll:false}); await R.at(2.2); await R.hl('#vrefatt'); }},
  {t:5.4, run: async R => { await R.hl('#vrefatt'); }},
 ]),
 sb('b19', 'Diventa collaboratore?', 'Se affidi una parte a chi può solo leggere, l’app chiede: Diventa collaboratore?', [
  {t:0, run: async R => { await R.hl('#vrefatt'); }},
 ]),
 sb('b20', 'Conclusione', 'Così ogni cosa ha il suo nome accanto.', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(760, 520, 1200); }},
 ]),
];
