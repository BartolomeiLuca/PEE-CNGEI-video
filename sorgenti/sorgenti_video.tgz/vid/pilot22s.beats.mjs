// Video 22 (sincronizzato): Logistica e viaggio
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'22s', title:'Logistica e viaggio', caption:'PEE CNGEI · Logistica e viaggio'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts22.json', import.meta.url)));
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block).catch(() => {});
const pg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const el = new Function('m', body)(m); if(el) el.id = id; return !!el; }, [id, body]);
const own = (R, id, rx) => pg(R, id, "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...m.querySelectorAll('*')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0]");
const top = R => R.F.evaluate(() => window.scrollTo(0, 0));
const sc = (R, y) => R.F.evaluate(y => window.scrollTo(0, y), y);
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const MP = '.usc-modpage';
const SCR = 600;
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const U1 = '.cal-row[data-u="u1"]';
const TA1 = MP + ' textarea[placeholder^="es. in sede"]';
const CH = t => R => R.F.locator(MP + ' button.ax-chip:text-is("' + t + '")').first();
const chp = (R, t) => R.F.locator(MP + ' button.ax-chip:text-is("' + t + '")').first();
const btn = (R, t) => R.F.locator(MP + ' button', {hasText:t}).first();
const ORA1 = "return [...m.querySelectorAll('select')].filter(s => s.options.length > 100)[0]";
const ORA2 = "return [...m.querySelectorAll('select')].filter(s => s.options.length > 100)[1]";
const TABS = (R, tab) => ck(R, '#usc-tab-' + tab);

export async function open(F){
  await F.evaluate(() => shOpen('p1', 0)); await sleep(4500);
  // preparazione fuori campo: Uscita al fiume con Anna e 14 ragazzi
  await F.evaluate(() => shSrUsc('u1')); await sleep(2000);
  await F.evaluate(() => uscTab('m:chi')); await sleep(1200);
  await F.locator(MP + ' .ax-chip', {hasText:'Anna Verdi'}).first().click(); await sleep(700);
  for (const [i, v] of [[0, '14'], [1, '6'], [2, '8']]) {
    await F.evaluate(i => { const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const ss = [...m.querySelectorAll('select')].filter(s => [...s.options].some(o => o.text === '14')); ss.forEach(s => s.removeAttribute('id')); ss[i].id = 'vprep'; }, i);
    await F.selectOption('#vprep', {label:v}); await sleep(700);
  }
  await F.evaluate(() => { document.querySelectorAll('#vprep').forEach(x => x.removeAttribute('id')); shOpen('p1', 0); }); await sleep(3500);
}

export const beats = [
sb('b01', 'Logistica e viaggio', [
  {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
sb('b02', 'Il nostro esempio', [
  {t:0.3, run: async R => { await H(R, '#sh-side'); await R.move(sg(R, 'Realizzare'), {ms:700, scroll:false}); await R.at(2.4); await H(R, {sel:'#sh-side button.sh-gh', text:'Realizzare'}); await R.at(3.0); await ck(R, sg(R, 'Realizzare')); }},
  {t:4.0, run: async R => { await R.move(si(R, 'Calendario e attività'), {ms:300, scroll:false}); await R.at(4.5); await H(R, {sel:'#sh-side .sh-si', text:'Calendario e attività'}); await R.at(5.7); await ck(R, si(R, 'Calendario e attività')); }},
  {t:6.2, run: async R => { await R.hlOff(); await top(R); await R.at(6.4); await H(R, U1); await R.move(U1 + ' .cal-ra button:nth-child(1)', {ms:400, scroll:false}); await R.at(6.9); await H(R, U1 + ' .cal-ra button:nth-child(1)'); await R.at(7.5); await ck(R, U1 + ' .cal-ra button:nth-child(1)'); }},
  {t:8.2, run: async R => { await R.hlOff(); await top(R); await R.at(11.0); await H(R, '#usc-tabs'); }},
 ]),
sb('b03', 'Ritrovo e spostamenti', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-log', {ms:600, scroll:false}); await R.at(1.0); await H(R, '#usc-tab-m-log'); await R.at(2.0); await ck(R, '#usc-tab-m-log'); }},
  {t:2.5, run: async R => { await R.hlOff(); await sc(R, SCR); await R.at(3.2); await H(R, MP + ' .usc-mph'); }},
  {t:5.7, run: async R => { await H(R, MP + ' .usc-mph .usc-hint'); }},
  {t:10.3, run: async R => { await R.move(MP + ' select.ax-pm-s', {ms:600, scroll:false}); await R.at(11.3); await H(R, MP + ' select.ax-pm-s'); }},
 ]),
sb('b04', 'Il luogo di ritrovo', [
  {t:0, run: async R => { await view(R, TA1); await R.at(0.9); await H(R, TA1); }},
  {t:2.3, run: async R => { await R.hlOff(); await R.move(btn(R, 'Usa l’indirizzo della sede'), {ms:900, scroll:false}); await R.at(5.8); await H(R, {sel:MP + ' button', text:'Usa l’indirizzo della sede'}); await R.at(7.9); await ck(R, btn(R, 'Usa l’indirizzo della sede')); }},
  {t:8.6, run: async R => { await R.hlOff(); await R.at(9.0); await H(R, TA1); }},
 ]),
sb('b05', 'Il luogo di ritrovo', [
  {t:0, run: async R => { await H(R, TA1); await R.at(3.4); await R.F.fill(TA1, ''); }},
  {t:4.6, run: async R => { await R.type(TA1, 'Piaz', 70); await R.at(6.1); await R.F.fill(TA1, 'Piazza del Popolo, Pesaro'); }},
  {t:7.0, run: async R => { await R.hlOff(); await R.move(btn(R, 'Cerca l’indirizzo'), {ms:600, scroll:false}); await R.at(8.1); await H(R, {sel:MP + ' button', text:'Cerca l’indirizzo'}); await R.at(8.7); await ck(R, btn(R, 'Cerca l’indirizzo')); }},
  {t:10.2, run: async R => { await R.hlOff(); await R.at(14.3); await H(R, '.ax-res'); await R.at(15.9); await ck(R, '.ax-res >> nth=0'); }},
 ]),
sb('b06', 'Il luogo di ritrovo', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vlk', "return [...m.querySelectorAll('a')].find(a => a.offsetParent && /maps/i.test(a.href + a.textContent))"); await pg(R, 'vmaps', "return m.querySelector('input[placeholder^=\"Link di Google Maps\"]')"); await R.at(1.5); await H(R, '#vlk'); }},
  {t:3.6, run: async R => { await R.move('#vlk', {ms:500, scroll:false}); }},
  {t:8.6, run: async R => { await R.hlOff(); await R.move('#vmaps', {ms:700, scroll:false}); await R.at(10.0); await H(R, '#vmaps'); }},
 ]),
sb('b07', 'Gli orari', [
  {t:0, run: async R => { await pg(R, 'vora1', ORA1); await view(R, '#vora1'); await R.at(0.5); await R.move('#vora1', {ms:700, scroll:false}); await R.at(1.5); await H(R, '#vora1'); await R.at(1.8); await R.selOpen('#vora1', {fast:true, maxn:230}); }},
  {t:3.0, run: async R => { await R.selHover('06:00', 240); await R.at(4.0); await R.selHover('06:05', 240); await R.at(4.8); await R.selHover('06:10', 240); await R.at(5.9); await R.selHover('06:00', 240); }},
  {t:6.9, run: async R => { await R.at(7.0); await R.selPick('#vora1', '08:30', true); }},
 ]),
sb('b08', 'Il rientro', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vsame', "return m.querySelector('.ax-same')"); await R.at(5.0); await H(R, '#vsame'); }},
  {t:8.6, run: async R => { await R.hlOff(); await R.move('#vsame input', {ms:900, scroll:false}); await R.at(10.9); await ck(R, '#vsame input'); }},
  {t:11.9, run: async R => { await R.hlOff(); await pg(R, 'vrient', "return [...m.querySelectorAll('textarea')].filter(e => e.offsetParent)[1]"); await R.at(12.6); await H(R, '#vrient'); }},
  {t:15.5, run: async R => { await R.hlOff(); await pg(R, 'vsame', "return m.querySelector('.ax-same')"); await R.at(16.2); await ck(R, '#vsame input'); }},
 ]),
sb('b09', 'Il rientro', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vora2', ORA2); await view(R, '#vora2'); await R.move('#vora2', {ms:500, scroll:false}); await R.at(1.4); await H(R, '#vora2'); await R.at(1.7); await R.selOpen('#vora2', {fast:true, maxn:230}); await R.at(2.55); await R.selPick('#vora2', '17:30', true); }},
 ]),
sb('b10', 'Dove si svolge', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vdove', "return [...m.querySelectorAll('button.ax-chip')].find(b => b.innerText.trim() === 'In sede')"); await view(R, '#vdove'); await R.at(4.4); await R.move(chp(R, 'In sede'), {ms:300, scroll:false}); await R.at(4.9); await H(R, {sel:MP + ' button.ax-chip', text:'In sede'}); }},
  {t:5.5, run: async R => { await R.move(chp(R, 'All’aperto vicino'), {ms:300, scroll:false}); await R.at(5.9); await H(R, {sel:MP + ' button.ax-chip', text:'All’aperto vicino'}); await R.at(6.8); await R.move(chp(R, 'Uscita'), {ms:300, scroll:false}); await H(R, {sel:MP + ' button.ax-chip', text:'Uscita'}); await R.at(7.5); await R.move(chp(R, 'Altro…'), {ms:300, scroll:false}); await H(R, {sel:MP + ' button.ax-chip', text:'Altro…'}); }},
  {t:12.8, run: async R => { await R.hlOff(); await R.move(chp(R, 'Uscita'), {ms:600, scroll:false}); await R.at(14.4); await H(R, {sel:MP + ' button.ax-chip', text:'Uscita'}); await R.at(14.9); await ck(R, chp(R, 'Uscita')); }},
 ]),
sb('b11', 'Il luogo dell’attività', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vta2', "return m.querySelector('textarea[placeholder^=\"es. Rifugio\"]')"); await view(R, '#vta2'); await R.at(1.0); await H(R, '#vta2'); await R.at(2.4); await R.type('#vta2', 'Fi', 70); await R.at(3.7); await R.F.fill('#vta2', 'Fiume Foglia, Montecchio'); }},
  {t:4.4, run: async R => { await R.hlOff(); await R.move(R.F.locator(MP + ' button:text-is("Cerca")').last(), {ms:500, scroll:false}); await R.at(4.8); await H(R, {sel:MP + ' button', text:'Cerca'}); await R.at(5.5); await ck(R, R.F.locator(MP + ' button:text-is("Cerca")').last()); }},
  {t:6.3, run: async R => { await R.hlOff(); await R.at(6.6); await H(R, '.ax-res'); await R.at(8.3); await ck(R, '.ax-res >> nth=0'); }},
  {t:9.0, run: async R => { await R.hlOff(); await own(R, 'vpart', '^partenza'); await R.at(9.6); await H(R, '#vpart'); }},
 ]),
sb('b12', 'Come vi spostate', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vauto', "return [...m.querySelectorAll('button.ax-chip')].find(b => b.innerText.trim() === 'Auto')"); await view(R, '#vauto'); await R.move(chp(R, 'A piedi'), {ms:700, scroll:false}); await R.at(2.0); await H(R, {sel:MP + ' button.ax-chip', text:'A piedi'}); }},
  {t:2.7, run: async R => { await R.move(chp(R, 'Bici'), {ms:250, scroll:false}); await R.at(2.95); await H(R, {sel:MP + ' button.ax-chip', text:'Bici'}); await R.at(3.5); await R.move(chp(R, 'Treno'), {ms:250, scroll:false}); await R.at(3.75); await H(R, {sel:MP + ' button.ax-chip', text:'Treno'}); await R.at(4.3); await R.move(chp(R, 'Bus / pullman'), {ms:250, scroll:false}); await R.at(4.6); await H(R, {sel:MP + ' button.ax-chip', text:'Bus / pullman'}); await R.at(5.7); await R.move(chp(R, 'Auto'), {ms:250, scroll:false}); await H(R, {sel:MP + ' button.ax-chip', text:'Auto'}); await R.at(6.5); await R.move(R.F.locator(MP + ' button.ax-chip:text-is("Altro…")').last(), {ms:250, scroll:false}); }},
  {t:7.0, run: async R => { await R.hlOff(); await R.move(chp(R, 'Auto'), {ms:900, scroll:false}); await R.at(10.4); await H(R, {sel:MP + ' button.ax-chip', text:'Auto'}); await R.at(10.7); await ck(R, chp(R, 'Auto')); }},
  {t:11.5, run: async R => { await R.hlOff(); await R.at(17.6); await own(R, 'vkm', '^km andata e ritorno'); await H(R, '#vkm'); }},
 ]),
sb('b13', 'Come vi spostate', [
  {t:0, run: async R => { await R.hlOff(); await own(R, 'vkm', '^km andata e ritorno'); await view(R, '#vkm'); await R.at(4.1); await H(R, '#vkm'); }},
  {t:8.9, run: async R => { await R.hlOff(); await R.move(btn(R, 'Calcola distanza'), {ms:600, scroll:false}); await R.at(9.5); await H(R, {sel:MP + ' button', text:'Calcola distanza'}); await R.at(10.9); await ck(R, btn(R, 'Calcola distanza')); }},
 ]),
sb('b14', 'Persone per auto e CO₂', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vpa', "return [...m.querySelectorAll('select')].find(s => s.options.length > 2 && s.options.length < 12 && s.options[1].text === '1')"); await view(R, '#vpa'); await R.at(1.9); await H(R, '#vpa'); await R.move('#vpa', {ms:500, scroll:false}); }},
  {t:3.4, run: async R => { await R.selOpen('#vpa', {fast:true}); await R.at(5.0); await R.selHover('4', 240); await R.at(6.0); await R.selPick('#vpa', '4', true); }},
  {t:7.4, run: async R => { await R.hlOff(); await own(R, 'vco2', 'impronta stimata'); await R.at(13.0); await H(R, '#vco2'); }, keep:true},
 ]),
sb('b15', 'Persone per auto e CO₂', [
  {t:0, run: async R => { await own(R, 'vco2', 'impronta stimata'); await R.move(chp(R, 'Bus / pullman'), {ms:900, scroll:false}); await R.at(3.4); await ck(R, chp(R, 'Bus / pullman')); }},
  {t:4.3, run: async R => { await own(R, 'vco2', 'impronta stimata'); await H(R, '#vco2'); await R.move(chp(R, 'Auto'), {ms:900, scroll:false}); await R.at(6.2); await ck(R, chp(R, 'Auto')); }},
 ]),
sb('b16', 'Spostamenti', [
  {t:0, run: async R => { await R.hlOff(); await own(R, 'vspo', '^spostamenti si cambia qui'); await view(R, '#vspo'); await R.at(1.4); await H(R, '#vspo'); await R.at(2.6); await R.hlOff(); }},
  {t:13.9, run: async R => { await R.hlOff(); await R.move(btn(R, '+ Spostamento in questa giornata'), {ms:500, scroll:false}); await R.at(14.9); await ck(R, btn(R, '+ Spostamento in questa giornata')); await R.sleepx(500); await pg(R, 'vtrip', "return [...m.querySelectorAll('.usc-pdone .usc-pdb')].pop()"); await H(R, '#vtrip'); }, keep:true},
  {t:23.4, run: async R => { await R.hlOff(); await R.at(24.3); await H(R, {sel:MP + ' button', text:'Calcola i km'}); }},
  {t:26.8, run: async R => { await R.hlOff(); await R.at(28.5); await ck(R, btn(R, 'togli')); }},
 ]),
sb('b17', 'Trasporti', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-trasp', {ms:500, scroll:false}); await R.at(1.0); await H(R, '#usc-tab-m-trasp'); await R.at(1.7); await ck(R, '#usc-tab-m-trasp'); }},
  {t:2.2, run: async R => { await R.hlOff(); await sc(R, SCR); await R.at(2.8); await H(R, MP + ' .usc-mph'); }},
  {t:7.6, run: async R => { await R.hlOff(); await own(R, 'vtn', '^pullman, treno, biglietti'); await R.at(8.3); await H(R, '#vtn'); }},
 ]),
sb('b18', 'Una spesa di trasporto', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vta', "return m.querySelector('textarea[placeholder^=\"es. pullman\"]')"); await view(R, '#vta'); await R.at(0.4); await H(R, '#vta'); await R.at(1.9); await R.type('#vta', 'Pu', 70); await R.at(3.0); await R.F.fill('#vta', 'Pullman andata e ritorno'); }},
  {t:3.7, run: async R => { await R.hlOff(); await R.at(4.4); await H(R, MP + ' input[placeholder="€"]'); await R.at(5.6); await R.at(6.2); await R.F.fill(MP + ' input[placeholder="€"]', '180'); }},
  {t:6.5, run: async R => { await R.hlOff(); await pg(R, 'vcalc', "return [...m.querySelectorAll('select')].find(s => s.options[0].text === 'a forfait')"); await R.move('#vcalc', {ms:500, scroll:false}); await R.at(7.4); await H(R, '#vcalc'); await R.at(7.8); await R.selOpen('#vcalc', {fast:true}); }},
  {t:8.7, run: async R => { await R.selHover('a forfait', 240); await R.at(11.3); await R.selHover('a persona', 240); await R.at(12.0); await R.selHover('a ragazzo', 240); await R.at(13.4); await R.selHover('a persona per notte', 240); }},
  {t:14.3, run: async R => { await R.at(14.9); await R.selPick('#vcalc', 'a forfait', true); }},
 ]),
sb('b19', 'Una spesa di trasporto', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vpaga', "return m.querySelector('select.ax-sp-car')"); await view(R, '#vpaga'); await R.move('#vpaga', {ms:400, scroll:false}); await R.at(0.8); await H(R, '#vpaga'); await R.at(1.1); await R.selOpen('#vpaga', {fast:true}); }},
  {t:1.9, run: async R => { await R.selHover('Ragazzi (quota)', 240); await R.at(3.6); await R.selHover('Unità', 240); await R.at(4.6); await R.selHover('Gruppo', 240); await R.at(5.4); await R.selHover('Sezione', 240); await R.at(6.6); await R.selHover('Altro', 240); await R.at(8.4); await R.selHover('Unità', 240); }},
  {t:11.8, run: async R => { await R.at(12.5); await R.selPick('#vpaga', 'Ragazzi (quota)', true); }},
  {t:14.5, run: async R => { await R.hlOff(); await R.move(btn(R, '+ Aggiungi un trasporto'), {ms:700, scroll:false}); await R.at(15.3); await H(R, {sel:MP + ' button', text:'+ Aggiungi un trasporto'}); await R.at(16.7); await ck(R, btn(R, '+ Aggiungi un trasporto')); }},
  {t:18.0, run: async R => { await R.hlOff(); await sc(R, SCR); await R.at(19.6); await H(R, MP + ' .usc-fsum, ' + MP + ' .usc-mph'); }},
 ]),
sb('b20', 'Locazioni', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-loc', {ms:500, scroll:false}); await R.at(0.9); await H(R, '#usc-tab-m-loc'); await R.at(1.6); await ck(R, '#usc-tab-m-loc'); }},
  {t:2.2, run: async R => { await R.hlOff(); await sc(R, SCR); await R.at(2.6); await H(R, MP + ' .usc-mph'); }},
  {t:8.5, run: async R => { await R.hlOff(); await pg(R, 'vta', "return m.querySelector('textarea[placeholder^=\"es. casa\"]')"); await view(R, '#vta'); await R.at(9.0); await H(R, '#vta'); await R.at(9.6); await R.type('#vta', 'Sa', 70); await R.at(10.4); await R.F.fill('#vta', 'Sala per il pranzo'); }},
  {t:10.8, run: async R => { await R.hlOff(); await R.at(11.1); await H(R, MP + ' input[placeholder="€"]'); await R.at(11.9); await R.F.fill(MP + ' input[placeholder="€"]', '60'); }},
  {t:12.1, run: async R => { await R.hlOff(); await pg(R, 'vpaga2', "return m.querySelector('select.ax-sp-car')"); await R.move('#vpaga2', {ms:400, scroll:false}); await R.at(12.3); await H(R, '#vpaga2'); await R.selOpen('#vpaga2', {fast:true}); await R.at(12.7); await R.selPick('#vpaga2', 'Unità', true); }},
 ]),
sb('b21', 'Altre spese', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'valtre', "return [...m.querySelectorAll('summary')].find(s => /altre spese/i.test(s.textContent))"); await view(R, '#valtre'); await R.at(1.9); await H(R, '#valtre'); }},
  {t:2.6, run: async R => { await R.hlOff(); await R.at(3.0); await ck(R, '#valtre'); }},
  {t:6.2, run: async R => { await pg(R, 'valtre', "return [...m.querySelectorAll('summary')].find(s => /altre spese/i.test(s.textContent))"); await H(R, '#valtre'); }},
 ]),
sb('b22', 'Dove vanno a finire i costi', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-costi', {ms:600, scroll:false}); await R.at(2.2); await H(R, '#usc-tab-m-costi'); await R.at(3.4); await ck(R, '#usc-tab-m-costi'); }},
  {t:4.0, run: async R => { await R.hlOff(); await sc(R, 560); await own(R, 'vcassa', '^cassa'); await R.at(5.0); await H(R, '#vcassa'); }},
  {t:10.6, run: async R => { await R.hlOff(); await own(R, 'vquota', '^quota$'); await R.at(11.3); await H(R, '#vquota'); }},
  {t:18.4, run: async R => { await R.hlOff(); await R.at(19.2); await H(R, '#vcassa'); }},
 ]),
sb('b23', 'Ricapitoliamo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 420, 800); }},
  {t:1.8, run: async R => { await R.at(2.4); await H(R, '#usc-tab-m-log'); }},
  {t:8.6, run: async R => { await R.hlOff(); await R.at(9.0); await H(R, '#usc-tab-m-trasp', '#usc-tab-m-loc'); }},
  {t:12.9, run: async R => { await R.hlOff(); await R.moveTo(760, 520, 1200); }},
 ]),
];
