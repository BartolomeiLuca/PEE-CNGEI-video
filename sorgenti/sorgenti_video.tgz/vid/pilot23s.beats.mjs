// Video 23 (sincronizzato): Pasti, materiali e spesa
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'23s', title:'Pasti, materiali e spesa', caption:'PEE CNGEI · Pasti, materiali e spesa'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts23.json', import.meta.url)));
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block).catch(() => {});
const pg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const el = new Function('m', body)(m); if(el) el.id = id; return !!el; }, [id, body]);
const own = (R, id, rx) => pg(R, id, "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...m.querySelectorAll('*')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0]");
const top = R => R.F.evaluate(() => window.scrollTo(0, 0));
const sc = (R, y) => R.F.evaluate(y => window.scrollTo(0, y), y);
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const MP = '.usc-modpage';
const SCR = 600;
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const U1 = '.cal-row[data-u="u1"]';
const TA1 = MP + ' textarea[placeholder^="es. in sede"]';
const CH = t => R => R.F.locator(MP + ' button.ax-chip:text-is("' + t + '")').first();
const chp = (R, t) => R.F.locator(MP + ' button.ax-chip:text-is("' + t + '")').first();
const btn = (R, t) => R.F.locator(MP + ' button', {hasText:t}).first();
const ORA1 = "return [...m.querySelectorAll('select')].filter(s => s.options.length > 100)[0]";
const ORA2 = "return [...m.querySelectorAll('select')].filter(s => s.options.length > 100)[1]";
const CM = (R, i) => R.F.locator(MP + ' .ax-cm').nth(i);
const nth = (R, id, body) => pg(R, id, body);
const OL = async R => { const r = await R.F.evaluate(() => { const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); if(!m) return 'nom'; const sel = [...m.querySelectorAll('select')].filter(x => x.offsetParent && [...x.options].some(o => o.text === 'Già in Unità')); if(sel.length) return 'ok'; const t = [...m.querySelectorAll('button.ax-mtog')].filter(b => b.offsetParent); if(t.length){ t[t.length - 1].click(); return 'clicked'; } return 'none'; }); if(r === 'clicked') await sleep(350); };
const TABS = (R, tab) => ck(R, '#usc-tab-' + tab);

export async function open(F){
  await F.evaluate(() => shOpen('p1', 0)); await sleep(4500);
  // preparazione fuori campo: Uscita al fiume con Anna e 14 ragazzi
  await F.evaluate(() => shSrUsc('u1')); await sleep(2000);
  await F.evaluate(() => uscTab('m:chi')); await sleep(1200);
  await F.locator(MP + ' .ax-chip', {hasText:'Anna Verdi'}).first().click(); await sleep(700);
  for (const [i, v] of [[0, '14'], [1, '6'], [2, '8']]) {
    await F.evaluate(i => { const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const ss = [...m.querySelectorAll('select')].filter(s => [...s.options].some(o => o.text === '14')); ss.forEach(s => s.removeAttribute('id')); ss[i].id = 'vprep'; }, i);
    await F.selectOption('#vprep', {label:v}); await sleep(700);
  }
  await F.evaluate(() => { document.querySelectorAll('#vprep').forEach(x => x.removeAttribute('id')); shOpen('p1', 0); }); await sleep(3500);
}

export const beats = [
sb('b01', 'Pasti, materiali e spesa', [
  {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
sb('b02', 'Il nostro esempio', [
  {t:0.3, run: async R => { await H(R, '#sh-side'); await R.move(sg(R, 'Realizzare'), {ms:900, scroll:false}); await R.at(2.0); await H(R, {sel:'#sh-side button.sh-gh', text:'Realizzare'}); await R.at(2.6); await ck(R, sg(R, 'Realizzare')); }},
  {t:3.6, run: async R => { await R.move(si(R, 'Calendario e attività'), {ms:300, scroll:false}); await R.at(5.2); await H(R, {sel:'#sh-side .sh-si', text:'Calendario e attività'}); await R.at(5.7); await ck(R, si(R, 'Calendario e attività')); }},
  {t:6.1, run: async R => { await R.hlOff(); await top(R); await R.at(6.3); await H(R, U1); await R.move(U1 + ' .cal-ra button:nth-child(1)', {ms:400, scroll:false}); await R.at(6.8); await H(R, U1 + ' .cal-ra button:nth-child(1)'); await R.at(7.3); await ck(R, U1 + ' .cal-ra button:nth-child(1)'); }},
  {t:8.0, run: async R => { await R.hlOff(); await top(R); await R.at(11.0); await H(R, '#usc-tabs'); }},
 ]),
sb('b03', 'Il modulo Pasti', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-pasti', {ms:500, scroll:false}); await R.at(0.7); await H(R, '#usc-tab-pasti'); await R.at(1.3); await ck(R, '#usc-tab-pasti'); }},
  {t:1.7, run: async R => { await R.hlOff(); await sc(R, SCR); await R.at(2.1); await H(R, MP + ' .usc-mph'); }},
  {t:3.2, run: async R => { await H(R, MP + ' .usc-mph .usc-hint'); }},
  {t:11.4, run: async R => { await R.hlOff(); await R.move(MP + ' select.ax-pm-s', {ms:700, scroll:false}); await R.at(13.0); await H(R, MP + ' select.ax-pm-s'); }},
  {t:14.0, run: async R => { await R.hlOff(); await R.move(btn(R, 'Word'), {ms:600, scroll:false}); await R.at(15.0); await H(R, {sel:MP + ' button.usc-btn', text:'Excel'}, {sel:MP + ' button.usc-btn', text:'Word'}); }},
 ]),
sb('b04', 'Come entra il cibo nella quota', [
  {t:0, run: async R => { await R.hlOff(); await view(R, MP + ' .ax-cm'); await R.at(3.7); await H(R, {sel:MP + ' .ax-cm', text:'Scrivo il menù'}, {sel:MP + ' .ax-cm', text:'Ho già un costo'}, {sel:MP + ' .ax-cm', text:'Ci pensa un servizio'}); }},
  {t:7.9, run: async R => { await R.hlOff(); await R.move(CM(R, 0), {ms:700, scroll:false}); await R.at(9.1); await H(R, {sel:MP + ' .ax-cm', text:'Scrivo il menù'}); }},
 ]),
sb('b05', 'Un costo a persona', [
  {t:0, run: async R => { await R.hlOff(); await R.move(CM(R, 1), {ms:700, scroll:false}); await R.at(1.3); await H(R, {sel:MP + ' .ax-cm', text:'Ho già un costo'}); await R.at(8.5); await ck(R, CM(R, 1)); }},
  {t:9.0, run: async R => { await R.hlOff(); await R.at(9.7); await H(R, MP + ' input[placeholder="es. 8"]'); await R.at(10.0); await R.F.fill(MP + ' input[placeholder="es. 8"]', '8'); }},
  {t:10.3, run: async R => { await R.hlOff(); await pg(R, 'vogni', "return [...m.querySelectorAll('select')].find(s => [...s.options].some(o => o.text.startsWith('€ al giorno')))"); await R.move('#vogni', {ms:500, scroll:false}); await R.at(11.1); await H(R, '#vogni'); await R.at(11.5); await R.selOpen('#vogni', {fast:true}); }},
  {t:12.5, run: async R => { await R.selHover('€ al giorno a persona', 240); await R.at(13.6); await R.selHover('€ a pasto a persona', 240); await R.at(14.9); await R.selPick('#vogni', '€ al giorno a persona', true); }},
 ]),
sb('b06', 'Il servizio cambusa', [
  {t:0, run: async R => { await R.hlOff(); await R.move(CM(R, 2), {ms:500, scroll:false}); await R.at(1.2); await H(R, {sel:MP + ' .ax-cm', text:'Ci pensa un servizio'}); await R.at(2.6); await ck(R, CM(R, 2)); }},
  {t:3.0, run: async R => { await R.hlOff(); await R.at(13.4); await R.move(CM(R, 0), {ms:500, scroll:false}); await R.at(14.0); await ck(R, CM(R, 0)); }},
 ]),
sb('b07', 'Chi paga il cibo', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vcibo', "return [...m.querySelectorAll('select')].find(s => [...s.options].some(o => o.text.startsWith('Ragazzi (quota)')))"); await view(R, '#vcibo'); await R.move('#vcibo', {ms:500, scroll:false}); await R.at(1.3); await H(R, '#vcibo'); await R.at(2.4); await R.selOpen('#vcibo', {fast:true}); }},
  {t:3.3, run: async R => { await R.selHover('Ragazzi (quota)', 240); await R.at(5.9); await R.selHover('Unità', 240); await R.at(6.8); await R.selHover('Gruppo', 240); await R.at(7.6); await R.selHover('Sezione', 240); await R.at(8.8); await R.selHover('Altro', 240); await R.at(10.4); await R.selHover('Unità', 240); }},
  {t:14.3, run: async R => { await R.at(14.9); await R.selPick('#vcibo', 'Ragazzi (quota)', true); }},
 ]),
sb('b08', 'La tabella dei pasti', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vtab', "return m.querySelector('table')"); await view(R, '#vtab'); await R.at(2.2); await H(R, '#vtab'); }},
  {t:9.6, run: async R => { await R.hlOff(); await R.at(10.0); await H(R, {sel:MP + ' button.ax-chip', text:'Merenda del mattino'}, {sel:MP + ' button.ax-chip', text:'Dopocena'}, {sel:MP + ' button.ax-chip', text:'Altro…'}); }},
  {t:11.5, run: async R => { await R.hlOff(); await R.move(R.F.locator(MP + ' button.ax-chip', {hasText:'Merenda del mattino'}).first(), {ms:500, scroll:false}); await R.at(12.8); await H(R, {sel:MP + ' button.ax-chip', text:'Merenda del mattino'}); await R.at(13.4); await ck(R, R.F.locator(MP + ' button.ax-chip', {hasText:'Merenda del mattino'}).first()); }},
  {t:15.0, run: async R => { await R.hlOff(); await pg(R, 'vmcx', "return [...m.querySelectorAll('button.usc-mcx')].filter(e => e.offsetParent)[1]"); await R.move('#vmcx', {ms:500, scroll:false}); await R.at(16.1); await H(R, '#vmcx'); await R.at(17.8); await ck(R, '#vmcx'); }},
 ]),
sb('b09', 'Il pasto', [
  {t:0, run: async R => { await R.hlOff(); await R.move(R.F.locator(MP + ' button.usc-mc').nth(1), {ms:800, scroll:false}); await R.at(1.4); await ck(R, R.F.locator(MP + ' button.usc-mc').nth(1)); }},
  {t:3.4, run: async R => { await R.hlOff(); await pg(R, 'vped', "const c = [...m.querySelectorAll('div')].filter(e => e.offsetParent && e.innerText && e.innerText.trim().startsWith('Pranzo ·') && e.innerText.length < 2500); return c.sort((a, b) => b.innerText.length - a.innerText.length)[0]"); await view(R, '#vped'); await R.at(3.8); await H(R, '#vped'); }},
  {t:8.6, run: async R => { await R.hlOff(); await pg(R, 'vsacco', "return [...m.querySelectorAll('input[type=checkbox]')].find(e => e.offsetParent && /Al sacco/i.test((e.closest('label')||e.parentElement).innerText))"); await R.at(9.1); await H(R, '#vsacco'); await R.at(11.6); await ck(R, '#vsacco'); }},
  {t:12.6, run: async R => { await R.hlOff(); await R.at(17.1); await pg(R, 'vsacco', "return [...m.querySelectorAll('input[type=checkbox]')].find(e => e.offsetParent && /Al sacco/i.test((e.closest('label')||e.parentElement).innerText))"); await ck(R, '#vsacco'); }},
  {t:17.8, run: async R => { await R.hlOff(); await R.move(R.F.locator(MP + ' button.usc-lnk', {hasText:'diverse in questo pasto'}).first(), {ms:800, scroll:false}); await R.at(22.4); await H(R, {sel:MP + ' button.usc-lnk', text:'diverse in questo pasto'}); }},
 ]),
sb('b10', 'Un piatto', [
  {t:0, run: async R => { await R.hlOff(); await R.move(R.F.locator(MP + ' button.usc-btn', {hasText:'+ Piatto'}).first(), {ms:400, scroll:false}); await R.at(0.8); await H(R, {sel:MP + ' button.usc-btn', text:'+ Piatto'}); await R.at(1.1); await ck(R, R.F.locator(MP + ' button.usc-btn', {hasText:'+ Piatto'}).first()); }},
  {t:1.5, run: async R => { await R.hlOff(); await view(R, MP + ' textarea.usc-dn'); await R.at(1.9); await H(R, MP + ' textarea.usc-dn'); await R.at(2.5); await R.at(3.4); await R.F.fill(MP + ' textarea.usc-dn', 'Pasta al pomodoro'); }},
  {t:4.0, run: async R => { await R.hlOff(); await R.at(4.6); await H(R, MP + ' textarea.usc-dchi'); await R.at(5.4); await R.F.fill(MP + ' textarea.usc-dchi', 'Anna'); }},
  {t:5.9, run: async R => { await R.hlOff(); await R.at(6.3); await H(R, MP + ' textarea.usc-dn', MP + ' textarea.usc-dchi'); }},
 ]),
sb('b11', 'Per chi', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vperchi', "return [...m.querySelectorAll('select')].find(s => [...s.options].some(o => o.text.startsWith('Tutti i presenti')))"); await R.move('#vperchi', {ms:400, scroll:false}); await R.at(0.5); await H(R, '#vperchi'); await R.at(0.95); await R.selOpen('#vperchi', {fast:true}); }},
  {t:2.0, run: async R => { await R.selHover('Tutti i presenti', 240); await R.at(3.8); await R.selHover('Solo i ragazzi', 240); await R.at(5.4); await R.selHover('Solo gli adulti', 240); await R.at(6.8); await R.selHover('Un altro numero', 240); await R.at(9.4); await R.selPick('#vperchi', 'Tutti i presenti', true); }},
  {t:10.2, run: async R => { await R.hlOff(); await pg(R, 'vperchi', "return [...m.querySelectorAll('select')].find(s => [...s.options].some(o => o.text.startsWith('Tutti i presenti')))"); await R.at(12.0); await H(R, '#vperchi'); }},
 ]),
sb('b12', 'Gli ingredienti', [
  {t:0, run: async R => { await R.hlOff(); await view(R, MP + ' input.usc-ingn'); await R.at(1.5); await H(R, MP + ' input.usc-ingn'); await R.at(1.9); await R.at(2.4); await R.F.fill(MP + ' input.usc-ingn', 'Pasta'); await R.P.keyboard.press('Tab'); }},
  {t:3.0, run: async R => { await R.hlOff(); await pg(R, 'vdose', "return [...m.querySelectorAll('input[type=number]')].filter(e => e.offsetParent)[0]"); await pg(R, 'vprice', "return [...m.querySelectorAll('input[type=number]')].filter(e => e.offsetParent)[1]"); await R.at(5.3); await R.move('#vdose', {ms:500, scroll:false}); await R.at(5.9); await H(R, '#vdose'); }},
  {t:8.0, run: async R => { await R.hlOff(); await R.move('#vprice', {ms:400, scroll:false}); await R.at(8.5); await H(R, '#vprice'); }},
  {t:11.3, run: async R => { await R.hlOff(); await R.at(15.4); await H(R, '#vdose', '#vprice'); }},
 ]),
sb('b13', 'Un secondo ingrediente', [
  {t:0, run: async R => { await R.hlOff(); await R.move(R.F.locator(MP + ' button.ax-add', {hasText:'+ Ingrediente'}).first(), {ms:500, scroll:false}); await R.at(2.2); await H(R, {sel:MP + ' button.ax-add', text:'+ Ingrediente'}); await R.at(2.6); await ck(R, R.F.locator(MP + ' button.ax-add', {hasText:'+ Ingrediente'}).first()); }},
  {t:3.0, run: async R => { await R.hlOff(); await R.at(3.6); await H(R, MP + ' input.usc-ingn >> nth=1'); await R.at(3.9); await R.at(4.6); await R.F.fill(MP + ' input.usc-ingn >> nth=1', 'Passata di pomodoro'); await R.P.keyboard.press('Tab'); }},
  {t:5.0, run: async R => { await R.hlOff(); await pg(R, 'vdose2', "return [...m.querySelectorAll('input[type=number]')].filter(e => e.offsetParent)[2]"); await R.at(6.9); await H(R, '#vdose2'); }},
  {t:10.5, run: async R => { await R.hlOff(); await pg(R, 'vprice2', "return [...m.querySelectorAll('input[type=number]')].filter(e => e.offsetParent)[3]"); await R.move('#vprice2', {ms:500, scroll:false}); await R.at(11.0); await H(R, '#vprice2'); }},
 ]),
sb('b14', 'La lista della spesa', [
  {t:0, run: async R => { await R.hlOff(); await R.at(0.9); await ck(R, R.F.locator(MP + ' button.usc-lnk', {hasText:'Chiudi'}).first()); }},
  {t:1.2, run: async R => { await pg(R, 'vspesa', "return document.getElementById('usc-spesa-box').closest('.usc-card2')"); await view(R, '#vspesa'); await R.at(4.0); await H(R, '#vspesa'); }},
  {t:9.2, run: async R => { await R.hlOff(); await R.at(9.7); await H(R, {sel:'#usc-spesa-box tr', text:'Pasta'}); }},
  {t:14.5, run: async R => { await R.hlOff(); await R.at(14.9); await H(R, {sel:'#usc-spesa-box tr', text:'Passata'}); }},
  {t:17.7, run: async R => { await R.hlOff(); await own(R, 'vwarn', 'stimat'); await R.at(18.2); await H(R, '#vwarn'); }},
 ]),
sb('b15', 'Completare il prezzo', [
  {t:0, run: async R => { await R.hlOff(); await R.at(2.2); await H(R, {sel:'#usc-spesa-box tr', text:'Passata'}); await R.move(R.F.locator('#usc-spesa-box tr', {hasText:'Passata'}).first(), {ms:700, scroll:false}); await R.at(5.0); await ck(R, R.F.locator('#usc-spesa-box tr', {hasText:'Passata'}).first()); }},
  {t:5.5, run: async R => { await R.hlOff(); await pg(R, 'vprice2', "return [...m.querySelectorAll('input[type=number]')].filter(e => e.offsetParent)[3]"); await R.at(7.6); await H(R, '#vprice2'); await R.at(8.6); await R.type('#vprice2', '1.5', 110); await R.P.keyboard.press('Tab'); }},
 ]),
sb('b16', 'La spesa completa', [
  {t:0, run: async R => { await R.hlOff(); await R.at(0.4); await ck(R, R.F.locator(MP + ' button.usc-lnk', {hasText:'Chiudi'}).first()); }},
  {t:0.9, run: async R => { await pg(R, 'vspesa', "return document.getElementById('usc-spesa-box').closest('.usc-card2')"); await view(R, '#vspesa'); await R.at(1.6); await H(R, '#vspesa'); }},
 ]),
sb('b17', 'Diete e porzioni', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vdiete', "return document.querySelector('.usc-pgrid .usc-card2')"); await view(R, '#vdiete'); await R.at(1.7); await H(R, '#vdiete'); }},
  {t:8.4, run: async R => { await R.hlOff(); await pg(R, 'vdsel', "return [...document.querySelectorAll('.usc-pgrid select')].find(s => [...s.options].some(o => o.text === 'Vegetariana'))"); await R.move('#vdsel', {ms:500, scroll:false}); await R.at(9.5); await H(R, '#vdsel'); await R.at(9.4); await R.selOpen('#vdsel', {fast:true}); await R.at(10.4); await R.selPick('#vdsel', 'Vegetariana', true); }},
  {t:11.8, run: async R => { await R.hlOff(); await pg(R, 'vdn', "return [...document.querySelectorAll('.usc-pgrid select')].filter(s => s.options.length > 30)[0]"); await R.at(12.0); await H(R, '#vdn'); }},
  {t:12.7, run: async R => { await R.hlOff(); await R.move(R.F.locator('.usc-pgrid button', {hasText:'Aggiungi riga'}).first(), {ms:500, scroll:false}); await R.at(13.3); await H(R, {sel:'.usc-pgrid button', text:'Aggiungi riga'}); }},
  {t:15.2, run: async R => { await R.hlOff(); await pg(R, 'vporz', "return [...document.querySelectorAll('.usc-pgrid select')].find(s => [...s.options].some(o => o.text === 'Abbondanti'))"); await R.move('#vporz', {ms:400, scroll:false}); await R.at(15.7); await H(R, '#vporz'); await R.at(16.1); await R.selOpen('#vporz', {fast:true}); await R.at(16.9); await R.selHover('Ridotte', 240); await R.at(17.6); await R.selHover('Standard', 240); await R.at(18.2); await R.selHover('Abbondanti', 240); await R.at(19.6); await R.selPick('#vporz', 'Standard', true); }},
 ]),
sb('b18', 'Dove va il costo del cibo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-costi', {ms:600, scroll:false}); await R.at(2.4); await H(R, '#usc-tab-m-costi'); await R.at(3.2); await ck(R, '#usc-tab-m-costi'); }},
  {t:3.8, run: async R => { await R.hlOff(); await sc(R, 560); await own(R, 'vcassa', '^cassa'); await R.at(5.1); await H(R, '#vcassa'); }},
 ]),
sb('b19', 'Il modulo Materiali', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-mat', {ms:500, scroll:false}); await R.at(1.0); await H(R, '#usc-tab-m-mat'); await R.at(1.8); await ck(R, '#usc-tab-m-mat'); }},
  {t:2.2, run: async R => { await R.hlOff(); await sc(R, SCR); await R.at(2.4); await H(R, MP + ' .usc-mph'); }},
  {t:3.9, run: async R => { await H(R, MP + ' .usc-mph .usc-hint'); }},
  {t:9.0, run: async R => { await R.hlOff(); await R.move(MP + ' summary.usc-mpst', {ms:600, scroll:false}); await R.at(10.0); await H(R, MP + ' summary.usc-mpst'); }},
 ]),
sb('b20', 'Un materiale', [
  {t:0, run: async R => { await R.hlOff(); await R.F.locator(MP + ' button.ax-mtog').first().click().catch(() => {}); await view(R, MP + ' textarea[placeholder="Materiale"]'); await R.at(2.2); await H(R, MP + ' textarea[placeholder="Materiale"]'); await R.at(2.6); await R.at(3.4); await R.F.fill(MP + ' textarea[placeholder="Materiale"]', 'Corde per il ponte'); }},
  {t:3.8, run: async R => { await R.hlOff(); await OL(R); await R.at(4.2); await H(R, MP + ' input.ax-q'); await R.at(5.2); await R.F.locator(MP + ' input.ax-q').first().fill('4'); }},
  {t:5.5, run: async R => { await R.hlOff(); await OL(R); await pg(R, 'vqm', "return m.querySelector('select.ax-qm')"); await R.move('#vqm', {ms:400, scroll:false}); await R.at(5.6); await H(R, '#vqm'); await R.selOpen('#vqm', {fast:true}); await R.at(7.0); await R.selHover('in tutto', 240); await R.at(8.0); await R.selHover('per ragazzo', 240); await R.at(8.7); await R.selHover('per persona', 240); await R.at(9.0); await R.selPick('#vqm', 'in tutto', true); }},
  {t:9.6, run: async R => { await R.hlOff(); await R.sleepx(400); await OL(R); await pg(R, 'vprov', "return [...m.querySelectorAll('select')].find(s => s.offsetParent && [...s.options].some(o => o.text === 'Già in Unità'))"); await R.move('#vprov', {ms:400, scroll:false}); await R.at(10.1); await H(R, '#vprov'); await R.at(10.2); await R.selOpen('#vprov', {fast:true}); await R.at(11.5); await R.selHover('Già in Unità', 240); await R.at(12.3); await R.selHover('Da comprare', 240); await R.at(13.0); await R.selHover('In prestito', 240); await R.at(14.1); await R.selHover('Di recupero o riciclo', 240); await R.at(15.5); await R.selPick('#vprov', 'Già in Unità', true); }},
  {t:17.4, run: async R => { await R.hlOff(); await OL(R); await pg(R, 'vproc', "const ss = [...m.querySelectorAll('select')].filter(s => s.offsetParent && [...s.options].some(o => o.text === 'Anna Verdi (CU)')); return ss[ss.length - 1]"); await R.move('#vproc', {ms:400, scroll:false}); await R.at(17.8); await H(R, '#vproc'); await R.at(17.9); await R.selOpen('#vproc', {fast:true}); await R.at(18.55); await R.selPick('#vproc', 'Anna Verdi (CU)', true); }},
  {t:19.3, run: async R => { await R.hlOff(); await OL(R); await R.at(20.8); await H(R, {sel:MP + ' button.ax-chip', text:'Riutilizzabile'}); await R.at(21.1); await ck(R, R.F.locator(MP + ' button.ax-chip', {hasText:'Riutilizzabile'}).first()); await R.at(22.0); await H(R, {sel:MP + ' button.ax-chip', text:'Monouso'}); await R.at(22.7); await H(R, {sel:MP + ' button.ax-chip', text:'Di recupero'}); }},
  {t:23.4, run: async R => { await R.hlOff(); await OL(R); await R.at(24.5); await H(R, {sel:MP + ' label.ax-check', text:'pronto'}); await R.at(25.3); await ck(R, R.F.locator(MP + ' label.ax-check', {hasText:'pronto'}).first()); }},
  {t:26.4, run: async R => { await R.hlOff(); await OL(R); await R.move(R.F.locator(MP + ' button.ax-add', {hasText:'+ Aggiungi materiale'}).first(), {ms:400, scroll:false}); await R.at(27.3); await H(R, {sel:MP + ' button.ax-add', text:'+ Aggiungi materiale'}); await R.at(27.8); await ck(R, R.F.locator(MP + ' button.ax-add', {hasText:'+ Aggiungi materiale'}).first()); }},
 ]),
sb('b21', 'Altri materiali', [
  {t:0, run: async R => { await R.hlOff(); await R.sleepx(300); }},
  {t:3.7, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const t = [...document.querySelectorAll('.usc-modpage textarea[placeholder="Materiale"]')].filter(e => e.offsetParent); const x = t[t.length - 1]; if(x) x.id = 'vmat2'; }); await view(R, '#vmat2'); await R.at(4.3); await H(R, '#vmat2'); await R.at(4.7); await R.at(5.6); await R.F.fill('#vmat2', 'Fazzoletti di carta'); }},
  {t:6.2, run: async R => { await R.hlOff(); await OL(R); await pg(R, 'vq2', "const q = [...m.querySelectorAll('input.ax-q')].filter(e => e.offsetParent); return q[q.length - 1]"); await R.at(6.5); await H(R, '#vq2'); await R.at(6.7); await R.F.fill('#vq2', '1'); await pg(R, 'vqm2', "const q = [...m.querySelectorAll('select.ax-qm')].filter(e => e.offsetParent); return q[q.length - 1]"); await R.at(7.0); await R.F.selectOption('#vqm2', {label:'per persona'}); }},
  {t:7.2, run: async R => { await R.hlOff(); await OL(R); await pg(R, 'vprov2', "const q = [...m.querySelectorAll('select')].filter(s => s.offsetParent && [...s.options].some(o => o.text === 'Da comprare')); return q[q.length - 1]"); await R.at(7.4); await H(R, '#vprov2'); await R.at(7.6); await R.F.selectOption('#vprov2', {label:'Da comprare'}); await R.at(8.3); await pg(R, 'vmono', "const q = [...m.querySelectorAll('button.ax-chip')].filter(b => b.offsetParent && b.innerText.trim() === 'Monouso'); return q[q.length - 1]"); await H(R, '#vmono'); await R.at(8.6); await ck(R, '#vmono'); }},
 ]),
sb('b22', 'I materiali dei momenti', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vgg', "const l = [...m.querySelectorAll('.usc-mpsec')].filter(e => /Materiali dei momenti/.test(e.innerText)); return l[l.length - 1]"); await view(R, '#vgg'); await R.at(0.6); await H(R, '#vgg'); await R.at(12.8); await R.hlOff(); }},
 ]),
sb('b23', 'Ricapitoliamo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 420, 800); }},
  {t:1.2, run: async R => { await R.at(1.7); await H(R, '#usc-tab-pasti'); }},
  {t:9.4, run: async R => { await R.hlOff(); await R.at(10.0); await H(R, '#usc-tab-m-mat'); }},
  {t:13.6, run: async R => { await R.hlOff(); await R.moveTo(760, 520, 1200); }},
 ]),
];
