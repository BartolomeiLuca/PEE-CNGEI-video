// Video 24 (sincronizzato): Cassa, costi e quota
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'24s', title:'Cassa, costi e quota', caption:'PEE CNGEI · Cassa, costi e quota'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts24.json', import.meta.url)));
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block).catch(() => {});
const pg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const el = new Function('m', body)(m); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const own = (R, id, rx) => pg(R, id, "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...m.querySelectorAll('*')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0]");
const top = R => R.F.evaluate(() => window.scrollTo(0, 0));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const MP = '.usc-modpage';
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const CM = (R, i) => R.F.locator(MP + ' .ax-cm').nth(i);
const zblk = async (R, sel, s = 1.12) => { await R.F.evaluate(sel0 => { const e = document.querySelector(sel0); const m = [...document.querySelectorAll('.usc-modpage')].find(x => x.offsetParent); document.querySelectorAll('#vzb').forEach(x => x.removeAttribute('id')); if(!e || !m) return; let p = e; while(p && p !== m && p.getBoundingClientRect().width < m.getBoundingClientRect().width * 0.7) p = p.parentElement; if(p) p.id = 'vzb'; }, sel); await R.zoomTo('#vzb', s); };
const CASSA = "return m.querySelector('details.usc-mpd')";
const ROWS = "return [...m.querySelectorAll('table.usc-tbl')].find(t => /Spesa totale/.test(t.innerText))";
const scrow = i => "return m.querySelectorAll('table.usc-sctab tr')[" + i + "]";
const setup = async (R, tab) => { await R.zoomOff(); await top(R); };

export async function open(F){
  await F.evaluate(() => shOpen('p1', 0)); await sleep(4500);
}

export const beats = [
sb('b01', 'Cassa, costi e quota', [
  {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
sb('b02', 'Il nostro esempio', [
  {t:0.3, run: async R => { await H(R, '#sh-side'); await R.move(sg(R, 'Realizzare'), {ms:900, scroll:false}); await R.at(1.8); await H(R, {sel:'#sh-side button.sh-gh', text:'Realizzare'}); await R.at(2.3); await ck(R, sg(R, 'Realizzare')); }},
  {t:3.4, run: async R => { await R.move(si(R, 'Calendario e attività'), {ms:300, scroll:false}); await R.at(4.2); await H(R, {sel:'#sh-side .sh-si', text:'Calendario e attività'}); await R.at(4.7); await ck(R, si(R, 'Calendario e attività')); }},
  {t:5.5, run: async R => { await R.hlOff(); await top(R); await R.F.evaluate(() => { const r = document.querySelector('.cal-row[data-u="b1"]'); if(r) r.scrollIntoView({block:'center', behavior:'instant'}); const b = [...document.querySelectorAll('.cal-row[data-u="b1"] .cal-ra button')].find(x => /Apri/.test(x.textContent)); if(b) b.id = 'vapri'; }); await R.move('#vapri', {ms:900, scroll:false}); await R.at(7.6); await H(R, '#vapri'); await R.at(8.3); await ck(R, '#vapri'); }},
  {t:9.0, run: async R => { await R.hlOff(); await sleep(500); await top(R); await R.move('#usc-tab-m-chi', {ms:500, scroll:false}); await R.at(9.9); await H(R, '#usc-tab-m-chi'); await R.at(10.5); await ck(R, '#usc-tab-m-chi'); }},
  {t:10.9, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo(0, 560)); await R.at(11.1); await H(R, MP + ' .ax-chips'); await R.move(MP + ' .ax-chip:has-text("Anna Verdi")', {ms:500, scroll:false}); await R.at(12.0); await ck(R, MP + ' .ax-chip:has-text("Anna Verdi")'); }},
  {t:12.6, run: async R => { await R.hlOff(); const b = R.F.locator(MP + ' button', {hasText:'+ Altra persona'}).first(); await R.move(b, {ms:700, scroll:false}); await R.at(13.2); await R.fakePrompt('Nome della persona', 'Marco Neri', async () => { await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await b.click(); }); await R.hlOff(); }},
  {t:17.7, run: async R => { await pg(R, 'vrag', "return [...m.querySelectorAll('select')].filter(s => [...s.options].some(o => o.text === '14'))[0]"); await R.F.evaluate(() => document.getElementById('vrag') && document.getElementById('vrag').scrollIntoView({block:'center', behavior:'instant'})); await R.move('#vrag', {ms:500, scroll:false}); await R.at(18.3); await H(R, '#vrag'); await R.at(18.6); await R.selOpen('#vrag', {fast:true}); await R.selPick('#vrag', '14', true); }},
  {t:20.7, run: async R => { await R.hlOff(); await own(R, 'vdays', 'due giorni|2 giorni'); await H(R, '#vdays'); await R.at(25.6); await R.hlOff(); await H(R, '#vrag'); }},
 ]),
sb('b03', 'Da dove arrivano i costi', [
  {t:0.3, run: async R => { await R.hlOff(); await top(R); await H(R, '#usc-tabs'); await R.move('#usc-tab-pasti', {ms:900, scroll:false}); await R.at(5.7); await H(R, '#usc-tab-pasti'); }},
  {t:6.2, run: async R => { await R.move('#usc-tab-m-trasp', {ms:500, scroll:false}); await R.at(7.4); await H(R, '#usc-tab-m-trasp'); }},
  {t:8.1, run: async R => { await R.move('#usc-tab-m-loc', {ms:500, scroll:false}); await R.at(9.5); await H(R, '#usc-tab-m-loc'); }},
  {t:10.3, run: async R => { await R.move('#usc-tab-m-mat', {ms:500, scroll:false}); await R.at(12.1); await H(R, '#usc-tab-m-mat'); }},
  {t:13.0, run: async R => { await R.hlOff(); await R.move('#usc-tab-pasti', {ms:900, scroll:false}); await R.at(14.3); await H(R, '#usc-tab-pasti'); await R.at(14.9); await ck(R, '#usc-tab-pasti'); }},
  {t:15.3, run: async R => { await R.hlOff(); await sleep(500); await view(R, MP + ' .ax-cm'); await R.move(CM(R, 1), {ms:500, scroll:false}); await R.at(16.0); await H(R, {sel:MP + ' .ax-cm', text:'Ho già un costo'}); await R.at(16.9); await ck(R, CM(R, 1)); }},
  {t:17.5, run: async R => { await R.hlOff(); await R.at(17.8); await H(R, MP + ' input[placeholder="es. 8"]'); await R.at(18.4); await R.F.fill(MP + ' input[placeholder="es. 8"]', '8'); }},
  {t:19.0, run: async R => { await R.hlOff(); await pg(R, 'vogni', "return [...m.querySelectorAll('select')].find(s => [...s.options].some(o => o.text.startsWith('€ al giorno')))"); await R.move('#vogni', {ms:400, scroll:false}); await R.at(19.1); await H(R, '#vogni'); await R.selOpen('#vogni', {fast:true}); await R.selPick('#vogni', '€ al giorno a persona', true); }},
  {t:20.9, run: async R => { await R.hlOff(); await pg(R, 'vcibo', "return [...m.querySelectorAll('select')].find(s => [...s.options].some(o => o.text.startsWith('Ragazzi (quota)')))"); await view(R, '#vcibo'); await R.move('#vcibo', {ms:500, scroll:false}); await R.at(21.5); await H(R, '#vcibo'); await R.at(22.0); await R.selOpen('#vcibo', {fast:true}); await R.selPick('#vcibo', 'Ragazzi (quota)', true); }},
 ]),
sb('b04', 'Un trasporto', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-trasp', {ms:700, scroll:false}); await R.at(1.7); await H(R, '#usc-tab-m-trasp'); await R.at(2.2); await ck(R, '#usc-tab-m-trasp'); }},
  {t:2.6, run: async R => { await R.hlOff(); await sleep(500); const ta = MP + ' textarea[placeholder^="es. pullman"]'; await view(R, ta); await R.move(ta, {ms:400, scroll:false}); await R.at(3.0); await H(R, ta); await R.at(3.3); await R.F.fill(ta, 'Pullman andata e ritorno'); }},
  {t:4.4, run: async R => { await R.hlOff(); const e = R.F.locator(MP + ' input[placeholder="€"]').first(); await e.evaluate(x => x.id = 'veur'); await R.move('#veur', {ms:400, scroll:false}); await R.at(4.9); await H(R, '#veur'); await R.at(5.3); await R.F.fill('#veur', '380'); }},
  {t:6.0, run: async R => { await R.at(6.3); await H(R, '#veur'); }},
  {t:7.8, run: async R => { await R.hlOff(); await pg(R, 'vpaga', "return m.querySelector('select.ax-sp-car')"); await R.move('#vpaga', {ms:400, scroll:false}); await R.at(8.1); await H(R, '#vpaga'); await R.at(8.6); await R.selOpen('#vpaga', {fast:true}); await R.selPick('#vpaga', 'Ragazzi (quota)', true); }},
 ]),
sb('b05', 'Una locazione', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-loc', {ms:700, scroll:false}); await R.at(1.5); await H(R, '#usc-tab-m-loc'); await R.at(1.95); await ck(R, '#usc-tab-m-loc'); }},
  {t:2.8, run: async R => { await R.hlOff(); await sleep(400); const ta = MP + ' textarea[placeholder^="es. casa"]'; await view(R, ta); await R.move(ta, {ms:400, scroll:false}); await R.at(3.3); await H(R, ta); await R.at(3.6); await R.F.fill(ta, 'Casa per la notte'); }},
  {t:4.5, run: async R => { await R.hlOff(); const e = R.F.locator(MP + ' input[placeholder="€"]').first(); await e.evaluate(x => x.id = 'veur'); await R.move('#veur', {ms:400, scroll:false}); await R.at(4.9); await H(R, '#veur'); await R.at(5.2); await R.F.fill('#veur', '240'); }},
  {t:7.0, run: async R => { await R.hlOff(); await pg(R, 'vpaga', "return m.querySelector('select.ax-sp-car')"); await R.move('#vpaga', {ms:700, scroll:false}); await R.at(9.0); await H(R, '#vpaga'); }},
 ]),
sb('b06', 'La Cassa', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-costi', {ms:700, scroll:false}); await R.at(1.1); await H(R, '#usc-tab-m-costi'); await R.at(1.6); await ck(R, '#usc-tab-m-costi'); }},
  {t:2.2, run: async R => { await R.hlOff(); await sleep(300); await top(R); await R.F.locator(MP + ' select.ax-pm-s').evaluate(x => x.id = 'vref'); await R.move('#vref', {ms:500, scroll:false}); await R.at(2.9); await H(R, '#vref'); await R.at(5.3); await R.selOpen('#vref', {fast:true}); await R.selPick('#vref', 'Anna Verdi (CU)', true); }},
  {t:7.6, run: async R => { await R.hlOff(); await pg(R, 'vcassa', CASSA); await view(R, '#vcassa', 'start'); await R.at(8.3); await H(R, '#vcassa'); }},
  {t:11.0, run: async R => { await R.hlOff(); await pg(R, 'vcsum', "return m.querySelector('details.usc-mpd summary')"); await R.at(11.6); await H(R, '#vcsum'); }},
  {t:14.0, run: async R => { await R.hlOff(); await pg(R, 'vbars', "return m.querySelector('#usc-costi-all .usc-inc')"); await R.at(15.9); await H(R, '#vbars'); }},
  {t:18.2, run: async R => { await R.hlOff(); await pg(R, 'vi0', "return m.querySelectorAll('#usc-costi-all .usc-inc1')[0]"); await pg(R, 'vi1', "return m.querySelectorAll('#usc-costi-all .usc-inc1')[1]"); await pg(R, 'vi2', "return m.querySelectorAll('#usc-costi-all .usc-inc1')[2]"); await R.at(18.5); await H(R, '#vi0'); await R.at(21.0); await R.hlOff(); await H(R, '#vi1'); await R.at(22.3); await R.hlOff(); await H(R, '#vi2'); }},
  {t:24.0, run: async R => { await R.hlOff(); await H(R, '#vbars'); }},
 ]),
sb('b07', 'Le singole voci', [
  {t:0, run: async R => { await R.hlOff(); await pg(R, 'vrows', ROWS); await view(R, '#vrows'); await R.at(0.5); await H(R, '#vrows'); }},
  {t:2.0, run: async R => { await R.hlOff(); await pg(R, 'vhead', "return " + "m.querySelector('table.usc-tbl tr')"); await R.at(2.1); await H(R, '#vhead'); }},
  {t:4.9, run: async R => { await R.hlOff(); await pg(R, 'vr1', "return m.querySelectorAll('table.usc-tbl tr')[1]"); await pg(R, 'vr2', "return m.querySelectorAll('table.usc-tbl tr')[2]"); await R.at(5.3); await H(R, '#vr1'); await R.at(7.5); await R.hlOff(); await H(R, '#vr2'); await R.at(9.7); await R.hlOff(); await H(R, '#vr1', '#vr2'); }},
  {t:12.3, run: async R => { await R.hlOff(); await R.at(12.6); await H(R, 'tr.usc-npgo'); await R.move('tr.usc-npgo', {ms:900, scroll:false}); await R.at(15.4); await R.hlOff(); await pg(R, 'vnpt', "return m.querySelector('.usc-npt')"); await H(R, '#vnpt'); }},
  {t:17.9, run: async R => { await R.hlOff(); await pg(R, 'vwarn', "return m.querySelector('#usc-costi-all .ax-warn')"); await R.at(18.2); await H(R, '#vwarn'); await R.at(19.2); await R.hlOff(); await H(R, '#vwarn'); }},
 ]),
sb('b08', null, [
  {t:0, run: async R => { await R.hlOff(); await R.zoomOff(); await view(R, 'tr.usc-npgo'); await R.at(2.0); await H(R, 'tr.usc-npgo'); await R.move('tr.usc-npgo', {ms:700, scroll:false}); await R.at(2.9); await ck(R, 'tr.usc-npgo'); }},
  {t:3.6, run: async R => { await R.hlOff(); await sleep(700); await pg(R, 'vpaga2', "return m.querySelector('select.ax-sp-car')"); await view(R, '#vpaga2'); await R.move('#vpaga2', {ms:500, scroll:false}); await R.at(7.4); await H(R, '#vpaga2'); await R.at(7.9); await R.selOpen('#vpaga2', {fast:true}); await R.selPick('#vpaga2', 'Ragazzi (quota)', true); }},
  {t:10.0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-costi', {ms:700, scroll:false}); await R.at(11.4); await H(R, '#usc-tab-m-costi'); await R.at(12.2); await ck(R, '#usc-tab-m-costi'); }},
  {t:12.9, run: async R => { await R.hlOff(); await sleep(500); await pg(R, 'vrows', ROWS); await view(R, '#vrows'); await R.at(13.6); await H(R, '#vrows'); }},
 ]),
sb('b09', 'La quota', [
  {t:0, run: async R => { await R.hlOff(); await R.zoomOff(); await view(R, '.usc-qbig'); await R.at(1.4); await H(R, '.usc-qbig'); await R.at(4.6); await R.zoomTo('.usc-qbig', 1.5); }},
  {t:9.2, run: async R => { await R.hlOff(); await R.zoomOff(); await view(R, '.usc-qcapi'); await R.at(14.0); await zblk(R, '.usc-qcapi'); await R.at(15.2); await H(R, '.usc-qcapi'); }},
  {t:16.6, run: async R => { await pg(R, 'qb0', "return m.querySelectorAll('.usc-qcapi b')[0]"); await pg(R, 'qb1', "return m.querySelectorAll('.usc-qcapi b')[1]"); await pg(R, 'qb2', "return m.querySelectorAll('.usc-qcapi b')[2]"); await pg(R, 'qb3', "return m.querySelectorAll('.usc-qcapi b')[3]"); await pg(R, 'qb4', "return m.querySelectorAll('.usc-qcapi b')[4]"); await R.at(17.4); await R.hlOff(); await H(R, '#qb0'); await R.at(19.7); await R.hlOff(); await H(R, '#qb1'); await R.at(22.6); await R.hlOff(); await H(R, '.usc-qcapi'); await R.at(25.1); await R.hlOff(); await H(R, '#qb2'); await R.at(28.4); await R.hlOff(); await H(R, '#qb3'); await R.at(30.6); await R.hlOff(); await H(R, '#qb4'); }},
 ]),
sb('b10', 'Chi paga la parte dei capi', [
  {t:0, run: async R => { await R.hlOff(); await R.zoomOff(); await pg(R, 'vscen', "return m.querySelector('table.usc-sctab')"); await view(R, '#vscen'); await zblk(R, '#vscen'); await R.at(2.6); await H(R, '#vscen'); }},
  {t:4.4, run: async R => { await pg(R, 'vs1', scrow(1)); await R.at(4.6); await R.hlOff(); await H(R, '#vs1'); await pg(R, 'vs2', scrow(2)); await pg(R, 'vs3', scrow(3)); await pg(R, 'vs4', scrow(4)); await pg(R, 'vs5', scrow(5)); await R.at(9.5); await R.hlOff(); await H(R, '#vs2'); await R.at(19.2); await R.hlOff(); await H(R, '#vs3'); await R.at(25.1); await R.hlOff(); await H(R, '#vs4'); await R.at(26.5); await H(R, '#vs4', '#vs5'); }},
  {t:34.5, run: async R => { await R.hlOff(); await pg(R, 'vb2', "return m.querySelectorAll('table.usc-sctab tr')[2].querySelector('button')"); await R.move('#vb2', {ms:700, scroll:false}); await R.at(35.4); await H(R, '#vb2'); await R.at(37.5); await ck(R, '#vb2'); }},
  {t:38.0, run: async R => { await R.hlOff(); await sleep(500); await pg(R, 'vb4', "return m.querySelectorAll('table.usc-sctab tr')[4].querySelector('button')"); await H(R, '#vb4'); await ck(R, '#vb4', {ms:500}); await sleep(900); }},
 ]),
sb('b11', 'Il contributo', [
  {t:0, run: async R => { await R.hlOff(); await R.zoomOff(); await view(R, MP + ' .usc-contrib input'); await R.at(1.9); await H(R, MP + ' .usc-contrib'); }},
  {t:10.0, run: async R => { await R.hlOff(); await R.F.locator(MP + ' .usc-contrib input').evaluate(x => x.id = 'vcon'); await R.move('#vcon', {ms:700, scroll:false}); await R.at(10.9); await H(R, '#vcon'); await R.at(11.8); await R.F.fill('#vcon', '100'); }},
  {t:12.8, run: async R => { await R.hlOff(); await R.at(16.2); await H(R, '#usc-qres'); }},
 ]),
sb('b12', 'Come si paga', [
  {t:0, run: async R => { await R.hlOff(); await R.zoomOff(); await pg(R, 'vpagabox', "return document.getElementById('usc-paga-box').closest('.usc-mpsec')"); await view(R, '#vpagabox', 'start'); await R.at(1.0); await H(R, '#vpagabox'); }},
  {t:1.9, run: async R => { await R.hlOff(); await R.F.locator('#vpagabox .ax-chip').nth(0).evaluate(x => x.id = 'vc0'); await R.F.locator('#vpagabox .ax-chip').nth(1).evaluate(x => x.id = 'vc1'); await R.F.locator('#vpagabox .ax-chip').nth(2).evaluate(x => x.id = 'vc2'); await H(R, '#vpagabox .ax-chips'); await R.move('#vc0', {ms:700, scroll:false}); await R.at(4.6); await R.move('#vc1', {ms:600, scroll:false}); await R.at(5.9); await R.move('#vc2', {ms:600, scroll:false}); }},
  {t:7.3, run: async R => { await R.hlOff(); await R.move('#vc0', {ms:600, scroll:false}); await R.at(8.1); await H(R, '#vc0'); await R.at(8.5); await ck(R, '#vc0'); }},
  {t:9.4, run: async R => { await R.hlOff(); await sleep(400); await R.at(9.7); await H(R, '#usc-paga-box input[type=date]'); await R.at(12.3); await R.F.fill('#usc-paga-box input[type=date]', '2026-12-29'); }},
  {t:14.2, run: async R => { await R.hlOff(); await R.at(14.5); await H(R, '#usc-paga-box input[placeholder^="IT00"]'); await R.at(14.9); await R.F.fill('#usc-paga-box input[placeholder^="IT00"]', 'IT60X0542811101000000123456'); }},
  {t:15.6, run: async R => { await R.hlOff(); await H(R, '#usc-paga-box input[placeholder^="es. CNGEI"]'); await R.at(16.0); await R.F.fill('#usc-paga-box input[placeholder^="es. CNGEI"]', 'CNGEI Sezione di Pesaro'); }},
  {t:16.8, run: async R => { await R.hlOff(); await own(R, 'vnota', 'valgono'); await R.at(17.0); await H(R, '#vnota'); }},
 ]),
sb('b13', 'Costi giornata per giornata', [
  {t:0, run: async R => { await R.hlOff(); await R.zoomOff(); await pg(R, 'vgiorn', "return [...m.querySelectorAll('summary')].find(s => /COSTI GIORNATA/i.test(s.textContent))"); await view(R, '#vgiorn'); await R.at(1.5); await H(R, '#vgiorn'); await R.at(4.1); await ck(R, '#vgiorn'); }},
  {t:4.8, run: async R => { await R.hlOff(); await sleep(700); await pg(R, 'vgt', "const d = [...m.querySelectorAll('details.usc-mpd')].pop(); return d.querySelector('table')"); await view(R, '#vgt'); await R.at(5.5); await H(R, '#vgt'); }},
  {t:6.5, run: async R => { await pg(R, 'vh1', "return [...m.querySelectorAll('details.usc-mpd')].pop().querySelectorAll('th')[1]"); await pg(R, 'vh2', "return [...m.querySelectorAll('details.usc-mpd')].pop().querySelectorAll('th')[2]"); await pg(R, 'vh3', "return [...m.querySelectorAll('details.usc-mpd')].pop().querySelectorAll('th')[3]"); await pg(R, 'vh4', "return [...m.querySelectorAll('details.usc-mpd')].pop().querySelectorAll('th')[4]"); await R.at(6.9); await R.hlOff(); await H(R, '#vh1'); await R.at(7.7); await R.hlOff(); await H(R, '#vh2'); await R.at(8.2); await R.hlOff(); await H(R, '#vh3'); await R.at(8.6); await R.hlOff(); await H(R, '#vh4'); }},
  {t:9.3, run: async R => { await R.hlOff(); await pg(R, 'vc1', "return [...m.querySelectorAll('details.usc-mpd')].pop().querySelectorAll('tr')[1].querySelectorAll('td')[2]"); await pg(R, 'vc2', "return [...m.querySelectorAll('details.usc-mpd')].pop().querySelectorAll('tr')[2].querySelectorAll('td')[2]"); await R.at(10.3); await H(R, '#vc1', '#vc2'); }},
  {t:14.3, run: async R => { await R.hlOff(); await own(R, 'vnota2', 'non sono di una giornata'); await R.at(15.0); await H(R, '#vnota2'); }},
 ]),
sb('b14', null, [
  {t:0, run: async R => { await R.hlOff(); await R.at(1.0); await H(R, '.usc-ctab button.usc-lnk'); await R.move('.usc-ctab button.usc-lnk', {ms:1000, scroll:false}); }},
 ]),
sb('b15', null, [
  {t:0, run: async R => { await R.hlOff(); await R.zoomOff(); await top(R); await R.at(2.4); await H(R, '#usc-tabs'); }},
  {t:5.4, run: async R => { await R.hlOff(); await pg(R, 'vcsum', "return m.querySelector('details.usc-mpd summary')"); await view(R, '#vcsum', 'start'); await R.at(5.7); await H(R, '#vcsum'); }},
  {t:9.8, run: async R => { await R.hlOff(); await view(R, '.usc-qbig'); await R.at(10.0); await H(R, '.usc-qbig'); }},
  {t:15.0, run: async R => { await R.hlOff(); await view(R, MP + ' .usc-contrib'); await R.at(15.3); await H(R, MP + ' .usc-contrib'); }},
  {t:16.8, run: async R => { await R.hlOff(); await view(R, '#usc-paga-box'); await R.at(17.0); await H(R, '#usc-paga-box'); }},
  {t:19.4, run: async R => { await R.hlOff(); }},
 ]),
];
