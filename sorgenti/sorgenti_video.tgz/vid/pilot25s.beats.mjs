// Video 25 (sincronizzato): Durante, sicurezza e piano B
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'25s', title:'Durante, sicurezza e piano B', caption:'PEE CNGEI · Durante, sicurezza e piano B'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts25.json', import.meta.url)));
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block).catch(() => {});
const top = R => R.F.evaluate(() => window.scrollTo(0, 0));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const MP = '.usc-modpage';
// --- gruppi del blocco ---
const GF = "const d = [...document.querySelectorAll('.usc-blk details')].find(x => { const s = x.querySelector(':scope > summary.usc-fldh'); return s && s.innerText.trim().toUpperCase().startsWith(KEY); });";
const gt = (R, key, id, body = 'return d') => R.F.evaluate(([key, id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const d = [...document.querySelectorAll('.usc-blk details')].find(x => { const s = x.querySelector(':scope > summary.usc-fldh'); return s && s.innerText.trim().toUpperCase().startsWith(key); }); if(!d) return false; const el = new Function('d', body)(d); if(el) el.id = id; return !!el; }, [key, id, body]).catch(() => false);
const gopenQ = (R, key) => R.F.evaluate(key => { const d = [...document.querySelectorAll('.usc-blk details')].find(x => { const s = x.querySelector(':scope > summary.usc-fldh'); return s && s.innerText.trim().toUpperCase().startsWith(key); }); return !!(d && d.open); }, key);
const gclose = (R, key) => R.F.evaluate(key => { const d = [...document.querySelectorAll('.usc-blk details')].find(x => { const s = x.querySelector(':scope > summary.usc-fldh'); return s && s.innerText.trim().toUpperCase().startsWith(key); }); if(d) d.open = false; }, key);
const gscroll = R => R.F.evaluate(() => { const s = document.getElementById('vgs'); if(s) window.scrollTo(0, s.getBoundingClientRect().top + window.scrollY - 120); });
const Gopen = async (R, key, tHl, tCk) => { await R.hlOff(); await gt(R, key, 'vgs', "return d.querySelector(':scope > summary')"); await gscroll(R); await R.move('#vgs', {ms:600, scroll:false, dx:0.3}); await R.at(tHl); await H(R, '#vgs'); await R.at(tCk); if(!(await gopenQ(R, key))) await ck(R, '#vgs', {dx:0.3}); await sleep(250); await R.hlOff(); };
const G = (R, key, id, body) => gt(R, key, id, body);
const TY = async (R, sel, text) => { await R.type(sel, text.slice(0, 9), 40); await R.F.fill(sel, text); };
const pickM = async (R, sel, pick) => { await R.selOpen(sel, {fast:true}); await R.selPick(sel, pick, true); };

export async function open(F){
  await F.evaluate(() => shOpen('p1', 0)); await sleep(4500);
}

export const beats = [
sb('b01', 'Durante, sicurezza e piano B', [
  {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
sb('b02', 'Il blocco di un’attività', [
  {t:0.2, run: async R => { await R.move(sg(R, 'Realizzare'), {ms:350, scroll:false}); await R.at(0.5); await ck(R, sg(R, 'Realizzare'), {ms:60}); await R.move(si(R, 'Calendario e attività'), {ms:250, scroll:false}); await R.at(1.2); await ck(R, si(R, 'Calendario e attività'), {ms:60}); }},
  {t:1.9, run: async R => { await R.hlOff(); await sleep(500); await top(R); await R.F.evaluate(() => { const b = [...document.querySelectorAll('.cal-row[data-u="r1"] .cal-ra button')].find(x => /Apri/.test(x.textContent)); if(b) b.id = 'vapri'; }); await R.move('#vapri', {ms:800, scroll:false}); await R.at(3.0); await H(R, '#vapri'); await R.at(5.9); await ck(R, '#vapri'); }},
  {t:6.6, run: async R => { await R.hlOff(); await sleep(700); await view(R, '.usc-blk', 'start'); await R.at(7.5); await H(R, '.usc-blk'); await R.at(10.9); await R.hlOff(); await H(R, '.usc-blk .usc-bh'); await R.at(11.7); await ck(R, '.usc-blk .usc-bh', {dx:0.4}); }},
  {t:12.5, run: async R => { await R.hlOff(); await sleep(700); await R.F.evaluate(() => { const L = [...document.querySelectorAll('.usc-blk .usc-mv2')]; const a = L.find(e => /^Referente dell/.test(e.textContent.trim())); const c = L.find(e => /^Chi la conduce/.test(e.textContent.trim())); if(a) a.id = 'vrefatt'; if(c) c.id = 'vcond'; const b = document.querySelector('.usc-blk'); if(b){ const y = b.getBoundingClientRect().top + window.scrollY - 60; window.scrollTo(0, y); } }); await R.at(13.4); }},
  {t:15.0, run: async R => { await R.hlOff(); await R.move('#vrefatt', {ms:500, scroll:false}); await R.at(15.4); await H(R, '#vrefatt'); await R.at(16.3); await R.hlOff(); await R.move('#vcond', {ms:300, scroll:false}); await H(R, '#vcond'); }},
  {t:17.5, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const g = document.querySelector('.usc-blk summary.usc-fldh'); if(g) window.scrollTo(0, g.getBoundingClientRect().top + window.scrollY - 140); }); await R.at(19.4); await H(R, {sel:'.usc-blk summary.usc-fldh', all:true}); }},
  {t:21.9, run: async R => { const keys = [['OBIETTIVI', 22.08], ['STRUMENTI', 23.6], ['TIPO', 25.0], ['SCALETTA', 26.12], ['LANCIO', 27.04], ['MATERIALI', 29.24], ['PIANO', 29.88], ['SICUREZZA', 30.72], ['BENESSERE', 31.6], ['LINK', 33.28]]; for (const [k, t] of keys) { await R.at(t); await R.hlOff(); await gt(R, k, 'vsm', "return d.querySelector(':scope > summary')"); await H(R, '#vsm'); } }},
  {t:33.9, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const s = [...document.querySelectorAll('.usc-blk summary.usc-fldh')][0]; const a = [...s.querySelectorAll('*')].filter(e => /^[↑↓]$/.test(e.textContent.trim())); a.forEach((e, i) => e.id = 'vfr' + i); }); await R.at(34.4); await H(R, '#vfr0', '#vfr1'); await R.at(37.0); await R.hlOff(); }},
 ]),
sb('b03', 'Lancio, sviluppo e conclusione', [
  {t:0, run: async R => { await R.hlOff(); await Gopen(R, 'LANCIO', 1.2, 3.6); }},
  {t:4.4, run: async R => { await R.hlOff(); await G(R, 'LANCIO', 'vsrc', "return [...d.querySelectorAll('*')].filter(e => e.children.length === 0 && /Dai percorsi/.test(e.textContent)).pop()"); await R.at(5.2); await H(R, '#vsrc'); }},
  {t:14.3, run: async R => { await R.hlOff(); await G(R, 'LANCIO', 'vlan', "return [...d.querySelectorAll('*')].filter(e => e.children.length === 0 && /^Presentiamo/.test(e.textContent.trim()))[0]"); await R.at(14.6); await H(R, '#vlan'); }},
  {t:16.1, run: async R => { await R.hlOff(); await G(R, 'LANCIO', 'vn1', "return [...d.querySelectorAll('*')].filter(e => e.children.length === 0 && /non ancora scritto/.test(e.textContent))[0]"); await G(R, 'LANCIO', 'vn2', "return [...d.querySelectorAll('*')].filter(e => e.children.length === 0 && /non ancora scritto/.test(e.textContent))[1]"); await R.at(16.3); await H(R, '#vn1', '#vn2'); }},
  {t:19.0, run: async R => { await R.hlOff(); await G(R, 'LANCIO', 'vmod', "return [...d.querySelectorAll('button')].find(b => /Modifica qui/.test(b.textContent))"); await R.move('#vmod', {ms:500, scroll:false}); await R.at(19.3); await H(R, '#vmod'); await R.at(20.2); await ck(R, '#vmod'); }},
  {t:20.7, run: async R => { await R.hlOff(); await sleep(500); await G(R, 'LANCIO', 'vsv', "return d.querySelectorAll('textarea.ax-ta')[1]"); await R.move('#vsv', {ms:400, scroll:false}); await R.at(21.0); await H(R, '#vsv'); await R.at(21.9); await TY(R, '#vsv', 'Ognuno dice il proprio nome e un gesto, e il gruppo lo ripete.', 50); }},
  {t:26.2, run: async R => { await R.hlOff(); await G(R, 'LANCIO', 'vco', "return d.querySelectorAll('textarea.ax-ta')[2]"); await R.move('#vco', {ms:400, scroll:false}); await R.at(26.8); await H(R, '#vco'); await R.at(27.6); await TY(R, '#vco', 'Cerchio finale: una parola per dire come ci si sente.', 50); }},
  {t:31.3, run: async R => { await R.hlOff(); await G(R, 'LANCIO', 'vfat', "return [...d.querySelectorAll('button.btn-primary')].find(b => /Fatto/.test(b.textContent))"); await R.move('#vfat', {ms:300, scroll:false}); await R.at(31.6); await H(R, '#vfat'); await R.at(32.1); await ck(R, '#vfat'); }},
  {t:32.6, run: async R => { await R.hlOff(); await sleep(600); await G(R, 'LANCIO', 'vl1', "return [...d.querySelectorAll('button.usc-lnk')].find(b => /Vai ai percorsi/.test(b.textContent))"); await G(R, 'LANCIO', 'vl2', "return [...d.querySelectorAll('button.usc-lnk')].find(b => /Cambia attività/.test(b.textContent))"); await R.at(33.7); await H(R, '#vl1'); await R.at(35.8); await R.hlOff(); await H(R, '#vl2'); }},
 ]),
sb('b04', 'La scaletta', [
  {t:0, run: async R => { await R.hlOff(); await gclose(R, 'LANCIO'); await Gopen(R, 'SCALETTA', 0.3, 0.9); }},
  {t:1.2, run: async R => { await G(R, 'SCALETTA', 'vss', "return d.querySelectorAll('select.ax-in')[0]"); await view(R, '#vss'); await R.move('#vss', {ms:500, scroll:false}); await R.at(1.5); await H(R, '#vss'); await R.at(2.3); await pickM(R, '#vss', '07:30'); }},
  {t:4.5, run: async R => { await R.hlOff(); await G(R, 'SCALETTA', 'vsd', "return d.querySelectorAll('select.ax-in')[1]"); await R.move('#vsd', {ms:350, scroll:false}); await R.at(5.0); await H(R, '#vsd'); await pickM(R, '#vsd', '10′'); }},
  {t:7.2, run: async R => { await R.hlOff(); await G(R, 'SCALETTA', 'vsd', "return d.querySelectorAll('select.ax-in')[3]"); await R.move('#vsd', {ms:350, scroll:false}); await H(R, '#vsd'); await sleep(250); await R.F.selectOption('#vsd', {label:'25′'}); }},
  {t:9.1, run: async R => { await R.hlOff(); await G(R, 'SCALETTA', 'vsd', "return d.querySelectorAll('select.ax-in')[5]"); await R.move('#vsd', {ms:350, scroll:false}); await H(R, '#vsd'); await sleep(250); await R.F.selectOption('#vsd', {label:'10′'}); }},
  {t:11.0, run: async R => { await R.hlOff(); await G(R, 'SCALETTA', 'vrows', "return d.querySelector('select.ax-in').closest('div').parentElement"); await R.at(11.3); await H(R, '#vrows'); }},
  {t:14.4, run: async R => { await R.hlOff(); await G(R, 'SCALETTA', 'vsw', "return d.querySelectorAll('select.ax-in')[2]"); await R.move('#vsw', {ms:500, scroll:false}); await R.at(15.2); await H(R, '#vsw'); await R.at(16.2); await pickM(R, '#vsw', 'Anna Verdi (CU)'); }},
  {t:18.3, run: async R => { await R.hlOff(); await G(R, 'SCALETTA', 'vtot', "return d.querySelector('.ax-tot')"); await view(R, '#vtot'); await R.at(19.4); await H(R, '#vtot'); }},
  {t:26.4, run: async R => { await R.hlOff(); await G(R, 'SCALETTA', 'vadd', "return [...d.querySelectorAll('button.ax-add')].find(b => /Aggiungi riga/.test(b.textContent))"); await R.move('#vadd', {ms:500, scroll:false}); await R.at(27.0); await H(R, '#vadd'); }},
 ]),
sb('b05', 'Strumenti e tipo', [
  {t:0, run: async R => { await R.hlOff(); await gclose(R, 'SCALETTA'); await Gopen(R, 'STRUMENTI', 0.7, 1.5); }},
  {t:3.2, run: async R => { await R.hlOff(); await G(R, 'STRUMENTI', 'vstr', "return d.querySelector('select.ax-in')"); await view(R, '#vstr'); await R.move('#vstr', {ms:400, scroll:false}); await R.at(3.9); await H(R, '#vstr'); await R.at(4.6); await R.selOpen('#vstr', {fast:true}); await R.at(5.3); await R.selHover('Legge', 200); await R.selPick('#vstr', 'Motto', true); }},
  {t:6.7, run: async R => { await R.hlOff(); await gclose(R, 'STRUMENTI'); await Gopen(R, 'TIPO', 7.3, 7.9); }},
  {t:8.5, run: async R => { await R.hlOff(); await G(R, 'TIPO', 'vtip', "return d.querySelector('select.ax-in')"); await view(R, '#vtip'); await R.move('#vtip', {ms:400, scroll:false}); await R.at(9.1); await H(R, '#vtip'); await R.at(9.7); await R.selOpen('#vtip', {fast:true}); await R.at(10.5); await R.selPick('#vtip', 'Gioco a basi', true); }},
 ]),
sb('b06', 'Cosa osservo', [
  {t:0, run: async R => { await R.hlOff(); await gclose(R, 'TIPO'); await Gopen(R, 'OBIETTIVI', 2.5, 3.4); }},
  {t:4.0, run: async R => { await R.hlOff(); await G(R, 'OBIETTIVI', 'vper', "return [...d.querySelectorAll('*')].filter(e => e.children.length === 0 && /^Personale · P1/.test(e.textContent.trim()))[0]"); await R.at(5.5); await H(R, '#vper'); }},
  {t:6.3, run: async R => { await R.hlOff(); await G(R, 'OBIETTIVI', 'vob', "return [...d.querySelectorAll('*')].filter(e => e.children.length === 0 && /^Conoscere il proprio corpo/.test(e.textContent.trim()))[0]"); await R.at(6.5); await H(R, '#vob'); }},
  {t:8.0, run: async R => { await R.hlOff(); await G(R, 'OBIETTIVI', 'voss', "return d.querySelector('select.ax-pm-s')"); await view(R, '#voss'); await R.move('#voss', {ms:400, scroll:false}); await R.at(8.8); await H(R, '#voss'); await R.at(9.5); await pickM(R, '#voss', 'Anna Verdi (CU)'); }},
  {t:10.9, run: async R => { await R.hlOff(); await G(R, 'OBIETTIVI', 'vis', "return [...d.querySelectorAll('summary')].find(x => /^Indicatori specifici/.test(x.innerText.trim()))"); await view(R, '#vis'); await R.move('#vis', {ms:400, scroll:false}); await R.at(11.5); await H(R, '#vis'); await R.at(12.9); await R.F.evaluate(() => { const s = document.getElementById('vis'); if(s && !s.parentElement.open) ST.ripple && 0; }); const o = await R.F.evaluate(() => { const s = document.getElementById('vis'); return !!(s && s.parentElement.open); }); if(!o) await ck(R, '#vis', {dx:0.3}); }},
  {t:13.4, run: async R => { await R.hlOff(); await sleep(400); await G(R, 'OBIETTIVI', 'vind', "return [...d.querySelectorAll('*')].filter(e => e.children.length === 0 && /^Descrivono le caratteristiche/.test(e.textContent.trim()))[0]"); await view(R, '#vind'); await R.at(13.7); await H(R, '#vind'); }},
  {t:16.3, run: async R => { await R.hlOff(); await G(R, 'OBIETTIVI', 'vosc', "return [...d.querySelectorAll('select.ax-in')].find(s => /Osserva anche un indicatore/.test(s.options[0].text))"); await view(R, '#vosc'); await R.move('#vosc', {ms:600, scroll:false}); await R.at(19.6); await H(R, '#vosc'); await R.at(20.2); await R.selOpen('#vosc', {fast:true}); await R.at(21.3); await R.P.evaluate(() => ST.menuOff()); }},
  {t:21.6, run: async R => { await R.hlOff(); await G(R, 'OBIETTIVI', 'vaa', "return [...d.querySelectorAll('button.ax-add')].find(b => /Osserva anche altro/.test(b.textContent))"); await R.move('#vaa', {ms:500, scroll:false}); await R.at(22.3); await H(R, '#vaa'); await R.at(26.0); await R.hlOff(); }},
 ]),
sb('b07', 'Sicurezza', [
  {t:0, run: async R => { await R.hlOff(); await gclose(R, 'OBIETTIVI'); await Gopen(R, 'SICUREZZA', 0.6, 1.9); }},
  {t:3.0, run: async R => { await G(R, 'SICUREZZA', 'vsr', "return d.querySelector('select.ax-pm-s')"); await R.move('#vsr', {ms:500, scroll:false}); await R.at(3.6); await H(R, '#vsr'); }},
  {t:7.4, run: async R => { await R.hlOff(); await G(R, 'SICUREZZA', 'vri', "return d.querySelector('textarea.ax-ta')"); await R.move('#vri', {ms:400, scroll:false}); await R.at(7.8); await H(R, '#vri'); await R.at(10.6); await TY(R, '#vri', 'Spazio libero per correre, sedie e tavoli messi da parte.', 52); }},
  {t:14.6, run: async R => { await R.hlOff(); await G(R, 'SICUREZZA', 'vnu', "return d.querySelector('textarea.ax-in')"); await R.move('#vnu', {ms:400, scroll:false}); await R.at(15.1); await H(R, '#vnu'); await R.at(16.1); await TY(R, '#vnu', '112, referente della sede', 60); }},
  {t:18.6, run: async R => { await R.hlOff(); await G(R, 'SICUREZZA', 'vk1', "return d.querySelectorAll('a')[0]"); await G(R, 'SICUREZZA', 'vk2', "return d.querySelectorAll('a')[1]"); await view(R, '#vk1'); await R.at(19.7); await H(R, '#vk1', '#vk2'); await R.at(21.0); await R.hlOff(); await H(R, '#vk1'); await R.at(23.6); await R.hlOff(); await H(R, '#vk2'); }},
 ]),
sb('b08', 'Benessere e inclusione', [
  {t:0, run: async R => { await R.hlOff(); await gclose(R, 'SICUREZZA'); await Gopen(R, 'BENESSERE', 0.2, 1.2); }},
  {t:2.0, run: async R => { await G(R, 'BENESSERE', 'vbr', "return d.querySelector('select.ax-pm-s')"); await R.move('#vbr', {ms:400, scroll:false}); await R.at(2.8); await H(R, '#vbr'); }},
  {t:3.9, run: async R => { await R.hlOff(); await G(R, 'BENESSERE', 'vba', "return d.querySelectorAll('textarea.ax-ta')[0]"); await R.move('#vba', {ms:500, scroll:false}); await R.at(5.3); await H(R, '#vba'); }},
  {t:7.0, run: async R => { await R.hlOff(); await G(R, 'BENESSERE', 'vbh', "return [...d.querySelectorAll('*')].filter(e => e.children.length === 0 && /senza nomi|dati sanitari/i.test(e.textContent)).pop()"); await R.at(7.2); await H(R, '#vbh'); await R.at(16.4); await R.hlOff(); await H(R, '#vba'); await R.at(17.2); await TY(R, '#vba', 'Chi si espone poco, chi è appena arrivato.', 60); }},
  {t:20.4, run: async R => { await R.hlOff(); await G(R, 'BENESSERE', 'vbc', "return d.querySelectorAll('textarea.ax-ta')[1]"); await R.move('#vbc', {ms:400, scroll:false}); await R.at(21.6); await H(R, '#vbc'); await R.at(24.3); await TY(R, '#vbc', 'Una coppia di riferimento e la possibilità di dire “passo” senza giudizio.', 46); }},
 ]),
sb('b09', 'Inclusione e BES', [
  {t:0, run: async R => { await R.hlOff(); await G(R, 'BENESSERE', 'vfx', "return d.querySelector('button.usc-fx')"); await gt(R, 'BENESSERE', 'vgs', "return d.querySelector(':scope > summary')"); await gscroll(R); await R.move('#vfx', {ms:900, scroll:false}); await R.at(2.2); await H(R, '#vfx'); await R.at(4.6); await ck(R, '#vfx'); }},
  {t:5.0, run: async R => { await R.hlOff(); await sleep(600); await R.at(10.8); await R.F.evaluate(() => { const b = [...document.querySelectorAll('button')].filter(x => /^Chiudi$/.test(x.textContent.trim())).pop(); let p = b; while(p && !(p.scrollHeight > p.clientHeight + 20 && /auto|scroll/.test(getComputedStyle(p).overflowY))) p = p.parentElement; if(p){ p.id = 'vmsc'; p.scrollTo({top:(p.scrollHeight - p.clientHeight) * 0.25, behavior:'smooth'}); } }); await R.at(13.5); await R.F.evaluate(() => { const p = document.getElementById('vmsc'); if(p) p.scrollTo({top:(p.scrollHeight - p.clientHeight) * 0.55, behavior:'smooth'}); }); await R.at(16.2); await R.F.evaluate(() => { const p = document.getElementById('vmsc'); if(p) p.scrollTo({top:(p.scrollHeight - p.clientHeight) * 0.9, behavior:'smooth'}); }); }},
  {t:18.8, run: async R => { await R.F.evaluate(() => { const b = [...document.querySelectorAll('button')].filter(x => /^Chiudi$/.test(x.textContent.trim())).pop(); if(b) b.id = 'vchi'; }); await R.move('#vchi', {ms:700, scroll:false}); await R.at(19.9); await H(R, '#vchi'); await R.at(20.8); await ck(R, '#vchi'); await sleep(400); await R.hlOff(); }},
 ]),
sb('b10', 'Il Piano B', [
  {t:0, run: async R => { await R.hlOff(); await gclose(R, 'BENESSERE'); await Gopen(R, 'PIANO B', 0.7, 1.1); }},
  {t:1.5, run: async R => { await G(R, 'PIANO B', 'vpr', "return d.querySelector('select.ax-pm-s')"); await R.move('#vpr', {ms:400, scroll:false}); await R.at(1.9); await H(R, '#vpr'); }},
  {t:2.8, run: async R => { await R.hlOff(); await G(R, 'PIANO B', 'vch', "return d.querySelector('button.ax-chip').parentElement"); await R.at(3.4); await H(R, '#vch'); }},
  {t:6.0, run: async R => { const L = [['Pioggia', 6.2], ['Pochi presenti', 7.6], ['Manca materiale', 8.8], ['Il tempo non basta', 10.1], ['Altro', 12.5]]; for (const [k, t] of L) { await R.at(t); await R.hlOff(); await G(R, 'PIANO B', 'vcx', "return [...d.querySelectorAll('button.ax-chip')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(k) + "))"); await H(R, '#vcx'); } }},
  {t:13.3, run: async R => { await R.hlOff(); await G(R, 'PIANO B', 'vp1', "return [...d.querySelectorAll('button.ax-chip')].find(b => /^Pioggia/.test(b.innerText.trim()))"); await R.move('#vp1', {ms:500, scroll:false}); await R.at(14.5); await ck(R, '#vp1'); }},
  {t:15.2, run: async R => { await R.hlOff(); await sleep(400); await G(R, 'PIANO B', 'vpb1', "return d.querySelector('textarea.ax-ta')"); await R.at(16.3); await H(R, '#vpb1'); await R.at(19.3); await TY(R, '#vpb1', 'Si gioca in sede, spostando i tavoli.', 62); }},
  {t:22.2, run: async R => { await R.hlOff(); await G(R, 'PIANO B', 'vp2', "return [...d.querySelectorAll('button.ax-chip')].find(b => /^Pochi presenti/.test(b.innerText.trim()))"); await R.move('#vp2', {ms:500, scroll:false}); await R.at(23.5); await ck(R, '#vp2'); await sleep(500); await R.F.evaluate(() => { const b = [...document.querySelectorAll('button.ax-chip')].find(x => /^Pochi presenti/.test(x.innerText.trim())); if(b && !b.classList.contains('on')) b.click(); }); }},
  {t:24.3, run: async R => { await R.hlOff(); await sleep(400); await G(R, 'PIANO B', 'vpb2', "return d.querySelectorAll('textarea.ax-ta')[1]"); await R.at(24.8); await H(R, '#vpb2'); await R.at(25.3); await TY(R, '#vpb2', 'Si fa un solo gruppo.', 80); }},
  {t:27.0, run: async R => { await R.hlOff(); await G(R, 'PIANO B', 'vch', "return d.querySelector('button.ax-chip').parentElement"); await H(R, '#vch'); }},
 ]),
sb('b11', 'I moduli dell’evento', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.at(2.7); await H(R, '#usc-tabs'); }},
  {t:4.2, run: async R => { await R.hlOff(); await R.move('#usc-tab-m-sic', {ms:600, scroll:false}); await R.at(5.0); await H(R, '#usc-tab-m-sic'); await R.at(5.7); await ck(R, '#usc-tab-m-sic'); }},
  {t:6.1, run: async R => { await R.hlOff(); await sleep(700); await view(R, MP, 'start'); await R.F.evaluate(() => { const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const s = [...m.querySelectorAll('summary.usc-mpst')].find(x => /note generali|per tutto/i.test(x.innerText)); if(s) s.id = 'vsum'; }); await R.move('#vsum', {ms:500, scroll:false}); await R.at(6.7); await H(R, '#vsum'); }},
  {t:11.3, run: async R => { await R.hlOff(); await sleep(300); await R.F.evaluate(() => { const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const s = [...m.querySelectorAll('.usc-mpst')].find(x => /nelle attività/i.test(x.innerText)); if(s){ s.id = 'vpdh'; s.scrollIntoView({block:'center', behavior:'instant'}); } }); await R.move('#vpdh', {ms:500, scroll:false}); await R.at(12.1); await H(R, '#vpdh'); }},
  {t:16.2, run: async R => { await R.hlOff(); await sleep(300); await R.F.evaluate(() => { const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const r = m.querySelector('.usc-pdone .usc-pdr'); if(r) r.id = 'vris'; const o = [...m.querySelectorAll('.usc-mpst .ax-opt')].pop(); if(o) o.id = 'vopt'; }); await R.at(16.9); await H(R, '#vris'); await R.at(21.2); await R.hlOff(); await H(R, '#vopt'); }},
 ]),
sb('b12', 'Benessere e Piano B', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-ben', {ms:700, scroll:false}); await R.at(1.7); await H(R, '#usc-tab-m-ben'); await R.at(2.1); await ck(R, '#usc-tab-m-ben'); }},
  {t:2.8, run: async R => { await R.hlOff(); await R.move('#usc-tab-m-pb', {ms:400, scroll:false}); await R.at(3.5); await H(R, '#usc-tab-m-pb'); await R.at(4.0); await ck(R, '#usc-tab-m-pb'); }},
  {t:4.3, run: async R => { await R.hlOff(); await sleep(700); await view(R, MP, 'start'); await R.F.evaluate(() => { const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); const r = m.querySelector('select.ax-pm-s'); if(r) r.id = 'vref'; const s = [...m.querySelectorAll('summary.usc-mpst')].find(x => /note generali|per tutto/i.test(x.innerText)); if(s) s.id = 'vsum'; const p = [...m.querySelectorAll('.usc-mpst')].find(x => /nelle attività/i.test(x.innerText)); if(p) p.id = 'vpdh'; }); await R.at(5.4); await H(R, '#vref'); await R.at(6.7); await R.hlOff(); await H(R, '#vsum'); await R.at(7.8); await R.hlOff(); await H(R, '#vpdh'); }},
 ]),
sb('b13', null, [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.at(10.2); await H(R, '#usc-tabs'); await R.at(16.0); await R.hlOff(); }},
 ]),
];
