// Video 26 (sincronizzato): Costruire la giornata. Ogni segmento {t} parte insieme alla frase che inizia al secondo t del file voce.
import { beats as OLD } from './pilot26.beats.mjs';
export const META = {n:'26', title:'Costruire la giornata', caption:'PEE CNGEI · Costruire la giornata'};
const O = id => OLD.find(b => b.id === id);
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block);
const bt = (R, id, n) => R.F.evaluate(([id, n]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const bs = [...document.querySelectorAll('.usc-blk')]; const b = bs[n < 0 ? bs.length + n : n]; if(b) b.id = id; return !!b; }, [id, n]);
const bi = async (R, id, n, body) => { for (let i = 0; i < 10; i++) { const ok = await R.F.evaluate(([id, n, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const bs = [...document.querySelectorAll('.usc-blk')]; const b = bs[n < 0 ? bs.length + n : n]; if(!b) return false; const el = new Function('b', body)(b); if(el) el.id = id; return !!el; }, [id, n, body]); if(ok) return true; await R.sleepx(300); } console.log('BI-FAIL', id); return false; };
const pg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]);
const setTxt = async (R, sel, text) => { await R.click(sel, {scroll:false, ms:600}); await R.P.keyboard.press('Control+A'); await R.P.keyboard.type(text, {delay:55}); await R.sleepx(150); await R.P.keyboard.press('Tab'); await R.sleepx(350); };
const TT = "const s = document.querySelector('.usc-slot[data-tslot]'); let p = s; while(p && !/Time table/.test(p.innerText.slice(0, 60))) p = p.parentElement; return p;";
const BAR = "const s = [...document.querySelectorAll('select')].find(s => !s.closest('.usc-blk') && [...s.options].some(o => o.text === '07:30' || o.text === '15:00')); let p = s; while(p && !/Foglio della giornata/.test(p.innerText)) p = p.parentElement; return p;";
const STS = "return [...document.querySelectorAll('select')].find(s => !s.closest('.usc-blk') && [...s.options].some(o => o.text === '15:00'))";
const slot = (R, id, txt) => R.F.evaluate(([id, txt]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const s = [...document.querySelectorAll('.usc-slot[data-tslot]')].find(e => e.innerText.includes(txt)); if(s) s.id = id; return !!s; }, [id, txt]);
const durSet = async (R, n, text) => { await bi(R, 'vdu', n, "return b.querySelector('textarea.usc-durin')"); await setTxt(R, '#vdu', text); };
const titSet = async (R, n, text) => { await bi(R, 'vti', n, "return b.querySelector('textarea.usc-bti')"); await setTxt(R, '#vti', text); };
const tagMe = (R) => R.F.evaluate(() => { const b = [...document.querySelectorAll('.usc-blk')].find(x => /Merenda/.test(x.querySelector('.usc-btt')?.innerText || '')); document.querySelectorAll('#vme').forEach(x => x.removeAttribute('id')); if(b) b.id = 'vme'; return !!b; });
const tb = async (R, id, rx, body, last = false) => { for (let i = 0; i < 10; i++) { const ok = await R.F.evaluate(([id, rx, body, last]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const bs = [...document.querySelectorAll('.usc-blk')].filter(x => new RegExp(rx).test(x.querySelector('.usc-btt')?.innerText || '')); const b = last ? bs[bs.length - 1] : bs[0]; if(!b) return false; const el = body ? new Function('b', body)(b) : b; if(el) el.id = id; return !!el; }, [id, rx, body, last]); if(ok) return true; await R.sleepx(300); } console.log('TB-FAIL', id); return false; };
const opened = (R, sel) => R.F.evaluate(sel => !!document.querySelector(sel + ' textarea.usc-bti')?.offsetParent, sel);
const palTap = async (R, rx) => { await R.hlOff(); await view(R, '.usc-pals', 'center'); await R.click(R.F.locator('.usc-pi', {hasText:rx}).first(), {scroll:false}); await R.sleepx(1500); };


const pal = (R, x) => ({sel:'.usc-pi', text:x});
const GRID = "";
const hvPal = async (R, rx, ms = 900) => { await view(R, '.usc-pals', 'center'); await R.move(R.F.locator('.usc-pi', {hasText:rx}).first(), {ms, scroll:false}); };
const sb = (id, segs, extra = {}) => ({id, scene:O(id).scene, say:O(id).say, cards:O(id).cards, segs, ...extra});

export const beats = [
 sb('b01', [
  {t:0, run: async R => { await R.moveTo(760, 520, 1400); }},
  {t:5.28}, {t:16.64}, {t:21.44},
 ]),
 sb('b02', [
  {t:0, run: async R => { await R.hl('.cal-row[data-u="r1"] .cal-ra .cal-bt2'); await R.at(0.5); await R.click('.cal-row[data-u="r1"] .cal-ra .cal-bt2', {scroll:false, ms:700}); await R.sleepx(1200); }},
  {t:2.16, run: async R => { await pg(R, 'vday', "return [...document.querySelectorAll('.usc-tab')].find(e => /^Sab 7/.test(e.innerText.trim()))"); await view(R, '#vday', 'center'); await R.hl('#vday'); }},
  {t:6.64, run: async R => { await pg(R, 'vtt', TT); await pg(R, 'vbar', BAR); await view(R, '#vtt', 'center'); await R.hl('#vtt'); await R.zoomTo('#vtt', 1.15, '#vbar'); }},
  {t:13.12, keep:true, run: async R => { await R.move('.usc-slot[data-tslot]', {ms:1100, scroll:false}); }},
  {t:18.24, run: async R => { await R.hl('#vbar'); }},
  {t:26.48, run: async R => { await pg(R, 'vst', STS); await R.hl('#vst'); await R.move('#vst', {ms:1200, scroll:false}); }},
  {t:31.44, keep:true, run: async R => { await R.selOpen('#vst'); }},
  {t:34.64, keep:true, run: async R => { await R.selPick('#vst', '15:00'); }},
  {t:36.0, run: async R => { await pg(R, 'vtt', TT); await R.hl('#vtt'); }},
 ], {setup: async R => { await R.zoomOff(); await R.click(R.F.locator('#sh-side button.sh-gh', {hasText:'Realizzare'}), {scroll:false, ms:600}); await R.click(R.F.locator('#sh-side .sh-si[onclick*="shCal"]'), {scroll:false, ms:600}); await R.sleepx(600); await R.F.evaluate(() => window.scrollTo(0, 0)); await R.sleepx(300); }}),
 sb('b03', [
  {t:0, run: async R => { await R.zoomOff(); await view(R, '.usc-pals', 'center'); }},
  {t:1.6, run: async R => { await R.hl('.usc-pals'); await R.move('.usc-pals', {ms:1500, scroll:false}); }},
  {t:6.96, run: async R => {
    const items = [['Sveglia', 6.96], ['Colazione', 7.68], ['Cerimonia', 8.64], ['dalla programmazione', 9.52], ['Attività nuova', 11.36], ['Hike', 12.64], ['Gioco', 13.36], ['Tempo libero', 14.12], [null, 15.0], ['Fuoco', 16.0], ['Silenzio', 17.36], ['Spostamento', 18.28], ['Momento personalizzato', 19.52]];
    for (const [x, t] of items) { await R.at(t); if (x) await R.hl(pal(R, x)); else await R.hl(pal(R, 'Pranzo'), pal(R, 'Merenda'), pal(R, 'Cena'), pal(R, 'Altro pasto')); }
  }},
  {t:21.2, run: async R => { await R.hlOff(); await R.move(R.F.locator('.usc-pi', {hasText:/^Merenda$/}).first(), {ms:1400, scroll:false}); await R.at(23.52); await R.hl(pal(R, 'Merenda')); await R.click(R.F.locator('.usc-pi', {hasText:/^Merenda$/}).first(), {scroll:false}); await R.sleepx(700); }},
  {t:25.12, run: async R => { await bt(R, 'vm1', -1); await view(R, '#vm1', 'start'); await R.hl('#vm1'); }},
  {t:28.8, run: async R => { await pg(R, 'vtt', TT); await view(R, '#vtt', 'center'); await R.hl('#vtt'); }},
  {t:32.12, run: async R => { await pg(R, 'vbar', BAR); await R.hl('#vbar'); }},
 ]),
 sb('b04', [
  {t:0, run: async R => { await R.zoomOff(); await bt(R, 'vm1', -1); await view(R, '#vm1', 'start'); await R.hl('#vm1'); await R.zoomTo('#vm1', 1.1); }},
  {t:2.72, run: async R => { await bi(R, 'vti', -1, "return b.querySelector('textarea.usc-bti')"); await R.hl('#vti'); }},
  {t:5.12, run: async R => { await bi(R, 'vdu', -1, "return b.querySelector('textarea.usc-durin')"); await R.hl('#vdu'); await R.at(6.4); await bi(R, 'vmi', -1, "return [...b.querySelectorAll('button.usc-ib')].find(x => x.innerText.trim() === '−')"); await R.hl('#vmi'); await R.click('#vmi', {scroll:false, ms:600}); await R.at(7.0); await bi(R, 'vpl', -1, "return [...b.querySelectorAll('button.usc-ib')].find(x => x.innerText.trim() === '+')"); await R.hl('#vpl'); await R.click('#vpl', {scroll:false, ms:500}); await R.at(9.2); await bi(R, 'vdu', -1, "return b.querySelector('textarea.usc-durin')"); await R.hl('#vdu'); await setTxt(R, '#vdu', '15'); }},
  {t:14.8, run: async R => { await R.hlOff(); }},
  {t:18.0, run: async R => { await bi(R, 'vqp', -1, "return [...b.querySelectorAll('select')].find(s => [...s.options].some(o => /Merenda del pomeriggio/.test(o.text)))"); await R.hl('#vqp'); await R.at(19.3); await R.selOpen('#vqp'); await R.at(21.0); await R.selPick('#vqp', 'Merenda del pomeriggio'); }},
  {t:22.48, run: async R => { await bi(R, 'vaf', -1, "return b.querySelector('select.ax-pm-s')"); await R.hl('#vaf'); await R.at(23.3); await R.selOpen('#vaf'); }},
  {t:25.92, keep:true, run: async R => { await R.selPick('#vaf', 'Anna Verdi (CU)'); }},
 ]),
 sb('b05', [
  {t:0, run: async R => { await R.zoomOff(); await bt(R, 'vb0', 0); await view(R, '#vb0', 'start'); await R.F.evaluate(() => window.scrollBy(0, -80)); }},
  {t:2.4, run: async R => { await R.hl(pal(R, 'Cerimonia')); await R.move(R.F.locator('.usc-pi', {hasText:'Cerimonia'}).first(), {ms:1500, scroll:false}); }},
  {t:9.12, keep:true, run: async R => { await R.at(9.5); await R.drag(R.F.locator('.usc-pi', {hasText:'Cerimonia'}).first(), '#vb0 .usc-bh', {fdx:0.5, fdy:0.4, tdx:0.45, tdy:0.5}); }},
  {t:12.88, run: async R => { await R.sleepx(900); await bt(R, 'vb0', 0); await view(R, '#vb0', 'start'); await R.hl('#vb0'); }},
  {t:15.76, run: async R => { await R.at(15.9); await titSet(R, 0, 'Alzabandiera'); await R.at(17.9); await durSet(R, 0, '15'); }},
 ]),
 sb('b06', [
  {t:0, run: async R => { await R.zoomOff(); await view(R, '.usc-pals', 'center'); await R.hl(pal(R, 'dalla programmazione')); await R.move(R.F.locator('.usc-pi', {hasText:'dalla programmazione'}).first(), {ms:1300, scroll:false}); }},
  {t:2.36, run: async R => { await R.at(2.8); await R.click(R.F.locator('.usc-pi', {hasText:'dalla programmazione'}).first(), {scroll:false}); await R.sleepx(500); }},
  {t:5.04, run: async R => { await bt(R, 'vm2', -1); await view(R, '#vm2', 'start'); await R.hl('#vm2'); }},
  {t:8.28, keep:true},
  {t:10.84, keep:true},
  {t:17.68, run: async R => { await R.at(18.3); await R.hl({sel:'#vm2 [onclick]', text:'Orientiamoci con la mappa'}); await R.click(R.F.locator('#vm2 [onclick]', {hasText:'Orientiamoci con la mappa'}).first(), {scroll:false}); await R.sleepx(500); }},
  {t:22.2, run: async R => { await bt(R, 'vm2', -1); await view(R, '#vm2', 'start'); await R.hl('#vm2'); }},
  {t:25.28, run: async R => { await R.at(26.2); await durSet(R, -1, '1h30'); }},
  {t:28.08, run: async R => { await R.at(30.2); await bi(R, 'vp1', -1, "return b.querySelectorAll('select.ax-pm-s')[0]"); await R.hl('#vp1'); await R.at(32.0); await bi(R, 'vp2', -1, "return b.querySelectorAll('select.ax-pm-s')[1]"); await R.hl('#vp2'); }},
  {t:33.4, keep:true, run: async R => { await R.at(33.7); await R.hl('#vp1'); await R.selOpen('#vp1'); await R.at(36.4); await R.selPick('#vp1', 'Anna Verdi (CU)'); await bi(R, 'vp2', -1, "return b.querySelectorAll('select.ax-pm-s')[1]"); await R.hl('#vp2'); await R.move('#vp2', {ms:500, scroll:false}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.F.evaluate(() => { const s = document.getElementById('vp2'); if(!s) return; const o = [...s.options].find(x => /Anna Verdi/.test(x.text)); console.log('VP2 opts', [...s.options].map(x => x.text).join('|')); if(o){ s.value = o.value; s.dispatchEvent(new Event('change', {bubbles:true})); } }); await R.sleepx(300); }},
 ]),
 sb('b07', [
  {t:0, run: async R => { await R.zoomOff(); await view(R, '.usc-pals', 'center'); await R.at(2.6); await R.hl(pal(R, 'Momento personalizzato')); await R.move(R.F.locator('.usc-pi', {hasText:'Momento personalizzato'}).first(), {ms:900, scroll:false}); await R.at(3.6); await R.click(R.F.locator('.usc-pi', {hasText:'Momento personalizzato'}).first(), {scroll:false}); await R.sleepx(500); }},
  {t:6.24, run: async R => { await bt(R, 'vm3', -1); await view(R, '#vm3', 'start'); await titSet(R, -1, 'Canto finale'); }},
  {t:8.32, run: async R => { await bi(R, 'vdt', -1, "return [...b.querySelectorAll('button.usc-cdot')][3]"); await R.hl('#vdt'); await R.click('#vdt', {scroll:false, ms:700}); }},
  {t:10.36, run: async R => { await bi(R, 'vtp', -1, "return [...b.querySelectorAll('select')].find(s => [...s.options].some(o => o.text === 'Serata'))"); await R.hl('#vtp'); await R.selOpen('#vtp'); await R.at(11.76); await R.selHover('Attività', 400); await R.at(12.64); await R.selHover('Gioco', 400); await R.at(13.3); await R.selHover('Hike', 400); await R.at(14.0); await R.selHover('Serata', 400); await R.at(14.8); await R.selHover('Tempo libero', 400); await R.at(15.2); await R.P.evaluate(() => ST.menuOff()); }},
  {t:15.76, run: async R => { await bi(R, 'vcs', -1, "return b.querySelector('textarea[placeholder^=\"Cosa succede\"]')"); await R.hl('#vcs'); await R.at(16.0); await R.type('#vcs', 'Canto insieme, in cerchio.', 25); }},
  {t:18.56, run: async R => { await view(R, '.usc-pals', 'center'); await R.at(21.6); await R.hl(pal(R, 'Attività nuova')); await R.at(23.3); await R.hl(pal(R, 'Hike')); await R.at(26.0); await R.hl(pal(R, 'Spostamento')); }},
 ]),
 sb('b08', [
  {t:0, run: async R => { await R.zoomOff(); await R.F.evaluate(() => window.scrollTo(0, 0)); await R.sleepx(300); }},
  {t:1.76, run: async R => { await R.at(2.6); await R.hl('.usc-blk .usc-bh'); }},
  {t:6.48, run: async R => { await pg(R, 'vtt', TT); await view(R, '#vtt', 'center'); await R.at(7.8); await R.hl('#vtt'); await slot(R, 'vsm', 'Merenda'); await slot(R, 'vsc', 'Canto finale'); await R.at(9.4); await R.hl('#vsm'); await R.drag('#vsm', '#vsc', {fdx:0.5, fdy:0.5, tdx:0.5, tdy:0.3}); }},
  {t:14.72, run: async R => { await R.hlOff(); await palTap(R, /Tempo libero/); await bt(R, 'vm4', -1); await view(R, '#vm4', 'start'); await R.at(16.2); await bi(R, 'vx', -1, "return b.querySelector('button.usc-bx')"); await R.hl('#vx'); await R.at(17.3); await R.click('#vx', {scroll:false, ms:600}); }},
  {t:20.56, run: async R => { const FCH = "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /(Chiudi|Apri) tutti/.test(b.innerText))"; await pg(R, 'vch', FCH); await view(R, '#vch', 'center'); await R.hl('#vch'); await R.at(21.1); const lab = await R.F.evaluate(() => document.getElementById('vch').innerText.trim()); await R.click('#vch', {scroll:false, ms:600}); await R.sleepx(500); if(/Apri/.test(lab)){ await pg(R, 'vch', FCH); await R.click('#vch', {scroll:false, ms:500}); await R.sleepx(400); } await R.hlOff(); await view(R, '.usc-blk', 'start'); }},
 ]),
 sb('b09', [
  {t:0, run: async R => { await R.zoomOff(); await tagMe(R); await view(R, '#vme', 'start'); await R.at(3.4); await R.hl('#vme'); }},
  {t:7.84, run: async R => { await tagMe(R); await R.click('#vme .usc-bh', {dx:0.4, scroll:false, ms:700}); await R.sleepx(500); const fx = async () => { await tagMe(R); return R.F.evaluate(() => { const b = document.getElementById('vme'); const l = b && [...b.querySelectorAll('label')].find(x => /Ora fissa/.test(x.innerText)); document.querySelectorAll('#vfx').forEach(x => x.removeAttribute('id')); if(l) l.id = 'vfx'; return !!l; }); }; await fx(); await R.at(9.6); await R.hl('#vfx'); await R.click('#vfx input', {scroll:false, ms:600}); }},
  {t:10.88, run: async R => { await tagMe(R); await R.F.evaluate(() => { const b = document.getElementById('vme'); document.querySelectorAll('#vfs').forEach(x => x.removeAttribute('id')); const s = b && [...b.querySelectorAll('select')].find(x => [...x.options].some(o => o.text === '17:00')); if(s) s.id = 'vfs'; }); await R.hl('#vfs'); await R.selOpen('#vfs'); await R.at(12.9); await R.selPick('#vfs', '17:00'); }},
  {t:14.08, run: async R => { await R.F.evaluate(() => { document.querySelectorAll('#vw1,#vw2').forEach(x => x.removeAttribute('id')); const w = [...document.querySelectorAll('.ax-warn')].filter(e => e.offsetParent && /ora fissa/.test(e.innerText)); const a = w.find(e => /^Con l’ora fissa/.test(e.innerText)); const b = w.find(e => /^Un blocco con/.test(e.innerText)); if(a) a.id = 'vw1'; if(b) b.id = 'vw2'; }); await view(R, '#vw1', 'center'); await R.hl('#vw1'); }},
  {t:16.32, keep:true},
  {t:22.2, run: async R => { await R.F.evaluate(() => { document.querySelectorAll('#vw1,#vw2').forEach(x => x.removeAttribute('id')); const w = [...document.querySelectorAll('.ax-warn')].filter(e => e.offsetParent && /ora fissa/.test(e.innerText)); const a = w.find(e => /^Con l’ora fissa/.test(e.innerText)); const b = w.find(e => /^Un blocco con/.test(e.innerText)); if(a) a.id = 'vw1'; if(b) b.id = 'vw2'; }); await R.hl('#vw1'); await R.at(23.8); await R.hl('#vw2'); await R.at(25.3); await R.F.evaluate(() => window.scrollTo(0, 0)); await pg(R, 'vtt', TT); await view(R, '#vtt', 'center'); await R.hl('#vtt'); }},
  {t:25.3, keep:true},
  {t:28.36, keep:true},
  {t:34.08, run: async R => { await tagMe(R); await view(R, '#vme', 'center'); await R.F.evaluate(() => { const b = document.getElementById('vme'); document.querySelectorAll('#vfs').forEach(x => x.removeAttribute('id')); const s = b && [...b.querySelectorAll('select')].find(x => [...x.options].some(o => o.text === '17:00')); if(s) s.id = 'vfs'; }); await R.hl('#vfs'); await R.selOpen('#vfs'); await R.at(35.0); await R.selPick('#vfs', '17:30'); }},
 ]),
 sb('b10', [
  {t:0, run: async R => { await R.zoomOff(); await tb(R, 'vcf', 'Canto finale', null); await view(R, '#vcf', 'start'); await R.hl('#vcf'); }},
  {t:2.96, run: async R => { if(!(await opened(R, '#vcf'))){ await R.click('#vcf .usc-bh', {dx:0.4, scroll:false, ms:700}); await R.sleepx(500); } await R.at(4.5); await tb(R, 'vsd', 'Canto finale', "return [...b.querySelectorAll('summary')].find(x => /Sposta o duplica/.test(x.innerText))"); await view(R, '#vsd', 'center'); await R.hl('#vsd'); await R.click('#vsd', {scroll:false, ms:700}); await R.sleepx(300); }},
  {t:9.28, run: async R => { await tb(R, 'vsd2', 'Canto finale', "return [...b.querySelectorAll('details')].find(d => /Sposta o duplica/.test(d.innerText))"); await R.hl('#vsd2'); }},
  {t:16.4, run: async R => { await tb(R, 'vdp', 'Canto finale', "const l = [...b.querySelectorAll('details label')].find(x => /Duplica in/.test(x.innerText)); return l && l.querySelector('select')"); await R.hl('#vdp'); await R.selOpen('#vdp'); await R.at(19.2); await R.selPick('#vdp', 'Sab 7 · in sede'); }},
  {t:21.76, run: async R => { await tb(R, 'vcp', 'Canto finale', null, true); await view(R, '#vcp', 'start'); if(!(await opened(R, '#vcp'))){ await R.click('#vcp .usc-bh', {dx:0.4, scroll:false, ms:700}); await R.sleepx(500); } await tb(R, 'vsd', 'Canto finale', "return [...b.querySelectorAll('summary')].find(x => /Sposta o duplica/.test(x.innerText))", true); const dop = await R.F.evaluate(() => document.getElementById('vsd').parentElement.open); if(!dop){ await view(R, '#vsd', 'center'); await R.click('#vsd', {scroll:false, ms:600}); await R.sleepx(300); } await tb(R, 'vup', 'Canto finale', "return b.querySelector('label.usc-tousc select')", true); await view(R, '#vup', 'center'); await R.hl('#vup'); await R.at(22.6); await R.selOpen('#vup'); await R.at(26.3); await R.selPick('#vup', 'Riunione di pattuglia · 21 nov'); }},
  {t:28.4},
 ]),
 sb('b11', [
  {t:0, run: async R => { await R.zoomOff(); await R.F.evaluate(() => window.scrollTo(0, 0)); await pg(R, 'vcerca', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /Cerca un’attività/.test(b.innerText))"); await R.at(3.2); await R.hl('#vcerca'); await R.at(4.2); await R.click('#vcerca', {scroll:false, ms:700}); await R.sleepx(700); }},
  {t:6.24, run: async R => { await R.hl('.an-box'); await R.at(8.8); await R.hl({sel:'.an-box button', text:'Le mie attività'}); await R.at(9.6); await R.hl({sel:'.an-box button', text:'Archivio nazionale'}); }},
  {t:13.36, run: async R => { await R.at(15.0); await R.hlOff(); await R.type('#an-q', 'fuoco', 120); await R.hl('#an-q'); await R.at(16.3); await R.hl('.an-box'); }},
  {t:25.6, run: async R => { await R.at(27.8); await R.hl({sel:'.an-box button', text:'Apri'}); await R.at(29.4); await R.hl({sel:'.an-box button', text:'Aggiungi all’uscita aperta'}); }},
  {t:35.76, run: async R => { await R.hl({sel:'.an-box button', text:'Aggiungi all’uscita aperta'}); await R.click(R.F.locator('.an-box button', {hasText:'Aggiungi all’uscita aperta'}).first(), {scroll:false, ms:700}); await R.sleepx(1000); const still = await R.F.evaluate(() => !!document.querySelector('.an-box')?.offsetParent); if(still){ await R.click('.modal-x', {scroll:false}); await R.sleepx(600); } await bt(R, 'vm5', -1); await view(R, '#vm5', 'center'); await R.hl('#vm5'); }},
 ]),
 sb('b12', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo(0, 0)); await pg(R, 'vdays', "return [...document.querySelectorAll('.usc-tab')][0]?.parentElement"); await R.hl('#vdays'); }},
  {t:1.28, keep:true},
  {t:4.16, run: async R => { await R.F.evaluate(() => window.scrollTo(0, 0)); await R.F.evaluate(() => { const b = [...document.querySelectorAll('#sh-side .sh-si')].find(x => /shCal/.test(x.getAttribute('onclick') || '')); if(b) b.click(); }); await R.sleepx(1000); await view(R, '.cal-row[data-u="b1"]', 'center'); await R.hl('.cal-row[data-u="b1"] .cal-ra .cal-bt2'); await R.click('.cal-row[data-u="b1"] .cal-ra .cal-bt2', {scroll:false, ms:700}); await R.sleepx(1200); await R.hlOff(); await R.F.evaluate(() => window.scrollTo(0, 0)); await pg(R, 'vdays', "return [...document.querySelectorAll('.usc-tab')].find(e => /partenza/.test(e.innerText))?.parentElement"); await R.at(9.6); await pg(R, 'vd1', "return [...document.querySelectorAll('.usc-tab')].find(e => /partenza/.test(e.innerText))"); await R.hl('#vd1'); await R.at(12.6); await pg(R, 'vd2', "return [...document.querySelectorAll('.usc-tab')].find(e => /rientro/.test(e.innerText))"); await R.hl('#vd2'); await R.click('#vd2', {scroll:false, ms:700}); await R.at(16.6); await pg(R, 'vtt', TT); await R.hl('#vtt'); }},
  {t:18.56, run: async R => { await R.at(19.4); await pg(R, 'vgi', "return [...document.querySelectorAll('.usc-tab.add')].pop()"); await R.hl('#vgi'); await R.move('#vgi', {ms:900, scroll:false}); }},
  {t:27.3, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const x = document.querySelector('.usc-dx'); if(x) x.id = 'vdx'; const g = document.querySelector('.usc-dgr'); if(g) g.id = 'vdg'; }); await R.move('#vdx', {ms:700, scroll:false}); await R.at(28.3); await R.hl('#vdx'); await R.at(29.6); await R.hlOff(); await R.move('#vdg', {ms:500, scroll:false}); await R.hl('#vdg'); }},
 ]),
 sb('b13', [
  {t:0, run: async R => { await R.hlOff(); }},
  {t:1.28}, {t:5.36}, {t:9.28}, {t:12.56}, {t:15.68}, {t:19.6}, {t:26.8},
 ]),
];
