// Video 27 (sincronizzato): Foglio del giorno, circolare e stampe.
import { sleep } from './rec.mjs';
import { prep27 } from './prep27.mjs';
import { CIT, FRASE, TEL } from './circ27.mjs';
export const META = {n:'27', title:'Foglio del giorno, circolare e stampe', caption:'PEE CNGEI · Foglio del giorno, circolare e stampe'};
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(5000); await F.evaluate(() => shSrUsc('r1')); await sleep(2000); await prep27(F); await sleep(800); }
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block);
const pg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]);
const setTxt = async (R, sel, text, D = 40) => { await R.click(sel, {scroll:false, ms:600}); await R.P.keyboard.press('Control+A'); await R.P.keyboard.type(text, {delay:D}); await R.sleepx(150); await R.P.keyboard.press('Tab'); await R.sleepx(350); };
const dz = (R, ...a) => R.P.evaluate(a => ST.docZoom(...a), a);
const pre = async (R, sel, ms = 700) => { await R.move(sel, {ms, scroll:false}); };
const top = R => R.F.evaluate(() => window.scrollTo(0, 0));
const EXP = "return [...document.querySelectorAll('summary')].find(s => s.offsetParent && /Esporta/.test(s.textContent))";
const MENU = R => R.F.evaluate(() => { const m = document.querySelector('.usc-pmm'); return !!(m && m.parentElement && m.parentElement.open); });
const menuOpen = async R => { for(let i = 0; i < 3; i++){ await pg(R, 'vexp', EXP); if(await MENU(R)) break; await R.click('#vexp', {scroll:false, ms:600}); await R.sleepx(250); } };
const menuClose = async R => { await pg(R, 'vexp', EXP); if(await MENU(R)) await R.click('#vexp', {scroll:false, ms:700}); };
const mi = (R, t) => R.F.locator('.usc-pmm button', {hasText:t}).first();
const mh = t => ({sel:'.usc-pmm button', text:t});
const mod = (R, id, rx, nth = 0) => pg(R, id, "const r = new RegExp(" + JSON.stringify(rx) + "); return [...document.querySelectorAll('.usc-modpage button')].filter(b => b.offsetParent && r.test(b.textContent.trim()))[" + nth + "]");
const mta = (R, id, n) => pg(R, id, "return [...document.querySelectorAll('.usc-modpage textarea')].filter(t => t.offsetParent)[" + n + "]");
const mtime = (R, id, n) => pg(R, id, "return [...document.querySelectorAll('.usc-modpage select')].filter(s => s.offsetParent && [...s.options].some(o => o.text === '06:05'))[" + n + "]");
const mlbl = (R, id, rx) => pg(R, id, "const r = new RegExp(" + JSON.stringify(rx) + "); return [...document.querySelectorAll('.usc-modpage .ax-lbl')].find(e => e.offsetParent && r.test(e.textContent.trim()))");
const typeMix = async (R, sel, text) => { await R.click(sel, {scroll:false, ms:450}); await R.P.keyboard.press('Control+A'); await R.P.keyboard.type(text.slice(0, 14), {delay:45}); await R.P.keyboard.insertText(text.slice(14)); await R.sleepx(150); await R.P.keyboard.press('Tab'); await R.sleepx(250); };
const sb = (id, scene, say, segs, extra = {}) => ({id, scene, say, segs, ...extra});
const DOCS = {giorno:'Giornata_Riunione_di_apertura.docx', ttg:'Time_table_giornata_Riunione_di_apertura.docx', ttx:'Time_table_Riunione_di_apertura.xlsx', circw:'Circolare_Riunione_di_apertura.docx', circp:'Circolare_Riunione_di_apertura.pdf'};

export const beats = [
 sb('b01', 'Foglio del giorno, circolare e stampe', 'Nel video precedente abbiamo costruito la giornata della Riunione di apertura. Adesso vediamo che cosa se ne ricava: il foglio della giornata, il Time table in Word e in Excel, e la circolare per le famiglie, da completare e scaricare in Word o in PDF. In chiusura, le stampe e l’esportazione completa. Andiamo con calma.', [
  {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
 sb('b02', 'Il menu Esporta', 'Tutto parte dal pulsante Esporta, in alto nella pagina dell’evento. Aprendolo trovi l’elenco dei documenti: Tutto il campo, in Word. Questa giornata. Time table della giornata. Time table del campo, in Word e in Excel. Menù e lista della spesa. Materiali. Quota spiegata. La Circolare, in Word e in PDF. Tutto di tutto. E infine Stampa questa vista. Li vediamo uno alla volta, cominciando dalla giornata.', [
  {t:0, run: async R => { await top(R); await pg(R, 'vexp', EXP); await R.hl('#vexp'); await R.move('#vexp', {ms:1100, scroll:false}); }},
  {t:4.48, keep:true, run: async R => { await R.click('#vexp', {scroll:false, ms:500}); await R.sleepx(400); await R.hl('.usc-pmm'); }},
  {t:7.08, run: async R => { await R.hl(mh('Tutto il campo')); }},
  {t:9.12, run: async R => { await R.hl(mh('Questa giornata')); }},
  {t:10.32, run: async R => { await R.hl(mh('Time table della giornata')); }},
  {t:12.16, run: async R => { await R.hl(mh('Time table del campo Word')); await R.at(14.48); await R.hl(mh('Time table del campo Excel')); }},
  {t:15.36, run: async R => { await R.hl(mh('Menù e lista')); }},
  {t:17.36, run: async R => { await R.hl(mh('Materiali')); }},
  {t:18.4, run: async R => { await R.hl(mh('Quota spiegata')); }},
  {t:19.68, run: async R => { await R.hl(mh('Circolare Word')); await R.at(21.6); await R.hl(mh('Circolare PDF')); }},
  {t:22.67, run: async R => { await R.hl(mh('Tutto di tutto')); }},
  {t:24.56, run: async R => { await R.hl(mh('Stampa questa vista')); }},
  {t:26.08, run: async R => { await R.hlOff(); await menuClose(R); }},
 ]),
 sb('b03', 'Il foglio della giornata', 'Vicino alla linguetta della giornata trovi due pulsanti: Excel, e Foglio della giornata, in Word. Scegliamo il Word. Si scarica un documento con il titolo, la data e il luogo, il Time table a colori e, sotto, una scheda per ogni momento. Per le attività dei percorsi trovi il percorso, l’obiettivo e il lancio. Per i pasti, chi se ne occupa. Per un momento personalizzato, che cosa si fa. È il foglio da stampare e portare in sede.', [
  {t:0, run: async R => { await pg(R, 'vday', "return [...document.querySelectorAll('.usc-tab')].find(e => /^Sab 7/.test(e.innerText.trim()))"); await view(R, '#vday', 'center'); await R.hl('#vday'); }},
  {t:2.48, run: async R => { await pg(R, 'vxl', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.textContent.trim() === '⤓ Excel')"); await pg(R, 'vfd', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.textContent.includes('Foglio della giornata (Word)'))"); await R.at(3.64); await R.hl('#vxl'); await R.at(4.48); await R.hl('#vfd'); }},
  {t:6.72, run: async R => { await R.click('#vfd', {scroll:false, ms:450}); }},
  {t:8.16, run: async R => { await R.hlOff(); await R.docShow(['giorno-1.png'], DOCS.giorno, 'Word'); await dz(R, 0, 0, 0.03, 1, 0.45, 1500); }},
  {t:9.68, run: async R => { await R.docHl([0, 0.09, 0.055, 0.82, 0.07]); }},
  {t:10.4, run: async R => { await R.docHl([0, 0.09, 0.1, 0.5, 0.05]); }},
  {t:11.72, run: async R => { await R.docHl([0, 0.095, 0.15, 0.81, 0.29]); }},
  {t:14.08, run: async R => { await R.docHlOff(); await dz(R, 0, 0, 0.45, 1, 0.5, 1500); }},
  {t:15.84, run: async R => { await R.docHl([0, 0.09, 0.48, 0.82, 0.13]); }},
  {t:20.52, run: async R => { await R.docHl([0, 0.09, 0.775, 0.82, 0.06]); }},
  {t:22.36, run: async R => { await R.docHl([0, 0.09, 0.845, 0.82, 0.06]); }},
  {t:25.08, run: async R => { await R.docHlOff(); await R.docOff(); await top(R); await menuOpen(R); }},
 ]),
 sb('b04', 'Il Time table', 'Se ti serve solo il programma, scegli Time table della giornata: è la griglia a colori, senza le schede dei momenti. Per l’intero evento c’è Time table del campo. E in Excel lo stesso Time table diventa un foglio di calcolo, con le righe di mezz’ora e un colore per ogni tipo di momento: comodo da ritoccare o da incollare altrove.', [
  {t:0, run: async R => { await R.P.evaluate(() => ST.docOff()); await top(R); await menuOpen(R); }},
  {t:1.76, keep:true, run: async R => { await menuOpen(R); await R.hl(mh('Time table della giornata')); await R.click(mi(R, 'Time table della giornata'), {scroll:false, ms:600}); }},
  {t:4.16, run: async R => { await R.hlOff(); await R.docShow(['ttg-1.png'], DOCS.ttg, 'Word'); await dz(R, 0, 0, 0.03, 1, 0.44, 1500); await R.docHl([0, 0.095, 0.15, 0.81, 0.29]); }},
  {t:7.04, run: async R => { await R.P.evaluate(() => ST.docOff()); await top(R); await menuOpen(R); await R.hl(mh('Time table del campo Word')); }},
  {t:9.96, keep:true, run: async R => { await R.hl(mh('Time table del campo Excel')); await R.click(mi(R, 'Time table del campo Excel'), {scroll:false, ms:500}); }},
  {t:11.28, run: async R => { await R.hlOff(); await R.docShow(['ttx-1.png'], DOCS.ttx, 'Excel'); await dz(R, 0, 0.06, 0.05, 0.5, 0.4, 1500); }},
  {t:13.68, run: async R => { await R.docHl([0, 0.08, 0.075, 0.075, 0.34]); }},
  {t:15.12, run: async R => { await R.docHl([0, 0.155, 0.075, 0.345, 0.34]); }},
  {t:17.08, run: async R => { await R.docHlOff(); }},
 ]),
 sb('b05', 'Circolare: ritrovo e orari', 'Passiamo alla circolare per le famiglie. Prima completiamo il modulo Ritrovo e spostamenti, perché la circolare ne legge i dati. Scrivi il luogo, per esempio in sede. Scegli l’ora del ritrovo: le quindici. E quella del rientro: le diciannove. Poi apri il modulo Circolare per le famiglie.', [
  {t:0, run: async R => { await R.docOff(); await menuClose(R); await top(R); await pg(R, 'vcc', "return document.querySelector('button[onclick*=\"m:circ\"]')"); await R.hl('#vcc'); }},
  {t:2.24, run: async R => { await pg(R, 'vrl', "return document.querySelector('button[onclick*=\"m:log\"]')"); await R.hl('#vrl'); await pre(R, '#vrl', 900); await R.at(3.9); await R.click('#vrl', {scroll:false, ms:80}); await R.sleepx(300); }},
  {t:7.6, run: async R => { await pg(R, 'vlu', "return document.querySelector('.usc-modpage textarea[placeholder^=\"es. in sede\"]')"); await view(R, '#vlu', 'center'); await R.hl('#vlu'); await setTxt(R, '#vlu', 'in sede', 50); }},
  {t:10.32, keep:true, run: async R => { await mtime(R, 'vs1', 0); await R.hl('#vs1'); await R.selOpen('#vs1', {fast:true}); await R.selPick('#vs1', '15:00', true); await R.at(12.88); await mtime(R, 'vs2', 1); await R.hl('#vs2'); await R.selOpen('#vs2', {fast:true}); await R.selPick('#vs2', '19:00', true); }},
  {t:15.4, run: async R => { await top(R); await pg(R, 'vcc', "return document.querySelector('button[onclick*=\"m:circ\"]')"); await R.hl('#vcc'); await pre(R, '#vcc', 800); await R.at(16.72); await R.click('#vcc', {scroll:false, ms:80}); await R.sleepx(500); }},
 ]),
 sb('b06', 'Circolare: citazione e frase', 'In alto c’è il referente della circolare. Subito sotto, l’apertura: una citazione e una frase d’apertura. I pulsanti Proponi una citazione e Proponi una frase ne suggeriscono una a caso, ma la circolare è tua: personalizzale. Scriviamo le nostre.', [
  {t:0, run: async R => { await pg(R, 'vref', "return [...document.querySelectorAll('.usc-modpage select')].find(s => s.offsetParent)"); await view(R, '#vref', 'center'); await R.hl('#vref'); }},
  {t:2.64, run: async R => { await mta(R, 'vct', 0); await mta(R, 'vfr', 1); await R.hl('#vct', '#vfr'); }},
  {t:6.96, run: async R => { await mod(R, 'vpc', '^Proponi una citazione'); await R.hl('#vpc'); await pre(R, '#vpc', 700); await R.at(7.76); await R.click('#vpc', {scroll:false, ms:80}); await R.sleepx(300); await mod(R, 'vpf', '^Proponi una frase'); await R.hl('#vpf'); await pre(R, '#vpf', 800); await R.at(9.44); await R.click('#vpf', {scroll:false, ms:80}); await R.sleepx(300); await R.at(11.68); await mta(R, 'vct', 0); await mta(R, 'vfr', 1); await R.hl('#vct', '#vfr'); }},
  {t:14.24, run: async R => { await mta(R, 'vct', 0); await typeMix(R, '#vct', CIT); await mta(R, 'vfr', 1); await typeMix(R, '#vfr', FRASE); await R.sleepx(300); }},
 ]),
 sb('b07', 'Circolare: cosa portare', 'Il riepilogo con data, ritrovo e rientro si compila da solo, leggendo Persone e date e Ritrovo e spostamenti. Poi Cosa portano. Puoi partire da Proponi una lista base, oppure scegliere le voci dalla lista, una alla volta: per esempio Uniforme completa. Ogni riga è una voce. Per la Pattuglia tocca i pulsanti: Bussola, Cartina. E in Da lasciare a casa, Cellulare e dispositivi elettronici. Più sotto trovi Quota e scadenze, e Autorizzazioni: compilale quando servono, qui le saltiamo.', [
  {t:0, run: async R => { await mlbl(R, 'vri', '^2\\. Riepilogo'); await view(R, '#vri', 'center'); await R.hl('#vri'); }},
  {t:8.08, run: async R => { await mlbl(R, 'vcp', '^3\\. Cosa portano'); await view(R, '#vcp', 'center'); await R.hl('#vcp'); }},
  {t:9.76, run: async R => { await mod(R, 'vpl', '^Proponi una lista base'); await R.hl('#vpl'); await pre(R, '#vpl', 800); }},
  {t:12.28, keep:true, run: async R => { await pg(R, 'vls', "return [...document.querySelectorAll('.usc-modpage select')].find(s => s.offsetParent && [...s.options].some(o => /Aggiungi dalla lista/.test(o.text)))"); await R.hl('#vls'); await R.at(13.2); await R.selOpen('#vls', {fast:true}); await R.at(15.6); await R.selPick('#vls', 'Uniforme completa', true); }},
  {t:17.84, run: async R => { await mta(R, 'vlt', 2); await R.hl('#vlt'); }},
  {t:19.52, run: async R => { await mod(R, 'vbu', '^Bussola$'); await R.hl('#vbu'); await pre(R, '#vbu', 900); await R.at(21.5); await R.click('#vbu', {scroll:false, ms:80}); await R.sleepx(150); await mod(R, 'vca', '^Cartina$'); await R.hl('#vca'); await pre(R, '#vca', 450); await R.at(22.9); await R.click('#vca', {scroll:false, ms:80}); await R.sleepx(150); }},
  {t:23.28, run: async R => { await mod(R, 'vce', '^Cellulare e dispositivi elettronici$'); await view(R, '#vce', 'center'); await R.hl('#vce'); await pre(R, '#vce', 1000); await R.at(25.1); await R.click('#vce', {scroll:false, ms:80}); await R.sleepx(200); }},
  {t:27.52, run: async R => { await mlbl(R, 'vq4', '^4\\. Quota'); await mlbl(R, 'vq5', '^5\\. Autorizzazioni'); await view(R, '#vq4', 'center'); await R.hl('#vq4', '#vq5'); }},
 ]),
 sb('b08', 'Circolare: invio, Word e PDF', 'Infine l’invio. Prepara il messaggio genera il testo da incollare in una chat o in una e-mail. Scrivi il telefono: compare nella firma e nei contatti. Poi scarica. Word da condividere, se vuoi ritoccarlo. Ecco il documento: intestazione, data, citazione, orari, cosa portare, e in fondo i contatti. Oppure Scarica in PDF, che si legge uguale su qualsiasi telefono. Il contenuto è lo stesso.', [
  {t:0, run: async R => { await mlbl(R, 'vin', '^6\\. Invio'); await view(R, '#vin', 'center'); await R.hl('#vin'); }},
  {t:1.64, run: async R => { await mod(R, 'vpm', '^Prepara il messaggio$'); await R.hl('#vpm'); await pre(R, '#vpm', 600); await R.at(2.2); await R.click('#vpm', {scroll:false, ms:80}); await R.sleepx(300); }},
  {t:6.32, run: async R => { await pg(R, 'vtel', "return [...document.querySelectorAll('.usc-modpage input[placeholder=\"Telefono\"]')].find(i => i.offsetParent)"); await view(R, '#vtel', 'center'); await R.hl('#vtel'); await setTxt(R, '#vtel', TEL, 45); }},
  {t:9.92, run: async R => { await mod(R, 'vwd', '^↓ Word da condividere'); await mod(R, 'vpd', '^↓ Scarica in PDF'); await view(R, '#vwd', 'center'); await R.hl('#vwd', '#vpd'); }},
  {t:11.28, run: async R => { await R.hl('#vwd'); await pre(R, '#vwd', 500); await R.at(11.84); await R.click('#vwd', {scroll:false, ms:80}); }},
  {t:13.92, run: async R => { await R.hlOff(); await R.docShow(['circw-1.png'], DOCS.circw, 'Word'); await dz(R, 0, 0, 0.02, 1, 0.5, 1500); }},
  {t:15.2, run: async R => { await R.docHl([0, 0.33, 0.02, 0.58, 0.045]); await R.at(16.24); await R.docHl([0, 0.33, 0.065, 0.3, 0.025]); await R.at(16.88); await R.docHl([0, 0.33, 0.1, 0.58, 0.04]); await R.at(17.76); await R.docHl([0, 0.33, 0.285, 0.58, 0.18]); }},
  {t:18.44, run: async R => { await dz(R, 0, 0, 0.5, 1, 0.45, 1400); await R.docHl([0, 0.33, 0.535, 0.58, 0.08]); await R.at(20.16); await R.docHl([0, 0.33, 0.835, 0.58, 0.085], [0, 0.11, 0.48, 0.18, 0.18]); }},
  {t:21.04, run: async R => { await R.docOff(); await mod(R, 'vpd', '^↓ Scarica in PDF'); await view(R, '#vpd', 'center'); await R.hl('#vpd'); await pre(R, '#vpd', 600); await R.at(21.84); await R.click('#vpd', {scroll:false, ms:80}); await R.sleepx(200); }},
  {t:23.24, run: async R => { await R.hlOff(); await R.docShow(['circp-1.png'], DOCS.circp, 'PDF'); await dz(R, 0, 0, 0.25, 1, 0.63, 1500); }},
  {t:25.6, run: async R => { await R.docHl([0, 0.38, 0.775, 0.52, 0.09]); }},
 ]),
 sb('b09', 'Stampe e riepilogo', 'Restano due voci del menu Esporta. Stampa questa vista apre la stampa del browser con la pagina che stai guardando, già impaginata. E Tutto di tutto raccoglie in un solo Word programma, pasti, materiali, quota e circolare: ideale per l’archivio dell’evento o per lo staff. Ricapitolando: Esporta ti dà il foglio della giornata, il Time table, la circolare e le stampe. Nel prossimo video passiamo alle uscite e ai campi. Grazie, e a presto.', [
  {t:0, run: async R => { await R.P.evaluate(() => ST.docOff()); await top(R); await menuOpen(R); await R.hl('.usc-pmm'); }},
  {t:2.72, run: async R => { await R.hl(mh('Stampa questa vista')); await R.move(mi(R, 'Stampa questa vista'), {ms:900, scroll:false}); }},
  {t:8.32, run: async R => { await R.hl(mh('Tutto di tutto')); await R.move(mi(R, 'Tutto di tutto'), {ms:900, scroll:false}); }},
  {t:17.84, run: async R => { await R.hl('.usc-pmm'); }},
  {t:24.28, run: async R => { await R.hlOff(); await menuClose(R); }},
 ]),
];
