// Video 28 (sincronizzato): Un campo di più giorni
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'28s', title:'Uscite ed eventi: creare e organizzare', caption:'PEE CNGEI · Uscite ed eventi'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts28.json', import.meta.url)));
const view = (R, sel, block = 'center') => R.F.locator(sel).first().evaluate((e, b) => e.scrollIntoView({block:b, behavior:'instant'}), block).catch(() => {});
const top = R => R.F.evaluate(() => window.scrollTo(0, 0));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const TY = async (R, sel, text) => { await R.type(sel, text.slice(0, 9), 40); await R.F.fill(sel, text); };
const pickM = async (R, sel, pick) => { await R.selOpen(sel, {fast:true}); await R.selPick(sel, pick, true); };
// tag generico: body riceve la pagina (document) e restituisce l'elemento
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = (rx, flags = 'i') => "const r = new RegExp(" + JSON.stringify(rx) + ", " + JSON.stringify(flags) + "); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";
const dayTab = t => "return [...document.querySelectorAll('button.usc-tab')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const schema = t => "return [...document.querySelectorAll('button.ax-chip')].find(b => b.offsetParent && b.innerText.trim() === " + JSON.stringify(t) + ")";
const slot = i => R => R.F.locator('.usc-slot[data-tslot]').nth(i);
const hlSlot = async (R, i) => { await R.hlOff(); await tg(R, 'vslot', "return document.querySelectorAll('.usc-slot[data-tslot]')[" + i + "]"); await H(R, '#vslot'); };
const goDay = async (R, t, tHl, tCk) => { await tg(R, 'vdt', dayTab(t)); await view(R, '#vdt'); await R.move('#vdt', {ms:500, scroll:false}); await R.at(tHl); await H(R, '#vdt'); await R.at(tCk); await ck(R, '#vdt'); await sleep(500); await R.hlOff(); };
const pickSchema = async (R, t, tHl, tCk) => { await tg(R, 'vsch', schema(t)); await view(R, '#vsch'); await R.move('#vsch', {ms:500, scroll:false}); await R.at(tHl); await H(R, '#vsch'); await R.at(tCk); await ck(R, '#vsch'); await sleep(900); await R.hlOff(); await view(R, '.usc-slot[data-tslot]', 'center'); };
const modI = (name, mark) => "return [...document.querySelectorAll('.usc-ms')].find(e => e.offsetParent && e.innerText.trim().replace(/\\s+/g,' ').startsWith('" + mark + " " + name + "'))";

export async function open(F){
  await F.evaluate(() => shOpen('p1', 0)); await sleep(4500);
}

export const beats = [
sb('b01', 'Un campo di più giorni', [
  {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
sb('b02', 'Creare il campo', [
  {t:1.5, run: async R => { await R.move(sg(R, 'Realizzare'), {ms:350, scroll:false}); await R.at(1.8); await ck(R, sg(R, 'Realizzare'), {ms:60}); await R.move(si(R, 'Calendario e attività'), {ms:250, scroll:false}); await R.at(2.8); await ck(R, si(R, 'Calendario e attività'), {ms:60}); }},
  {t:3.4, run: async R => { await sleep(500); await top(R); await R.F.locator('button', {hasText:'+ Campo'}).first().evaluate(b => b.id = 'vcampo'); await R.move('#vcampo', {ms:600, scroll:false}); await R.at(3.9); await H(R, '#vcampo'); await R.at(4.4); await ck(R, '#vcampo'); }},
  {t:6.2, run: async R => { await R.hlOff(); await sleep(700); await R.F.evaluate(() => { const r = [...document.querySelectorAll('input[type=radio]')].find(x => /Per l’Unità/.test(x.parentElement.innerText)); if(r) r.parentElement.id = 'vpc'; }); await R.move('#vpc', {ms:500, scroll:false}); await R.at(7.3); await H(R, '#vpc'); await R.at(8.9); await ck(R, '#vpc'); }},
  {t:9.6, run: async R => { await R.hlOff(); await R.move('#cal-nt', {ms:400, scroll:false}); await R.at(10.1); await H(R, '#cal-nt'); await R.at(11.2); await TY(R, '#cal-nt', 'Campo invernale'); }},
  {t:12.6, run: async R => { await R.hlOff(); await R.move('#cal-d1', {ms:400, scroll:false}); await R.at(13.3); await H(R, '#cal-d1'); await R.at(15.3); await R.F.fill('#cal-d1', '2026-12-27'); }},
  {t:17.0, run: async R => { await R.hlOff(); await R.move('#cal-d2', {ms:400, scroll:false}); await R.at(17.6); await H(R, '#cal-d2'); await R.at(20.0); await R.F.fill('#cal-d2', '2026-12-30'); }},
  {t:21.2, run: async R => { await R.hlOff(); await R.move('#cal-tp', {ms:400, scroll:false}); await R.at(21.7); await H(R, '#cal-tp'); await R.at(22.2); await pickM(R, '#cal-tp', 'Campo invernale'); }},
  {t:24.0, run: async R => { await R.hlOff(); await R.F.locator('button', {hasText:/^Crea$/}).first().evaluate(b => b.id = 'vcrea'); await R.move('#vcrea', {ms:400, scroll:false}); await R.at(24.5); await H(R, '#vcrea'); await ck(R, '#vcrea'); }},
 ]),
sb('b03', 'Il campo nel calendario', [
  {t:0, run: async R => { await R.hlOff(); await sleep(600); await R.F.evaluate(() => { const r = [...document.querySelectorAll('.cal-row')].find(x => /Campo invernale/.test(x.innerText)); if(r){ r.id = 'vrow'; r.scrollIntoView({block:'center', behavior:'instant'}); const b = [...r.querySelectorAll('button')].find(x => /Apri/.test(x.textContent)); if(b) b.id = 'vapri'; } }); await R.at(1.2); await H(R, '#vrow'); await R.move('#vapri', {ms:900, scroll:false}); await R.at(5.4); await R.hlOff(); await H(R, '#vapri'); await R.at(6.1); await ck(R, '#vapri'); }},
 ]),
sb('b04', 'Giornate e notti', [
  {t:0, run: async R => { await R.hlOff(); await sleep(900); await top(R); await tg(R, 'vhead', inner('4 giornate, 3 notti')); await R.at(1.8); await H(R, '#vhead'); }},
  {t:7.4, run: async R => { await R.hlOff(); await tg(R, 'vtabs', "const b = [...document.querySelectorAll('button.usc-tab')].find(b => b.offsetParent && /^Dom 27/.test(b.innerText.trim())); return b && b.parentElement"); await view(R, '#vtabs'); await R.at(8.4); await H(R, '#vtabs'); }},
  {t:10.5, run: async R => { for (const [t, at] of [['Dom 27', 10.9], ['Lun 28', 13.0], ['Mar 29', 14.1], ['Mer 30', 16.5]]) { await R.at(at); await R.hlOff(); await tg(R, 'vdt', dayTab(t)); await H(R, '#vdt'); } }},
 ]),
sb('b05', 'Visione d’insieme', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.F.evaluate(() => window.scrollTo(0, 120)); await R.at(1.7); const L = [['Cassa', 4.8], ['Quota ragazzi', 5.4], ['Materiali', 6.8], ['Menù e spesa', 7.8], ['Moduli compilati', 9.1]]; for (const [k, t] of L) { await R.at(t); await R.hlOff(); await tg(R, 'vcard', "const e = [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && x.textContent.trim() === " + JSON.stringify(k) + ")[0]; return e && (e.closest('summary, button, details') || e.parentElement)"); await H(R, '#vcard'); } }},
 ]),
sb('b06', 'Persone e date', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-m-chi', {ms:500, scroll:false}); await R.at(1.3); await H(R, '#usc-tab-m-chi'); await R.at(1.9); await ck(R, '#usc-tab-m-chi'); }},
  {t:2.4, run: async R => { await R.hlOff(); await sleep(600); await R.F.locator('.usc-modpage .ax-chip', {hasText:'Anna Verdi'}).first().evaluate(b => b.id = 'vanna'); await view(R, '#vanna'); await R.move('#vanna', {ms:400, scroll:false}); await R.at(3.0); await ck(R, '#vanna'); }},
  {t:3.6, run: async R => { await R.hlOff(); const b = R.F.locator('.usc-modpage button', {hasText:'+ Altra persona'}).first(); await R.move(b, {ms:500, scroll:false}); await R.at(3.8); await R.fakePrompt('Nome della persona', 'Marco Neri', async () => { await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await b.click(); }); }},
  {t:6.6, run: async R => { await R.hlOff(); await sleep(400); await tg(R, 'vs0', "const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); return [...m.querySelectorAll('select.ax-in')].filter(s => s.options.length > 60)[0]"); await tg(R, 'vs1', "const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); return [...m.querySelectorAll('select.ax-in')].filter(s => s.options.length > 60)[1]"); await tg(R, 'vs2', "const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); return [...m.querySelectorAll('select.ax-in')].filter(s => s.options.length > 60)[2]"); await view(R, '#vs0'); await R.move('#vs0', {ms:350, scroll:false}); await R.at(7.0); await H(R, '#vs0'); await R.at(7.6); await pickM(R, '#vs0', '16'); }},
  {t:9.8, run: async R => { await R.hlOff(); await tg(R, 'vs1', "const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); return [...m.querySelectorAll('select.ax-in')].filter(s => s.options.length > 60)[1]"); await R.move('#vs1', {ms:300, scroll:false}); await H(R, '#vs1'); await R.at(10.7); await R.F.selectOption('#vs1', {label:'7'}); }},
  {t:11.0, run: async R => { await R.hlOff(); await tg(R, 'vs2', "const m = [...document.querySelectorAll('.usc-modpage')].find(e => e.offsetParent); return [...m.querySelectorAll('select.ax-in')].filter(s => s.options.length > 60)[2]"); await R.move('#vs2', {ms:300, scroll:false}); await H(R, '#vs2'); await R.at(11.6); await R.F.selectOption('#vs2', {label:'9'}); }},
  {t:12.3, run: async R => { await R.hlOff(); await R.F.locator('.usc-modpage button.ax-chip', {hasText:'Più giorni'}).first().evaluate(b => b.id = 'vpg'); await view(R, '#vpg'); await R.at(13.7); await H(R, '#vpg'); }},
  {t:15.8, run: async R => { await R.hlOff(); await R.at(16.4); await H(R, '.usc-modpage input[type=date]'); }},
  {t:18.0, run: async R => { await R.hlOff(); await tg(R, 'vnot', inner('4 giorni, 3 notti')); await R.at(18.2); await H(R, '#vnot'); }},
 ]),
sb('b07', 'Giornata tipo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-campo', {ms:500, scroll:false}); await R.at(0.3); await H(R, '#usc-tab-campo'); await R.at(0.9); await ck(R, '#usc-tab-campo'); }},
  {t:1.2, run: async R => { await R.hlOff(); await sleep(500); await goDay(R, 'Lun 28', 1.6, 2.4); }},
  {t:3.6, run: async R => { await tg(R, 'vtt', inner('Ancora niente in questa giornata')); await R.at(4.0); await H(R, '#vtt'); }},
  {t:5.4, run: async R => { await R.hlOff(); await tg(R, 'vsch', schema('Giornata tipo')); await tg(R, 'vchips', "const b = [...document.querySelectorAll('button.ax-chip')].find(b => b.offsetParent && b.innerText.trim() === 'Giornata tipo'); return b && b.parentElement"); await view(R, '#vchips'); await R.at(6.4); await H(R, '#vchips'); }},
  {t:8.0, run: async R => { for (const [t, at] of [['Giornata tipo', 8.3], ['Giornata di hike', 9.4], ['Arrivo', 10.5], ['Rientro', 11.1]]) { await R.at(at); await R.hlOff(); await tg(R, 'vsc', schema(t)); await H(R, '#vsc'); } }},
  {t:12.0, run: async R => { await R.hlOff(); await pickSchema(R, 'Giornata tipo', 12.3, 13.0); }},
  {t:13.9, run: async R => { for (const [i, at] of [[0, 16.3], [1, 17.9], [2, 18.7], [3, 19.7], [4, 21.2], [6, 22.4], [10, 23.5]]) { await R.at(at); await hlSlot(R, i); } await R.at(24.6); await R.hlOff(); }},
 ]),
sb('b08', 'Giornata di hike', [
  {t:0, run: async R => { await R.hlOff(); await goDay(R, 'Mar 29', 0.6, 1.8); }},
  {t:3.0, run: async R => { await pickSchema(R, 'Giornata di hike', 3.7, 4.3); }},
  {t:5.2, run: async R => { for (const [i, at] of [[0, 7.0], [1, 7.7], [2, 8.6], [3, 9.9], [4, 11.1], [5, 11.7], [6, 13.4]]) { await R.at(at); await hlSlot(R, i); } await R.at(14.0); await R.hlOff(); }},
 ]),
sb('b09', 'Arrivo e rientro', [
  {t:0, run: async R => { await R.hlOff(); await goDay(R, 'Dom 27', 0.9, 2.0); }},
  {t:2.9, run: async R => { await pickSchema(R, 'Arrivo', 3.2, 3.6); }},
  {t:4.2, run: async R => { for (const [i, at] of [[0, 4.6], [1, 5.3], [2, 6.5], [3, 8.1], [5, 9.8]]) { await R.at(at); await hlSlot(R, i); } await R.at(10.9); await R.hlOff(); }},
  {t:11.1, run: async R => { await goDay(R, 'Mer 30', 11.5, 12.6); }},
  {t:13.9, run: async R => { await pickSchema(R, 'Rientro', 14.1, 14.5); }},
  {t:15.1, run: async R => { for (const [i, at] of [[2, 15.8], [3, 17.3], [6, 19.2]]) { await R.at(at); await hlSlot(R, i); } await R.at(20.0); await R.hlOff(); }},
 ]),
sb('b10', 'Time table e Sintesi', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move('#usc-tab-campo', {ms:400, scroll:false}); await R.at(0.15); await ck(R, '#usc-tab-campo', {ms:60}); }},
  {t:0.8, run: async R => { await sleep(600); await tg(R, 'vttc', inner('^Time table dell’evento')); await view(R, '#vttc', 'start'); await R.at(1.1); await H(R, '#vttc'); }},
  {t:4.3, run: async R => { await R.hlOff(); await tg(R, 'vtth', inner('trascinalo per spostarlo')); await R.at(5.4); await H(R, '#vtth'); }},
  {t:7.8, run: async R => { await R.hlOff(); await tg(R, 'vsin', inner('^Sintesi$')); await view(R, '#vsin', 'start'); await R.at(8.5); await H(R, '#vsin'); }},
  {t:10.0, run: async R => { await tg(R, 'vst', "const t = [...document.querySelectorAll('table')].find(t => t.offsetParent && /Pranzo e cena/.test(t.innerText)); return t"); await R.hlOff(); await R.at(10.7); await H(R, '#vst'); }},
 ]),
sb('b11', 'Più Giornata', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vadd', "return [...document.querySelectorAll('button.usc-tab')].find(b => b.offsetParent && /Giornata/.test(b.innerText) && /^\\+/.test(b.innerText.trim()))"); await view(R, '#vadd'); await R.move('#vadd', {ms:700, scroll:false}); await R.at(1.4); await H(R, '#vadd'); await R.at(2.3); await ck(R, '#vadd'); }},
  {t:2.8, run: async R => { await R.hlOff(); await sleep(700); await top(R); await tg(R, 'vhead', inner('5 giornate, 4 notti')); await R.at(3.8); await H(R, '#vhead'); }},
  {t:8.4, run: async R => { await R.hlOff(); await tg(R, 'vdt', dayTab('Gio 31')); await view(R, '#vdt'); await R.at(9.4); await H(R, '#vdt'); }},
  {t:10.9, run: async R => { await R.hlOff(); await tg(R, 'vdt', dayTab('Mer 30')); await R.at(12.0); await H(R, '#vdt'); await R.at(14.2); await R.hlOff(); }},
  {t:14.9, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const x = document.querySelector('.usc-dx'); if(x) x.id = 'vdx'; const g = document.querySelector('.usc-dgr'); if(g) g.id = 'vdg'; }); await R.move('#vdx', {ms:700, scroll:false}); await R.at(16.4); await R.hl('#vdx'); await R.at(17.3); await R.hlOff(); await R.move('#vdg', {ms:400, scroll:false}); await R.hl('#vdg'); await R.at(18.6); await R.hlOff(); }},
 ]),
sb('b12', 'I moduli dell’evento', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.F.evaluate(() => document.getElementById('usc-tab-campo').click()); await sleep(500); await tg(R, 'vmods', "const e = document.querySelector('.usc-ms'); return e && e.parentElement"); await R.F.evaluate(() => { const e = document.querySelector('.usc-ms'); if(e) e.scrollIntoView({block:'center', behavior:'instant'}); }); await R.at(1.0); await H(R, '#vmods'); }},
  {t:2.2, run: async R => { await R.hlOff(); await tg(R, 'vm1', modI('Persone e date', '✓')); await R.at(3.0); await H(R, '#vm1'); }},
  {t:4.8, run: async R => { for (const [n, at] of [['Ritrovo e spostamenti', 8.1], ['Pasti', 9.7], ['Trasporti', 10.2], ['Locazioni', 11.0], ['Quota', 11.8], ['Sicurezza', 12.3], ['Benessere e inclusione', 13.2], ['Piano B', 14.7], ['Materiali', 15.3], ['Circolare per le famiglie', 16.1]]) { await R.at(at); await R.hlOff(); await tg(R, 'vmx', modI(n, '!')); await H(R, '#vmx'); } await R.at(17.2); await R.hlOff(); }},
 ]),
sb('b13', null, [
  {t:0, run: async R => { await R.hlOff(); await top(R); }},
 ]),
];
