// Video 29: L'anno di solito
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'29s', title:'Anno tipo', caption:'PEE CNGEI · Anno tipo'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts29.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + "); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";
const rowCell = n => "const r = [...document.querySelectorAll('.tg-t tr')].find(r => r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r && r.cells[0]";
const thM = m => "return [...document.querySelectorAll('.tg-t th')].find(t => t.innerText.trim() === " + JSON.stringify(m) + ")";
const legend = n => "const tb = document.querySelector('.tg-t').getBoundingClientRect().top; const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + " && e.getBoundingClientRect().top < tb + 5); return c[0] && (c[0].parentElement.children.length < 3 ? c[0].parentElement : c[0])";
const center = (R, sel) => R.F.locator(sel).first().evaluate(e => e.scrollIntoView({block:'center', inline:'center', behavior:'smooth'})).catch(() => {});
const gridX = (R, x) => R.F.evaluate(x => document.querySelector('.tg-sc').scrollTo({left:x, behavior:'smooth'}), x);
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const btn = (R, t) => R.F.locator('button.pfx-m', {hasText:t}).first();
const branca = async (R, t, tck) => { await R.move(btn(R, t), {ms:450, scroll:false}); await R.at(tck); await ck(R, btn(R, t), {ms:60}); await sleep(700); };

export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }

export const beats = [
sb('b01', 'Anno tipo', [ {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0.6, run: async R => { await R.move(sg(R, 'Realizzare'), {ms:500, scroll:false}); await R.at(1.5); await ck(R, sg(R, 'Realizzare'), {ms:60}); await R.move(si(R, 'Anno tipo'), {ms:400, scroll:false}); await R.at(4.4); await ck(R, si(R, 'Anno tipo'), {ms:60}); }},
  {t:5.2, run: async R => { await sleep(600); await tg(R, 'vg', "return document.querySelector('.tg-sc')"); await R.at(6.0); await H(R, '#vg'); }},
  {t:7.4, run: async R => { await R.hlOff(); await tg(R, 'vf', thM('Filone')); await tg(R, 'vfc', rowCell('Programmazione')); await R.at(8.5); await H(R, '#vf'); }},
  {t:10.9, run: async R => { await R.hlOff(); await tg(R, 'vm', "return document.querySelector('.tg-t tr')"); await R.at(11.4); await H(R, '#vm'); await R.at(14.4); await R.hlOff(); }},
 ]),
sb('b03', 'Non è uno schema da seguire', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'vint', inner('^Come di solito si organizza')); await R.at(1.0); await H(R, '#vint'); await R.at(10.6); await R.hlOff(); }},
 ]),
sb('b04', 'Le quattro Branche', [
  {t:0, run: async R => { await R.hlOff(); for (const [t, at] of [['Gruppo', 3.0], ['Branco', 3.6], ['Reparto', 4.2], ['Compagnia', 4.8]]) { await R.at(at); await R.hlOff(); await tg(R, 'vb', "return [...document.querySelectorAll('button.pfx-m')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")"); await H(R, '#vb'); } await R.at(7.4); await R.hlOff(); }},
  {t:7.5, run: async R => { await branca(R, 'Branco', 8.4); }},
  {t:11.9, run: async R => { await branca(R, 'Compagnia', 12.7); }},
  {t:15.3, run: async R => { await branca(R, 'Gruppo', 16.0); }},
  {t:18.0, run: async R => { await branca(R, 'Reparto', 18.9); }},
 ]),
sb('b05', 'I colori', [
  {t:0, run: async R => { await R.hlOff(); await top(R); for (const [n, at] of [['Con i ragazzi e le ragazze', 1.8], ['Staff', 4.9], ['Gruppo e Sezione', 6.4], ['Famiglie', 8.7], ['Adulti (Percorso Senior)', 10.4]]) { await R.at(at); await R.hlOff(); await tg(R, 'vl', legend(n)); await H(R, '#vl'); } await R.at(13.4); await R.hlOff(); }},
 ]),
sb('b06', 'Il mese in corso', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'vnov', thM('Nov')); await R.at(1.1); await H(R, '#vnov'); await R.at(4.4); await R.hlOff(); }},
  {t:6.5, run: async R => { await R.F.evaluate(() => document.querySelector('.tg-sc').scrollTo({top:260, left:60, behavior:'smooth'})); await R.at(8.6); await sleep(0); }},
  {t:10.6, run: async R => { await R.F.evaluate(() => document.querySelector('.tg-sc').scrollTo({top:0, left:0, behavior:'smooth'})); }},
 ]),
sb('b07', 'I filoni', [
  {t:0.2, run: async R => { await R.hlOff(); for (const [n, at] of [['Programmazione', 2.2], ['Staff', 4.1], ['Percorso Promessa', 5.4], ['Progressione verticale', 6.8], ['Campi e uscite', 8.5], ['Passaggi e Partenza', 9.9], ['Famiglie', 11.7], ['Consiglio di Gruppo', 12.6], ['Formazione', 14.2], ['Percorso Senior', 15.2], ['Gestione', 16.5]]) { await tg(R, 'vr', rowCell(n)); await center(R, '#vr'); await R.at(at); await R.hlOff(); await H(R, '#vr'); } await R.at(17.8); await R.hlOff(); }},
 ]),
sb('b10', 'Fino ad agosto', [
  {t:0, run: async R => { await R.hlOff(); await sleep(500); await top(R); await R.at(1.2); await gridX(R, 2000); await R.at(3.0); await tg(R, 'vago', thM('Ago')); await H(R, '#vago'); }},
  {t:5.6, run: async R => { await R.hlOff(); await R.F.locator('.tgi', {hasText:'Chiusura programmazione'}).first().evaluate(b => b.id = 'vchi'); await R.at(6.5); await H(R, '#vchi'); await R.at(11.2); await R.hlOff(); }},
 ]),
sb('b11', null, [
  {t:0, run: async R => { await R.hlOff(); await gridX(R, 0); await top(R); await R.at(6.5); await tg(R, 'vb', "return document.querySelector('button.pfx-m').parentElement"); await H(R, '#vb'); await R.at(8.0); await R.hlOff(); await tg(R, 'vl', legend('Staff')); await H(R, '#vl'); await R.at(9.3); await R.hlOff(); await tg(R, 'vnov', thM('Nov')); await H(R, '#vnov'); await R.at(11.6); await R.hlOff(); }},
 ]),
];
