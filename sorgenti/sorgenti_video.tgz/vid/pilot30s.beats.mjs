// Video 29: Verifica delle attività
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'30s', title:'Verifica delle attività', caption:'PEE CNGEI · Misurare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts30.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";
const rowCell = n => "const r = [...document.querySelectorAll('.tg-t tr')].find(r => r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r && r.cells[0]";
const thM = m => "return [...document.querySelectorAll('.tg-t th')].find(t => t.innerText.trim() === " + JSON.stringify(m) + ")";
const legend = n => "const tb = document.querySelector('.tg-t').getBoundingClientRect().top; const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + " && e.getBoundingClientRect().top < tb + 5); return c[0] && (c[0].parentElement.children.length < 3 ? c[0].parentElement : c[0])";
const center = (R, sel) => R.F.locator(sel).first().evaluate(e => e.scrollIntoView({block:'center', inline:'center', behavior:'smooth'})).catch(() => {});
const gridX = (R, x) => R.F.evaluate(x => document.querySelector('.tg-sc').scrollTo({left:x, behavior:'smooth'}), x);
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const btn = (R, t) => R.F.locator('button.pfx-m', {hasText:t}).first();
const branca = async (R, t, tck) => { await R.move(btn(R, t), {ms:450, scroll:false}); await R.at(tck); await ck(R, btn(R, t), {ms:60}); await sleep(700); };


const TY = async (R, sel, text) => { await R.type(sel, text.slice(0, 9), 40); await R.F.fill(sel, text); };
const ta = (R, id, ph, n) => R.F.evaluate(([id, ph, n]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const t = [...document.querySelectorAll('textarea')].filter(x => x.offsetParent !== null || true).filter(x => (x.placeholder||'').startsWith(ph))[n]; if(t){ t.id = id; t.scrollIntoView({block:'center', behavior:'instant'}); } }, [id, ph, n]);
const attHd = (R, id, n) => R.F.evaluate(([id, n]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const h = document.querySelectorAll('.ver-hd')[n]; if(h) h.id = id; }, [id, n]);
const stat = (R, id, n) => R.F.evaluate(([id, n]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const h = document.querySelectorAll('.ver-st')[n]; if(h) h.id = id; }, [id, n]);
const fld = async (R, id, ph, n, tHl, tTy, text) => { await ta(R, id, ph, n); await R.move('#' + id, {ms:400, scroll:false}); await R.at(tHl); await H(R, '#' + id); await R.at(tTy); await TY(R, '#' + id, text); await R.hlOff(); };
const mis = t => si(null, t);

export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }

export const beats = [
sb('b01', 'Verifica delle attività', [ {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0.6, run: async R => { await R.move(sg(R, 'Misurare'), {ms:500, scroll:false}); await R.at(1.9); await ck(R, sg(R, 'Misurare'), {ms:60}); await R.move(si(R, 'Verifica delle attività'), {ms:400, scroll:false}); await R.at(3.8); await ck(R, si(R, 'Verifica delle attività'), {ms:60}); }},
 ]),
sb('b03', 'Lo scopo e Come funziona', [
  {t:0, run: async R => { await R.hlOff(); await sleep(500); await top(R); await tg(R, 'vsub', "return document.querySelector('#sh-main h1, main h1, h1') && document.querySelector('h1').nextElementSibling"); await R.at(2.2); await H(R, '#vsub'); }},
  {t:9.2, run: async R => { await R.hlOff(); await tg(R, 'vcf', inner('^come funziona — verifica')); await R.move('#vcf', {ms:500, scroll:false}); await R.at(11.0); await H(R, '#vcf'); await R.at(12.6); await ck(R, '#vcf'); }},
  {t:14.8, run: async R => { await R.hlOff(); await R.at(15.3); await ck(R, '#vcf', {ms:200}); await sleep(400); await top(R); }},
 ]),
sb('b04', 'Gli elenchi dei percorsi', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'vp1', inner('^Percorso 1 — ')); await tg(R, 'vbox', "return document.querySelector('.ver-c') && document.querySelector('.ver-c').parentElement"); await R.at(1.0); await H(R, '#vbox'); await R.at(4.6); await R.hlOff(); }},
  {t:4.8, run: async R => { await H(R, '#vp1'); await R.at(7.0); await R.hlOff(); await attHd(R, 'vh0', 0); await H(R, '#vh0'); await R.at(8.0); await R.hlOff(); }},
  {t:8.4, run: async R => { await tg(R, 'vp2', inner('^Percorso 2 — ')); await R.F.evaluate(() => { const e = document.getElementById('vp2'); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }); await R.at(9.8); await H(R, '#vp2'); await R.at(11.0); await R.hlOff(); }},
  {t:12.9, run: async R => { await R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'})); await R.at(14.0); await tg(R, 'vsub', "return document.querySelector('h1').nextElementSibling"); }},
 ]),
sb('b05', 'Compilare la prima attività', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await attHd(R, 'vh0', 0); await R.move('#vh0', {ms:500, scroll:false}); await R.at(1.8); await H(R, '#vh0'); await R.at(2.9); await R.hlOff(); await ck(R, '#vh0', {ms:250}); await sleep(500); }},
  {t:3.4, run: async R => { await fld(R, 'vf1', 'Aspetti', 0, 4.7, 6.0, 'Il gioco ha coinvolto tutte le pattuglie.'); }},
  {t:8.0, run: async R => { await fld(R, 'vf2', 'Criticità', 0, 9.2, 10.8, 'Poco tempo per il giro finale.'); }},
  {t:12.4, run: async R => { await fld(R, 'vf3', 'Modifiche', 0, 13.7, 15.6, 'Giro finale spostato a fine serata.'); }},
 ]),
sb('b06', 'Chiudere e riaprire', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:0})); await sleep(500); await attHd(R, 'vh0', 0); await R.move('#vh0', {ms:500, scroll:false}); await R.at(1.7); await H(R, '#vh0'); await R.at(3.7); await ck(R, '#vh0'); await R.hlOff(); }},
  {t:4.3, run: async R => { await R.at(4.6); await ck(R, '#vh0', {ms:150}); }},
 ]),
sb('b07', 'La seconda attività', [
  {t:0, run: async R => { await R.hlOff(); await attHd(R, 'vh1', 1); await R.F.evaluate(() => document.querySelectorAll('.ver-hd')[1].scrollIntoView({block:'start', behavior:'instant'})); await R.move('#vh1', {ms:400, scroll:false}); await R.at(1.8); await H(R, '#vh1'); await R.at(2.7); await R.hlOff(); await ck(R, '#vh1', {ms:250}); await sleep(500); }},
  {t:3.5, run: async R => { await fld(R, 'vg1', 'Aspetti', 1, 3.9, 4.7, 'La mappa ha divertito tutti.'); }},
  {t:6.0, run: async R => { await ta(R, 'vg2', 'Criticità', 1); await H(R, '#vg2'); await R.at(7.2); await ta(R, 'vg3', 'Modifiche', 1); await R.hlOff(); await H(R, '#vg3'); await R.at(9.0); await R.hlOff(); }},
 ]),
sb('b08', 'Lo stato', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:0})); await sleep(400); await stat(R, 'vs0', 0); await R.F.evaluate(() => { const e = document.querySelectorAll('.ver-st')[6]; e && e.scrollIntoView({block:'center', behavior:'instant'}); }); await stat(R, 'vs6', 6); await R.at(1.6); await H(R, '#vs6'); }},
  {t:4.4, run: async R => { await R.hlOff(); await R.at(4.7); await H(R, '#vs6'); await R.at(5.5); await R.hlOff(); await R.move(si(R, 'Valutazione finale'), {ms:350, scroll:false}); await R.at(5.7); await ck(R, si(R, 'Valutazione finale'), {ms:60}); await sleep(600); await R.move(si(R, 'Verifica delle attività'), {ms:350, scroll:false}); await R.at(7.2); await ck(R, si(R, 'Verifica delle attività'), {ms:60}); }},
  {t:8.0, run: async R => { await sleep(500); await stat(R, 'vs0', 0); await R.F.evaluate(() => window.scrollTo({top:0})); await R.at(9.5); await H(R, '#vs0'); await R.at(10.9); await R.hlOff(); }},
 ]),
sb('b09', 'I pulsanti in fondo', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:1e5, behavior:'smooth'})); await sleep(1100); for (const [t, at] of [['← Percorso Personale', 3.8], ['Valutazione finale →', 6.8], ['← Torna alle priorità', 9.2], ['↓ Scarica la Scheda (Word)', 12.4]]) { await tg(R, 'vbt', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim() === " + JSON.stringify(t) + ")"); await R.at(at); await R.hlOff(); await H(R, '#vbt'); } await R.at(13.6); await R.hlOff(); }},
 ]),
sb('b10', null, [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'})); }},
 ]),
];
