// Video 29: Valutazione finale
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'31s', title:'Valutazione finale', caption:'PEE CNGEI · Misurare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts31.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";
const rowCell = n => "const r = [...document.querySelectorAll('.tg-t tr')].find(r => r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r && r.cells[0]";
const thM = m => "return [...document.querySelectorAll('.tg-t th')].find(t => t.innerText.trim() === " + JSON.stringify(m) + ")";
const legend = n => "const tb = document.querySelector('.tg-t').getBoundingClientRect().top; const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + " && e.getBoundingClientRect().top < tb + 5); return c[0] && (c[0].parentElement.children.length < 3 ? c[0].parentElement : c[0])";
const center = (R, sel) => R.F.locator(sel).first().evaluate(e => e.scrollIntoView({block:'center', inline:'center', behavior:'smooth'})).catch(() => {});
const gridX = (R, x) => R.F.evaluate(x => document.querySelector('.tg-sc').scrollTo({left:x, behavior:'smooth'}), x);
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const btn = (R, t) => R.F.locator('button.pfx-m', {hasText:t}).first();
const branca = async (R, t, tck) => { await R.move(btn(R, t), {ms:450, scroll:false}); await R.at(tck); await ck(R, btn(R, t), {ms:60}); await sleep(700); };



const TY = async (R, sel, text) => { await R.type(sel, text.slice(0, 9), 40); await R.F.fill(sel, text); };
const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const SC = "return [...document.querySelectorAll('select.obs-select')].find(s => /Punteggio/.test(s.innerText))";
const CM = "return document.querySelector('select[onchange*=\"ppIdrSet\"][onchange*=\"\\'c\\'\"]')";
const NT = "return [...document.querySelectorAll('input, textarea')].find(x => (x.placeholder||'').startsWith('Osservazioni qualitative'))";
const VC = "return document.querySelector('textarea[oninput*=\"valCompl\"]')";
const RI = "return document.querySelector('select[onchange*=\"riobsSet\"]')";
const cardHd = n => "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + ")[0].parentElement";

export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }

export const beats = [
sb('b01', 'Valutazione finale', [ {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0.4, run: async R => { await R.move(sg(R, 'Misurare'), {ms:500, scroll:false}); await R.at(1.3); await ck(R, sg(R, 'Misurare'), {ms:60}); await R.move(si(R, 'Valutazione finale'), {ms:300, scroll:false}); await R.at(2.6); await ck(R, si(R, 'Valutazione finale'), {ms:60}); }},
 ]),
sb('b03', 'Lo scopo', [
  {t:0, run: async R => { await R.hlOff(); await sleep(500); await top(R); await tg(R, 'vsub', "return document.querySelector('h1').nextElementSibling"); await R.at(1.2); await H(R, '#vsub'); }},
  {t:8.0, run: async R => { await R.hlOff(); await tg(R, 'vexp', inner('^Al termine di ciascun percorso rispondi')); await R.at(9.2); await H(R, '#vexp'); await R.at(22.6); await R.hlOff(); }},
 ]),
sb('b04', 'I percorsi', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.F.evaluate(() => window.scrollTo(0, 280)); await R.at(1.2); await tg(R, 'vc1', cardHd('Corporeità')); await H(R, '#vc1'); await R.at(6.4); await R.hlOff(); }},
  {t:6.6, run: async R => { await R.F.evaluate(() => window.scrollTo({top:640, behavior:'smooth'})); await sleep(900); await tg(R, 'vc2', cardHd('Comunicare')); await R.at(7.5); await H(R, '#vc2'); await R.at(9.8); await R.hlOff(); }},
 ]),
sb('b05', 'Il punteggio', [
  {t:0, run: async R => { await R.hlOff(); await q(R, 'vsc', SC); await R.move('#vsc', {ms:500, scroll:false}); await R.at(1.5); await H(R, '#vsc'); await R.at(3.9); await R.hlOff(); await R.selOpen('#vsc', {fast:true}); for (const [n, at] of [['1 —', 5.4], ['3 —', 7.9], ['5 —', 10.5], ['7 —', 12.8], ['9 —', 14.8]]) { await R.at(at - 0.1); await R.selHover(n, 300); } await R.at(17.2); await R.selPick('#vsc', '7 — Presente', true); }},
 ]),
sb('b06', 'Il comportamento', [
  {t:0, run: async R => { await R.hlOff(); await q(R, 'vcm', CM); await R.move('#vcm', {ms:500, scroll:false}); await R.at(0.6); await H(R, '#vcm'); await R.at(2.0); await R.hlOff(); await R.selOpen('#vcm', {fast:true}); for (const [n, at] of [['Spontaneo', 3.6], ['Stimolato', 4.4], ['Non adottato', 5.4]]) { await R.at(at - 0.1); await R.selHover(n, 300); } await R.at(6.6); await R.selPick('#vcm', 'Stimolato', true); }},
 ]),
sb('b07', 'Osservazioni qualitative', [
  {t:0, run: async R => { await R.hlOff(); await q(R, 'vnt', NT); await R.move('#vnt', {ms:500, scroll:false}); await R.at(0.9); await H(R, '#vnt'); await R.at(3.0); await TY(R, '#vnt', 'Si sono organizzati da soli, con qualche aiuto'); await R.hlOff(); }},
 ]),
sb('b08', 'Valutazione complessiva', [
  {t:0, run: async R => { await R.hlOff(); await q(R, 'vvc', VC); await R.move('#vvc', {ms:500, scroll:false}); await R.at(1.0); await H(R, '#vvc'); await R.at(7.9); await TY(R, '#vvc', 'Obiettivo raggiunto in buona parte: il gioco ha funzionato. Riproporrei le attività in pattuglia.'); await R.hlOff(); }},
 ]),
sb('b09', 'Dal punto di partenza a oggi', [
  {t:0, run: async R => { await R.hlOff(); await q(R, 'vri', RI); await tg(R, 'vbox', "const s = document.querySelector('select[onchange*=\"riobsSet\"]'); return s && s.closest('div[style*=\"dashed\"]')"); await R.at(0.9); await H(R, '#vbox'); await R.at(4.0); await R.hlOff(); await R.move('#vri', {ms:500, scroll:false}); await R.at(4.6); await H(R, '#vri'); await R.at(7.9); await R.hlOff(); await tg(R, 'vcam', inner('^Non avevi osservato questo percorso')); await R.at(8.6); await H(R, '#vcam'); await R.at(14.4); await R.hlOff(); }},
  {t:14.6, run: async R => { await tg(R, 'vnp', inner('^Non serve per il Progetto Personale')); await R.at(14.9); await H(R, '#vnp'); await R.at(18.5); await R.hlOff(); }},
 ]),
sb('b10', 'Il riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vrp', inner('^Riepilogo con punteggi')); await R.F.evaluate(() => document.getElementById('vrp').scrollIntoView({block:'start', behavior:'smooth'})); await sleep(900); await R.at(1.2); await H(R, '#vrp'); }},
  {t:3.0, run: async R => { await R.hlOff(); await tg(R, 'vrs', "const e = [...document.querySelectorAll('body *')].find(x => x.children.length === 0 && /sviluppo solido/.test(x.textContent)); return e && e.parentElement"); await R.at(6.6); await H(R, '#vrs'); await R.at(12.2); await R.hlOff(); }},
  {t:12.3, run: async R => { await tg(R, 'vnv', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && /^non valutato$/.test(e.textContent.trim())).pop()"); await R.at(14.2); await H(R, '#vnv'); await R.at(15.5); await R.hlOff(); }},
 ]),
sb('b11', 'I pulsanti in fondo', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:1e5, behavior:'smooth'})); await sleep(1100); for (const [t, at] of [['← Verifica delle attività', 3.7], ['Controllo e invio →', 6.6], ['↓ Scarica la Scheda (Word)', 9.2]]) { await tg(R, 'vbt', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim() === " + JSON.stringify(t) + ")"); await R.at(at); await R.hlOff(); await H(R, '#vbt'); } await R.at(10.2); await R.hlOff(); }},
 ]),
sb('b12', null, [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'})); }},
 ]),
];
