// Video 29: Numeri dell’anno
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'32s', title:'Numeri dell’anno', caption:'PEE CNGEI · Misurare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts32.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";
const rowCell = n => "const r = [...document.querySelectorAll('.tg-t tr')].find(r => r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r && r.cells[0]";
const thM = m => "return [...document.querySelectorAll('.tg-t th')].find(t => t.innerText.trim() === " + JSON.stringify(m) + ")";
const legend = n => "const tb = document.querySelector('.tg-t').getBoundingClientRect().top; const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + " && e.getBoundingClientRect().top < tb + 5); return c[0] && (c[0].parentElement.children.length < 3 ? c[0].parentElement : c[0])";
const center = (R, sel) => R.F.locator(sel).first().evaluate(e => e.scrollIntoView({block:'center', inline:'center', behavior:'smooth'})).catch(() => {});
const gridX = (R, x) => R.F.evaluate(x => document.querySelector('.tg-sc').scrollTo({left:x, behavior:'smooth'}), x);
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const btn = (R, t) => R.F.locator('button.pfx-m', {hasText:t}).first();
const branca = async (R, t, tck) => { await R.move(btn(R, t), {ms:450, scroll:false}); await R.at(tck); await ck(R, btn(R, t), {ms:60}); await sleep(700); };




const card = l => "const e = [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && x.textContent.trim().toLowerCase() === " + JSON.stringify(l.toLowerCase()) + ")[0]; return e && e.parentElement";
const cardS = (R, l) => R.F.evaluate(l2 => { const e = [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && x.textContent.trim().toLowerCase() === l2)[0]; if(e) e.parentElement.scrollIntoView({block:'center', behavior:'smooth'}); }, l.toLowerCase());
const seq = async (R, list) => { for (const [l, at] of list) { await tg(R, 'vk', card(l)); await R.at(at); await R.hlOff(); await H(R, '#vk'); } };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";

export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }

export const beats = [
sb('b01', 'Numeri dell’anno', [ {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0.4, run: async R => { await R.move(sg(R, 'Misurare'), {ms:450, scroll:false}); await R.at(1.1); await ck(R, sg(R, 'Misurare'), {ms:60}); await R.move(si(R, 'Numeri dell’anno'), {ms:300, scroll:false}); await R.at(2.4); await ck(R, si(R, 'Numeri dell’anno'), {ms:60}); }},
 ]),
sb('b03', 'La spiegazione', [
  {t:0, run: async R => { await R.hlOff(); await sleep(500); await top(R); await tg(R, 'vsub', "return document.querySelector('h1').nextElementSibling"); await R.at(1.9); await H(R, '#vsub'); await R.at(12.9); await R.hlOff(); }},
 ]),
sb('b04', 'Le attività dell’Unità', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'vh', head_('Le attività dell’Unità')); await R.at(1.9); await H(R, '#vh'); await R.at(3.0); await R.hlOff(); await seq(R, [['attività nel calendario', 4.2], ['giornate di attività', 8.1], ['attività fuori sede', 10.8], ['bivacchi e campi', 13.7], ['attività di staff', 15.6]]); await R.at(16.1); await R.hlOff(); }},
 ]),
sb('b05', 'Le schede con il trattino', [
  {t:0, run: async R => { await R.hlOff(); await seq(R, [['ragazzi presenti in media', 2.5], ['adulti dello staff presenti in media', 4.3], ['chilometri indicati', 8.5], ['spesa prevista', 12.4]]); await R.at(18.3); await R.hlOff(); }},
 ]),
sb('b06', 'I grafici a barre', [
  {t:0, run: async R => { await R.hlOff(); await seq(R, [['tipo di attività più utilizzato', 1.7]]); await R.at(4.8); await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:300, behavior:'smooth'})); await sleep(900); await tg(R, 'vf', head_('Per formato')); await R.at(6.5); await H(R, '#vf'); await R.at(8.1); await R.hlOff(); await tg(R, 'vt', head_('Per tipo di evento')); await R.at(8.5); await H(R, '#vt'); await R.at(13.2); await R.hlOff(); }},
 ]),
sb('b07', 'Il percorso educativo', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vpe', head_('Il percorso educativo')); await R.F.evaluate(() => document.getElementById('vpe').scrollIntoView({block:'start', behavior:'smooth'})); await sleep(900); await R.at(1.1); await H(R, '#vpe'); await R.at(2.4); await R.hlOff(); await seq(R, [['attività nei percorsi', 3.2], ['già verificate', 5.6]]); await R.at(10.0); await R.hlOff(); }},
 ]),
sb('b08', 'Ambiti e percorsi', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'va', head_('Attività per ambito')); await R.F.evaluate(() => window.scrollTo({top:900, behavior:'smooth'})); await sleep(900); await R.at(1.8); await H(R, '#va'); await R.at(5.0); await R.hlOff(); await tg(R, 'vs', "return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && x.textContent.trim() === 'Spirituale')[0].parentElement"); await R.at(8.4); await H(R, '#vs'); await R.at(10.0); await R.hlOff(); await tg(R, 'vp', head_('Percorsi più affrontati')); await R.at(10.5); await H(R, '#vp'); await R.at(11.8); await R.hlOff(); await tg(R, 'vm', head_('Strumenti del metodo più usati')); await R.at(12.4); await H(R, '#vm'); await R.at(14.0); await R.hlOff(); }},
 ]),
sb('b09', 'Le note in fondo', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:1e5, behavior:'smooth'})); await sleep(1000); await tg(R, 'vn1', "return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && /^Contati dai percorsi/.test(x.textContent.trim()))[0]"); await R.at(2.0); await H(R, '#vn1'); await R.at(8.6); await R.hlOff(); await tg(R, 'vn1b', "return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && /^Le verifiche sono testi/.test(x.textContent.trim()))[0]"); await R.at(9.8); await H(R, '#vn1b'); await R.at(15.2); await R.hlOff(); await tg(R, 'vn2', "return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && /^Come sono calcolati$/.test(x.textContent.trim()))[0].parentElement"); await R.at(16.2); await H(R, '#vn2'); await R.at(21.8); await R.hlOff(); }},
 ]),
sb('b10', null, [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'})); }},
 ]),
];
