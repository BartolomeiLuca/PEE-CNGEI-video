// Video 33: Spese mese per mese
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'33s', title:'Spese mese per mese', caption:'PEE CNGEI · Misurare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts33.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }

export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0.4, run: async R => { await R.move(sg(R, 'Misurare'), {ms:450, scroll:false}); await R.at(1.1); await ck(R, sg(R, 'Misurare'), {ms:60}); await R.move(si(R, 'Spese mese per mese'), {ms:300, scroll:false}); await R.at(3.5); await ck(R, si(R, 'Spese mese per mese'), {ms:60}); }},
 ]),
sb('b03', 'La spiegazione', [
  {t:0, run: async R => { await R.hlOff(); await sleep(500); await top(R); await tg(R, 'vsub', "return document.querySelector('h1').nextElementSibling"); await R.at(1.0); await H(R, '#vsub'); await R.at(11.9); await R.hlOff(); }},
 ]),
sb('b04', 'I due filtri', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await R.move('#bil-c', {ms:500, scroll:false}); await R.at(1.9);
     await R.selOpen('#bil-c', {fast:true}); await R.at(2.7); await R.selHover('Tutti', 400); await R.at(6.3); await R.selHover('I trimestre', 400);
     await R.at(7.4); await R.selPick('#bil-c', R.menu[0], true);
     await R.move('#bil-k', {ms:500, scroll:false}); await R.at(8.6);
     await R.selOpen('#bil-k', {fast:true});
     for (const [n, at] of [['Pasti', 9.7], ['Materiali', 10.3], ['Trasporti', 11.2], ['Locazioni', 12.0], ['Altre', 12.9]]) { await R.at(at); await R.selHover(n, 300); }
     await R.at(13.6); await R.selPick('#bil-k', R.menu[0], true); }},
 ]),
sb('b05', 'La tabella', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vtab', TAB); await R.at(0.7); await H(R, '#vtab'); await R.at(3.9); await R.hlOff();
     for (const [n, at, off] of [['mese', 5.9, 6.3], ['preventivo', 6.4, 7.1], ['speso', 7.2, 8.0], ['differenza', 8.1, 9.1]]) { await tg(R, 'vth', TH(n)); await R.at(at); await H(R, '#vth'); await R.at(off); await R.hlOff(); }
     await tg(R, 'vtot', ROW('Totale')); await R.at(10.0); await H(R, '#vtot'); await R.at(10.8); await R.hlOff();
     await tg(R, 'vmsg', inner('^Ancora nessuna')); await R.at(12.7); await H(R, '#vmsg'); await R.at(20.0); await R.hlOff(); }},
 ]),
sb('b06', 'Nuova spesa', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vreg', head_('Registro delle spese')); await R.F.evaluate(() => document.getElementById('vreg').scrollIntoView({block:'start', behavior:'smooth'})); await sleep(900); await R.at(0.8); await H(R, '#vreg'); await R.at(2.3); await R.hlOff();
     await tg(R, 'vnew', BTN('Nuova spesa')); await R.move('#vnew', {ms:450, scroll:false}); await R.at(5.3); await H(R, '#vnew'); await R.at(5.6); await R.hlOff(); await ck(R, '#vnew', {ms:60}); await sleep(700);
     await q(R, 'vd', "return document.querySelector('textarea.sp-d')"); await R.move('#vd', {ms:400, scroll:false}); await R.at(8.9); await H(R, '#vd'); await R.at(9.5); await TY(R, '#vd', 'Materiali per il gioco'); await R.hlOff();
     await q(R, 'vk', "return document.querySelector('select[onchange*=\"spSet(0,\\'cat\\'\"]')"); await R.move('#vk', {ms:400, scroll:false}); await R.at(12.3); await R.selOpen('#vk', {fast:true}); await R.at(13.0); await R.selHover('Materiali', 400); await R.at(13.6); await R.selPick('#vk', 'Materiali', true);
     await q(R, 'vi', "return document.querySelector('input.sp-i')"); await R.move('#vi', {ms:400, scroll:false}); await R.at(15.0); await R.hlOff(); await H(R, '#vi'); await R.at(15.9); await TY(R, '#vi', '18.5', 2); await R.at(17.2); await R.hlOff(); }},
 ]),
sb('b07', 'Chi, come, quando', [
  {t:0, run: async R => { await R.hlOff();
     await q(R, 'va', "return document.querySelector('select[onchange*=\"spSet(0,\\'att\\'\"]')"); await R.move('#va', {ms:400, scroll:false}); await R.at(1.6); await R.selOpen('#va', {fast:true}); await R.at(2.9); await R.selHover('Riunione di apertura', 500); await R.at(3.9); await pk(R, '#va', 'Riunione di apertura');
     await q(R, 'vw', "return document.querySelector('select[onchange*=\"spPayWho(0\"]')"); await R.move('#vw', {ms:400, scroll:false}); await R.at(5.3); await R.selOpen('#vw', {fast:true}); await R.at(6.2); await R.selHover('Anna', 400); await R.at(6.6); await pk(R, '#vw', 'Anna');
     await q(R, 'vp', "return document.querySelector('select[onchange*=\"spSet(0,\\'pag\\'\"]')"); await R.move('#vp', {ms:400, scroll:false}); await R.at(7.5); await R.selOpen('#vp', {fast:true}); await R.at(8.2); await R.selHover('Contanti', 400); await R.at(8.5); await R.selPick('#vp', 'Contanti', true);
     await q(R, 'vg', "return document.querySelector('textarea.sp-g')"); await R.move('#vg', {ms:400, scroll:false}); await R.at(10.3); await H(R, '#vg'); await R.at(12.9); await R.hlOff();
     await q(R, 'vn', "return document.querySelector('textarea.sp-n')"); await R.move('#vn', {ms:300, scroll:false}); await R.at(13.1); await H(R, '#vn'); await R.at(13.9); await R.hlOff();
     await q(R, 'vc', "return document.querySelector('input[onchange*=\"spSet(0,\\'conf\\'\"]')"); await R.move('#vc', {ms:300, scroll:false}); await R.at(14.8); await H(R, '#vc'); await R.at(16.0); await R.hlOff(); }},
 ]),
sb('b08', 'Il totale del mese', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(900); await tg(R, 'vrow', ROW('Novembre 2026')); await R.at(2.0); await H(R, '#vrow'); await R.at(4.4); await R.hlOff();
     await tg(R, 'vin', "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith('Novembre 2026')); return r && (r.querySelector('input.bil-in') || r.cells[2])"); await R.at(4.6); await H(R, '#vin'); await R.at(6.5); await R.hlOff();
     await tg(R, 'vtot', ROW('Totale')); await R.at(7.0); await H(R, '#vtot'); await R.at(8.3); await R.hlOff();
     await tg(R, 'vin2', "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith('Novembre 2026')); return r && (r.querySelector('input.bil-in') || r.cells[2])"); await R.at(8.8); await H(R, '#vin2'); await R.at(12.8); await R.hlOff(); }},
 ]),
sb('b09', 'Recupera dalle attività', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vrc', BTN('Recupera dalle attività')); await R.F.evaluate(() => document.getElementById('vrc').scrollIntoView({block:'center', behavior:'smooth'})); await sleep(900); await R.move('#vrc', {ms:450, scroll:false}); await R.at(1.2); await H(R, '#vrc'); await R.at(2.6); await R.hlOff();
     await R.at(13.9); await ck(R, '#vrc', {ms:60}); await sleep(600); await tg(R, 'vh', "return document.querySelector('.sh-hint')"); await H(R, '#vh'); await R.at(16.9); await R.hlOff(); }},
 ]),
sb('b10', 'Filtri e somma', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vf', "return document.querySelector('#sp-da') && document.querySelector('#sp-da').parentElement.parentElement"); await R.F.evaluate(() => document.getElementById('vf') && document.getElementById('vf').scrollIntoView({block:'center', behavior:'smooth'})); await sleep(900);
     for (const [id, at, off] of [['#sp-da', 2.3, 3.0], ['#sp-a', 3.0, 3.5], ['#sp-cat', 3.5, 4.3], ['#sp-att', 4.3, 5.0], ['#sp-doc', 5.0, 6.2]]) { await R.move(id, {ms:350, scroll:false}); await R.at(at); await H(R, id); await R.at(off); await R.hlOff(); }
     await tg(R, 'vsum', inner('Speso e confermato')); await R.at(12.8); await H(R, '#vsum'); await R.at(15.7); await R.hlOff(); }},
 ]),
sb('b11', 'Scaricare i dati', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(700);
     await tg(R, 'vb1', BTN('Scarica per Excel')); await R.at(4.7); await H(R, '#vb1'); await R.at(6.0); await R.hlOff();
     await tg(R, 'vb2', BTN('Scarica il Word')); await R.at(6.4); await H(R, '#vb2'); await R.at(7.6); await R.hlOff();
     await tg(R, 'vb3', BTN('Rendiconto')); await R.F.evaluate(() => document.getElementById('vb3') && document.getElementById('vb3').scrollIntoView({block:'center', behavior:'smooth'})); await sleep(900); await R.at(9.5); await H(R, '#vb3'); await R.at(10.9); await R.hlOff();
     await tg(R, 'vb4', BTN('Word sintetico')); await R.at(11.0); await H(R, '#vb4'); await R.at(11.9); await R.hlOff();
     await tg(R, 'vb5', BTN('Word dettagliato')); await R.at(12.0); await H(R, '#vb5'); await R.at(13.3); await R.hlOff(); }},
 ]),
sb('b12', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
];
