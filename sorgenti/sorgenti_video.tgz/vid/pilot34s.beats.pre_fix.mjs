// Video 34: Verifica dell’anno
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'34s', title:'Verifica dell’anno', caption:'PEE CNGEI · Misurare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts34.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }
const ANV = "return document.querySelector('#anv-bene')";
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0.2, run: async R => { await R.move(sg(R, 'Misurare'), {ms:400, scroll:false}); await R.at(0.9); await ck(R, sg(R, 'Misurare'), {ms:60}); await R.move(si(R, 'Verifica dell’anno'), {ms:300, scroll:false}); await R.at(2.4); await ck(R, si(R, 'Verifica dell’anno'), {ms:60}); }},
 ]),
sb('b03', 'La spiegazione', [
  {t:0, run: async R => { await R.hlOff(); await sleep(500); await top(R); await tg(R, 'vsub', "return document.querySelector('h1').nextElementSibling"); await R.at(0.7); await H(R, '#vsub'); await R.at(14.9); await R.hlOff(); }},
 ]),
sb('b04', 'La scheda del ciclo', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vcy', "const h = [...document.querySelectorAll('h3')].find(x => x.offsetParent && /^I trimestre/.test(x.innerText.trim())); return h && h.parentElement"); await R.at(1.2); await H(R, '#vcy'); await R.at(7.3); await R.hlOff(); }},
 ]),
sb('b05', 'I percorsi del ciclo', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vt', "const h = [...document.querySelectorAll('h3')].find(x => x.offsetParent && /^I trimestre/.test(x.innerText.trim())); return h && h.parentElement.querySelector('table')");
     await R.at(0.1); await H(R, '#vt'); await R.at(1.9); await R.hlOff();
     for (const [n, at, off] of [['P1', 2.5, 3.4], ['C1', 3.4, 4.4]]) { await tg(R, 'vr', ROW(n)); await R.at(at); await H(R, '#vr'); await R.at(off); await R.hlOff(); }
     for (const [n, at, off] of [['dal punto', 5.6, 7.5], ['attività', 7.6, 10.9], ['valutazione', 11.0, 12.8]]) { await tg(R, 'vh', TH(n)); await R.at(at); await H(R, '#vh'); await R.at(off); await R.hlOff(); }
     await tg(R, 'vv', ROW('P1')); await R.F.evaluate(() => { const r = document.getElementById('vv'); r && (r.id = 'vv'); }); await tg(R, 'vc4', "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith('P1')); return r && r.cells[r.cells.length - 1]"); await R.at(13.1); await H(R, '#vc4'); await R.at(14.5); await R.hlOff(); }},
 ]),
sb('b06', 'Gli Indicatori di Risultato', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vir', inner('^Indicatori di Risultato')); await R.at(1.4); await H(R, '#vir'); await R.at(5.2); await R.hlOff(); }},
 ]),
sb('b07', 'Le cinque domande', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vh3', head_('La riflessione dell’anno')); await R.F.evaluate(() => document.getElementById('vh3').scrollIntoView({block:'start', behavior:'smooth'})); await sleep(900); await R.at(0.4); await H(R, '#vh3'); await R.at(1.7); await R.hlOff();
     for (const [id, at, off] of [['#anv-bene', 3.3, 5.3], ['#anv-migl', 5.5, 6.9], ['#anv-porta', 7.1, 9.4], ['#anv-ambiti', 9.6, 12.0], ['#anv-staff', 12.2, 14.9]]) { await R.move(id, {ms:350, scroll:false}); await R.at(at); await H(R, id); await R.at(off); await R.hlOff(); } }},
 ]),
sb('b08', 'Scrivere la riflessione', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => document.getElementById('anv-bene').scrollIntoView({block:'center', behavior:'smooth'})); await sleep(700);
     await R.move('#anv-bene', {ms:400, scroll:false}); await R.at(1.9); await TY(R, '#anv-bene', 'Le pattuglie si sono organizzate da sole');
     await R.move('#anv-migl', {ms:400, scroll:false}); await R.at(5.6); await TY(R, '#anv-migl', 'Più tempo per le verifiche');
     await R.move('#anv-porta', {ms:400, scroll:false}); await R.at(8.6); await TY(R, '#anv-porta', 'L’autonomia delle pattuglie'); await R.hlOff(); }},
 ]),
sb('b09', 'Si salva da solo', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vst', "return document.querySelector('#anv-st')"); await R.F.evaluate(() => document.getElementById('vst').scrollIntoView({block:'center', behavior:'smooth'})); await sleep(700); await R.move('#vst', {ms:400, scroll:false}); await R.at(2.0); await H(R, '#vst'); await R.at(4.0); await R.hlOff(); await R.at(5.3); await H(R, '#vst'); await R.at(7.2); await R.hlOff(); }},
 ]),
sb('b10', 'Il Word dell’anno', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vw', BTN('Scarica il Word dell’anno')); await R.move('#vw', {ms:500, scroll:false}); await R.at(2.5); await H(R, '#vw'); await R.at(4.5); await R.hlOff(); }},
 ]),
sb('b11', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
];
