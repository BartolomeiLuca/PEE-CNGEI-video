// Video 35: Condividi con lo staff
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'35s', title:'Condividi con lo staff', caption:'PEE CNGEI · Condividere'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts35.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) {} };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }
const bt = (sel, t) => "const r = [...document.querySelectorAll(" + JSON.stringify(sel) + ")].find(b => b.offsetParent && b.innerText.trim().toLowerCase().includes(" + JSON.stringify(t) + ")); return r";
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await top(R); await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0.3, run: async R => { await R.move(sg(R, 'Condividere'), {ms:400, scroll:false}); await R.at(1.1); await ck(R, sg(R, 'Condividere'), {ms:60}); await R.move(si(R, 'Condividi con lo staff'), {ms:300, scroll:false}); await R.at(2.6); await ck(R, si(R, 'Condividi con lo staff'), {ms:60}); }},
 ]),
sb('b03', 'La pagina', [
  {t:0, run: async R => { await R.hlOff(); await sleep(400); await top(R); await tg(R, 'vit', inner('^Invita una persona su')); await R.at(1.4); await H(R, '#vit'); await R.at(6.8); await R.hlOff(); await R.at(6.9); await H(R, '#sh-share'); await R.at(9.4); await R.hlOff(); }},
 ]),
sb('b04', 'I tre ruoli', [
  {t:0, run: async R => { await R.hlOff();
     for (const [rx, at, off] of [['^Lettore:', 1.4, 5.5], ['^Co-titolare:', 5.9, 9.4], ['^Collaboratore:', 9.6, 14.4]]) { await tg(R, 'vru', inner(rx)); await R.at(at); await H(R, '#vru'); await R.at(off); await R.hlOff(); } }},
 ]),
sb('b05', 'Scrivere l’email', [
  {t:0, run: async R => { await R.hlOff(); await R.move('#cl-inv', {ms:400, scroll:false}); await R.at(1.7); await TY(R, '#cl-inv', 'marco.neri@esempio.it', 9);
     await tg(R, 'vnt', inner('^La persona invitata deve')); await R.at(2.5); await H(R, '#vnt'); await R.at(8.2); await R.hlOff(); }},
 ]),
sb('b06', 'Scegliere il ruolo', [
  {t:0, run: async R => { await R.hlOff(); await R.move('#cl-invr', {ms:500, scroll:false}); await R.at(1.4); await R.selOpen('#cl-invr', {fast:true});
     for (const [n, at] of [['Lettore', 2.5], ['Co-titolare', 3.2], ['Collaboratore', 4.0]]) { await R.at(at); await R.selHover(n, 300); }
     await R.at(5.6); await R.selPick('#cl-invr', 'Collaboratore', true); }},
 ]),
sb('b07', 'Invitare', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vin', BTN('Invita')); await R.move('#vin', {ms:350, scroll:false}); await R.at(0.4); await ck(R, '#vin', {ms:60}); await sleep(800);
     await tg(R, 'vms', "return document.querySelector('#cl-msg')"); await R.at(1.4); await H(R, '#vms'); await R.at(8.9); await R.hlOff(); }},
 ]),
sb('b08', 'Avvisare subito', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vwa', "return document.querySelector('#cl-wanow')"); await R.at(1.9); await H(R, '#vwa'); await R.at(3.1); await R.hlOff();
     console.log('vb1', await tg(R, 'vb1', "return document.querySelectorAll('#vwa a.wa')[0]")); await R.at(4.0); await H(R, '#vb1'); await R.at(4.6); await R.hlOff();
     console.log('vb2', await tg(R, 'vb2', "return document.querySelectorAll('#vwa a.wa')[1]")); await R.at(4.8); await H(R, '#vb2'); await R.at(5.5); await R.hlOff();
     await tg(R, 'vnn', inner('^Avvisa su WhatsApp e Avvisa via email')); await R.F.evaluate(() => { const e = document.getElementById('vnn'); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }); await sleep(800); await R.at(7.8); await H(R, '#vnn'); await R.at(14.6); await R.hlOff(); }},
 ]),
sb('b09', 'Chi ha accesso', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vha', inner('^Hanno accesso')); await R.F.evaluate(() => { const e = document.getElementById('vha'); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }); await sleep(800); await R.at(0.6); await H(R, '#vha'); await R.at(1.7); await R.hlOff();
     await tg(R, 'vap', inner('non ha ancora aperto')); await R.at(3.8); await H(R, '#vap'); await R.at(6.2); await R.hlOff();
     await q(R, 'vrl', "return document.querySelector('#cl-mem select.cl-role')"); await R.move('#vrl', {ms:400, scroll:false}); await R.at(7.6); await R.selOpen('#vrl', {fast:true}); await R.at(8.3); await R.selHover('Co-titolare', 300); await R.at(8.8); await R.selPick('#vrl', 'Collaboratore', true);
     console.log('vwb', await tg(R, 'vwb', "return document.querySelectorAll('#cl-mem a.wa')[0]")); await R.at(9.5); await H(R, '#vwb'); await R.at(10.7); await R.hlOff();
     await tg(R, 'vtg', "return [...document.querySelectorAll('#cl-mem button')].find(b => /togli accesso/i.test(b.innerText))"); await R.at(11.2); await H(R, '#vtg'); await R.at(12.3); await R.hlOff(); }},
 ]),
sb('b10', 'Per te', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(700); await tg(R, 'vpr', "return [...document.querySelectorAll('header button, header a, #sh-root button, #sh-root a')].find(b => b.offsetParent && /^Progetti$/i.test(b.innerText.trim()))"); await R.move('#vpr', {ms:600, scroll:false}); await R.at(4.9); await H(R, '#vpr'); await R.at(11.9); await R.hlOff(); }},
 ]),
sb('b11', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(760, 520, 1400); }},
 ]),
];
