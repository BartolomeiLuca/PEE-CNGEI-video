// Video 36: Lavorare in due
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'36s', title:'Lavorare in due', caption:'PEE CNGEI · Condividere'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts36.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await sleep(4000); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'L’invito', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vmo', "const e = [...document.querySelectorAll('div')].find(d => d.offsetParent && /ti ha invitato su/.test(d.innerText) && d.innerText.length < 400 && !d.querySelector('div div div')); return e");
     await tg(R, 'vim', inner('ti ha invitato su')); await R.at(2.7); await H(R, '#vim'); await R.at(7.6); await R.hlOff();
     await tg(R, 'vco', "return [...document.querySelectorAll('strong,b')].find(e => e.offsetParent && /^collaboratore$/i.test(e.textContent.trim()))"); await R.at(8.9); await H(R, '#vco'); await R.at(10.0); await R.hlOff();
     await tg(R, 'vru', inner('^modifica il progetto, lavorando')); await R.at(10.0); await H(R, '#vru'); await R.at(13.9); await R.hlOff();
     await tg(R, 'vpt', BTN('Più tardi')); await R.move('#vpt', {ms:500, scroll:false}); await R.at(14.7); await ck(R, '#vpt', {ms:60}); }},
 ]),
sb('b03', 'Per te', [
  {t:0, run: async R => { await R.hlOff(); await sleep(500);
     await tg(R, 'vpr', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Progetti/.test(b.innerText.trim()))"); await R.move('#vpr', {ms:500, scroll:false}); await R.at(1.0); await H(R, '#vpr'); await R.at(3.2); await R.hlOff();
     await tg(R, 'vh', inner('^Per te · 2 novità')); await R.at(4.6); await H(R, '#vh'); await R.at(6.2); await R.hlOff();
     await tg(R, 'vr1', ROWB('^Invito:')); await R.at(6.6); await H(R, '#vr1'); await R.at(7.3); await R.hlOff();
     await tg(R, 'vr2', ROWB('^Attività affidata a te')); await R.at(7.4); await H(R, '#vr2'); await R.at(10.9); await R.hlOff();
     await tg(R, 'vap', RB('^Attività affidata a te', 'Apri')); await R.move('#vap', {ms:500, scroll:false}); await R.at(11.3); await H(R, '#vap'); await R.at(12.9); await R.hlOff();
     await tg(R, 'vhc', RB('^Attività affidata a te', 'Ho capito')); await R.move('#vhc', {ms:400, scroll:false}); await R.at(13.4); await H(R, '#vhc'); await R.at(16.4); await R.hlOff(); }},
 ]),
sb('b04', 'Il ruolo', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vru', inner('^Il tuo ruolo: Collaboratore')); await sc(R, 'vru'); await sleep(800); await R.move('#vru', {ms:500, scroll:false}); await R.at(4.2); await H(R, '#vru'); await R.at(6.0); await R.hlOff(); await R.at(15.2); }},
 ]),
sb('b05', 'Apro l’attività', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(800);
     await tg(R, 'vap', RB('^Attività affidata a te', 'Apri')); await R.move('#vap', {ms:400, scroll:false}); await R.at(0.3); await ck(R, '#vap', {ms:60}); await R.F.waitForSelector('#att-0-0 summary .aff-chip', {timeout:20000}).catch(() => {}); await sleep(600);
     await R.F.evaluate(() => { const d = document.getElementById('att-0-0'); if(d){ d.open = true; d.scrollIntoView({block:'start', behavior:'smooth'}); } }); await sleep(1000);
     await R.at(6.7); await tg(R, 'vch', "return document.querySelector('#att-0-0 summary .aff-chip')"); await H(R, '#vch'); await R.at(8.6); await R.hlOff();
     await R.at(9.4); await tg(R, 'vrf', "return [...document.querySelectorAll('#att-0-0 *')].find(e => e.offsetParent && e.children.length === 0 && /^Marco Neri/.test(e.textContent.trim()))"); await H(R, '#vrf'); await R.at(11.0); await R.hlOff(); }},
 ]),
sb('b06', 'Scrivo nello Sviluppo', [
  {t:0, run: async R => { await R.hlOff(); await q(R, 'vsv', "return [...document.querySelectorAll('#att-0-0 textarea')].find(t => /^Che cosa fanno/.test(t.placeholder))"); await R.move('#vsv', {ms:500, scroll:false}); await R.at(2.5); await TY(R, '#vsv', 'A staffetta, a squadre, con un traguardo per ogni pattuglia');
     await R.hlOff(); await tg(R, 'vsa', "return [...document.querySelectorAll('body *')].filter(e => e.getClientRects().length && e.children.length === 0 && /Salvato/.test(e.textContent))[0]"); await R.at(9.5); await H(R, '#vsa'); await R.at(10.8); await R.hlOff(); }},
 ]),
sb('n1', 'Completo l’attività', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const d = document.getElementById('att-0-0'); d && d.scrollIntoView({block:'start', behavior:'smooth'}); }); await sleep(1000);
     await R.at(2.0); await H(R, '#att-0-0 summary'); await R.at(5.4); await R.hlOff();
     await q(R, 'vlc', "return [...document.querySelectorAll('#att-0-0 textarea')].find(t => /^Presentiamo/.test(t.value))"); await R.move('#vlc', {ms:500, scroll:false}); await R.at(7.8); await H(R, '#vlc'); await R.at(9.8); await R.hlOff();
     await q(R, 'vcn', "return [...document.querySelectorAll('#att-0-0 textarea')].find(t => /^Come si chiude/.test(t.placeholder))"); await R.move('#vcn', {ms:500, scroll:false}); await R.at(12.3); await TY(R, '#vcn', 'Ci si siede in cerchio: ognuno e ognuna dice una cosa nuova che ha scoperto del Reparto');
     await R.hlOff(); await tg(R, 'vsa', "return [...document.querySelectorAll('body *')].filter(e => e.getClientRects().length && e.children.length === 0 && /Salvato/.test(e.textContent))[0]"); await R.at(18.0); await H(R, '#vsa'); await R.at(19.0); await R.hlOff(); }},
 ]),
sb('n2', 'Indicatori specifici', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const d = document.querySelector('#att-0-0 .att-obj'); if(d){ d.open = false; d.scrollIntoView({block:'center', behavior:'smooth'}); } }); await sleep(1100);
     await R.at(1.4); await H(R, '#att-0-0 .att-obj summary'); await R.at(3.4); await R.hlOff();
     await R.at(4.0); await H(R, '#att-0-0 .att-obj summary'); await R.at(8.4); await R.hlOff();
     await R.move('#att-0-0 .att-obj summary', {ms:500, scroll:false}); await R.at(8.9); await ck(R, '#att-0-0 .att-obj summary', {ms:60}); await sleep(900);
     await q(R, 'vck', "return [...document.querySelectorAll('#att-0-0 .att-obj input[type=checkbox]')].find(c => !c.checked)"); await R.move('#vck', {ms:500, scroll:false}); await R.at(9.8); await ck(R, '#vck', {ms:60}); await sleep(500); await R.at(10.9); await H(R, '#vck'); await R.at(16.9); await R.hlOff(); }},
 ]),
sb('b07', 'Una parte non mia', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const d = document.getElementById('att-0-1'); if(d){ d.open = true; d.scrollIntoView({block:'start', behavior:'smooth'}); } }); await sleep(1100);
     await tg(R, 'vch', "return document.querySelector('#att-0-1 summary .aff-chip')"); await R.at(1.9); await H(R, '#vch'); await R.at(3.0); await R.hlOff();
     await tg(R, 'vlk', "return document.querySelector('#att-0-1 .att-lock')"); await R.at(4.4); await H(R, '#vlk'); await R.at(8.9); await R.hlOff();
     if(await q(R, 'vti', "return [...document.querySelectorAll('#att-0-1 input, #att-0-1 textarea')].find(i => /Orientiamoci/.test(i.value))")){ await R.move('#vti', {ms:400, scroll:false}); } await R.at(9.2); await H(R, '#vti'); await R.at(10.8); await R.hlOff(); }},
 ]),
sb('n3', 'Le altre pagine', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(600);
     await R.at(3.8); await R.move(sg(R, 'Capire'), {ms:500, scroll:false}); await R.at(4.9); await ck(R, sg(R, 'Capire'), {ms:60}); await sleep(600); await R.move(si(R, 'Il mio staff'), {ms:400, scroll:false}); await R.at(5.6); await ck(R, si(R, 'Il mio staff'), {ms:60}); await sleep(1300);
     await tg(R, 'vt', "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Email/.test(t.innerText) && /Ruolo/.test(t.innerText))"); await R.at(6.5); await H(R, '#vt'); await R.at(8.3); await R.hlOff();
     await tg(R, 'vrl', "const t = [...document.querySelectorAll('table')].find(t => t.offsetParent && /Email/.test(t.innerText) && /Ruolo/.test(t.innerText)); return t.querySelectorAll('tbody tr')[1]"); await R.move('#vrl', {ms:500, scroll:false}); await R.at(8.6); await H(R, '#vrl'); await R.at(11.4); await R.hlOff();
     await R.move(sg(R, 'Progettare'), {ms:500, scroll:false}); await R.at(11.7); await ck(R, sg(R, 'Progettare'), {ms:60}); await sleep(600); await R.move(si(R, 'Obiettivi e indicatori'), {ms:400, scroll:false}); await R.at(12.6); await ck(R, si(R, 'Obiettivi e indicatori'), {ms:60}); await sleep(1500);
     await tg(R, 'vin', "return [...document.querySelectorAll('main input, main textarea, main select')].find(e => e.offsetParent && e.disabled)"); await R.move('#vin', {ms:500, scroll:false}); await R.at(16.2); await H(R, '#vin'); await R.at(19.2); await R.hlOff(); }},
 ]),
sb('b08', 'Chi affida', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vrf', "const e = [...document.querySelectorAll('#att-0-1 *')].find(e => e.offsetParent && e.children.length === 0 && /^Referente dell’attività/.test(e.textContent.trim())); return e && e.parentElement"); await sc(R, 'vrf'); await sleep(900); await R.at(5.0); await H(R, '#vrf'); await R.at(7.2); await R.hlOff(); }},
 ]),
sb('b09', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(760, 520, 1400); }},
 ]),
];
