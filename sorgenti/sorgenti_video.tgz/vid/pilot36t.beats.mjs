import { sleep } from './rec.mjs';
export const META = {n:'36t', title:'t', caption:'PEE CNGEI · Condividere'};
export async function open(F){ await sleep(4000); }
export const beats = [
 {id:'t1', scene:'t', say:'x'.repeat(300), run: async R => {
   const F = R.F;
   await F.evaluate(() => { const b=[...document.querySelectorAll('button')].find(b=>b.offsetParent&&/^Più tardi/.test(b.innerText.trim())); b&&b.click(); }); await sleep(800);
   await F.evaluate(() => { const r=[...document.querySelectorAll('.cl-row')].find(r=>r.offsetParent&&/^Attività affidata a te/.test(r.innerText.trim())); const b=r&&[...r.querySelectorAll('button')].find(b=>b.innerText.trim()==='Apri'); b&&b.click(); }); await sleep(5000);
   await F.evaluate(() => { const v=[...document.querySelectorAll('#sh-side .sh-si')].some(e=>e.offsetParent&&/Come osservo/.test(e.innerText)); if(!v) shGrp('Osservare'); }); await sleep(500);
   await F.evaluate(() => { [...document.querySelectorAll('#sh-side .sh-si')].find(e=>e.offsetParent&&/Come osservo/.test(e.innerText))?.click(); }); await sleep(2500);
   await R.P.screenshot({path:'/tmp/g41a.png'}); await F.evaluate(() => { ossWizOpen('P1'); }); await sleep(3500); await R.P.screenshot({path:'/tmp/g41b.png'});
   await F.evaluate(() => { ossWizClose(); }); await sleep(600);
   await F.evaluate(() => { ossSaveFrom({att:{nome:'Il gioco dei nodi', main:'P1', also:[], dom:'Chi si mette alla prova con il proprio corpo?', foc:[], dur:60, lan:'Lanciamo una sfida di squadra.', svi:'', con:'', temi:[], tipi:[], strum:[]}}); }); await sleep(1500);
   await R.P.screenshot({path:'/tmp/g41c.png'});
   console.log(JSON.stringify(await F.evaluate(() => ({toast:[...document.querySelectorAll('[role=status],.toast,#toast')].map(e=>e.innerText), list:[...document.querySelectorAll('#oss-list *, .oss-card, .oss-it')].slice(0,6).map(e=>e.className+':'+e.innerText.slice(0,80)), note:document.querySelector('.oss-note')?.innerText}))));
   await F.evaluate(() => { const e=document.querySelector('.oss-card, .oss-it, #oss-list'); e&&e.scrollIntoView({block:'center'}); }); await sleep(800); await R.P.screenshot({path:'/tmp/g41d.png'});
 }},
];
