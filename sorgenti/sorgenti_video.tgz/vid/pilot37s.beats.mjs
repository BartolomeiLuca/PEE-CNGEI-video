// Video 37: Controllo e invio
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'37s', title:'Controllo e invio', caption:'PEE CNGEI · Condividere'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts37.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const S13 = "return [...document.querySelectorAll('details summary')].find(s => s.offsetParent && /Osservare e Progettare ·/.test(s.textContent))";
const S45 = "return [...document.querySelectorAll('details summary')].find(s => s.offsetParent && /Verifica delle attività e Valutazione/.test(s.textContent))";
const DB = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0.3, run: async R => { await R.move(sg(R, 'Condividere'), {ms:400, scroll:false}); await R.at(2.5); await ck(R, sg(R, 'Condividere'), {ms:60}); await R.move(si(R, 'Controllo e invio'), {ms:300, scroll:false}); await R.at(5.7); await ck(R, si(R, 'Controllo e invio'), {ms:60}); await R.moveTo(900, 520, 1000); }},
 ]),
sb('b03', 'Prima lista', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vs13', S13); await R.move('#vs13', {ms:500, scroll:false}); await R.at(1.9); await H(R, '#vs13'); await R.at(6.9); await R.hlOff();
     await R.at(8.2); await ck(R, '#vs13', {ms:60}); await sleep(700);
     await tg(R, 'vok', inner('^✓ Dati: nome')); await R.at(12.5); await H(R, '#vok'); await R.at(13.6); await R.hlOff();
     await tg(R, 'vo1', inner('Contesto territoriale e contesto')); await R.at(17.5); await H(R, '#vo1'); await R.at(18.9); await R.hlOff();
     await tg(R, 'vo2', inner('Numeri dell’Unità')); await R.at(19.1); await H(R, '#vo2'); await R.at(20.3); await R.hlOff();
     await tg(R, 'vo3', inner('Analisi delle dinamiche di gruppo')); await R.at(20.7); await H(R, '#vo3'); await R.at(22.5); await R.hlOff();
     await tg(R, 'vs13', S13); await R.at(23.0); await H(R, '#vs13'); await R.at(26.2); await R.hlOff(); }},
 ]),
sb('b04', 'Seconda lista', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vs45', S45); await sc(R, 'vs45'); await sleep(700); await R.move('#vs45', {ms:500, scroll:false}); await R.at(0.6); await H(R, '#vs45'); await R.at(4.3); await R.hlOff(); await R.at(4.6); await ck(R, '#vs45', {ms:60}); await sleep(600);
     await tg(R, 'vv1', inner('Verifica di ogni attività descritta')); await R.at(7.1); await H(R, '#vv1'); await R.at(8.6); await R.hlOff();
     await tg(R, 'vv2', inner('Comportamento indicato per ogni indicatore')); await R.at(8.8); await H(R, '#vv2'); await R.at(11.2); await R.hlOff();
     await tg(R, 'vvq', inner('Osservazioni qualitative per ogni indicatore')); await R.at(11.4); await H(R, '#vvq'); await R.at(12.9); await R.hlOff();
     await tg(R, 'vv3', inner('Valutazione complessiva per ogni priorità')); await R.at(13.1); await H(R, '#vv3'); await R.at(15.6); await R.hlOff(); }},
 ]),
sb('b05', 'I documenti Word', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vd1', DB('↓ Scheda fino a Progettare')); await sc(R, 'vd1'); await sleep(900);
     await R.at(1.4); await R.move('#vd1', {ms:500, scroll:false}); await R.at(2.3); await H(R, '#vd1'); await R.at(6.9); await R.hlOff();
     await tg(R, 'vd2', DB('↓ Scheda completa')); await R.move('#vd2', {ms:400, scroll:false}); await R.at(7.0); await H(R, '#vd2'); await R.at(10.8); await R.hlOff();
     await tg(R, 'vnt', inner('^Il Word riporta le Sezioni')); await R.at(10.9); await H(R, '#vnt'); await R.at(20.3); await R.hlOff();
     await tg(R, 'vd2', DB('↓ Scheda completa')); await R.move('#vd2', {ms:400, scroll:false}); await R.at(21.5); await ck(R, '#vd2', {ms:60}); }},
 ]),
sb('n1', 'Scheda fino a Progettare', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vd1', DB('↓ Scheda fino a Progettare')); await sc(R, 'vd1'); await sleep(900); await tg(R, 'vd1', DB('↓ Scheda fino a Progettare')); await R.move('#vd1', {ms:500, scroll:false}); await R.at(2.2); await H(R, '#vd1'); await R.at(4.3); await ck(R, '#vd1', {ms:60}); await R.at(5.8); await R.hlOff();
     await R.at(6.0); await H(R, '#vd1'); await R.at(10.4); await R.hlOff(); }},
 ]),
sb('b06', 'Dati in Excel', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vd3', DB('↓ Dati dell')); await R.move('#vd3', {ms:500, scroll:false}); await R.at(0.4); await H(R, '#vd3'); await R.at(3.8); await R.hlOff(); await R.at(8.6); await ck(R, '#vd3', {ms:60}); }},
 ]),
sb('n2', 'Torna alle priorità', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vtp', DB('← Torna alle priorità')); await sc(R, 'vtp'); await sleep(900); await tg(R, 'vtp', DB('← Torna alle priorità')); await R.move('#vtp', {ms:500, scroll:false}); await R.at(2.3); await H(R, '#vtp'); await R.at(4.0); await R.hlOff(); await R.at(7.4); await top(R); await R.at(14.0); await tg(R, 'vs13', S13); await H(R, '#vs13'); await R.at(16.2); await R.hlOff(); }},
 ]),
sb('b07', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(760, 520, 1400); }},
 ]),
];
