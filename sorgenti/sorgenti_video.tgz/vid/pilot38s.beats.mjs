// Video 38: Cerca e archivio nazionale
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'38s', title:'Cerca e archivio nazionale', caption:'PEE CNGEI · Condividere'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts38.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(3000); await F.evaluate(() => gGo('3')); await sleep(2000); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Apro la ricerca', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vcc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /Cerca un’attività/.test(b.innerText))"); await R.move('#vcc', {ms:600, scroll:false}); await R.at(5.0); await ck(R, '#vcc', {ms:60}); await sleep(900);
     await tg(R, 'vt1', OVB('Le mie attività')); await R.at(9.7); await H(R, '#vt1'); await R.at(10.9); await R.hlOff();
     await tg(R, 'vt2', OVB('Archivio nazionale')); await R.at(11.1); await H(R, '#vt2'); await R.at(12.4); await R.hlOff(); }},
 ]),
sb('b03', 'Le mie attività', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vq', "return document.getElementById('an-q')"); await R.move('#vq', {ms:600, scroll:false}); await R.at(7.3); await H(R, '#vq'); await R.at(9.5); await R.hlOff();
     await R.at(9.8); await TY(R, '#vq', 'mappa', 5); await sleep(600);
     await tg(R, 'vr1', inner('^Orientiamoci con la mappa$')); await R.at(13.4); await H(R, '#vr1'); await R.at(15.8); await R.hlOff(); }},
 ]),
sb('b04', 'I filtri', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vam', SEL('Personale')); await R.at(2.2);
     await R.selOpen('#vam', {fast:true}); await R.at(4.2); await R.selHover('Personale', 400); await R.at(5.0); await R.selHover('Comunitario', 400); await R.at(5.9); await R.selHover('Spirituale', 400); await R.at(6.7); await R.P.evaluate(() => ST.menuOff());
     await tg(R, 'vdu', SEL('fino a 1 ora')); await R.at(7.0); await R.selOpen('#vdu', {fast:true}); await R.at(8.4); await R.selHover('fino a 30', 400); await R.at(9.7); await R.selHover('fino a 1 ora', 400); await R.at(10.6); await R.selHover('fino a 2 ore', 400); await R.at(11.5); await R.P.evaluate(() => ST.menuOff());
     await tg(R, 'vha', inner('^Ha funzionato$')); await R.move('#vha', {ms:600, scroll:false}); await R.at(19.3); await H(R, '#vha'); await R.at(22.9); await R.hlOff(); }},
 ]),
sb('n1', 'Gli altri filtri', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { try{ AN.f.q = ''; }catch(e){} const q = document.getElementById('an-q'); if(q) q.value = ''; try{ anList(); }catch(e){} }); await sleep(600);
     await tg(R, 'vbr', SEL('Reparto')); await R.at(2.0); await R.selOpen('#vbr', {fast:true}); await R.at(2.8); await R.selHover('Reparto', 400); await R.at(3.6); await R.P.evaluate(() => ST.menuOff());
     await tg(R, 'vpe', SEL('P1 · Corporeità')); await R.at(4.2); await R.selOpen('#vpe', {fast:true}); await R.at(7.4); await R.selHover('C1', 400); await R.at(8.3); await R.selHover('P1', 400); await R.at(9.2); await R.P.evaluate(() => ST.menuOff());
     await tg(R, 'vti', SEL('Ogni tipo di attività')); await R.move('#vti', {ms:300, scroll:false}); await R.at(9.8); await H(R, '#vti'); await R.at(11.0); await R.hlOff();
     await tg(R, 'vst', SEL('Ogni strumento del Metodo')); await R.move('#vst', {ms:300, scroll:false}); await R.at(11.3); await H(R, '#vst'); await R.at(15.6); await R.hlOff();
     await tg(R, 'vdv', SEL('In sede')); await R.at(15.9); await R.selOpen('#vdv', {fast:true}); await R.at(17.3); await R.selHover('In sede', 350); await R.at(18.0); await R.selHover('Fuori sede', 350); await R.at(18.8); await R.selHover('In uscita', 350); await R.at(19.6); await R.P.evaluate(() => ST.menuOff());
     await tg(R, 'vam', SEL('Personale')); await R.at(20.0); await R.selOpen('#vam', {fast:true}); await R.at(21.5); await R.selPick('#vam', 'Comunitario', true); await sleep(900);
     await tg(R, 'vl', "return document.querySelector('.an-ov .an-res, .an-ov [id*=res], .an-ov')"); await R.at(22.9); await H(R, '#vl'); await R.at(25.0); await R.hlOff();
     await tg(R, 'vam', SEL('Comunitario')); await R.at(26.0); await R.selOpen('#vam', {fast:true}); await R.at(26.6); await R.selPick('#vam', 'Tutti gli ambiti', true); }},
 ]),
sb('b05', 'Apri e Riusa', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vap', OVB('Apri')); await R.move('#vap', {ms:600, scroll:false}); await R.at(2.6); await H(R, '#vap'); await R.at(5.5); await R.hlOff();
     await tg(R, 'vru', OVB('Riusa in questo progetto')); await R.move('#vru', {ms:500, scroll:false}); await R.at(6.3); await H(R, '#vru'); await R.at(8.0); await R.hlOff();
     await R.at(12.7); await ck(R, '#vru', {ms:60}); await sleep(900);
     await tg(R, 'vx', "return [...document.querySelectorAll('.an-ov .modal-x')].find(b => b.offsetParent)"); await R.move('#vx', {ms:500, scroll:false}); await R.at(17.9); await ck(R, '#vx', {ms:60}); }},
 ]),
sb('n2', 'Riuso un’attività', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { document.querySelectorAll('.an-pick').forEach(b => { let c = b; while(c && getComputedStyle(c).position !== 'fixed') c = c.parentElement; if(c) c.remove(); }); document.querySelectorAll('.an-ov').forEach(e => e.remove()); anOpen(); }); await sleep(1200);
     await tg(R, 'vru', ACT('Cucina a fuoco', 'Riusa')); await R.F.evaluate(() => { const b = document.getElementById('vru'); b && b.scrollIntoView({block:'center', behavior:'smooth'}); }); await sleep(900); await R.move('#vru', {ms:500, scroll:false}); await R.at(3.0); await H(R, '#vru'); await R.at(4.0); await ck(R, '#vru', {ms:60}); await sleep(900); await R.hlOff();
     await tg(R, 'vpk', "return [...document.querySelectorAll('button.an-pick')].find(b => b.offsetParent && /^Percorso 2/.test(b.innerText.trim()))"); await R.move('#vpk', {ms:500, scroll:false}); await R.at(8.5); await H(R, '#vpk'); await R.at(9.0); await ck(R, '#vpk', {ms:60}); await sleep(1500); await R.hlOff();
     await R.F.evaluate(() => { if(!document.getElementById('an-q')) anOpen(); }); await sleep(900);
     await tg(R, 'vap', ACT('Cucina a fuoco', 'Apri')); await R.F.evaluate(() => { const b = document.getElementById('vap'); b && b.scrollIntoView({block:'center', behavior:'smooth'}); }); await sleep(900); await R.move('#vap', {ms:500, scroll:false}); await R.at(15.8); await H(R, '#vap'); await R.at(17.6); await ck(R, '#vap', {ms:60}); }},
 ]),
sb('b06', 'Archivio nazionale', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => anOpen()); await sleep(700);
     await tg(R, 'vt2', OVB('Archivio nazionale')); await R.move('#vt2', {ms:350, scroll:false}); await R.at(1.2); await ck(R, '#vt2', {ms:60}); await sleep(800);
     await tg(R, 'vco', inner('^Collegato come')); await R.at(8.9); await H(R, '#vco'); await R.at(11.4); await R.hlOff(); }},
 ]),
sb('b07', 'Proporre un’attività', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(760, 520, 1400); }},
 ]),
sb('b08', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(700, 480, 1400); }},
 ]),
];
