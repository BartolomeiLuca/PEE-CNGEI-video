// Video 39: Progetto Personale, da A che punto sei alla Sezione 3
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'39s', title:'Progetto Personale: dalla Sezione 1 alla 3', caption:'PEE CNGEI · Progetto Personale'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts39.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('pp1', 0)); await sleep(4000); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'A che punto sei', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(820, 300, 900);
     const CARD = (id, rx) => tg(R, id, LP(rx, 2));
     await CARD('vc1', '^Sezione 1 · Osservazione'); await R.at(8.2); await H(R, '#vc1'); await R.at(11.5); await R.hlOff();
     await CARD('vc2', '^Sezione 2 · Obiettivi'); await R.at(11.7); await H(R, '#vc2'); await R.at(14.8); await R.hlOff();
     await CARD('vc3', '^Sezione 3 · Percorso'); await R.at(15.0); await H(R, '#vc3'); await R.at(17.9); await R.hlOff();
     await CARD('vc4', '^Sezione 4 · Verifica'); await R.at(18.1); await H(R, '#vc4'); await R.at(20.7); await R.hlOff();
     await CARD('vc5', '^Sezione 5 · Valutazione'); await R.at(20.9); await H(R, '#vc5'); await R.at(23.3); await R.hlOff();
     await tg(R, 'vco', BTN('Continua')); await R.at(24.0); await R.move('#vco', {ms:700, scroll:false}); await H(R, '#vco'); await R.at(29.0); await R.hlOff();
     await tg(R, 'vin', LP('^Gli invii$', 2)); await scr(R, 'vin'); await R.at(31.0); await H(R, '#vin'); await R.at(40.8); await R.hlOff(); await top(R); }},
 ]),
sb('b03', 'Sezione 1 · Contesto', [
  {t:0, run: async R => { await R.hlOff(); await sleep(500); await tg(R, 'vco', BTN('Continua')); await R.move('#vco', {ms:300, scroll:false}); await R.at(0.5); await ck(R, '#vco', {ms:50}); await sleep(1400);
     await tg(R, 'vis', "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Istruzioni di compilazione/i.test(s.innerText))"); await R.at(8.0); await R.move('#vis', {ms:600, scroll:false}); await R.at(12.9); await ck(R, '#vis', {ms:50}); await sleep(600); await R.at(15.9); await ck(R, '#vis', {ms:50}); await sleep(500);
     await tg(R, 'vaz', LP('^Per il tuo Progetto Personale', 1)); await R.at(16.7); await H(R, '#vaz'); await R.at(27.4); await R.hlOff();
     await tg(R, 'vn', INP('^Nome e cognome')); await R.at(28.4); await H(R, '#vn'); await R.at(30.4); await R.hlOff();
     await tg(R, 'vs', INP('^Sezione')); await R.at(30.7); await H(R, '#vs'); await R.at(31.4); await R.hlOff();
     await tg(R, 'vg', "return [...document.querySelectorAll('#main-app select')].find(s => [...s.options].some(o => o.text === 'Monogruppo'))"); await R.at(31.6); await H(R, '#vg'); await R.at(33.1); await R.hlOff();
     await R.at(33.3); await R.selOpen('#vg', {fast:true}); await R.at(34.2); await R.selHover('Monogruppo', 400); await R.at(35.4); await R.selHover('Gruppo 1', 400); await R.at(36.2); await R.selHover('Gruppo 2', 400); await R.at(37.2); await R.P.evaluate(() => ST.menuOff());
     await tg(R, 'vu', INP('^Nome dell.Unità')); await scr(R, 'vu'); await R.at(38.6); await H(R, '#vu'); await R.at(39.8); await R.hlOff();
     await tg(R, 'vt1', INP('^Totale$')); await scr(R, 'vt1'); await R.at(41.0); await H(R, '#vt1'); await R.at(42.1); await R.hlOff();
     await tg(R, 'vt2', INP('^di cui maschi')); await R.at(42.2); await H(R, '#vt2'); await R.at(43.0); await R.hlOff();
     await tg(R, 'vt3', INP('^di cui femmine')); await R.at(43.1); await H(R, '#vt3'); await R.at(43.8); await R.hlOff();
     await tg(R, 'vt4', INP('^1° anno')); await R.at(43.9); await H(R, '#vt4'); await R.at(45.6); await R.hlOff(); }},
 ]),
sb('b04', 'KOS e Occasioni osservative', [
  {t:0, run: async R => { await R.hlOff(); await go(R, 'vk', "shSub('1a','','occ')"); await top(R);
     await tg(R, 'vq1', LP('^Il gruppo osservato corrisponde', 1)); await R.at(10.9); await H(R, '#vq1'); await R.at(14.6); await R.hlOff();
     await tg(R, 'vr1', "const i = document.querySelector('#main-app input[value=si]'); return i && (i.closest('label') || i.parentElement)"); await R.at(15.6); await H(R, '#vr1'); await R.at(16.1); await R.hlOff();
     await tg(R, 'vr2', "const i = document.querySelector('#main-app input[value=parte]'); return i && (i.closest('label') || i.parentElement)"); await R.at(16.2); await H(R, '#vr2'); await R.at(16.9); await R.hlOff();
     await tg(R, 'vr3', "const i = document.querySelector('#main-app input[value=no]'); return i && (i.closest('label') || i.parentElement)"); await R.at(17.1); await H(R, '#vr3'); await R.at(17.8); await R.hlOff();
     await R.move('#vr2', {ms:500, scroll:false}); await R.at(18.6); await ck(R, '#vr2', {ms:60}); await sleep(500);
     await tg(R, 'vnt', LP('^Chi è entrato dopo', 0)); await R.at(19.3); await H(R, '#vnt'); await R.at(24.6); await R.hlOff();
     await tg(R, 'vko', "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /Percorso osservativo KOS/i.test(s.innerText))"); await scr(R, 'vko'); await R.at(26.1); await H(R, '#vko'); await R.move('#vko', {ms:600, scroll:false}); await R.at(27.6); await ck(R, '#vko', {ms:50}); await sleep(700); await R.hlOff();
     await tg(R, 'vc1', "const c = [...document.querySelectorAll('#main-app details[open] input[type=checkbox]')].filter(x => x.offsetParent); return c[0] && (c[0].closest('label') || c[0])"); await R.at(29.2); await R.move('#vc1', {ms:500, scroll:false}); await ck(R, '#vc1', {ms:60}); await sleep(500);
     await tg(R, 'vc2', "const c = [...document.querySelectorAll('#main-app details[open] input[type=checkbox]')].filter(x => x.offsetParent); return c[1] && (c[1].closest('label') || c[1])"); await R.at(30.0); await R.move('#vc2', {ms:400, scroll:false}); await ck(R, '#vc2', {ms:60}); await sleep(500);
     await tg(R, 'vtb', "return [...document.querySelectorAll('#main-app table')].find(t => t.offsetParent && /Cosa hai osservato/i.test(t.innerText))"); await scr(R, 'vtb'); await R.at(32.2); await H(R, '#vtb'); await R.at(38.8); await R.hlOff();
     await tg(R, 'vad', BTN('+ Aggiungi attività')); await scr(R, 'vad'); await R.move('#vad', {ms:500, scroll:false}); await R.at(39.8); await H(R, '#vad'); await R.at(41.4); await R.hlOff(); }},
 ]),
sb('b05', 'Sezione 1 · Scheda di osservazione', [
  {t:0, run: async R => { await R.hlOff(); await go(R, 'vp', "shSub('1b','P','')"); await top(R);
     await tg(R, 'vpo', LP('^Percorsi osservati$', 1)); await R.at(9.4); await H(R, '#vpo'); await R.at(11.5); await R.hlOff();
     await tg(R, 'vh1', "return document.querySelector('#main-app .pc-hdr')"); await R.at(12.0); await H(R, '#vh1'); await R.at(17.8); await R.hlOff();
     await R.move('#vh1', {ms:500, scroll:false}); await R.at(19.6); await ck(R, '#vh1', {ms:60}); await sleep(900);
     await tg(R, 'vsc', "return document.querySelector('#main-app .obs-scale-wrap')"); await R.at(20.8); await H(R, '#vsc'); await R.at(21.9); await R.hlOff();
     await tg(R, 'vgr', LP('^Griglia osservativa', 1)); await scr(R, 'vgr'); await R.at(22.0); await H(R, '#vgr'); await R.at(30.0); await R.hlOff();
     await tg(R, 'vf1', LP('^Focus osservativo', 0)); await R.at(32.6); await H(R, '#vf1'); await R.at(34.9); await R.hlOff();
     await tg(R, 'vf2', LP('^Comportamenti positivi emersi', 0)); await R.at(35.1); await H(R, '#vf2'); await R.at(36.9); await R.hlOff();
     await tg(R, 'vf3', LP('^Comportamenti da migliorare', 0)); await R.at(37.0); await H(R, '#vf3'); await R.at(38.2); await R.hlOff();
     await tg(R, 'vf4', LP('^Note specifiche', 0)); await R.at(38.3); await H(R, '#vf4'); await R.at(40.3); await R.hlOff();
     await R.at(40.6); await H(R, '#vgr'); await R.at(46.9); await R.hlOff();
     await tg(R, 'vnn', LP('^Attività:', 1)); await R.at(47.0); await H(R, '#vnn'); await R.at(49.9); await R.hlOff();
     await tg(R, 'vob', LP('^Obiettivi del percorso', 0)); await scr(R, 'vob'); await R.at(50.8); await H(R, '#vob'); await R.at(53.0); await R.hlOff();
     await tg(R, 'vco2', LP('^Cosa osservare', 1)); await scr(R, 'vco2'); await R.at(53.5); await H(R, '#vco2'); await R.at(56.2); await R.hlOff();
     await await R.at(58.3); await tg(R, 'vnn2', BTN('Non osservato')); await H(R, '#vnn2'); await R.at(60.4); await R.hlOff();
     await tg(R, 'vnx', BTN('Sviluppo Comunitario')); await scr(R, 'vnx'); await R.move('#vnx', {ms:500, scroll:false}); await R.at(61.1); await H(R, '#vnx'); await R.at(63.9); await R.hlOff();
     await tg(R, 'vdg', BTN('↓ Scarica griglia')); await R.move('#vdg', {ms:500, scroll:false}); await R.at(64.3); await H(R, '#vdg'); await R.at(66.9); await R.hlOff(); }},
 ]),
sb('b06', 'Lettura del gruppo', [
  {t:0, run: async R => { await R.hlOff(); await go(R, 'vl', "shSub('1c','','')"); await sleep(1500); await top(R);
     await tg(R, 'vlt', LP('^Come siamo messi', 0)); await R.at(4.6); await H(R, '#vlt'); await R.at(6.0); await R.hlOff();
     await tg(R, 'vcp', LP('^Copertura per ambito', 2)); await scr(R, 'vcp'); await R.at(8.5); await H(R, '#vcp'); await R.at(14.4); await R.hlOff(); }},
 ]),
sb('b07', 'Le priorità', [
  {t:0, run: async R => { await R.hlOff(); await go(R, 'vpr', "shSub('1d','','')"); await sleep(1000); await top(R);
     await tg(R, 'vrg', LP('^Regola PEE', 0)); await R.at(2.4); await H(R, '#vrg'); await R.at(9.0); await R.hlOff();
     await tg(R, 'vp1', LP('^Corporeità$', 1)); await R.at(13.9); await H(R, '#vp1'); await R.at(16.0); await R.hlOff();
     await tg(R, 'vp2', LP('^Comunicare$', 1)); await scr(R, 'vp2'); await R.at(16.2); await H(R, '#vp2'); await R.at(18.0); await R.hlOff();
     await tg(R, 'vp3', LP('^Sviluppo Spirituale', 0)); await scr(R, 'vp3'); await R.at(18.3); await H(R, '#vp3'); await R.at(22.2); await R.hlOff(); }},
 ]),
sb('b08', 'Sezione 2 · Obiettivi e Indicatori', [
  {t:0, run: async R => { await R.hlOff(); await go(R, 'vs2', "shPP('2')"); await top(R);
     await tg(R, 'vpa', LP('^Priorità 1 — Personale', 1)); await R.at(12.9); await H(R, '#vpa'); await R.at(18.6); await R.hlOff();
     await tg(R, 'vpb', LP('^Priorità 2 — Comunitario', 1)); await R.at(18.9); await H(R, '#vpb'); await R.at(21.8); await R.hlOff();
     await tg(R, 'vob', "return document.querySelector('#main-app .u-r')"); await R.move('#vob', {ms:600, scroll:false}); await R.at(23.7); await ck(R, '#vob', {ms:50}); await sleep(900);
     await tg(R, 'vop', "const o = document.getElementById('vob'); return o && (o.closest('details') || o.parentElement)"); await R.at(25.4); await H(R, '#vop'); await R.at(29.0); await R.hlOff();
     await tg(R, 'vb1', BTN('← Sezione 1')); await scr(R, 'vb1'); await R.at(30.2); await H(R, '#vb1'); await R.at(31.8); await R.hlOff();
     await tg(R, 'vb3', BTN('Sezione 3')); await R.at(32.0); await H(R, '#vb3'); await R.at(32.8); await R.hlOff(); }},
 ]),
sb('b09', 'Sezione 3 · Percorso Educativo', [
  {t:0, run: async R => { await R.hlOff(); await go(R, 'vs3', "shPP('3')"); await top(R);
     await tg(R, 'vce', "return document.getElementById('an-open')"); await R.at(5.3); await H(R, '#vce'); await R.at(8.6); await R.hlOff();
     await tg(R, 'vqu', LP('^Per quale obiettivo progetti', 1)); await R.at(9.8); await H(R, '#vqu'); await R.at(15.2); await R.hlOff();
     await tg(R, 'vra', "const i = document.querySelector('#main-app input[name=sez3pri]'); return i && (i.closest('label') || i.parentElement)"); await R.move('#vra', {ms:600, scroll:false}); await R.at(16.0); await ck(R, '#vra', {ms:60}); await sleep(600);
     await tg(R, 'vsp', LP('^Spunti, se ti servono', 1)); await scr(R, 'vsp'); await R.at(19.2); await H(R, '#vsp'); await R.at(25.4); await R.hlOff();
     await tg(R, 'vri', LP('^Rielaborazione\\.', 1)); await scr(R, 'vri'); await R.at(25.7); await H(R, '#vri'); await R.at(32.5); await R.hlOff();
     await tg(R, 'vph', LP('^Percorso 1 — P1', 1)); await scr(R, 'vph'); await R.move('#vph', {ms:500, scroll:false}); await R.at(33.0); await ck(R, '#vph', {ms:60}); await sleep(900);
     const RW = (id, p) => tg(R, id, "const r = [...document.querySelectorAll('#main-app table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(p) + ")); return r");
     await RW('vw1', 'Necessità educativa'); await scr(R, 'vw1'); await R.at(34.8); await H(R, '#vw1'); await R.at(36.2); await R.hlOff();
     await RW('vw2', 'Obiettivi'); await R.at(36.4); await H(R, '#vw2'); await R.at(37.3); await R.hlOff();
     await RW('vw3', 'Indicatori'); await R.at(37.4); await H(R, '#vw3'); await R.at(38.4); await R.hlOff();
     await RW('vw4', 'Strumenti'); await R.at(38.6); await H(R, '#vw4'); await R.at(41.4); await R.hlOff();
     await RW('vw5', 'Tempistiche'); await R.at(41.6); await H(R, '#vw5'); await R.at(42.3); await R.hlOff();
     await RW('vw6', 'Attività'); await R.at(42.4); await H(R, '#vw6'); await R.at(45.4); await R.hlOff();
     await tg(R, 'va1', "const l = [...document.querySelectorAll('#main-app *')].find(e => e.offsetParent && e.children.length === 0 && /^Attività 1 —/.test(e.textContent.trim())); return l && (l.closest('summary') || l.parentElement)"); await scr(R, 'va1'); await R.at(45.6); await H(R, '#va1'); await R.at(46.2); await R.F.evaluate(() => { const d = document.getElementById('va1') && document.getElementById('va1').closest('details'); if(d && !d.open) d.open = true; }); await sleep(500); await R.at(47.2); await R.hlOff();
     await tg(R, 'va2', "return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && /tipi di attività/.test(s.innerText))"); await R.at(47.3); await H(R, '#va2'); await R.at(49.2); await R.hlOff();
     await tg(R, 'va3', LP('^Lancio', 1)); await R.at(49.8); await H(R, '#va3'); await R.at(52.4); await R.hlOff();
     await tg(R, 'va4', "return document.querySelector('#main-app .att-mv')"); await R.at(52.6); await H(R, '#va4'); await R.at(54.9); await R.hlOff();
     await tg(R, 'va5', BTN('⇄ Sposta')); await R.move('#va5', {ms:500, scroll:false}); await R.at(55.0); await H(R, '#va5'); await R.at(57.3); await R.hlOff();
     await tg(R, 'va6', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && b.innerText.trim() === '×')"); await R.move('#va6', {ms:400, scroll:false}); await R.at(57.7); await H(R, '#va6'); await R.at(58.8); await R.hlOff(); }},
 ]),
sb('b10', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(700, 480, 1400); }},
 ]),
];
