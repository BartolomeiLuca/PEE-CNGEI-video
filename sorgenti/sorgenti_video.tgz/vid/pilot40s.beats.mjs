// Video 40: Progetto Personale, verifica, valutazione, invii, checklist
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'40s', title:'Progetto Personale: verifica, valutazione, invii', caption:'PEE CNGEI · Progetto Personale'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts40.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('pp1', 0)); await sleep(4000); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Sezione 4 · Verifica delle Attività', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} }); await go(R, 'vs4', "shPP('4')"); await top(R);
     await tg(R, 'vpc', LP('^Percorso 1 — P1', 0)); await R.at(15.2); await H(R, '#vpc'); await R.at(17.6); await R.hlOff();
     await tg(R, 'va1', LP('^Attività 1 — Gioco', 1)); await R.at(17.8); await H(R, '#va1'); await R.at(21.2); await R.hlOff();
     await tg(R, 'vst', "return document.querySelector('#main-app .ver-st')"); await R.at(23.5); await H(R, '#vst'); await R.at(25.0); await R.hlOff();
     await tg(R, 'vf1', TA('Aspetti positivi')); await R.move('#va1', {ms:500, scroll:false}); await R.at(24.3); await ck(R, '#va1', {ms:50}); await sleep(700); await tg(R, 'vf1', TA('Aspetti positivi')); await tg(R, 'vf2', TA('Criticità')); await tg(R, 'vf3', TA('Modifiche fatte')); await R.at(26.7); await H(R, '#vf1'); await R.at(32.4); await R.hlOff();
     await R.at(32.7); await H(R, '#vf2'); await R.at(37.5); await R.hlOff();
     await R.at(37.7); await H(R, '#vf3'); await R.at(43.8); await R.hlOff();
     await R.move('#vf1', {ms:500, scroll:false}); await R.at(44.4); await ck(R, '#vf1', {ms:50}); await TY(R, '#vf1', 'Gli Esploratori e le Esploratrici si sono divertiti e hanno collaborato bene.', 14); await sleep(300);
     await R.at(47.1); await go(R, 'vs4b', "shPP('4')"); await top(R);
     await tg(R, 'vst2', "return document.querySelector('#main-app .ver-st')"); await R.at(49.4); await H(R, '#vst2'); await R.at(51.4); await R.hlOff();
     await tg(R, 'vp2', LP('^Percorso 2 — C1', 0)); await scr(R, 'vp2'); await R.at(51.8); await H(R, '#vp2'); await R.at(55.1); await R.hlOff();
     await tg(R, 'vfa', LP('^Facoltativo · non è il percorso', 0)); await R.at(56.6); await H(R, '#vfa'); await R.at(59.7); await R.hlOff();
     await tg(R, 'vnh', BTN('Nascondi')); await R.move('#vnh', {ms:500, scroll:false}); await R.at(60.9); await H(R, '#vnh'); await R.at(63.6); await R.hlOff(); }},
 ]),
sb('b03', 'Sezione 5 · Valutazione Finale', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} }); await go(R, 'vs5', "shPP('5')"); await top(R);
     await tg(R, 'vk1', LP('^Corporeità$', 1)); await R.at(8.3); await H(R, '#vk1'); await R.at(10.8); await R.hlOff();
     await tg(R, 'vsp', SELN(0)); await scr(R, 'vsp'); await R.at(17.0); await H(R, '#vsp'); await R.at(19.6); await R.hlOff();
     await R.at(19.9); await R.selOpen('#vsp', {fast:true}); await R.at(21.9); await R.selHover('1 —', 350); await R.at(23.0); await R.selHover('3 —', 350); await R.at(24.2); await R.selHover('5 —', 350); await R.at(25.3); await R.selHover('7 —', 350); await R.at(26.3); await R.selHover('9 —', 350); await R.at(27.0); await R.selPick('#vsp', '7 — Presente', true);
     await tg(R, 'vcm', SELN(1)); await R.at(27.5); await H(R, '#vcm'); await R.at(28.4); await R.hlOff(); await R.at(28.5); await R.selOpen('#vcm', {fast:true}); await R.at(29.6); await R.selHover('Spontaneo', 350); await R.at(30.4); await R.selHover('Stimolato', 350); await R.at(31.9); await R.selHover('Non adottato', 350); await R.at(32.6); await R.selPick('#vcm', 'Stimolato', true);
     await tg(R, 'vq', TA('Osservazioni qualitative')); await R.at(33.4); await H(R, '#vq'); await R.at(36.5); await R.hlOff(); await R.move('#vq', {ms:400, scroll:false}); await R.at(36.8); await ck(R, '#vq', {ms:50}); await TY(R, '#vq', 'In pattuglia hanno confrontato altezza e passo, scherzando senza imbarazzo.', 12); await sleep(300);
     await tg(R, 'vv', TA('Hai raggiunto')); await scr(R, 'vv'); await R.at(41.1); await H(R, '#vv'); await R.at(47.5); await R.hlOff(); await R.move('#vv', {ms:400, scroll:false}); await R.at(48.0); await ck(R, '#vv', {ms:50}); await TY(R, '#vv', 'Obiettivo raggiunto in parte: riproporrei i giochi di confronto con più tempo.', 12); await sleep(300);
     await tg(R, 'vdp', LP('^Dal punto di partenza', 1)); await scr(R, 'vdp'); await R.at(51.3); await H(R, '#vdp'); await R.at(53.3); await R.hlOff();
     await tg(R, 'vpa', LP('^Partenza$', 1)); await R.at(53.6); await H(R, '#vpa'); await R.at(56.6); await R.hlOff();
     await tg(R, 'vog', SELN(2)); await R.at(57.0); await H(R, '#vog'); await R.at(58.4); await R.hlOff(); await R.at(58.5); await R.selOpen('#vog', {fast:true}); await R.at(59.5); await R.selPick('#vog', '6 — In sviluppo', true); await sleep(700);
     await tg(R, 'vca', LP('^Il cammino', 1)); await R.at(60.9); await H(R, '#vca'); await R.at(64.8); await R.hlOff();
     await tg(R, 'vk2', LP('^Comunicare$', 1)); await scr(R, 'vk2'); await R.at(66.7); await H(R, '#vk2'); await R.at(68.6); await R.hlOff();
     await tg(R, 'vfa', LP('^Facoltativo · non è il percorso', 0)); await R.at(69.5); await H(R, '#vfa'); await R.at(70.7); await R.hlOff();
     await tg(R, 'vnh', BTN('Nascondi')); await R.move('#vnh', {ms:400, scroll:false}); await R.at(70.9); await H(R, '#vnh'); await R.at(71.6); await R.hlOff(); }},
 ]),
sb('b04', 'Check-list del progetto', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} }); await go(R, 'vck', "shPP('c')"); await top(R);
     await tg(R, 'vs1', SUM('Sezioni 1–3')); await R.at(5.9); await H(R, '#vs1'); await R.at(9.0); await R.hlOff();
     await tg(R, 'vs2', SUM('Sezioni 4 e 5')); await R.at(9.3); await H(R, '#vs2'); await R.at(12.8); await R.hlOff();
     await R.move('#vs1', {ms:500, scroll:false}); await R.at(16.3); await ck(R, '#vs1', {ms:50}); await sleep(600);
     await hh(R, 'vl1', '^✓ Dati', 17.4, 19.0, 0);
     await hh(R, 'vl2', '^○ Numeri dell’Unità', 22.3, 23.4, 0);
     await hh(R, 'vl3', '^○ Occasioni osservative', 23.6, 25.0, 0);
     await hh(R, 'vl4', '^○ 3 priorità', 25.3, 27.4, 0);
     await hh(R, 'vl5', '^○ Almeno 3 attività', 27.8, 30.6, 0);
     await tg(R, 'vpm', SUM('^Promemoria per l’invio')); await scr(R, 'vpm'); await R.move('#vpm', {ms:500, scroll:false}); await R.at(46.9); await H(R, '#vpm'); await R.at(47.3); await ck(R, '#vpm', {ms:50}); await sleep(600); await R.at(52.3); await R.hlOff();
     await tg(R, 'vd1', BTN('↓ Scheda Sezioni 1–3')); await scr(R, 'vd1'); await R.at(53.6); await H(R, '#vd1'); await R.at(56.5); await R.hlOff();
     await tg(R, 'vd2', BTN('↓ Scheda completa')); await R.at(56.6); await H(R, '#vd2'); await R.at(60.0); await R.hlOff();
     await tg(R, 'vd3', BTN('↓ Dati dell')); await R.at(60.1); await H(R, '#vd3'); await R.at(62.2); await R.hlOff(); }},
 ]),
sb('b05', 'Invio del Progetto Personale', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} }); await go(R, 'vin', "shPP('i')"); await top(R);
     await hh(R, 'vi1', 'Comunicazione di avvio', 11.3, 13.5);
     await tg(R, 'vb1', BTN('Prepara la mail di avvio')); await R.move('#vb1', {ms:500, scroll:false}); await R.at(14.0); await H(R, '#vb1'); await R.at(20.5); await R.hlOff();
     await tg(R, 'vc1', CB(0)); await R.move('#vc1', {ms:500, scroll:false}); await R.at(21.5); await H(R, '#vc1'); await R.at(22.3); await ck(R, '#vc1', {ms:50}); await R.at(23.0); await R.hlOff();
     await hh(R, 'vi2', 'Presa in carico', 23.6, 25.4);
     await tg(R, 'vc2', CB(1)); await R.move('#vc2', {ms:500, scroll:false}); await R.at(28.1); await H(R, '#vc2'); await R.at(29.2); await ck(R, '#vc2', {ms:50}); await R.at(29.9); await R.hlOff();
     await hh(R, 'vi3', 'Sviluppo con il Capo Gruppo mentore', 30.4, 33.1);
     await tg(R, 'vcg', "return document.getElementById('it-cg')"); await scr(R, 'vcg'); await R.at(34.3); await H(R, '#vcg'); await R.at(38.9); await R.hlOff(); await R.at(39.1); await R.selOpen('#vcg', {fast:true}); await R.at(39.3); await R.selHover('Sì', 350); await R.at(40.3); await R.selHover('Non ancora', 350); await R.at(40.9); await R.selPick('#vcg', 'Sì', true);
     await hh(R, 'vi4', 'Prima consegna', 41.4, 45.5);
     await tg(R, 'vm2', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && (b.getAttribute('onclick') || '').includes('parziale') && /Prepara/.test(b.innerText))"); await R.move('#vm2', {ms:400, scroll:false}); await R.at(45.7); await H(R, '#vm2'); await R.at(46.9); await R.hlOff();
     await tg(R, 'vw2', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /Scarica il Word \\(Sezioni/.test(b.innerText))"); await R.move('#vw2', {ms:400, scroll:false}); await R.at(47.0); await H(R, '#vw2'); await R.at(48.5); await R.hlOff();
     await hh(R, 'vi5', 'Riscontro', 48.6, 50.8);
     await tg(R, 'vrs', BTN('+ Aggiungi il riscontro')); await scr(R, 'vrs'); await R.move('#vrs', {ms:500, scroll:false}); await R.at(51.3); await H(R, '#vrs'); await R.at(53.2); await R.hlOff(); await R.at(53.5); await ck(R, '#vrs', {ms:50}); await sleep(800);
     await tg(R, 'vrc', "return document.querySelector('#main-app .pp-risc')"); await R.at(54.3); await H(R, '#vrc'); await R.at(58.5); await R.hlOff();
     await hh(R, 'vi6', 'Consegna finale', 59.0, 62.7);
     await hh(R, 'vi7', 'Approvazione finale', 62.9, 67.4);
     await tg(R, 'vic', SUM('^I Responsabili dei Centri')); await scr(R, 'vic'); await R.at(67.6); await H(R, '#vic'); await R.move('#vic', {ms:500, scroll:false}); await R.at(69.0); await ck(R, '#vic', {ms:50}); await sleep(700); await R.at(72.1); await R.hlOff(); }},
 ]),
sb('b06', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(700, 480, 1400); }},
 ]),
];
