// Video 41: osservazione degli adulti (staff)
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'41s', title:'Osservazione degli adulti: il mio staff', caption:'PEE CNGEI · Staff e Capo Gruppo'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts41.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4000); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const ST_ = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-card, #main-app .st-note, #main-app .st-ct')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";
const clk = async (R, id, t) => { await R.move('#' + id, {ms:500, scroll:false}); if(t !== undefined) await R.at(t); await ck(R, '#' + id, {ms:50}); await sleep(700); };
const oss = i => "return [...document.querySelectorAll('#main-app select.obs-select')].filter(e => e.offsetParent)[" + i + "]";
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Il mio staff', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} });
     await tg(R, 'ssg', "return [...document.querySelectorAll('#sh-side .sh-gh')].find(b => /osservare/i.test(b.innerText))"); await R.move('#ssg', {ms:400, scroll:false}); await R.at(0.3); await ck(R, '#ssg', {ms:50}); await sleep(600); await tg(R, 'ss0', SB("shStaffPage")); await R.F.evaluate(() => { const e = document.getElementById('ss0'); e && e.scrollIntoView({block:'center'}); }); await R.at(0.4); await R.move('#ss0', {ms:500, scroll:false}); await R.at(2.2); await H(R, '#ss0'); await R.at(2.7); await ck(R, '#ss0', {ms:50}); await R.hlOff(); await sleep(1500); await dq(R);
     
     await tg(R, 'sb1', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Osservazione/.test(b.innerText.trim()))");
     await tg(R, 'sb2', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Riepilogo/.test(b.innerText.trim()))");
     await tg(R, 'sb3', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Percorso formativo/.test(b.innerText.trim()))");
     await tg(R, 'sbar', "const a = [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Osservazione delle persone/.test(b.innerText.trim())); const z = [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Percorso formativo/.test(b.innerText.trim())); let e = a; while(e && !e.contains(z)) e = e.parentElement; return e"); await R.at(6.9); await H(R, '#sbar'); await R.at(9.0); await R.hlOff(); await R.at(9.1); await H(R, '#sb1'); await R.at(10.75); await R.hlOff();
     await R.at(10.8); await H(R, '#sb2'); await R.at(12.35); await R.hlOff(); await R.at(12.5); await H(R, '#sb3'); await R.at(14.0); await R.hlOff();
     await tg(R, 'sdsc', SUM('Prima di osservare gli adulti')); await scr(R, 'sdsc');
     await R.at(20.2); await H(R, '#sdsc');
     const op = await R.F.evaluate(() => { const d = document.getElementById('sdsc'); return d && d.parentElement && d.parentElement.open; }); 
     await R.move('#sdsc', {ms:500, scroll:false}); await R.at(22.0); if(!op){ await ck(R, '#sdsc', {ms:50}); await sleep(800); }
     await R.at(23.0); await R.hlOff();
     for (const [i, a, b] of [[0, 23.8, 25.9], [1, 30.3, 31.6], [2, 36.3, 38.0], [3, 43.9, 46.0]]) { await tg(R, 'sh' + i, "return [...document.querySelectorAll('#main-app .sh-disc-in h4')][" + i + "]"); await sc(R, 'sh' + i); await R.at(a); await H(R, '#sh' + i); await R.at(b + 0.5); await R.hlOff(); }
  }},
 ]),
sb('b03', 'Auto osservazione e aggiungi persona', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(600);
     await tg(R, 'sau', SD('Auto osservazione')); await scr(R, 'sau'); await R.at(1.2); await H(R, '#sau'); await R.at(8.0); await R.hlOff();
     await tg(R, 'sli', "return document.getElementById('st-side')"); await R.at(14.5); await H(R, '#sli'); await R.at(16.2); await R.hlOff();
     await tg(R, 'sad', "return document.querySelector('#main-app .st-add')"); await R.move('#sad', {ms:500, scroll:false}); await R.at(16.5); await H(R, '#sad'); await R.at(17.3); await ck(R, '#sad', {ms:50}); await R.hlOff(); await sleep(1800); for(let k = 0; k < 6 && !(await R.F.evaluate(() => !!document.getElementById('st-pick'))); k++){ await R.F.evaluate(() => { try{ renderStaffPhase1(); }catch(e){} }); await sleep(700); console.log('DBG3', await R.F.evaluate(() => JSON.stringify({free:stFreeRows().length, pick:!!document.getElementById('st-pick'), add:_stAdd}))); } if(!(await R.F.evaluate(() => !!document.getElementById('st-pick')))){ console.log('fallback unit row'); console.log('DBG2', await R.F.evaluate(() => JSON.stringify({free:stFreeRows().length, rows:(ST_UNIT.rows||[]).length, mem:STAFF_MEMBERS, add:(typeof _stAdd!=='undefined'?_stAdd:'?'), card:(document.querySelector('#main-app .st-addcard')||{innerText:'none'}).innerText.slice(0,200)}))); await R.F.evaluate(() => { try{ autoProfile.link = null; [...(ST_UNIT.rows || []), ...(((scheda.pp || {}).staffTab) || [])].forEach(r => { if(/Marco Neri/.test(r.nome)) r.mail = 'anna.verdi@x.it'; }); try{ stUnitKick(true); }catch(e){} window.stFreeRows = () => (ST_UNIT.rows || []).map((r, i) => ({r, i})).filter(({r}) => !STAFF_MEMBERS.includes(r.nome)); renderStaffPhase1(); }catch(e){} }); await sleep(700); }
     await tg(R, 'spk', "return document.getElementById('st-pick')"); await scr(R, 'spk'); await R.at(18.2); await H(R, '#spk'); await R.at(21.6); await R.hlOff();
     await R.at(22.0); await R.selOpen('#spk', {fast:true}); await R.at(23.2); await R.selHover('Marco Neri', 400); await R.at(23.9); await R.selPick('#spk', (R.menu || []).find(t => /Marco Neri/.test(t)) || 'Marco Neri', true); await R.F.evaluate(() => { const e = document.getElementById('st-pick'); if(e && e.value === ''){ e.value = '0'; e.dispatchEvent(new Event('change', {bubbles:true})); } }); await sleep(400);
     await tg(R, 'sag', "return document.querySelector('#main-app .st-addcard .st-row button.btn-primary')"); await R.move('#sag', {ms:500, scroll:false}); await R.at(24.4); await H(R, '#sag'); await R.at(25.0); await R.hlOff(); await R.at(25.1); await RS(R); await R.F.evaluate(() => { const e = document.getElementById('st-pick'); if(e){ const o = [...e.options].find(x => /Marco Neri/.test(x.text)); if(o) e.value = o.value; } }); await ck(R, '#sag', {ms:50}); await sleep(700); if(!(await R.F.evaluate(() => STAFF_MEMBERS.includes('Marco Neri')))){ console.log('fallback Marco'); await R.F.evaluate(() => { const r = (ST_UNIT.rows || []).find(x => /Marco Neri/.test(x.nome || '')); if(r){ const n = stAddRow(r); if(n) stAddedGo(n); } }); await sleep(1200); }
     await tg(R, 'sad2', "return document.querySelector('#main-app .st-add')"); await sc(R, 'sad2'); await R.move('#sad2', {ms:350, scroll:false}); await ck(R, '#sad2', {ms:50}); await sleep(300);
     await tg(R, 'smn', "return document.getElementById('new-member-input')"); await sc(R, 'smn'); await sleep(250); await R.at(27.2); await H(R, '#smn'); await R.at(28.8); await R.hlOff();
     await tg(R, 'sup', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /Aggiorna dall/.test(b.innerText))"); await R.move('#sup', {ms:500, scroll:false}); await R.at(29.2); await H(R, '#sup'); await R.at(32.8); await R.hlOff();
     await tg(R, 'sad3', "return document.querySelector('#main-app .st-add')"); await scr(R, 'sad3'); await ck(R, '#sad3', {ms:50}); await sleep(900);
     await tg(R, 'san', SD('Marco Neri')); await scr(R, 'san'); await R.at(34.0); await H(R, '#san'); await R.at(38.0); await R.hlOff(); }},
 ]),
sb('b04', 'Profilo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'san2', SD('Marco Neri')); await R.move('#san2', {ms:500, scroll:false}); await R.at(0.2); await ck(R, '#san2', {ms:50}); await sleep(700);
     await tg(R, 'pgs', GS('Profilo')); await tg(R, 'pgrid', "return document.querySelector('#main-app .st-grid')"); await R.at(3.0); await H(R, '#pgrid'); await R.at(8.0); await R.hlOff();
     await tg(R, 'pnt', "return document.querySelector('#main-app .st-note.link')"); await R.at(8.5); await H(R, '#pnt'); await R.at(11.8); await R.hlOff();
     await tg(R, 'pes', "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent && [...e.options].some(o => /Bassa/.test(o.text)))[0]"); await scr(R, 'pes'); await R.at(12.9); await H(R, '#pes'); await R.at(15.0); await R.hlOff();
     await R.at(15.1); await R.selOpen('#pes', {fast:true}); await R.at(16.4); await R.selHover('Bassa', 400); await R.at(18.3); await R.selHover('Media', 400); await R.at(20.0); await R.selHover('Alta', 400); await R.at(21.6); await R.selPick('#pes', (R.menu || []).find(t => /^Media/.test(t)) || 'Media', true); await sleep(400);
     await tg(R, 'prm', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /Rimuovi dallo staff/.test(b.innerText))"); await scr(R, 'prm'); await R.move('#prm', {ms:500, scroll:false}); await R.at(23.2); await H(R, '#prm'); await R.at(25.8); await R.hlOff();
     await tg(R, 'pav', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /^Avanti/.test(b.innerText.trim()))"); await R.move('#pav', {ms:500, scroll:false}); await R.at(26.7); await H(R, '#pav'); await R.at(27.6); await ck(R, '#pav', {ms:50}); await R.hlOff(); await sleep(900); }},
 ]),
sb('b05', 'Scheda di osservazione', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(500);
     await tg(R, 'ocat', "return document.querySelector('#main-app select.obs-select')"); 
     await tg(R, 'ost', "return document.querySelector('#main-app .st-main')"); await R.at(2.6); await H(R, '#ost'); await R.at(8.5); await R.hlOff();
     await tg(R, 'o0', oss(0)); await scr(R, 'o0'); await R.move('#o0', {ms:400, scroll:false}); await R.at(10.8); await H(R, '#o0'); await R.at(12.0); await R.hlOff();
     await R.at(12.2); await R.selOpen('#o0', {fast:true}); await R.at(12.6); await R.selHover('1 —', 300); await R.at(13.5); await R.selHover('3 —', 300); await R.at(14.9); await R.selHover('4 —', 300); await R.at(15.9); await R.selHover('6 —', 300); await R.at(17.2); await R.selHover('7 —', 300); await R.at(19.6); await R.selHover('9 —', 300); await R.at(21.6); await R.selHover('10', 300); await R.at(23.5); await R.selHover('Non osservato', 300);
     await R.at(25.4); await R.selPick('#o0', (R.menu || []).find(t => /^3 —/.test(t)) || '3', true); await sleep(300);
     for (const [i, v, t] of [[1, '6', 31.8], [2, '5', 34.2], [3, '4', 36.6]]) { await tg(R, 'o' + i, oss(i)); await R.move('#o' + i, {ms:400, scroll:false}); await R.at(t - 0.6); await H(R, '#o' + i); await R.at(t); await R.selOpen('#o' + i, {fast:true}); await R.at(t + 0.6); await R.selPick('#o' + i, (R.menu || []).find(x => new RegExp('^' + v + ' —').test(x)) || v, true); await R.hlOff(); await sleep(250); }
     await R.at(41.5); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} });
     await tg(R, 'oc', "return document.querySelector('#main-app .obs-card, #main-app [onclick*=toggleCard]')"); await R.move('#oc', {ms:500, scroll:false}); await R.at(43.4); await H(R, '#oc'); await R.at(44.2); await ck(R, '#oc', {ms:50}); await R.hlOff(); await sleep(1000);
     await R.at(48.0); await tg(R, 'ocn', SD('Marco Neri')); await scr(R, 'ocn'); await R.at(48.6); await H(R, '#ocn'); await R.at(50.0); await R.hlOff(); }},
 ]),
sb('b06', 'Lettura individuale', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} }); await R.F.evaluate(() => stGo('let')); await sleep(1500); await top(R); 
     await tg(R, 'lh', "return document.querySelector('#main-app .st-intro')"); await scr(R, 'lh'); await R.at(1.0); await H(R, '#lh'); await R.at(8.0); await R.hlOff();
     await tg(R, 'lf', "const c = [...document.querySelectorAll('#main-app [id^=indicazione-wrap] *')].filter(x => x.offsetParent && /punti di forza/i.test(x.textContent)); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; return e && e.parentElement"); await scr(R, 'lf'); await R.at(8.6); await H(R, '#lf'); await R.at(10.8); await R.hlOff();
     await tg(R, 'ls', LP('sviluppo formativo|aree di sviluppo', 1)); await scr(R, 'ls'); await R.at(10.9); await H(R, '#ls'); await R.at(12.4); await R.hlOff();
     await tg(R, 'li', LP('interpretativ', 1)); await scr(R, 'li'); await R.at(12.6); await H(R, '#li'); await R.at(16.8); await R.hlOff();
     await tg(R, 'lb', "const c = [...document.querySelectorAll('#main-app [id^=indicazione-wrap] *')].filter(x => x.offsetParent && /Brave space/i.test(x.textContent)); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; return e && e.parentElement"); await scr(R, 'lb'); await R.at(17.8); await H(R, '#lb'); await R.at(24.6); await R.hlOff(); }},
 ]),
sb('b07', 'Evoluzione', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => stGo('evo')); await sleep(1500); await tg(R, 'etl', "return document.getElementById('tl-note-input') && document.getElementById('tl-note-input').closest('.st-card, .card, div')"); await scr(R, 'etl'); await R.at(1.0); await H(R, '#etl'); await R.at(4.0); await R.hlOff();
     await tg(R, 'ed', "return document.getElementById('tl-date-input')"); await R.at(6.2); await H(R, '#ed'); await R.at(6.9); await R.hlOff();
     await tg(R, 'en', "return document.getElementById('tl-note-input')"); await R.at(7.0); await H(R, '#en'); await R.at(7.9); await R.hlOff();
     await tg(R, 'ep', "return [...document.querySelectorAll('#main-app select[id^=tl-obs-]')].filter(e => e.offsetParent)[0]"); await R.at(8.0); await H(R, '#ep'); await R.at(9.0); await R.hlOff();
     await R.move('#en', {ms:500, scroll:false}); await R.at(11.8); await ck(R, '#en', {ms:50}); await TY(R, '#en', 'Ha guidato il gioco di apertura della riunione di staff.', 6); await sleep(300);
     await R.move('#ep', {ms:500, scroll:false}); await R.at(12.4); await R.selOpen('#ep', {fast:true}); await R.at(13.0); await R.selPick('#ep', (R.menu || []).find(t => /^6 —/.test(t)) || '6', true); await sleep(400);
     await tg(R, 'es', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /Salva lo scatto/.test(b.innerText))"); await sc(R, 'es'); await sleep(300); await R.move('#es', {ms:250, scroll:false}); await R.at(14.4); await H(R, '#es'); await R.at(15.0); await RS(R); await ck(R, '#es', {ms:50}); await R.hlOff(); await sleep(1200);
     await tg(R, 'ecs', "return [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && /Guidato|guidato il gioco/.test(e.textContent))[0]"); await scr(R, 'ecs'); await R.at(16.5); await H(R, '#ecs'); await R.at(18.6); await R.hlOff(); }},
 ]),
sb('b08', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => stEmbGo(2)); await sleep(1800); await top(R);
     await tg(R, 'rt', LP('Come siamo messi', 1)); await R.at(0.8); await H(R, '#rt'); await R.at(3.4); await R.hlOff();
     await tg(R, 'rm', "return document.querySelector('#main-app .rie-radar')"); await R.at(3.8); await H(R, '#rm'); await R.at(10.6); await R.hlOff();
     await tg(R, 'rc', "return document.querySelector('#main-app .rie-radar-hdr')"); await R.at(11.2); await H(R, '#rc'); await R.at(15.8); await R.hlOff();
     await tg(R, 'rp', "const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && /Osservazione ancora in corso|Segna almeno \\d+ percorsi/.test(x.textContent)); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; while(e && e.parentElement && e.getBoundingClientRect().height < 70) e = e.parentElement; return e"); await scr(R, 'rp'); await R.at(16.2); await H(R, '#rp'); await R.at(21.0); await R.hlOff();
     await R.at(24.3); await tg(R, 'ram', LP('ambito più scoperto', 1)); await scr(R, 'ram'); await R.at(25.0); await H(R, '#ram'); await R.at(26.6); await R.hlOff();
     await tg(R, 'rle', LP('letture dello staff', 1)); await scr(R, 'rle'); await R.at(26.8); await H(R, '#rle'); await R.at(30.8); await R.hlOff();
     await top(R); await tg(R, 'rpf', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /Percorso formativo/.test(b.innerText))"); await R.move('#rpf', {ms:600, scroll:false}); await R.at(31.7); await H(R, '#rpf'); await R.at(36.0); await R.hlOff(); }},
 ]),
sb('b09', 'Ricapitolando', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(700, 480, 1400); }},
 ]),
];
