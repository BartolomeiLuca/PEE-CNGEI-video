// Video 42: Eventi per gli adulti
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'42s', title:'Eventi per gli adulti: uscite e bivacchi dello staff', caption:'PEE CNGEI · Staff e Capo Gruppo'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts42.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4000); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const TB = async (R, k, t, tb) => { await CS(R, 'tb' + k.replace(/\W/g,''), "#main-app [onclick=\"uscTab('" + k + "')\"]"); await scr(R, 'tb' + k.replace(/\W/g,'')); await R.at(t); await R.move('#tb' + k.replace(/\W/g,''), {ms:450, scroll:false}); await H(R, '#tb' + k.replace(/\W/g,'')); await sleep(300); await ck(R, '#tb' + k.replace(/\W/g,''), {ms:50}); await R.hlOff(); await sleep(500); };
const TBf = async (R, k, t) => { const id = 'tf' + k.replace(/\W/g,''); await CS(R, id, "#main-app [onclick=\"uscTab('" + k + "')\"]"); await R.at(t); await R.move('#' + id, {ms:250, scroll:false}); await ck(R, '#' + id, {ms:30}); await R.F.evaluate(k => { try{ if(String(USC_TAB) !== k) uscTab(k); }catch(e){} }, k); await sleep(250); };
const dtSet = (R, id, v) => R.F.evaluate(([i, v]) => { const e = document.getElementById(i); if(e){ e.value = v; e.dispatchEvent(new Event('input', {bubbles:true})); e.dispatchEvent(new Event('change', {bubbles:true})); } }, [id, v]);
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Eventi per gli adulti', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} });
     await R.at(3.4); await tg(R, 'ss0', SB("shSec('usc')")); await R.move('#ss0', {ms:500, scroll:false}); await R.at(4.8); await H(R, '#ss0'); await R.at(5.7); await ck(R, '#ss0', {ms:50}); await R.hlOff(); await sleep(1500); await top(R);
     await tg(R, 'pti', LP('Uscite e bivacchi dello staff', 0)); await HL(R, 'pti', 7.0, 9.8);
     await tg(R, 'pde', LP('Preparate insieme le uscite', 0)); await HL(R, 'pde', 10.2, 17.9);
     await tg(R, 'pbx', LP('mette insieme momenti', 1)); await scr(R, 'pbx'); await HL(R, 'pbx', 18.6, 27.9);
     await CS(R, 'pca', "#main-app [onclick='anOpen()']"); await scr(R, 'pca'); await HL(R, 'pca', 28.2, 34.2);
     await CS(R, 'pc0', "#main-app [onclick=\"uscOpen('e1')\"]"); await scr(R, 'pc0'); await HL(R, 'pc0', 35.6, 38.9);
     await CS(R, 'pc1', "#main-app [onclick=\"uscOpen('e2')\"]"); await HL(R, 'pc1', 39.9, 43.9);
     await CS(R, 'pc2', "#main-app [onclick=\"uscOpen('e3')\"]"); await HL(R, 'pc2', 44.4, 49.9);
     await R.at(50.2); await H(R, '#pc0'); await sleep(500); await R.hlOff(); }},
 ]),
sb('b03', 'Creare un evento', [
  {t:0, run: async R => { await R.hlOff();
     await CS(R, 'nn', "#main-app .usc-cardnew"); await scr(R, 'nn'); await R.move('#nn', {ms:500, scroll:false}); await R.at(1.9); await H(R, '#nn'); await R.at(2.6); await ck(R, '#nn', {ms:50}); await R.hlOff(); await sleep(1200);
     await CS(R, 'nt', "#usc-new-t"); await scr(R, 'nt'); await R.move('#nt', {ms:400, scroll:false}); await R.at(4.0); await ck(R, '#nt', {ms:50}); await TY(R, '#nt', 'Formazione sul Metodo', 20);
     await CS(R, 'nd1', "#usc-new-d1"); await R.move('#nd1', {ms:500, scroll:false}); await R.at(8.4); await H(R, '#nd1'); await dtSet(R, 'nd1', '2027-01-23'); await R.at(10.9); await R.hlOff();
     await CS(R, 'nd2', "#usc-new-d2"); await R.move('#nd2', {ms:500, scroll:false}); await HL(R, 'nd2', 11.5, 15.8);
     for (const [k, a, b] of [['sede', 17.6, 19.9], ['giorno', 20.1, 21.6], ['bivacco', 21.8, 23.9], ['campo', 24.1, 26.0]]) { await CS(R, 'nf' + k, "[onclick=\"uscNewSel('" + k + "')\"]"); await HL(R, 'nf' + k, a, b); }
     await CS(R, 'nfg', "[onclick=\"uscNewSel('giorno')\"]"); await RS(R); await R.move('#nfg', {ms:500, scroll:false}); await R.at(30.1); await ck(R, '#nfg', {ms:50}); await sleep(300);
     await tg(R, 'npp', LP('partecipanti partono dai membri', 0)); await HL(R, 'npp', 31.6, 35.9);
     await CS(R, 'ncr', "[onclick='uscCreate()']"); await R.move('#ncr', {ms:500, scroll:false}); await R.at(35.9); await H(R, '#ncr'); await sleep(500); await RS(R); await ck(R, '#ncr', {ms:50}); await R.hlOff(); await sleep(1500); }},
 ]),
sb('b04', "Dentro l'evento", [
  {t:0, run: async R => { await R.hlOff(); await top(R); await sleep(400);
     await CS(R, 'm0', "#main-app select.usc-msel"); await R.move('#m0', {ms:500, scroll:false}); await R.at(2.0); await H(R, '#m0'); await R.at(7.6); await R.hlOff();
     await tg(R, 'm1', "return [...document.querySelectorAll('#main-app select.usc-msel')].find(s => [...s.options].some(o => /Attività formativa/.test(o.text)))"); await R.move('#m1', {ms:500, scroll:false}); await R.at(8.2); await H(R, '#m1'); await R.at(8.6); await R.hlOff();
     await R.selOpen('#m1', {fast:true}); await R.at(10.3); await R.selHover('Attività formativa', 300); await R.at(11.5); await R.selHover('Riunione di staff', 300); await R.at(12.7); await R.selHover('Pit stop', 300); await R.at(13.7); await R.selHover('Riunione con i genitori', 300); await R.at(15.1); await R.selHover('Uscita di staff', 300); await R.at(16.4); await R.selHover('Bivacco di staff', 300); await R.at(18.1); await R.selHover('Altro', 300); await R.at(19.8); await R.selPick('#m1', (R.menu || []).find(t => /^Attività formativa/.test(t)) || 'Attività formativa', true); await sleep(300);
     const tiles = [["spesa", 25.0, 25.7], ["quota", 25.8, 26.9], ["mat", 27.2, 27.9], ["pasti", 28.0, 29.4], ["mod", 29.5, 30.7]];
     for (const [k, a, b] of tiles) { await CS(R, 'ti' + k, "#main-app button.usc-tile[onclick*=\"USC_TILE=USC_TILE==='" + k + "'\"]"); await HL(R, 'ti' + k, a, b); }
     await tg(R, 'mrs', LP('Programma riservato allo staff', 1)); await HL(R, 'mrs', 34.4, 41.0); }},
 ]),
sb('b05', 'La giornata', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} });
     await tg(R, 'tt', LP('La giornata è vuota', 1)); await scr(R, 'tt'); await HL(R, 'tt', 1.8, 5.2);
     for (const [k, a, b] of [['tipo', 5.6, 6.5], ['hike', 6.7, 7.6], ['arrivo', 7.9, 8.4], ['rientro', 8.5, 9.2]]) { await CS(R, 'sc' + k, "[onclick=\"uscSchema(1,'" + k + "')\"]"); await HL(R, 'sc' + k, a, b); }
     await R.move('#sctipo', {ms:500, scroll:false}); await R.at(9.9); await ck(R, '#sctipo', {ms:50}); await sleep(1200);
     await tg(R, 'ttb', LP('Programma di sabato', 1)); await scr(R, 'ttb'); await HL(R, 'ttb', 11.2, 16.0);
     await CS(R, 'pi0', "#main-app .usc-pi"); await tg(R, 'pal', "const p = document.querySelector('#main-app .usc-pi'); return p && p.parentElement"); await scr(R, 'pal'); await HL(R, 'pal', 17.0, 31.5);
     await CS(R, 'pif', "#main-app [onclick='uscBlkAdd(4)']"); await R.move('#pif', {ms:500, scroll:false}); await R.at(32.2); await H(R, '#pif'); await sleep(300); await ck(R, '#pif', {ms:50}); await R.hlOff(); await sleep(1500);
     await tg(R, 'ttc', LP('Programma di sabato', 1)); await scr(R, 'ttc'); await R.at(36.8); await H(R, '#ttc'); await R.at(41.6); await R.hlOff(); }},
 ]),
sb('b06', 'I moduli', [
  {t:0, run: async R => { await R.hlOff(); await TB(R, 'm:chi', 1.2);
     await tg(R, 'cp', LP('Chi partecipa', 1)); await scr(R, 'cp'); await HL(R, 'cp', 2.9, 5.4);
     await tg(R, 'ca', LP('\\+ Altra persona', 0)); await HL(R, 'ca', 5.8, 8.2);
     await tg(R, 'cd', LP('Quanto dura', 1)); await HL(R, 'cd', 8.7, 12.7);
     await tg(R, 'ci', LP('Altri incarichi', 1)); await scr(R, 'ci'); await HL(R, 'ci', 13.1, 18.6);
     await TB(R, 'pasti', 18.9); await TB(R, 'm:costi', 22.3); await TB(R, 'm:circ', 25.0);
     await TBf(R, 'm:sic', 30.3); await TBf(R, 'm:ben', 31.2); await TBf(R, 'm:pb', 32.6);
     await TBf(R, 'm:obs', 34.4); await TBf(R, 'm:scatto', 35.1); await TBf(R, 'm:energy', 35.8); await TBf(R, 'm:casa', 36.9);
     await CS(R, 'tad', "#main-app [onclick='USC_ADDMOD=!USC_ADDMOD;uscRe()']"); await scr(R, 'tad'); await R.move('#tad', {ms:500, scroll:false}); await R.at(41.2); await H(R, '#tad'); await sleep(500); await ck(R, '#tad', {ms:50}); await R.hlOff(); await sleep(1200); }},
 ]),
sb('b07', 'Esporta', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { USC_ADDMOD = false; uscRe(); }); await sleep(600); await top(R);
     await tg(R, 'ex', "return document.querySelector('#main-app summary.usc-btn')"); await scr(R, 'ex'); await R.move('#ex', {ms:500, scroll:false}); await R.at(1.5); await H(R, '#ex'); await sleep(300); await ck(R, '#ex', {ms:50}); await R.hlOff(); await sleep(500);
     await tg(R, 'exm', "const d = document.querySelector('#main-app details[open]'); return d"); await R.at(2.9); await H(R, '#exm'); await R.at(12.4); await R.hlOff(); await ck(R, '#ex', {ms:50}); await sleep(400);
     await tg(R, 'xl', LP('Excel', 0)); await scr(R, 'xl'); await HL(R, 'xl', 12.9, 16.0);
     await CS(R, 'tu', "#main-app [onclick='uscHome()']"); await scr(R, 'tu'); await R.move('#tu', {ms:500, scroll:false}); await R.at(17.1); await H(R, '#tu'); await R.at(18.8); await ck(R, '#tu', {ms:50}); await R.hlOff(); await sleep(1500);
     await tg(R, 'nw', "return [...document.querySelectorAll('#main-app [onclick^=\"uscOpen\"]')].find(e => /Formazione sul Metodo/.test(e.innerText))"); await scr(R, 'nw'); await HL(R, 'nw', 19.8, 22.0);
     await R.move('#nw', {ms:500, scroll:false}); await ck(R, '#nw', {ms:50}); await sleep(900); await R.F.evaluate(() => { const e = document.getElementById('nw'); if(e && document.querySelector('#main-app .usc-cardnew')) e.click(); }); await sleep(900);
     await CS(R, 'del', "#main-app [onclick='uscDel()']"); await scr(R, 'del'); await HL(R, 'del', 22.8, 25.6); }},
 ]),
sb('b08', 'Ricapitolando', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(700, 480, 1400); }},
 ]),
];
