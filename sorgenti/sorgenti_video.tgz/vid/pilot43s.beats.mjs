// Video 43: Capo Gruppo
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'43s', title:'Capo Gruppo: Capi Unità e Check degli adulti', caption:'PEE CNGEI · Staff e Capo Gruppo'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts43.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4000); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'I miei Capi Unità', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => goPhaseInternal(1)); await sleep(1200);
     await tg(R, 'ss0', SB("goPhase(1)")); await R.move('#ss0', {ms:500, scroll:false}); await R.at(2.6); await H(R, '#ss0'); await R.at(3.4); await ck(R, '#ss0', {ms:50}); await R.hlOff(); await sleep(900); await top(R);
     await tg(R, 'gn', LF('^Nome del gruppo$', 0, 2)); await HL(R, 'gn', 5.6, 10.0);
     await tg(R, 'sli', "return document.getElementById('st-side')"); await scr(R, 'sli'); await R.at(10.1); await H(R, '#sli'); await R.at(19.0); await R.hlOff();
     await tg(R, 'smn', SD('Marco Neri')); await R.move('#smn', {ms:500, scroll:false}); await R.at(19.4); await H(R, '#smn'); await sleep(300); await ck(R, '#smn', {ms:50}); await R.hlOff(); await sleep(900); await top(R);
     for (const [k, a, b] of [['prof', 23.4, 24.2], ['oss', 24.3, 25.7], ['let', 25.8, 27.0], ['evo', 27.1, 28.3]]) { await R.at(a); await R.F.evaluate(k => stGo(k), k); await sleep(500); await top(R); await tg(R, 'gm', "return document.querySelector('#main-app .st-main')"); await H(R, '#gm'); await R.at(b); await R.hlOff(); }
     await R.at(34.8); await R.F.evaluate(() => stGo('oss')); await sleep(1500);
     for (const [rx, a, b] of [['Sviluppo Personale', 39.0, 39.8], ['Sviluppo Comunitario', 39.8, 40.7], ['Sviluppo Spirituale', 40.7, 41.5]]) { await tg(R, 'am' + rx.slice(-3), LEAF('^' + rx + '$', 0, 1)); await scr(R, 'am' + rx.slice(-3)); await HL(R, 'am' + rx.slice(-3), a, b); }
     await R.hlOff(); }},
 ]),
sb('b03', 'Lettura dei Capi Unità', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'ss2', SB("goPhase(2)")); await R.move('#ss2', {ms:500, scroll:false}); await R.at(0.3); await H(R, '#ss2'); await sleep(300); await ck(R, '#ss2', {ms:50}); await R.hlOff(); await sleep(1200); await dq(R); await sleep(800); await top(R);
     await tg(R, 'rt', LF('^Come siamo messi come staff', 0, 0)); await HL(R, 'rt', 2.5, 5.9);
     await tg(R, 'rd', LF('^Fotografia dei percorsi', 0, 0)); await HL(R, 'rd', 6.1, 14.8);
     await tg(R, 'rc', LF('^Copertura per ambito$', 0, 1)); await scr(R, 'rc'); await HL(R, 'rc', 15.6, 30.2);
     await CS(R, 'cc', "#main-app .cov-cell"); await R.move('#cc', {ms:500, scroll:false}); await HL(R, 'cc', 30.6, 33.6);
     await tg(R, 'rl', LF('^SVILUPPO PERSONALE$', 1, 2)); await scr(R, 'rl'); await HL(R, 'rl', 34.2, 38.6);
     await tg(R, 'rp', LF('^PROFILO', 0, 1)); await scr(R, 'rp'); await HL(R, 'rp', 39.0, 44.6); }},
 ]),
sb('b04', 'Check degli adulti', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await tg(R, 'ss4', SB("shChk")); await R.move('#ss4', {ms:500, scroll:false}); await R.at(0.2); await H(R, '#ss4'); await sleep(300); await ck(R, '#ss4', {ms:50}); await R.hlOff(); await sleep(1200); await dq(R); await sleep(800); await top(R);
     await tg(R, 'ci', LF('^Un momento in cui lo staff', 0, 0)); await HL(R, 'ci', 3.4, 15.6);
     await tg(R, 'k0', "return document.querySelectorAll('#main-app .chk-r')[0]"); await tg(R, 'k1', "return document.querySelectorAll('#main-app .chk-r')[1]"); await tg(R, 'k2', "return document.querySelectorAll('#main-app .chk-r')[2]");
     await scr(R, 'k0'); await R.at(16.2); await H(R, '#k0'); await R.at(18.4); await R.hlOff(); await R.at(18.5); await H(R, '#k1'); await R.at(19.8); await R.hlOff(); await R.at(19.9); await H(R, '#k2'); await R.at(21.6); await R.hlOff();
     await tg(R, 'ka', "return document.querySelector('#main-app .chk-on')"); await scr(R, 'k0'); await HL(R, 'ka', 19.9, 22.0);
     await tg(R, 'kn', "return document.querySelector('#main-app .chk-r textarea.chk-nm')"); await HL(R, 'kn', 23.0, 24.7);
     await tg(R, 'km', "return document.querySelector('#main-app .chk-r select.chk-sel')"); await HL(R, 'km', 25.0, 27.6);
     await tg(R, 'k3', "return document.querySelectorAll('#main-app .chk-r')[2]"); await scr(R, 'k3'); await HL(R, 'k3', 27.8, 31.0);
     await scr(R, 'k0'); await tg(R, 'kp', "return [...document.querySelectorAll('#main-app span')].find(e => e.offsetParent && /^Prossimo:/.test(e.innerText.trim()))"); await HL(R, 'kp', 31.2, 35.8);
     await tg(R, 'ks', "return document.getElementById('chk-a-gf')"); await scr(R, 'ks'); await R.move('#ks', {ms:500, scroll:false}); await R.at(36.3); await H(R, '#ks'); await R.at(38.0); await R.hlOff();
     await R.selOpen('#ks', {fast:true}); await R.at(39.6); await R.selHover('Termometro', 300); await R.at(41.3); await R.selHover('Semaforo', 300); await R.at(42.4); await R.selHover('La barca', 300); await R.at(43.7); await R.selHover('Come faremmo a fallire', 300); await R.at(45.3); await R.selHover('La scultura', 300); await R.at(46.9); await R.selHover('La ruota', 300); await R.at(47.8); await R.selPick('#ks', (R.menu || []).find(t => /^Termometro/.test(t)) || 'Termometro dello staff', true); await sleep(300);
     await tg(R, 'kh', "return [...document.querySelectorAll('#main-app button.att-how')][0]"); await R.move('#kh', {ms:500, scroll:false}); await R.at(49.4); await H(R, '#kh'); await sleep(400); await RS(R); await ck(R, '#kh', {ms:50}); await R.hlOff(); await sleep(1500);
     await tg(R, 'mo', "return document.querySelector('[role=dialog], .modal, .att-scheda, .ov-box')"); await R.at(51.0); await R.F.evaluate(() => { const d = document.querySelector('[role=dialog], .modal, .att-scheda, .ov-box'); if(d) d.scrollTo({top:0, behavior:'smooth'}); });
     await R.at(54.6); await R.F.evaluate(() => { const d = document.querySelector('[role=dialog], .modal, .att-scheda, .ov-box'); const s = d && (d.querySelector('.ov-body, .sc-body') || d); if(s) s.scrollTo({top:260, behavior:'smooth'}); });
     await R.at(58.0); await R.F.evaluate(() => { const d = document.querySelector('[role=dialog], .modal, .att-scheda, .ov-box'); const s = d && (d.querySelector('.ov-body, .sc-body') || d); if(s) s.scrollTo({top:600, behavior:'smooth'}); });
     await R.at(61.0); await R.F.evaluate(() => { const b = [...document.querySelectorAll('button.modal-x')].find(x => x.offsetParent) || [...document.querySelectorAll('button')].find(x => x.offsetParent && (/^[×x✕]$|Chiudi/i.test(x.innerText.trim()) || (x.getAttribute('aria-label') || '').match(/chiudi/i))); if(b) b.click(); }); await sleep(900);
     await tg(R, 'kt', "return document.querySelector('#main-app button.chk-del')"); await scr(R, 'kt'); await HL(R, 'kt', 62.4, 64.0);
     await tg(R, 'kad', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /Aggiungi un check/.test(b.innerText))"); await scr(R, 'kad'); await HL(R, 'kad', 64.3, 66.5);
     await tg(R, 'kre', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /Rimetti quelli di serie/.test(b.innerText))"); await HL(R, 'kre', 66.8, 70.3);
     await tg(R, 'kgu', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /Per chi conduce/.test(b.innerText))"); await HL(R, 'kgu', 70.6, 74.5); }},
 ]),
sb('b05', 'Ricapitolando', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(700, 480, 1400); }},
 ]),
];
