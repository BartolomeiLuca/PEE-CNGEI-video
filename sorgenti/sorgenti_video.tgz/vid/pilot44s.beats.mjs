// Video 44: Osservare insieme
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'44s', title:'Osservazione condivisa', caption:'PEE CNGEI · Condividere'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts44.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const BT = t => "return [...document.querySelectorAll('main button, .content button, button')].find(b => b.offsetParent && !b.closest('#sh-side') && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const CQ = (pid, sel, rx) => "let e = document.getElementById('mvs-" + pid + "'); while(e && !e.querySelector(" + JSON.stringify(sel) + ")) e = e.parentElement; if(!e) return null; const l = [...e.querySelectorAll(" + JSON.stringify(sel) + ")]; return " + (rx ? "l.find(x => " + rx + ".test(x.innerText.trim()))" : "l[0]");
const ROWM = "return [...document.querySelectorAll('table tr')].find(r => r.offsetParent && /condiviso · collaboratore/.test(r.innerText))";
const goP = (R, pid) => R.F.evaluate(pid => { const s = document.getElementById('mvs-' + pid); s && s.scrollIntoView({block:'center', behavior:'smooth'}); }, pid);
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Il mio staff', [
  {t:0, run: async R => { await R.hlOff(); await R.move(sg(R, 'Capire'), {ms:500, scroll:false}); await R.at(1.9); await ck(R, sg(R, 'Capire'), {ms:60}); await sleep(500); await R.move(si(R, 'Il mio staff'), {ms:300, scroll:false}); await R.at(2.7); await ck(R, si(R, 'Il mio staff'), {ms:60}); await sleep(900);
     await tg(R, 'vq', inner('^Come programmi\\?$')); await R.at(4.1); await H(R, '#vq'); await R.at(5.7); await R.hlOff();
     await tg(R, 'vi', BT('Programmazione individuale')); await R.at(7.4); await H(R, '#vi'); await R.at(12.9); await R.hlOff();
     await tg(R, 'vc', BT('Programmazione condivisa')); await R.at(13.3); await H(R, '#vc'); await R.at(21.8); await R.hlOff();
     await tg(R, 'vn', inner('^Nella tabella Adulti in staff')); await R.at(22.1); await H(R, '#vn'); await R.at(27.9); await R.hlOff(); }},
 ]),
sb('b03', 'La tabella degli adulti', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vt', inner('^Adulti in staff')); await sc(R, 'vt'); await sleep(900); await R.at(0.7); await H(R, '#vt'); await R.at(2.5); await R.hlOff();
     await tg(R, 'vr2', ROWM); await R.at(4.5); await tg(R, 'vr1', "return [...document.querySelectorAll('table tr')].find(r => r.offsetParent && /titolare/.test(r.innerText) && !/collaboratore/.test(r.innerText))"); await H(R, '#vr1'); await R.at(7.2); await R.hlOff();
     await tg(R, 'vr2', ROWM); await R.at(7.4); await H(R, '#vr2'); await R.at(9.2); await R.hlOff();
     await tg(R, 'vck', "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && /collaboratore/.test(r.innerText)); return r && r.querySelector('input[type=checkbox]')"); await R.move('#vck', {ms:500, scroll:false}); await R.at(9.8); await H(R, '#vck'); await R.at(12.3); await R.hlOff();
     await tg(R, 'vlb', "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && /collaboratore/.test(r.innerText)); return r && [...r.querySelectorAll('*')].find(e => e.children.length === 0 && /condiviso · collaboratore/.test(e.textContent))"); await R.at(14.0); await H(R, '#vlb'); await R.at(16.9); await R.hlOff();
     await tg(R, 'vru', "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && /collaboratore/.test(r.innerText)); return r && [...r.querySelectorAll('select')].find(s => [...s.options].some(o => o.text === 'VCU'))");
     await R.at(17.4); await R.selOpen('#vru', {fast:true}); await R.at(20.3); await R.selHover('CU', 350); await R.at(21.0); await R.selHover('VCU', 350); await R.at(22.3); await R.selHover('SiS', 350); await R.at(23.5); await R.selHover('CG', 350); await R.at(24.4); await R.selHover('Aiuto', 350); await R.at(25.0); await R.selHover('Volontario', 350); await R.at(25.8); await R.selHover('Altro', 350); await R.at(26.7); await R.P.evaluate(() => ST.menuOff());
     await tg(R, 'vwn', "const e = [...document.querySelectorAll('b, strong')].find(b => b.offsetParent && /^Attenzione ai dati personali/.test(b.textContent)); return e && e.parentElement"); await sc(R, 'vwn'); await sleep(600); await R.at(28.1); await H(R, '#vwn'); await R.at(36.2); await R.hlOff(); }},
 ]),
sb('b04', 'Come osservo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move(sg(R, 'Osservare'), {ms:500, scroll:false}); await R.at(2.0); await ck(R, sg(R, 'Osservare'), {ms:60}); await sleep(500); await R.move(si(R, 'Come osservo'), {ms:300, scroll:false}); await R.at(2.7); await ck(R, si(R, 'Come osservo'), {ms:60}); await sleep(900);
     await tg(R, 'vto', inner('^Tipo di osservazione$')); await R.at(3.4); await H(R, '#vto'); await R.at(4.9); await R.hlOff();
     await tg(R, 'vi', BT('Osservazione individuale')); await R.at(6.1); await H(R, '#vi'); await R.at(10.3); await R.hlOff();
     await tg(R, 'vc', BT('Osservazione condivisa')); await R.at(10.8); await H(R, '#vc'); await R.at(16.4); await R.hlOff();
     await tg(R, 'vc', BT('Osservazione condivisa')); await R.at(16.8); await H(R, '#vc'); await R.at(18.6); await R.hlOff();
     await tg(R, 'vta', "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Chi ha osservato/.test(t.innerText))"); await sc(R, 'vta'); await sleep(700); await R.at(21.7); await H(R, '#vta'); await R.at(26.2); await R.hlOff(); }},
 ]),
sb('b05', 'Sviluppo Personale', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.move(si(R, 'Sviluppo Personale'), {ms:500, scroll:false}); await R.at(0.9); await ck(R, si(R, 'Sviluppo Personale'), {ms:60}); await sleep(1000);
     await tg(R, 'vbar', "const e = [...document.querySelectorAll('*')].find(e => e.offsetParent && e.children.length === 0 && /^Percorsi osservati$/.test(e.textContent.trim())); return e && e.parentElement"); await R.at(2.4); await H(R, '#vbar'); await R.at(4.7); await R.hlOff();
     await tg(R, 'vls', "return [...document.querySelectorAll('*')].find(e => e.offsetParent && !e.closest('#sh-side') && e.children.length === 0 && /^Sviluppo Personale$/i.test(e.textContent.trim()) && /SVILUPPO PERSONALE/.test(e.textContent.trim()) || false)"); 
     await tg(R, 'vmn', "return [...document.querySelectorAll('*')].find(e => e.offsetParent && e.children.length === 0 && /^MN$/.test(e.textContent.trim()))"); await R.at(11.9); await H(R, '#vmn'); await R.at(13.6); await R.hlOff();
     await R.move('#card-P1 > div button', {ms:500, scroll:false}).catch(() => {}); await R.at(14.5); await H(R, '#card-P1 > div button'); await R.at(16.0); await R.hlOff(); }},
 ]),
sb('b06', 'Il blocco', [
  {t:0, run: async R => { await R.hlOff(); await goP(R, 'P1'); await sleep(1200); await tg(R, 'vlk', "return [...document.querySelectorAll('*')].find(e => e.offsetParent && e.children.length === 0 && /Marco/.test(e.textContent) && false) || [...document.querySelectorAll('div')].filter(d => d.offsetParent && /^Marco ha già risposto/.test(d.innerText.trim()) && d.innerText.length < 200)[0]"); await R.at(2.0); await H(R, '#vlk'); await R.at(10.9); await R.hlOff(); }},
 ]),
sb('b07', 'Il tuo valore', [
  {t:0, run: async R => { await R.hlOff(); await R.selOpen('#mvs-P1', {fast:true}); await R.at(3.2); await R.selHover('1 — Non ancora', 400); await R.at(6.3); await R.selHover('3 — Tracce', 400); await R.at(8.6); await R.selHover('5 — In sviluppo', 400); await R.at(9.6); await R.selHover('7 — Presente', 400); await R.at(10.3); await R.selHover('9 — Consolidato', 400); await R.at(12.0); await R.selHover('Non osservato', 400); await R.at(15.2); await R.selPick('#mvs-P1', '7 — Presente', true); }},
 ]),
sb('b08', 'Dopo la risposta', [
  {t:0, run: async R => { await R.hlOff(); await sleep(400); await R.at(3.0); await H(R, '#card-P1 .mv-sc'); await R.at(8.5); await R.hlOff();
     await R.at(9.0); await H(R, '#card-P1 .mv-mr'); await R.at(11.2); await R.hlOff();
     await R.at(11.5); await H(R, '#card-P1 .mv-list'); await R.at(12.6); await R.hlOff();
     await R.at(15.4); await H(R, '#card-P1 .mv-st'); await R.at(18.5); await R.hlOff();
     await R.at(19.5); await H(R, '#card-P1 .mv-st button:nth-of-type(1)'); await R.at(21.4); await R.hlOff(); }},
 ]),
sb('b09', 'Da confrontare', [
  {t:0, run: async R => { await R.hlOff(); await goP(R, 'P2'); await sleep(1200); await R.at(5.4); await R.selOpen('#mvs-P2', {fast:true}); await R.at(6.5); await R.selPick('#mvs-P2', '8 — Presente', true); await sleep(500);
     await R.at(8.4); await H(R, '#card-P2 .mv-sc'); await R.at(11.2); await R.hlOff();
     await R.at(11.7); await H(R, '#card-P2 .mv-c'); await R.at(16.3); await R.hlOff();
     await R.at(16.6); await H(R, '#card-P2 .mv-c button:nth-of-type(1)'); await R.at(18.2); await R.hlOff();
     await R.at(18.4); await H(R, '#card-P2 .mv-c button:nth-of-type(2)'); await R.at(21.9); await R.hlOff(); }},
 ]),
sb('b10', 'La nota', [
  {t:0, run: async R => { await R.hlOff(); await R.move('#card-P2 .mv-noteinp', {ms:500, scroll:false}); await R.at(2.1); await H(R, '#card-P2 .mv-noteinp'); await R.at(4.4); await R.hlOff();
     await R.at(4.7); await TY(R, '#card-P2 .mv-noteinp', 'Sabato, nel gioco a squadre, ha aiutato i più piccoli a calmarsi'); await R.at(8.5); await H(R, '#card-P2 .mv-noteinp'); await R.at(11.0); await R.hlOff(); }},
 ]),
sb('b11', 'Da riguardare', [
  {t:0, run: async R => { await R.hlOff(); await goP(R, 'P4'); await sleep(1200); await R.at(5.6); await R.selOpen('#mvs-P4', {fast:true}); await R.at(6.5); await R.selPick('#mvs-P4', '7 — Presente', true); await sleep(600);
     await R.at(8.1); await H(R, '#card-P4 .mv-c'); await R.at(13.2); await R.hlOff();
     await R.at(14.7); await H(R, '#card-P4 .mv-tag'); await R.at(16.0); await R.hlOff();
     await R.at(16.9); await H(R, '#card-P4 .mv-c button:nth-of-type(1)'); await R.at(18.3); await R.hlOff();
     await R.at(18.6); await H(R, '#card-P4 .mv-c button:nth-of-type(2)'); await R.at(19.5); await R.hlOff();
     await R.move('#card-P4 .mv-c button:nth-of-type(1)', {ms:400, scroll:false}); await R.at(20.3); await ck(R, '#card-P4 .mv-c button:nth-of-type(1)', {ms:60}); }},
 ]),
sb('b12', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
];
