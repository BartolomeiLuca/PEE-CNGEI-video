// Video 45: Confronto e sintesi
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'45s', title:'Confronto e sintesi', caption:'PEE CNGEI · Condividere'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts45.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const BT = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && !b.closest('#sh-side') && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const D = " #cf-detail ";
const LEAFP = rx => "const r = new RegExp(" + JSON.stringify(rx) + "); const e = [...document.querySelectorAll('#cf-detail *')].find(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); return e";
const SO = "return [...document.querySelectorAll('select')].find(s => s.offsetParent && [...s.options].some(o => o.text === 'Divergenza'))";
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Dove si trova', [
  {t:0, run: async R => { await R.hlOff(); await R.move(sg(R, 'Osservare'), {ms:500, scroll:false}); await R.at(0.7); await ck(R, sg(R, 'Osservare'), {ms:60}); await sleep(500); await R.move(si(R, 'Confronto e sintesi'), {ms:400, scroll:false}); await R.at(6.0); await ck(R, si(R, 'Confronto e sintesi'), {ms:60}); await sleep(900);
     await R.at(7.6); await H(R, '.cf-lg'); await R.at(13.9); await R.hlOff();
     await R.at(14.5); await H(R, '.cf-cnt'); await R.at(19.4); await R.hlOff();
     await tg(R, 'vso', SO); await R.move('#vso', {ms:500, scroll:false}); await R.at(20.2); await H(R, '#vso'); await R.at(20.9); await R.hlOff(); }},
 ]),
sb('b03', 'La tabella', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(900, 520, 900);
     await tg(R, 'vt1', "return [...document.querySelectorAll('table')].find(t => t.offsetParent)"); await R.at(0.5); await H(R, '#vt1'); await R.at(2.8); await R.hlOff();
     await tg(R, 'h1', TH('percorso')); await R.at(4.4); await H(R, '#h1'); await R.at(5.2); await R.hlOff();
     await tg(R, 'h2', TH('tu')); await R.at(5.3); await H(R, '#h2'); await R.at(5.9); await R.hlOff();
     await tg(R, 'h3', TH('marco')); await R.at(8.6); await H(R, '#h3'); await R.at(9.6); await R.hlOff();
     await tg(R, 'h4', TH('media')); await R.at(10.0); await H(R, '#h4'); await R.at(10.6); await R.hlOff();
     await tg(R, 'h5', TH('range')); await R.at(10.8); await H(R, '#h5'); await R.at(14.0); await R.hlOff();
     await tg(R, 'h6', TH('valore')); await R.at(14.4); await H(R, '#h6'); await R.at(17.6); await R.hlOff();
     await tg(R, 'vco', ROW('Corporeità')); await R.at(20.9); await H(R, '#vco'); await R.at(24.3); await R.hlOff(); }},
 ]),
sb('b04', 'Divergenza', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(900, 520, 900);
     await tg(R, 'vg', ROW('Gestione delle emozioni')); await R.at(3.6); await H(R, '#vg'); await R.at(9.5); await R.hlOff();
     await tg(R, 'vg', ROW('Gestione delle emozioni')); await R.at(9.9); await H(R, '#vg'); await R.at(14.8); await R.hlOff();
     await tg(R, 'vca', ROW('Capacità operative')); await R.at(15.3); await H(R, '#vca'); await R.at(26.4); await R.hlOff();
     await tg(R, 'vpr', ROW('Progettualità')); await R.at(27.2); await H(R, '#vpr'); await R.at(31.2); await R.hlOff(); }},
 ]),
sb('b05', 'Ordina per', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vso', SO); await R.at(0.3); await R.selOpen('#vso', {fast:true}); await R.at(2.5); await R.selHover('Ordine dei percorsi', 400); await R.at(4.1); await R.selHover('Divergenza', 400); await R.at(12.3); await R.selPick('#vso', 'Divergenza', true); await sleep(900);
     await tg(R, 'vso', SO); await R.at(13.9); await R.selOpen('#vso', {fast:true}); await R.at(15.0); await R.selPick('#vso', 'Ordine dei percorsi', true); }},
 ]),
sb('b06', 'Il pannello', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await tg(R, 'vg', ROW('Gestione delle emozioni')); await R.move('#vg', {ms:600, scroll:false}); await R.at(0.8); await ck(R, '#vg', {ms:60}); await sleep(900); await R.moveTo(1180, 300, 600);
     await tg(R, 'p1', LEAFP('^Attività e presenze$')); await R.at(5.8); await H(R, '#p1'); await R.at(7.2); await R.hlOff();
     await tg(R, 'p2', LEAFP('^Nessuna attività collegata')); await R.at(11.8); await H(R, '#p2'); await R.at(13.2); await R.hlOff();
     await tg(R, 'p3', LEAFP('^Livelli e note personali$')); await R.at(13.8); await H(R, '#p3'); await R.at(15.5); await R.hlOff();
     await tg(R, 'p4', LEAFP('^Marco Neri · Tracce')); await R.at(19.0); await H(R, '#p4'); await R.at(24.6); await R.hlOff();
     await tg(R, 'p5', LEAFP('^Tu · Presente')); await R.at(24.8); await H(R, '#p5'); await R.at(27.0); await R.hlOff();
     await tg(R, 'p6', LEAFP('^Dalla griglia osservativa$')); await R.at(27.9); await H(R, '#p6'); await R.at(29.7); await R.hlOff();
     await tg(R, 'p7', LEAFP('^Nella griglia non avete ancora')); await R.at(33.0); await H(R, '#p7'); await R.at(34.4); await R.hlOff(); }},
 ]),
sb('b07', 'Valore del percorso', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'v1', LEAFP('^Valore del percorso$')); await sc(R, 'v1'); await sleep(900); await R.at(0.9); await tg(R, 'v1', LEAFP('^Valore del percorso$')); await H(R, '#v1'); await R.at(2.3); await R.hlOff();
     await R.at(3.0); await H(R, '#cf-detail .mv-sc'); await R.at(4.3); await R.hlOff();
     await R.at(4.5); await H(R, '#cf-detail .mv-mr'); await R.at(6.5); await R.hlOff();
     await R.at(6.8); await H(R, '#cf-detail .mv-list'); await R.at(8.5); await R.hlOff();
     await R.at(12.6); await R.F.evaluate(() => { const e = document.querySelector('#cf-detail .cf-mv .mv-c'); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }); await sleep(900); await R.at(14.4); await H(R, '#cf-detail .cf-mv .mv-c button.btn-primary'); await R.at(15.9); await R.hlOff();
     await R.at(16.4); await H(R, '#cf-detail .cf-mv .mv-c button:has-text("Scegli un altro valore")'); await R.at(18.2); await R.hlOff();
     await R.move('#cf-detail .cf-mv .mv-c button:has-text("Scegli un altro valore")', {ms:400, scroll:false}); await R.at(19.8); await ck(R, '#cf-detail .cf-mv .mv-c button:has-text("Scegli un altro valore")', {ms:60}); await sleep(900); if(!(await R.F.evaluate(() => !!document.getElementById('mvv-P2')))) { await R.F.locator('#cf-detail .cf-mv .mv-c button:has-text("Scegli un altro valore")').first().click(); await sleep(900); }
     await R.F.evaluate(() => { const e = document.querySelector('#cf-detail select[id^=mvv-]'); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }); await sleep(700);
     await R.at(21.0); await R.selOpen('#cf-detail select[id^=mvv-]', {fast:true}); await R.at(23.0); await R.selHover('3 — Tracce', 350); await R.at(26.0); await R.selHover('7 — Presente', 350); await R.at(27.8); await R.selPick('#cf-detail select[id^=mvv-]', '5 — In sviluppo', true);
     await R.at(29.2); await H(R, '#cf-detail textarea[id^=mvw-]'); await R.at(30.0); await TY(R, '#cf-detail textarea[id^=mvw-]', 'Contesti diversi: un livello intermedio, da rivedere dopo il campo'); await R.at(31.3); await R.hlOff(); }},
 ]),
sb('b08', 'La sintesi', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const e = document.querySelector('#cf-detail select[id^=mvv-]'); }); await R.F.locator('#cf-detail textarea[id^=mvw-]').first().press('Tab').catch(() => {});
     await R.F.evaluate(() => { const e = [...document.querySelectorAll('#cf-detail *')].find(e => e.children.length === 0 && /^Sintesi dello staff/.test(e.textContent)); e && e.scrollIntoView({block:'start', behavior:'smooth'}); }); await sleep(900);
     await tg(R, 's1', LEAFP('^Sintesi dello staff')); await R.at(0.7); await H(R, '#s1'); await R.at(5.3); await R.hlOff();
     await R.at(6.8); await H(R, '#cf-detail label.gr-f:nth-of-type(1)'); await R.at(8.4); await R.hlOff();
     await R.at(8.7); await H(R, '#cf-detail label.gr-f:nth-of-type(2)'); await R.at(10.4); await R.hlOff();
     await R.at(10.5); await H(R, '#cf-detail label.gr-f:nth-of-type(3)'); await R.at(12.4); await R.hlOff();
     await R.at(12.6); await H(R, '#cf-detail label.gr-f'); await R.at(18.0); await R.hlOff();
     await R.at(18.9); await TY(R, '#cf-detail label.gr-f:nth-of-type(1) textarea', 'Aiuta i più piccoli nei momenti di tensione'); await sleep(300);
     await tg(R, 'vpc', BT('Precompila')); await R.at(23.3); await H(R, '#vpc'); await R.at(27.4); await R.hlOff(); }},
 ]),
sb('b09', 'I pulsanti', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vb1', BT('Porta le sintesi')); await sc(R, 'vb1'); await sleep(1000);
     await tg(R, 'vb1', BT('Porta le sintesi')); await R.move('#vb1', {ms:500, scroll:false}); await R.at(2.0); await H(R, '#vb1'); await R.at(4.5); await R.hlOff();
     await tg(R, 'vb2', BT('Scarica la Scheda')); await R.at(4.8); await H(R, '#vb2'); await R.at(6.5); await R.hlOff();
     await tg(R, 'vb3', BT('Scarica tabella')); await R.at(6.7); await H(R, '#vb3'); await R.at(8.6); await R.hlOff();
     await tg(R, 'vb4', BT('Vai alle priorità')); await R.at(8.8); await H(R, '#vb4'); await R.at(11.8); await R.hlOff();
     await tg(R, 'vb1', BT('Porta le sintesi')); await R.move('#vb1', {ms:400, scroll:false}); await R.at(13.4); await ck(R, '#vb1', {ms:60}); }},
 ]),
sb('b10', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
];
