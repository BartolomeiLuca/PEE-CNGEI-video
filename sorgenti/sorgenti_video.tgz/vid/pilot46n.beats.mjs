// Video 40: Progetto Personale, verifica, valutazione, invii, checklist
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'46n', title:'Progetto Personale: gli invii', caption:'PEE CNGEI · Progetto Personale'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts46n.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('pp1', 0)); await sleep(4000); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Check-list del progetto', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} }); await go(R, 'vck', "shPP('c')"); await top(R);
     await tg(R, 'vs1', SUM('Sezioni 1–3')); await R.at(5.7); await H(R, '#vs1'); await R.at(9.0); await R.hlOff();
     await tg(R, 'vs2', SUM('Sezioni 4 e 5')); await R.at(9.3); await H(R, '#vs2'); await R.at(12.7); await R.hlOff();
     await R.move('#vs1', {ms:500, scroll:false}); await R.at(15.8); await ck(R, '#vs1', {ms:50}); await sleep(600);
     await hh(R, 'vl1', '^[○✓] ?Dati', 16.5, 18.4, 0);
     await hh(R, 'vl2', '^[○✓] ?Numeri dell’Unità', 21.5, 22.7, 0);
     await hh(R, 'vl3', '^[○✓] ?Occasioni osservative', 23.0, 24.3, 0);
     await hh(R, 'vl4', '^[○✓] ?3 priorità', 24.5, 26.5, 0);
     await hh(R, 'vl5', '^[○✓] ?Almeno 3 attività', 26.7, 30.0, 0);
     await hh(R, 'vl6', '^[○✓] ?Griglia osservativa compilata', 30.1, 36.3, 0);
     await tg(R, 'vpm', SUM('^Promemoria per l’invio')); await scr(R, 'vpm'); await R.move('#vpm', {ms:500, scroll:false}); await R.at(41.0); await H(R, '#vpm'); await R.at(42.3); await ck(R, '#vpm', {ms:50}); await sleep(600); await R.at(46.5); await R.hlOff();
     await tg(R, 'vd1', BTN('↓ Scheda Sezioni 1–3')); await scr(R, 'vd1'); await R.at(48.0); await H(R, '#vd1'); await R.at(50.9); await R.hlOff();
     await tg(R, 'vd2', BTN('↓ Scheda completa')); await R.at(51.0); await H(R, '#vd2'); await R.at(54.3); await R.hlOff();
     await tg(R, 'vd3', BTN('↓ Dati dell')); await R.at(54.4); await H(R, '#vd3'); await R.at(56.5); await R.hlOff(); }},
 ]),
sb('b03', 'Invio del Progetto Personale', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} }); await go(R, 'vin', "shPP('i')"); await top(R);
     await hh(R, 'vi1', 'Comunicazione di avvio', 10.8, 12.9);
     await tg(R, 'vb1', BTN('Prepara la mail di avvio')); await R.move('#vb1', {ms:500, scroll:false}); await R.at(13.1); await H(R, '#vb1'); await R.at(20.0); await R.hlOff();
     await tg(R, 'vc1', CB(0)); await R.move('#vc1', {ms:500, scroll:false}); await R.at(20.4); await H(R, '#vc1'); await R.at(21.9); await ck(R, '#vc1', {ms:50}); await R.at(22.6); await R.hlOff();
     await hh(R, 'vi2', 'Presa in carico', 22.8, 24.6);
     await tg(R, 'vc2', CB(1)); await R.move('#vc2', {ms:500, scroll:false}); await R.at(27.7); await H(R, '#vc2'); await R.at(28.9); await ck(R, '#vc2', {ms:50}); await R.at(29.4); await R.hlOff();
     await hh(R, 'vi3', 'Sviluppo con il Capo Gruppo mentore', 29.6, 32.4);
     await tg(R, 'vcg', "return document.getElementById('it-cg')"); await scr(R, 'vcg'); await R.at(33.2); await H(R, '#vcg'); await R.at(38.1); await R.hlOff(); await R.at(38.3); await R.selOpen('#vcg', {fast:true}); await R.at(38.5); await R.selHover('Sì', 300); await R.at(39.4); await R.selHover('Non ancora', 300); await R.at(40.0); await R.selPick('#vcg', 'Sì', true);
     await hh(R, 'vi4', 'Prima consegna', 40.5, 44.5);
     await tg(R, 'vm2', BTN('Invia in revisione')); await scr(R, 'vm2'); await R.move('#vm2', {ms:400, scroll:false}); await R.at(44.8); await H(R, '#vm2'); await R.at(46.2); await R.hlOff(); await ck(R, '#vm2', {ms:50}); await sleep(1000);
     await tg(R, 'vmi', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /^L.invio fissa il progetto/.test(e.textContent.trim())).sort((a, b) => a.textContent.length - b.textContent.length)[0]"); await R.at(46.8); await H(R, '#vmi'); await R.at(51.8); await R.hlOff();
     await tg(R, 'vmw', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /^Funzione in preparazione/.test(e.textContent.trim())).sort((a, b) => a.textContent.length - b.textContent.length)[0]"); await R.at(52.0); await H(R, '#vmw'); await R.at(58.2); await R.hlOff();
     await R.F.evaluate(() => { try{ ppGiroFormClose(); }catch(e){} }); await sleep(500);
     await tg(R, 'vw2', "return [...document.querySelectorAll('#main-app button')].find(b => b.offsetParent && /Scarica il Word \\(Sezioni/.test(b.innerText))"); await scr(R, 'vw2'); await R.move('#vw2', {ms:400, scroll:false}); await R.at(58.4); await H(R, '#vw2'); await R.at(59.9); await R.hlOff();
     await tg(R, 'vra', BTN('Registra l’approvazione')); await R.move('#vra', {ms:400, scroll:false}); await R.at(61.9); await H(R, '#vra'); await R.at(64.2); await R.hlOff();
     await hh(R, 'vi6', 'Consegna finale · Sezioni 1', 64.5, 72.0);
     await hh(R, 'vi7', 'Approvazione finale', 72.1, 76.4);
     await tg(R, 'vic', SUM('^I Responsabili dei Centri')); await scr(R, 'vic'); await R.at(76.6); await H(R, '#vic'); await R.move('#vic', {ms:500, scroll:false}); await R.at(78.0); await ck(R, '#vic', {ms:50}); await sleep(700); await R.at(81.0); await R.hlOff(); }},
 ]),
sb('b04', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(700, 480, 1400); }},
 ]),
];
