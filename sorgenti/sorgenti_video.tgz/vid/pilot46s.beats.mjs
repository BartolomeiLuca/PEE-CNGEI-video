// Video 46: Progettare insieme allo staff
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'46s', title:'Progettare insieme allo staff', caption:'PEE CNGEI · Progettare'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts46.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false);
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
export async function open(F){ await F.evaluate(() => shOpen('p1', 0)); await sleep(4500); }
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const BT = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && !b.closest('#sh-side') && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const LF = rx => "const r = new RegExp(" + JSON.stringify(rx) + "); return [...document.querySelectorAll('body *')].find(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim()))";
const LFP = rx => "const r = new RegExp(" + JSON.stringify(rx) + "); const e = [...document.querySelectorAll('body *')].find(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); return e && e.parentElement";
const STT = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Condividi/.test(t.innerText) && /Ruolo/.test(t.innerText))";
const CELL = (r, c) => "const t = [...document.querySelectorAll('table')].find(t => t.offsetParent && /Condividi/.test(t.innerText) && /Ruolo/.test(t.innerText)); const rw = t && t.querySelectorAll('tbody tr')[" + r + "]; return rw && rw.cells[" + c + "]";
const grp = async (R, name) => { await R.move(sg(R, name), {ms:500, scroll:false}); await ck(R, sg(R, name), {ms:60}); await sleep(700); };
const AS = n => '#att-0-2 .att-share .aff-row:nth-of-type(' + n + ') select';
const opn = id => R => R.F.evaluate(id => { const d = document.getElementById(id); if(d){ d.open = true; d.scrollIntoView({block:'start', behavior:'smooth'}); } }, id);
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Il mio staff', [
  {t:0, run: async R => { await R.hlOff(); await R.at(0.0); await grp(R, 'Capire'); await R.move(si(R, 'Il mio staff'), {ms:400, scroll:false}); await R.at(2.0); await ck(R, si(R, 'Il mio staff'), {ms:60}); await sleep(1200);
     await tg(R, 'vq', LFP('^Come programmi\\?$')); await R.at(3.9); await H(R, '#vq'); await R.at(6.0); await R.hlOff();
     await tg(R, 'vi', LFP('^Programmazione individuale$')); await R.at(6.6); await H(R, '#vi'); await R.at(12.2); await R.hlOff();
     await tg(R, 'vc', LFP('^Programmazione condivisa$')); await R.at(12.7); await H(R, '#vc'); await R.at(20.8); await R.hlOff();
     await tg(R, 'vn', LF('^Nella tabella Adulti in staff')); await R.at(21.2); await H(R, '#vn'); await R.at(26.0); await R.hlOff(); }},
 ]),
sb('b03', 'La tabella', [
  {t:0, run: async R => { await R.hlOff(); await tg(R, 'vt', STT); await sc(R, 'vt'); await sleep(900); await tg(R, 'vt', STT); await R.at(0.5); await H(R, '#vt'); await R.at(2.2); await R.hlOff();
     await tg(R, 'vr1', "const t = [...document.querySelectorAll('table')].find(t => t.offsetParent && /Condividi/.test(t.innerText) && /Ruolo/.test(t.innerText)); return t.querySelectorAll('tbody tr')[0]"); await R.at(2.6); await H(R, '#vr1'); await R.at(8.0); await R.hlOff();
     await tg(R, 'vk', CELL(1, 1)); await R.at(9.6); await H(R, '#vk'); await R.at(13.6); await R.hlOff();
     await R.at(14.0); await H(R, '#vk'); await R.at(17.0); await R.hlOff();
     await tg(R, 'vrl', "const t = [...document.querySelectorAll('table')].find(t => t.offsetParent && /Condividi/.test(t.innerText) && /Ruolo/.test(t.innerText)); return t.querySelectorAll('tbody tr')[1].cells[2].querySelector('select')");
     await R.at(17.2); await R.selOpen('#vrl', {fast:true}); await R.at(19.6); await R.selHover('CU', 350); await R.at(20.5); await R.selHover('VCU', 350); await R.at(22.8); await R.selHover('Altro', 350); await R.at(23.6); await R.P.evaluate(() => ST.menuOff());
     await tg(R, 'vnm', CELL(1, 3)); await R.at(24.2); await H(R, '#vnm'); await R.at(25.2); await R.hlOff();
     await tg(R, 'vem', CELL(1, 4)); await R.at(25.4); await H(R, '#vem'); await R.at(29.3); await R.hlOff(); }},
 ]),
sb('b04', 'Le attività', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await grp(R, 'Progettare'); await R.move(si(R, 'Percorso Personale'), {ms:400, scroll:false}); await R.at(0.9); await ck(R, si(R, 'Percorso Personale'), {ms:60}); await sleep(1300);
     if(!(await R.F.evaluate(() => { const d = document.getElementById('att-0-0'); return !!(d && d.offsetParent); }))){ await tg(R, 'vpc', inner('^Percorso 1 . P1')); await R.move('#vpc', {ms:500, scroll:false}); await R.at(3.2); await ck(R, '#vpc', {ms:60}); await sleep(1500); }
     await R.F.evaluate(() => { const d = document.getElementById('att-0-2'); if(d) d.open = false; const e = document.getElementById('att-0-0'); e && e.scrollIntoView({block:'start', behavior:'smooth'}); }); await sleep(1000);
     await R.at(4.6); await H(R, '#att-0-0 summary'); await R.at(5.6); await R.hlOff();
     await R.at(8.0); await H(R, '#att-0-0 summary .aff-chip'); await R.at(10.0); await R.hlOff();
     await R.at(10.8); await H(R, '#att-0-0 summary .aff-chip'); await R.at(13.2); await R.hlOff();
     await R.F.evaluate(() => { const e = document.getElementById('att-0-1'); e && e.scrollIntoView({block:'start', behavior:'smooth'}); }); await sleep(900);
     await R.at(13.6); await H(R, '#att-0-1 summary .aff-chip'); await R.at(15.5); await R.hlOff();
     await R.F.evaluate(() => { const e = document.getElementById('att-0-2'); e && e.scrollIntoView({block:'start', behavior:'smooth'}); }); await sleep(900);
     await R.at(15.8); await H(R, '#att-0-2 summary'); await R.at(18.8); await R.hlOff();
     await R.move('#att-0-2 summary', {ms:500, scroll:false}); await R.at(19.0); await ck(R, '#att-0-2 summary', {ms:60}); await sleep(600); }},
 ]),
sb('b05', 'Il referente', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const d = document.getElementById('att-0-2'); if(d){ d.open = true; d.scrollIntoView({block:'start', behavior:'smooth'}); } }); await sleep(900);
     await R.at(0.6); await H(R, '#att-0-2 .att-share'); await R.at(4.5); await R.hlOff();
     await R.at(4.8); await H(R, '#att-0-2 .att-share .aff-row'); await R.at(13.4); await R.hlOff();
     await R.move(AS(1), {ms:500, scroll:false}); await R.at(15.8); await R.selOpen(AS(1), {fast:true}); await R.at(17.4); await R.selHover('Anna Verdi', 350); await R.at(18.4); await R.selHover('Marco Neri', 350); await R.at(19.7); await R.selHover('Un’altra', 350);
     await R.at(22.6); await R.selHover('Anna Verdi', 300); await R.at(23.9); await R.selPick(AS(1), 'Anna Verdi (CU)', true); await sleep(800); await R.at(24.9); await H(R, '#att-0-2 .att-share'); await R.at(26.4); await R.hlOff(); }},
 ]),
sb('b06', 'Più referenti', [
  {t:0, run: async R => { await R.hlOff(); await R.move(AS(1), {ms:500, scroll:false}); await R.at(2.8); await R.selOpen(AS(1), {fast:true}); await R.at(4.3); await R.selHover('Marco Neri', 350); await R.at(5.0); await R.selPick(AS(1), 'Marco Neri (VCU)', true); await sleep(900);
     await R.at(5.9); await H(R, '#att-0-2 .att-share'); await R.at(8.7); await R.hlOff();
     await R.F.evaluate(() => shPerc('P')); await sleep(1500); await R.F.evaluate(() => { const d = document.getElementById('att-0-2'); if(d){ d.open = true; d.scrollIntoView({block:'start', behavior:'instant'}); } }); await sleep(600);
     await R.at(9.5); await H(R, '#att-0-2 summary .aff-chip'); await R.at(16.0); await R.hlOff(); }},
 ]),
sb('b07', 'Parte affidata a un’altra persona', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { const d = document.getElementById('att-0-0'); if(d){ d.open = true; d.scrollIntoView({block:'start', behavior:'smooth'}); } }); await sleep(1000);
     await R.at(5.7); await H(R, '#att-0-0 .ed-aff'); await R.at(11.0); await R.hlOff();
     await R.at(12.0); await H(R, '#att-0-0 .ed-aff button:nth-of-type(1)'); await R.at(12.8); await R.move('#att-0-0 .ed-aff button:nth-of-type(1)', {ms:400, scroll:false}); await R.at(13.0); await ck(R, '#att-0-0 .ed-aff button:nth-of-type(1)', {ms:60}); await sleep(900); await R.hlOff();
     await R.at(14.6); await R.move('textarea[placeholder="Cosa suggerisci?"]', {ms:500, scroll:false}); await R.at(15.2); await TY(R, 'textarea[placeholder="Cosa suggerisci?"]', 'Aggiungi una variante per chi arriva in ritardo');
     await R.at(20.0); const inv = R.F.locator('button', {hasText:/^Invia$/}).first(); await R.move(inv, {ms:400, scroll:false}); await R.at(20.6); await ck(R, inv, {ms:60}); await sleep(1200);
     await R.at(24.4); await H(R, '#att-0-0 .ed-aff button:nth-of-type(2)'); await R.at(27.0); await R.move('#att-0-0 .ed-aff button:nth-of-type(2)', {ms:400, scroll:false}); await R.at(27.2); await ck(R, '#att-0-0 .ed-aff button:nth-of-type(2)', {ms:60}); await sleep(900); await R.hlOff(); }},
 ]),
sb('b08', 'I ruoli', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await grp(R, 'Condividere'); await R.move(si(R, 'Condividi con lo staff'), {ms:400, scroll:false}); await R.at(5.0); await ck(R, si(R, 'Condividi con lo staff'), {ms:60}); await sleep(1500);
     await tg(R, 'vro', "return [...document.querySelectorAll('select')].filter(s => s.offsetParent && [...s.options].some(o => o.text === 'Co-titolare')).pop()"); await sc(R, 'vro'); await sleep(900); await tg(R, 'vro', "return [...document.querySelectorAll('select')].filter(s => s.offsetParent && [...s.options].some(o => o.text === 'Co-titolare')).pop()");
     await R.move('#vro', {ms:500, scroll:false}); await R.at(7.0); await H(R, '#vro'); await R.at(8.6); await R.hlOff();
     await R.selOpen('#vro', {fast:true}); await R.at(9.2); await R.selHover('Lettore', 400); await R.at(13.3); await R.selHover('Co-titolare', 400); await R.at(17.0); await R.selHover('Collaboratore', 400); await R.at(25.4); await R.P.evaluate(() => ST.menuOff()); }},
 ]),
sb('b09', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1400); }},
 ]),
];
