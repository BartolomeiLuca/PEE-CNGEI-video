import { sleep } from './rec2.mjs';
import fs from 'fs';
import { mkPage, prepComp, sendGiro, revWork, compWork, BASE, REV } from './rvcommon.mjs';
export const META = {n:'47n', title:'Dal lato di chi compila', caption:'PEE CNGEI · Progetto Personale'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts47n.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const EML = "return [...document.querySelectorAll('input')].filter(i => i.offsetParent && /Tutor/.test((i.closest('div') || {}).innerText || '') && !/Capo Gruppo|Commissario/.test((i.closest('div') || {}).innerText || '') && i.type !== 'checkbox' && i.type !== 'radio')[0]";
const LBL = (rx, n = 0) => "const r = new RegExp(" + JSON.stringify(rx) + "); return [...document.querySelectorAll('label')].filter(l => l.offsetParent && r.test(l.innerText))[" + n + "]";
const LAST = t => "return [...document.querySelectorAll('button')].filter(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + ")).pop()";
export const recUser = c => c.u;
const ckR = async (R, id, body, at, hl) => { for(let k = 0; k < 4; k++){ await tg(R, id, body); try{ await R.move('#' + id, {ms:500, scroll:false}); if(at) await R.at(at); if(hl){ await H(R, '#' + id); await R.at(hl); await R.hlOff(); } await ck(R, '#' + id, {ms:50}); return true; }catch(e){ await sleep(500); } } console.log('ckR✗', id); return false; };
export async function open(F, c){ c.R && c.R.P.setDefaultTimeout(4000); await F.evaluate(() => { scheda._p2Seen = true; shOpen('pp1', 0); scheda.pp.nome = 'Anna Verdi'; scheda.pp.mail = {area:'altoadriatico', tutorMail:''}; saveData(true); }); await sleep(4500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Invia in revisione', [
  {t:0, run: async R => { await R.hlOff(); await R.P.evaluate(() => { try{ ST.menuOff(); }catch(e){} }); await go(R, 'vin', "shPP('i')"); await top(R);
     await tg(R, 'vb', BTN('Invia in revisione')); await scr(R, 'vb'); await R.move('#vb', {ms:500, scroll:false}); await R.at(2.8); await H(R, '#vb'); await R.at(4.3); await R.hlOff(); await ck(R, '#vb', {ms:50}); await sleep(1100);
     await tg(R, 'vmi', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /^L.invio fissa il progetto/.test(e.textContent.trim())).sort((a, b) => a.textContent.length - b.textContent.length)[0]"); await R.at(5.0); await H(R, '#vmi'); await R.at(11.3); await R.hlOff();
     await tg(R, 'vac', inner('^A chi$')); await R.at(11.7); await H(R, '#vac'); await R.at(15.5); await R.hlOff();
     await tg(R, 'vr1', LBL('Il mio Tutor')); await R.move('#vr1', {ms:400, scroll:false}); await R.at(12.6); await ck(R, '#vr1', {ms:50}); await sleep(500); await tg(R, 'vr1', LBL('Il mio Tutor')); await R.at(13.1); await tg(R, 'vr2', LBL('L.ICdF')); await R.move('#vr2', {ms:500, scroll:false}); await R.at(14.4); await R.move('#vr1', {ms:400, scroll:false});
     await tg(R, 'vun', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /^Il revisore è uno solo/.test(e.textContent.trim())).sort((a, b) => a.textContent.length - b.textContent.length)[0]"); await R.at(15.6); await H(R, '#vun'); await R.at(21.2); await R.hlOff();
     await tg(R, 'vem', EML); await scr(R, 'vem'); await R.at(21.3); await TY(R, '#vem', REV.email, 9); await R.P.keyboard.press('Tab'); await sleep(900);
     await tg(R, 'vca', LBL('Condividi in app', 0)); await R.move('#vca', {ms:500, scroll:false}); await R.at(24.2); await H(R, '#vca'); await R.at(26.5);
     const on = await R.F.evaluate(() => { const l = [...document.querySelectorAll('label')].find(l => l.offsetParent && /Condividi in app/.test(l.innerText)); const i = l && l.querySelector('input'); return i ? i.checked : null; }); console.log('condividi on:', on); if(on === false) await ck(R, '#vca', {ms:50});
     await tg(R, 'vpm', LBL('Prepara la mail', 0)); await R.move('#vpm', {ms:400, scroll:false}); await R.at(26.7); await H(R, '#vpm'); await R.at(27.9); await R.hlOff(); const mon = await R.F.evaluate(() => { const l = [...document.querySelectorAll('label')].find(l => l.offsetParent && /Prepara la mail/.test(l.innerText)); const i = l && l.querySelector('input'); return i ? i.checked : null; }); console.log('mail on:', mon); if(mon) await ck(R, '#vpm', {ms:50}); await sleep(300); await tg(R, 'vca', LBL('Condividi in app', 0)); await R.move('#vca', {ms:400, scroll:false}); await R.at(28.2); await H(R, '#vca'); await R.at(37.1); await R.hlOff();
     await tg(R, 'vcg', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /^Capo Gruppo · in copia/.test(e.textContent.trim())).sort((a, b) => b.textContent.length - a.textContent.length).pop()"); await R.at(37.3); await H(R, {sel:'#vcg'}); await R.at(42.9); await R.hlOff();
     await tg(R, 'vgr', LBL('Includi la griglia osservativa')); await scr(R, 'vgr'); await R.move('#vgr', {ms:500, scroll:false}); await R.at(43.2); await H(R, '#vgr'); await R.at(51.9); await R.hlOff();
     await R.F.evaluate(() => { [1,2,3].forEach(i => { try{ ppGiroDest(i, 'mail', false); }catch(e){} }); }); await tg(R, 'vgo', LAST('Invia in revisione')); await scr(R, 'vgo'); await R.move('#vgo', {ms:500, scroll:false}); await R.at(52.2); await H(R, '#vgo'); await R.at(53.3); await R.hlOff(); await ck(R, '#vgo', {ms:50}); await sleep(600);
     const { mkPage } = await import('./rvcommon.mjs'); const { revWork } = await import('./rvcommon.mjs'); const c = R.ctx; R.bg = (async () => { const PL = await mkPage(R.br, c.db, c.L); await revWork(PL, c.db, 1); })().catch(e => console.log('bg✗', String(e).slice(0, 200))); }},
 ]),
sb('b03', 'Recepire le richieste', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { try{ ppGiroFormClose(); }catch(e){} }); await top(R); await R.moveTo(900, 400, 800);
     await tg(R, 'vpr', "return [...document.querySelectorAll('a,button')].find(e => e.offsetParent && /^Progetti/.test(e.innerText.trim()))"); await R.at(5.0); await R.move('#vpr', {ms:500, scroll:false}); await H(R, '#vpr'); await R.at(9.0); await R.hlOff();
     await R.bg; await R.F.evaluate(async () => { try{ await rpLoad(); rpTog(); rpTog(); }catch(e){ return String(e) } }).then(r => console.log('RPL', r)); await sleep(1200); if(0) console.log('DBG', await R.F.evaluate(() => JSON.stringify({d: !!document.getElementById('rp-dock'), t: document.body.innerText.match(/Revisioni da recepire[^\n]*/g), badge: document.body.innerText.match(/Progetti[^\n]*/)}))); await R.P.screenshot({path:'/tmp/d1.png'});
      console.log('PRE', await R.F.evaluate(() => JSON.stringify({ctx: typeof CL !== 'undefined' && CL.ctx && CL.ctx.id, rvs: !!window._rvs, pt: window._rp && JSON.stringify(window._rp.pts[0]).slice(0,200), aside: [...document.querySelectorAll('aside,#rp-pill')].map(e => e.id + ':' + e.tagName), open: window._rp && window._rp.open, pts: window._rp && window._rp.pts && window._rp.pts.length, pill: !!document.getElementById('rp-pill')}))); await R.move('#rp-pill', {ms:500, scroll:false}); await R.at(9.4); await H(R, '#rp-pill'); await R.at(10.0); await ck(R, '#rp-pill', {ms:50}); await sleep(900); await R.hlOff();
     await R.P.screenshot({path:'/tmp/d2.png'}); console.log('DK', await R.F.evaluate(() => JSON.stringify({open: window._rp && window._rp.open, pts: window._rp && window._rp.pts && window._rp.pts.length, pill: !!document.getElementById('rp-pill'), bro: window.BRO}))); await tg(R, 'vtu', inner('^Tocca a te')); await R.at(12.9); await H(R, '#vtu'); await R.at(14.2); await R.hlOff();
     await tg(R, 'vse', inner('^1 · Osservazione del Gruppo di Pari')); await R.at(14.5); await H(R, '#vse'); await R.at(17.0); await R.hlOff();
     await tg(R, 'vdf', "return [...document.querySelectorAll('#rp-dock *')].find(e => e.offsetParent && e.children.length === 0 && /^Da fare$/.test(e.textContent.trim()))"); await R.at(17.2); await H(R, '#vdf'); await R.at(19.0); await R.hlOff();
     await tg(R, 'vpt', "return [...document.querySelectorAll('#rp-dock *')].find(e => e.offsetParent && e.children.length === 0 && /^Aggiungi il quartiere/.test(e.textContent.trim()))"); await R.move('#vpt', {ms:500, scroll:false}); await R.at(19.3); await ck(R, '#vpt', {ms:50}); await sleep(2500);
     await tg(R, 'vnt', "return document.querySelector('.rp-inl')"); await scr(R, 'vnt'); await R.at(22.2); await H(R, '#vnt'); await R.at(25.2); await R.hlOff();
     await tg(R, 'vta', TA('Quali elementi del territorio')); await R.at(25.3); await R.F.evaluate(() => { const t = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith('Quali elementi del territorio')); t.value = ''; }); await TY(R, '#vta', 'Il quartiere è servito da due linee urbane e ha un parco a cinque minuti dalla sede.', 14);
     await ckR(R, 'vho', "return [...document.querySelectorAll('.rp-inl .rv-st .rv-b')].find(x => /Ho fatto/.test(x.textContent))", 27.4); await sleep(900);
     await tg(R, 'vq', "return [...document.querySelectorAll('.rp-inl textarea, .rp-inl input')].find(e => e.offsetParent)"); await R.at(28.6); await H(R, '#vq'); await R.at(31.2); await R.hlOff();
     await tg(R, 'vqi', "return [...document.querySelectorAll('.rp-inl button')].find(b => b.offsetParent && /^Invia$/.test(b.innerText.trim()))"); await R.move('#vqi', {ms:400, scroll:false}); await R.at(31.6); await H(R, '#vqi'); await R.at(32.6); await R.hlOff();
     await ckR(R, 'vhf', "return [...document.querySelectorAll('#rp-dock button')].find(b => b.offsetParent && /^Ho finito/.test(b.innerText.trim()))", 34.8, 36.2); await sleep(1500);
     await R.at(37.0); await R.moveTo(700, 400, 1200); }},
 ]),
sb('b04', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(700, 480, 1400); }},
 ]),
];
