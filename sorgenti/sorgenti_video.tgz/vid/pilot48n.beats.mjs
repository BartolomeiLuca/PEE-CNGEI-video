import { sleep } from './rec2.mjs';
import fs from 'fs';
import { mkPage, prepComp, sendGiro, revWork, compWork, BASE, REV } from './rvcommon.mjs';
export const META = {n:'48n', title:'Dal lato di chi rivede', caption:'PEE CNGEI · Progetto Personale'};
const TX = JSON.parse(fs.readFileSync(new URL('./texts48n.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side button.sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el) el.id = id; return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
export const recUser = c => c.L;
const ckR = async (R, id, body, at, hl) => { for(let k = 0; k < 4; k++){ await tg(R, id, body); try{ await R.move('#' + id, {ms:500, scroll:false}); if(at) await R.at(at); if(hl){ await H(R, '#' + id); await R.at(hl); await R.hlOff(); } await ck(R, '#' + id, {ms:50}); return true; }catch(e){ await sleep(500); } } console.log('ckR✗', id); return false; };
const waitFor = async (R, body, ms = 20000) => { const t = Date.now(); while(Date.now() - t < ms){ const ok = await R.F.evaluate(b => !!new Function(b)(), body).catch(() => false); if(ok) return true; await sleep(300); } return false; };
let PC = null;
export async function prepare(c){ // fuori campo: chi compila invia il giro 1
  const { launch } = await import('./harness_new.mjs'); const { serve } = await import('./harness_new.mjs'); await serve();
  c.br0 = await launch('chromium'); PC = await mkPage(c.br0, c.db, c.u); await prepComp(PC); await sendGiro(PC, REV.email);
}
export async function open(F, c){ await F.evaluate(() => { try{ window.open = () => null; }catch(e){} }); await sleep(4500); }
const OPEN1 = "return [...document.querySelectorAll('[onclick*=\"rvOpen\"]')].find(e => e.offsetParent)";
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Aprire il progetto da rivedere', [
  {t:0, run: async R => { await R.hlOff(); await R.F.evaluate(() => { window.open = () => null; }); await R.moveTo(700, 450, 900);
     await tg(R, 'vet', "const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /^(Tocca a te|Aspetta il compilatore)/.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0]"); await R.at(8.6); await H(R, '#vet'); await R.at(16.0); await R.hlOff();
     await tg(R, 'vop', OPEN1); await R.move('#vop', {ms:600, scroll:false}); await R.at(17.0); await ck(R, '#vop', {ms:60}); await sleep(5000);
     await tg(R, 'vba', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /^COPIA INVIATA DA/i.test(e.textContent.trim())).sort((a, b) => a.textContent.length - b.textContent.length)[0]"); await R.at(18.6); await H(R, '#vba'); await R.at(21.8); await R.hlOff();
     await tg(R, 'vpa', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /Revisione · Giro 1/.test(e.textContent.trim()) && e.textContent.length < 60).sort((a, b) => a.textContent.length - b.textContent.length)[0]"); await R.at(22.2); await H(R, '#vpa'); await R.at(25.0); await R.hlOff(); }},
 ]),
sb('b03', 'Scrivere le richieste', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(150, 400, 700);
     await tg(R, 'vnv', "return document.querySelector('#rv-nav') || [...document.querySelectorAll('body *')].find(e => e.offsetParent && /^Il progetto$/i.test(e.textContent.trim()))"); await R.at(0.3); await H(R, '#vnv'); await R.at(2.4); await R.hlOff();
     await tg(R, 'vpn', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /Revisione · Giro 1/.test(e.textContent.trim()) && e.textContent.length < 60).sort((a, b) => a.textContent.length - b.textContent.length)[0]"); await R.at(2.5); await H(R, '#vpn'); await R.at(3.9); await R.hlOff();
     await tg(R, 'vfu', "const h = [...document.querySelectorAll('#rv-doc .rd-art *')].find(e => e.children.length === 0 && e.textContent.trim() === 'Contesto territoriale'); let c = h; while(c && !c.querySelector('.rd-cb')) c = c.parentElement; return c && c.querySelector('.rd-cb')"); await scr(R, 'vfu'); await R.move('#vfu', {ms:700, scroll:false}); await R.at(5.6); await H(R, '#vfu'); await R.at(6.9); await ck(R, '#vfu', {ms:60}); await sleep(700); await R.hlOff();
     await tg(R, 'vta', "return document.querySelector('#rv-doc textarea[data-bk]')"); await scr(R, 'vta'); await R.at(8.4); await TY(R, '#vta', 'Aggiungi il quartiere e un riferimento al territorio.', 10);
     await tg(R, 'vag', "return [...document.querySelectorAll('#rv-doc .rv-bs button')].find(b => /Aggiungi richiesta/.test(b.innerText))"); await R.move('#vag', {ms:500, scroll:false}); await R.at(12.2); await ck(R, '#vag', {ms:50}); await sleep(1500);
     await tg(R, 'vbz', "return document.querySelector('#rv-doc .rd-fix')"); await R.at(13.6); await H(R, '#vbz'); await R.at(17.0); await R.hlOff();
     await tg(R, 'vin', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Invia le richieste di revisione/.test(b.innerText.trim()))"); await R.move('#vin', {ms:600, scroll:false}); await R.at(17.3); await H(R, '#vin'); await R.at(21.2); await R.hlOff();
     await R.at(23.4); await R.hlOff(); await ck(R, '#vin', {ms:60}); const c = R.ctx; R.bg = (async () => { const { compWork } = await import('./rvcommon.mjs'); await compWork(PC, c.db); })().catch(e => console.log('bg✗', String(e).slice(0, 200))); await sleep(1800);
     await R.F.evaluate(() => { const tt = [...document.querySelectorAll('body *')].find(e => e.offsetParent && e.children.length === 0 && /^Tocca a chi ha scritto il progetto/.test(e.textContent.trim())); if(tt) tt.scrollIntoView({block:'center', behavior:'smooth'}); });
     await tg(R, 'vtc', "return [...document.querySelectorAll('body *')].find(e => e.offsetParent && e.children.length === 0 && /^Tocca a chi ha scritto il progetto/.test(e.textContent.trim()))"); await R.at(25.8); await H(R, '#vtc'); await R.at(27.6); await R.hlOff(); await ckR(R, 'vcl', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Chiudi e torna ai progetti/.test(b.innerText.trim()))", 27.8); }},
 ]),
sb('b04', 'Rilettura e approvazione', [
  {t:0, run: async R => { await R.hlOff(); await R.bg; await R.F.evaluate(() => { window.open = () => null; }); const lb = R.F.locator('button', {hasText:/Leggi e rivedi/}).first(); try{ await R.move(lb, {ms:600, scroll:false}); await R.at(2.8); await R.click(lb, {scroll:false}); }catch(e){ console.log('leggi✗', String(e).slice(0,80)); await R.F.evaluate(id => rvOpen(id), R.ctx.db.t.pee_giri[1].id); } await waitFor(R, "return window._rd && window._rd.anchors && window._rd.anchors.length && [...document.querySelectorAll('button')].some(b => b.offsetParent && /^Tutto il progetto/.test(b.innerText.trim()))"); await sleep(1500); await top(R); console.log('TOG', await R.F.evaluate(() => { const c = [...document.querySelectorAll('body *')].filter(e => /^Tutto il progetto/.test(e.textContent.trim())); const e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; return e ? e.tagName + '|' + e.className + '|' + (e.offsetParent ? 'vis' : 'hid') + '|' + e.outerHTML.slice(0, 160) : 'none'; }));
     await tg(R, 'vt1', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Tutto il progetto/.test(b.innerText.trim()))"); console.log('V1', await R.F.evaluate(() => !!document.getElementById('vt1')), await R.F.evaluate(() => { const e = document.getElementById('vt1'); return e ? e.tagName + e.getBoundingClientRect().width : 'x'; })); await sleep(900); console.log('V2', await R.F.evaluate(() => !!document.getElementById('vt1'))); await R.move('#vt1', {ms:500, scroll:false}); await R.at(7.6); await H(R, '#vt1'); await R.at(9.0);
     await tg(R, 'vt2', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Solo le modifiche dal giro/.test(b.innerText.trim()))"); await R.move('#vt2', {ms:500, scroll:false}); await R.hlOff(); await H(R, '#vt2'); await R.at(10.0); await R.at(11.4); await ck(R, '#vt2', {ms:50}); await sleep(1200); await R.at(13.6); await tg(R, 'vt1', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Tutto il progetto/.test(b.innerText.trim()))"); await R.at(14.0); await ck(R, '#vt1', {ms:50}); await sleep(800); await R.hlOff();
     await tg(R, 'vdc', "return [...document.querySelectorAll('body *')].filter(e => e.offsetParent && /^Da confermare/.test(e.textContent.trim())).sort((a, b) => a.textContent.length - b.textContent.length)[0]"); await R.at(14.4); await H(R, '#vdc'); await R.at(19.7); await R.hlOff();
     await tg(R, 'vgp', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Vai al punto nel progetto/.test(b.innerText.trim()))"); await R.move('#vgp', {ms:500, scroll:false}); await R.at(20.3); await H(R, '#vgp'); await R.at(21.8); await R.hlOff(); await ck(R, '#vgp', {ms:50}); await sleep(1500);
     await tg(R, 'vcf', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Conferma$/.test(b.innerText.trim()))"); await R.move('#vcf', {ms:500, scroll:false}); await R.at(24.3); await H(R, '#vcf'); await R.at(25.8); await R.hlOff();
     await tg(R, 'vri', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Riapri$/.test(b.innerText.trim()))"); await R.move('#vri', {ms:500, scroll:false}); await R.at(26.4); await H(R, '#vri'); await R.at(28.0); await R.hlOff();
     await R.move('#vcf', {ms:400, scroll:false}); await R.at(28.3); await ck(R, '#vcf', {ms:50}); await sleep(1300);
     await tg(R, 'vcb', "return [...document.querySelectorAll('body *')].find(e => e.offsetParent && e.children.length === 0 && /^Confermato/.test(e.textContent.trim()))"); await R.at(28.9); await H(R, '#vcb'); await R.at(31.8); await R.hlOff();
     await ckR(R, 'vap', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Approva$/.test(b.innerText.trim()))", 32.4, 34.8); await sleep(1500); }},
 ]),
sb('b05', 'Chiusura', [
  {t:0, run: async R => { await R.hlOff();
     await tg(R, 'vch', "return [...document.querySelectorAll('body *')].find(e => e.offsetParent && e.children.length === 0 && /Revisione chiusa/.test(e.textContent.trim()))"); await R.F.evaluate(() => { const e = [...document.querySelectorAll('body *')].find(e => e.offsetParent && e.children.length === 0 && /Revisione chiusa/.test(e.textContent.trim())); e && e.scrollIntoView({block:'center', behavior:'instant'}); }); await R.at(0.3); await H(R, '#vch'); await R.at(3.2); await R.hlOff();
     await tg(R, 'vrr', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Riapri la revisione/.test(b.innerText.trim()))"); await R.move('#vrr', {ms:600, scroll:false}); await R.at(3.8); await H(R, '#vrr'); await R.at(9.6); await R.hlOff();
     await tg(R, 'vwd', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Scarica il Word di questo giro/.test(b.innerText.trim()))"); await R.move('#vwd', {ms:600, scroll:false}); await R.at(10.2); await H(R, '#vwd'); await R.at(14.0); await R.hlOff(); }},
 ]),
sb('b06', 'Riepilogo', [
  {t:0, run: async R => { await R.hlOff(); await R.moveTo(700, 480, 1400); }},
 ]),
];
