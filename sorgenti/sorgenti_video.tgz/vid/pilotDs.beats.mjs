// Video Dashboard
import { sleep } from './rec.mjs';
import fs from 'fs';
export const META = {n:'Ds', title:'La Dashboard', caption:'PEE CNGEI · Per iniziare'};
const TX = JSON.parse(fs.readFileSync(new URL('./textsD.json', import.meta.url)));
const H = async (R, ...a) => { try { await R.hl(...a); } catch(e) { console.log("H✗", a[0], String(e).slice(0,120)); } };
const sb = (id, scene, segs, extra = {}) => ({id, scene, say:TX[id], segs, ...extra});
const ck = async (R, sel, o = {}) => { await R.move(sel, {scroll:false, ms:o.ms ?? 90, dx:o.dx ?? 0.5, dy:o.dy ?? 0.5}); await R.P.evaluate(([x, y]) => ST.ripple(x, y), [R.cx, R.cy]); await R.P.mouse.click(R.cx, R.cy); };
const sg = (R, t) => R.F.locator('#sh-side .sh-gh', {hasText:t}).first();
const si = (R, t) => R.F.locator('#sh-side .sh-si', {hasText:t}).first();
const tg = async (R, id, body) => { const ok = await R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ if(el.id && !el.dataset.oid && !el.dataset.tagged) el.dataset.oid = el.id; el.id = id; el.dataset.tagged = '1'; } return !!el; }, [id, body]).catch(() => false); if(!ok) console.log('T✗', id); return ok; };
const inner = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('body *')].filter(e => e.offsetParent && r.test(e.textContent.trim())); return c.filter(e => !c.some(x => x !== e && e.contains(x)))[0];";

const q = (R, id, body) => R.F.evaluate(([id, body]) => { document.querySelectorAll('#' + id).forEach(x => x.removeAttribute('id')); const el = new Function(body)(); if(el){ el.id = id; el.scrollIntoView({block:'center', behavior:'instant'}); } return !!el; }, [id, body]).catch(() => false);
const TY = async (R, sel, text, n = 9) => { await R.type(sel, text.slice(0, n), 40); await R.F.fill(sel, text); };
const head_ = n => "const r = new RegExp('^' + " + JSON.stringify(n) + " + '$', 'i'); return [...document.querySelectorAll('body *')].filter(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))[0]";
const top = R => R.F.evaluate(() => window.scrollTo({top:0, behavior:'smooth'}));
const TAB = "return [...document.querySelectorAll('table')].find(t => t.offsetParent && /Preventivo/.test(t.innerText))";
const TH = n => "return [...document.querySelectorAll('table th')].find(t => t.offsetParent && t.innerText.trim().toLowerCase().startsWith(" + JSON.stringify(n) + "))";
const ROW = n => "const r = [...document.querySelectorAll('table tr')].find(r => r.offsetParent && r.cells[0] && r.cells[0].innerText.trim().startsWith(" + JSON.stringify(n) + ")); return r";
const BTN = t => "return [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const pk = async (R, sel, prefix, fast = true) => { const n = (R.menu || []).find(t => t.startsWith(prefix)); if(n) await R.selPick(sel, n, fast); };
const menuTour = async (R, sel, list, back) => { await R.selOpen(sel, {fast:true}); for (const [n, at] of list) { await R.at(at); await R.selHover(n, 400); } return R.menu; };
const sc = (R, id) => R.F.evaluate(id => { const e = document.getElementById(id); e && e.scrollIntoView({block:'center', behavior:'smooth'}); }, id);
const ROWB = rx => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e";
const RB = (rx, t) => "const e = [...document.querySelectorAll('.cl-row')].find(r => r.offsetParent && /" + rx + "/.test(r.innerText.trim())); return e && [...e.querySelectorAll('button')].find(b => b.innerText.trim() === " + JSON.stringify(t) + ")";
const SEL = o => "return [...document.querySelectorAll('.an-ov select')].find(s => [...s.options].some(x => x.text === " + JSON.stringify(o) + "))";
const OVB = t => "return [...document.querySelectorAll('.an-ov button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const ACT = (n, t) => "const t = [...document.querySelectorAll('.an-ov *')].find(e => e.children.length === 0 && e.textContent.trim() === " + JSON.stringify(n) + "); let c = t; while(c && ![...c.querySelectorAll('button')].some(b => /Riusa/.test(b.innerText))) c = c.parentElement; return c && [...c.querySelectorAll('button')].find(b => b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";

const SB = fn => "return [...document.querySelectorAll('#sh-side [onclick]')].find(e => e.offsetParent && e.getAttribute('onclick').includes(" + JSON.stringify(fn) + "))";
const LEAF = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app *')].find(x => x.offsetParent && x.children.length === 0 && r.test(x.textContent.trim()))";
const LP = (rx, up = 1) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(x => x.offsetParent && r.test(x.textContent.trim())); let e = c.filter(x => !c.some(y => y !== x && x.contains(y)))[0]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const INP = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app label')].find(x => x.offsetParent && r.test(x.textContent.trim()))";
const dq = async R => { if(await tg(R, 'vqc', "return [...document.querySelectorAll('button')].find(b => b.offsetParent && /^Continua →/.test(b.innerText.trim()))")){ await R.move('#vqc', {ms:500, scroll:false}); await sleep(300); await ck(R, '#vqc', {ms:50}); await sleep(1000); } };
const go = async (R, id, fn) => { await tg(R, id, SB(fn)); await R.move('#' + id, {ms:500, scroll:false}); await ck(R, '#' + id, {ms:60}); await sleep(900); await dq(R); };
const scr = async (R, id) => { await sc(R, id); await sleep(700); };

const SELN = i => "return [...document.querySelectorAll('#main-app select')].filter(e => e.offsetParent)[" + i + "]";
const TA = p => "return [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith(" + JSON.stringify(p) + "))";
const CB = (i) => "const c = [...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e => e.offsetParent); return c[" + i + "] && (c[" + i + "].closest('label') || c[" + i + "].parentElement)";
const SUM = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app summary')].find(s => s.offsetParent && r.test(s.innerText))";
const HD = (id, rx) => tg(R_, id, LP(rx, 1));
let R_ = null;
const hh = async (R, id, rx, t0, t1, up = 1) => { await tg(R, id, LP(rx, up)); await scr(R, id); await R.at(t0); await H(R, '#' + id); await R.at(t1); await R.hlOff(); };
const RS = R => R.F.evaluate(() => { document.querySelectorAll('[data-oid]').forEach(e => { e.id = e.dataset.oid; }); });
const LF = (rx, n, up) => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); const c = [...document.querySelectorAll('#main-app *')].filter(e => e.offsetParent && e.children.length === 0 && r.test(e.textContent.trim())); let e = c[" + n + "]; for(let i = 0; i < " + up + " && e; i++) e = e.parentElement; return e";
const CS = (R, id, css) => tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")");
const HL = async (R, id, a, b) => { await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const SD = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('#main-app .st-item')].find(e => e.offsetParent && r.test(e.innerText))";
const GS = rx => "const r = new RegExp(" + JSON.stringify(rx) + ", 'i'); return [...document.querySelectorAll('.gsn-step')].find(e => e.offsetParent && r.test(e.innerText))";
const DC = c => "return document.querySelector('#panel-dash [data-c=" + c + "]')";
const DB_ = t => "return [...document.querySelectorAll('#panel-dash button')].find(b => b.offsetParent && b.innerText.trim().startsWith(" + JSON.stringify(t) + "))";
const HC = async (R, id, css, a, b) => { await tg(R, id, "return document.querySelector(" + JSON.stringify(css) + ")"); await scr(R, id); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
const HLc = async (R, id, c, a, b) => { await tg(R, id, DC(c)); await scr(R, id); await R.at(a); await H(R, '#' + id); await R.at(b); await R.hlOff(); };
export async function open(F){ await F.evaluate(() => { try{ scheda._p2Seen = true; }catch(e){} shOpen('p1', 0); }); await sleep(4000); await F.evaluate(() => shDash()); await sleep(1500); }
export const beats = [
sb('b01', 'Introduzione', [ {t:0, run: async R => { await R.moveTo(760, 520, 1400); }} ]),
sb('b02', 'Il titolo e il ciclo', [
  {t:0, run: async R => { await R.hlOff(); await top(R);
     await HC(R, 'dh1', '#panel-dash h1', 0.9, 2.6); await HC(R, 'dsb', '#panel-dash .sh-dh .sub', 2.7, 7.4);
     await tg(R, 'drn', DB_('Rinomina')); await R.move('#drn', {ms:500, scroll:false}); await R.at(9.2); await H(R, '#drn'); await R.at(11.8); await R.hlOff();
     await HC(R, 'dsg', '#panel-dash .sh-seg', 12.6, 13.9);
     await tg(R, 'dc1', DB_('Il mio ciclo')); await R.at(14.2); await H(R, '#dc1'); await R.at(18.0); await R.hlOff();
     await tg(R, 'dc2', DB_('Il mio anno')); await R.at(18.2); await H(R, '#dc2'); await R.at(22.0); await R.hlOff();
     await tg(R, 'dsm', "return [...document.querySelectorAll('#panel-dash summary')].find(s => s.offsetParent)"); await R.move('#dsm', {ms:600, scroll:false}); await R.at(23.6); await H(R, '#dsm'); await R.at(25.6); await ck(R, '#dsm', {ms:50}); await R.hlOff(); await sleep(1200);
     await R.at(26.6); await tg(R, 'dsm2', "const d = [...document.querySelectorAll('#panel-dash details')].find(s => s.offsetParent && s.open); return d"); await H(R, '#dsm2'); await R.at(28.2); await R.hlOff(); await ck(R, '#dsm', {ms:50}); }} ]),
sb('b03a', 'Prossime scadenze', [
  {t:0, run: async R => { await R.hlOff(); await RS(R); await top(R); await tg(R, 'dsc', LF('^Prossime scadenze$', 0, 2)); await R.at(0.9); await H(R, '#dsc'); await tg(R, 'dpit', LF('^Primo pit stop', 0, 1)); await R.at(8.0); await R.hlOff(); await H(R, '#dpit'); await R.at(11.0); await R.hlOff(); await tg(R, 'dap', DB_('Apri')); await R.move('#dap', {ms:600, scroll:false}); await R.at(12.6); await H(R, '#dap'); await R.at(15.3); await R.hlOff(); await tg(R, 'dps', DC('passo')); await R.at(17.9); await H(R, '#dps'); await R.at(19.9); await R.hlOff(); }} ]),
sb('b03', 'Prossimo passo e colpo d’occhio', [
  {t:0, run: async R => { await R.hlOff(); await RS(R); await top(R);
     await tg(R, 'dps', DC('passo')); await scr(R, 'dps'); await R.at(4.14); await H(R, '#dps'); await R.at(10.84); await R.hlOff();
     await tg(R, 'dvai', DB_('Vai')); await R.move('#dvai', {ms:500, scroll:false}); await R.at(11.14); await H(R, '#dvai'); await sleep(300); await ck(R, '#dvai', {ms:50}); await R.hlOff(); await sleep(1100);
     await R.F.evaluate(() => shDash()); await sleep(700); await top(R);
     await HLc(R, 'dan', 'anno', 13.44, 16.54);
     await tg(R, 'dog', "return [...document.querySelectorAll('#panel-dash [data-c=anno] *')].find(e => e.offsetParent && e.children.length === 0 && /^oggi$/i.test(e.textContent.trim()))"); await R.at(18.34); await H(R, '#dog'); await R.at(21.34); await R.hlOff();
     await tg(R, 'dpg', LF('^PERSONALE$', 0, 1)); await R.at(21.94); await H(R, '#dpg'); await R.at(25.74); await R.hlOff();
     await tg(R, 'dpc', LF('^COMUNITARIO$', 0, 1)); await R.at(25.84); await H(R, '#dpc'); await R.at(27.34); await R.hlOff();
     await tg(R, 'drr', LF('^Riunioni$', 0, 1)); await R.at(30.34); await H(R, '#drr'); await R.at(32.24); await R.hlOff();
     await tg(R, 'dus', LF('^Uscite, bivacchi e campi$', 0, 1)); await R.at(32.34); await H(R, '#dus'); await R.at(35.14); await R.hlOff();
     await tg(R, 'dvi', DB_('Visione')); await R.move('#dvi', {ms:600, scroll:false}); await R.at(38.24); await H(R, '#dvi'); await R.at(39.84); await R.hlOff(); }} ]),
sb('b04', 'Check, attività, avanzamento e numeri', [
  {t:0, run: async R => { await R.hlOff(); await RS(R);
     await HLc(R, 'dck', 'chk', 1.0, 9.0); await tg(R, 'dve', DB_('Vedi e personalizza')); await R.at(5.5); await H(R, '#dve'); await R.at(8.6); await R.hlOff();
     await HLc(R, 'dpr', 'prossime', 9.2, 15.0);
     await tg(R, 'del', DB_('Elenco dell')); await R.at(16.4); await H(R, '#del'); await R.at(18.2); await R.hlOff();
     await tg(R, 'dcl', DB_('Calendario')); await R.at(18.3); await H(R, '#dcl'); await R.at(19.6); await R.hlOff();
     await HLc(R, 'dav', 'avanz', 19.7, 31.6);
     await HLc(R, 'dnu', 'numeri', 32.0, 38.8);
     await tg(R, 'din', DB_('Inserisci i numeri')); await R.at(36.0); await H(R, '#din'); await R.at(38.0); await R.hlOff(); }} ]),
sb('b05', 'Le ultime schede', [
  {t:0, run: async R => { await R.hlOff(); await RS(R);
     await HLc(R, 'dvr', 'verificare', 1.4, 7.2); await HLc(R, 'dam', 'ambiti', 7.4, 17.2); await HLc(R, 'dpa', 'percorsi', 17.5, 23.0); }} ]),
sb('b06', 'Personalizzare e Il mio anno', [
  {t:0, run: async R => { await R.hlOff(); await RS(R); await top(R);
     await tg(R, 'dpe', DB_('Personalizza')); await R.move('#dpe', {ms:600, scroll:false}); await R.at(3.4); await H(R, '#dpe'); await sleep(300); await ck(R, '#dpe', {ms:50}); await R.hlOff(); await sleep(1000);
     await R.at(4.9); await tg(R, 'deb', "return document.querySelector('#panel-dash .sh-ebanner')"); await H(R, '#deb'); await R.at(6.6); await R.hlOff();
     await tg(R, 'dpr1', "return document.querySelector('#panel-dash [data-c=passo] button[onclick*=shMove]')"); await tg(R, 'ddo', "return document.querySelector('#panel-dash [data-c=passo] button[onclick*=\"shMove(\\'passo\\',1)\"]')"); await tg(R, 'dnh', "return document.querySelector('#panel-dash [data-c=passo] button[onclick*=shHide]')");
     await R.at(8.3); await H(R, '#dpr1'); await R.at(8.8); await R.hlOff(); await H(R, '#ddo'); await R.at(10.0); await R.hlOff(); await H(R, '#dnh'); await R.at(11.5); await R.hlOff();
     await tg(R, 'ddo', "return document.querySelector('#panel-dash [data-c=passo] button[onclick*=\"shMove(\\'passo\\',1)\"]')"); await R.at(9.1); await ck(R, '#ddo', {ms:60}); await sleep(900); await RS(R);
     await tg(R, 'dpr2', "return document.querySelector('#panel-dash [data-c=passo] button[onclick*=\"shMove(\\'passo\\',-1)\"]')"); if(await R.F.locator('#dpr2').count()){ await ck(R, '#dpr2', {ms:60}); await sleep(900); } await RS(R);
     await R.at(15.6); await tg(R, 'dh2', "return document.querySelector('#panel-dash [data-c=verificare] button[onclick*=shHide]')"); await scr(R, 'dh2'); await H(R, '#dh2'); await sleep(500); await ck(R, '#dh2', {ms:60}); await R.hlOff(); await sleep(1000);
     await R.at(16.4); await tg(R, 'dsn', "return [...document.querySelectorAll('#panel-dash h2')].find(h => /nascoste/i.test(h.innerText))"); await scr(R, 'dsn'); await H(R, '#dsn'); await R.at(20.0); await R.hlOff();
     if(await tg(R, 'dmo', DB_('Mostra'))){ await R.move('#dmo', {ms:500, scroll:false}); await sleep(300); await ck(R, '#dmo', {ms:50}); await sleep(900); }
     await tg(R, 'drp', DB_('Ripristina la disposizione')); await scr(R, 'drp'); await R.at(20.8); await H(R, '#drp'); await R.at(23.5); await ck(R, '#drp', {ms:60}); await R.hlOff(); await sleep(900); await top(R);
     await tg(R, 'dfa', DB_('Fatto')); await R.move('#dfa', {ms:500, scroll:false}); await R.at(24.2); await H(R, '#dfa'); await R.at(25.0); await ck(R, '#dfa', {ms:50}); await R.hlOff(); await sleep(900);
     await tg(R, 'dma', DB_('Il mio anno')); await R.move('#dma', {ms:500, scroll:false}); await R.at(28.7); await H(R, '#dma'); await R.at(29.6); await ck(R, '#dma', {ms:50}); await R.hlOff(); await sleep(1200); await top(R);
     await tg(R, 'dci', "return [...document.querySelectorAll('#panel-dash h3, #panel-dash h2')].find(h => /cicli di quest/i.test(h.innerText))"); await R.at(30.6); await H(R, '#dci'); await R.at(32.0); await R.hlOff();
     await tg(R, 'dnc', DB_('+ Nuovo ciclo')); await R.at(32.1); await H(R, '#dnc'); await R.at(33.9); await R.hlOff();
     await tg(R, 'dvd', "return [...document.querySelectorAll('#panel-dash h3, #panel-dash h2')].find(h => /Visione d.insieme dell/i.test(h.innerText))"); await scr(R, 'dvd'); await R.at(34.2); await H(R, '#dvd'); await R.at(37.6); await R.hlOff();
     await tg(R, 'dva', DB_('Apri la verifica')); await scr(R, 'dva'); await R.at(37.7); await H(R, '#dva'); await R.at(38.8); await R.hlOff(); }} ]),
sb('b07', 'Ricapitolando', [ {t:0, run: async R => { await R.hlOff(); await top(R); await R.moveTo(760, 520, 1200); }} ]),
];
