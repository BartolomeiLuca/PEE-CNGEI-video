import sys,glob,subprocess,numpy as np
def f0(a,sr=16000):
    fr=800;hop=400;out=[]
    for i in range(0,len(a)-fr,hop):
        x=a[i:i+fr]
        if np.sqrt((x**2).mean())<0.02: continue
        x=x-x.mean(); c=np.correlate(x,x,'full')[fr-1:]
        lo,hi=int(sr/350),int(sr/80)
        k=np.argmax(c[lo:hi])+lo
        if c[k]/c[0]>0.45: out.append(sr/k)
    return np.array(out)
for d in sys.argv[1:]:
    allf=[]
    for f in sorted(glob.glob(f'audio/{d}/b*.mp3')):
        a=np.frombuffer(subprocess.run(['ffmpeg','-v','quiet','-i',f,'-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout,dtype=np.float32)
        allf+=list(f0(a))
    x=np.array(allf); print(d,'n',len(x),'median %.0f'%np.median(x),'std %.1f'%x.std(),'p10-p90 %.0f-%.0f'%tuple(np.percentile(x,[10,90])))
