// Stato di partenza del video 27: la giornata costruita nel video 26 (+ dati della circolare)
const sleep = ms => new Promise(r => setTimeout(r, ms));
export async function prep27(P){
  const lastKey = () => P.evaluate(() => { const p = uscCur().prog; return Object.keys(p).sort((a, b) => (p[b].cr || 0) - (p[a].cr || 0))[0]; });
  const set = (k, f, v) => P.evaluate(([k, f, v]) => uscBlkSet(k, f, v, true), [k, f, v]);
  await P.locator('select').filter({has:P.locator('option', {hasText:'15:00'})}).last().selectOption({label:'15:00'}); await sleep(400);
  await P.evaluate(() => uscBlkAdd(2, 'b1')); await sleep(500);
  let k = await lastKey(); await set(k, 't', 'Alzabandiera'); await set(k, 'dur', 15); await sleep(300);
  await P.evaluate(() => uscBlkAdd(3)); await sleep(600);
  await P.locator('.usc-blk').last().locator('[onclick]', {hasText:'Orientiamoci con la mappa'}).first().click(); await sleep(600);
  k = await lastKey(); await set(k, 'dur', 90); await sleep(300);
  await P.locator('.usc-blk').last().locator('select.ax-pm-s').nth(0).selectOption({label:'Anna Verdi (CU)'}); await sleep(300);
  await P.locator('.usc-blk').last().locator('select.ax-pm-s').nth(1).selectOption({index:1}).catch(()=>{}); await sleep(300);
  await P.evaluate(() => uscBlkAdd(10)); await sleep(600);
  k = await lastKey();
  await P.locator('.usc-blk').last().locator('select.ax-pm-s').first().selectOption({label:'Anna Verdi (CU)'}); await sleep(300);
  await P.evaluate(k => uscBlkFix(k, true), k); await sleep(300); await set(k, 'ora', '17:30'); await sleep(300);
  await P.evaluate(() => uscBlkAdd(16)); await sleep(600);
  k = await lastKey(); await set(k, 't', 'Canto finale'); await set(k, 'desc', 'Un canto tutti insieme, in cerchio.'); await sleep(300);
  await P.evaluate(() => { document.querySelectorAll('.usc-blk').forEach(b => { const d = b.querySelector('.usc-bh'); }); });
}
