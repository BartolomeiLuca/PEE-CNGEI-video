// Libreria di registrazione: palco (stage.html) + app vera in un iframe + cursore, zoom, evidenziazioni
import { FakeDB, serve, launch, person } from './harness_new.mjs';
import fs from 'fs';
const sleep = ms => new Promise(r => setTimeout(r, ms));
export { sleep, FakeDB };

export async function startRec({db, user, outDir, open, caption, headed}){
  process.env.SITE = '/tmp/site_sh'; process.env.KEEPCLOSED = '1';
  const root = (await serve());
  fs.mkdirSync('/tmp/site_sh/vidstage', {recursive:true});
  fs.copyFileSync(new URL('./stage.html', import.meta.url), '/tmp/site_sh/vidstage/index.html');
  fs.mkdirSync(outDir, {recursive:true});
  fs.mkdirSync('/tmp/site_sh/vidstage/docs', {recursive:true}); for(const d of ['docs27png']) if(fs.existsSync(new URL('./' + d, import.meta.url).pathname)) for(const f of fs.readdirSync(new URL('./' + d, import.meta.url).pathname)) fs.copyFileSync(new URL('./' + d + '/' + f, import.meta.url).pathname, '/tmp/site_sh/vidstage/docs/' + f);
  const { chromium } = await import('playwright'); const br = await chromium.launch({executablePath: process.env.CHROME_BIN || undefined, args:['--lang=it-IT'], env:{...process.env, LANGUAGE:'it_IT', LC_ALL:'it_IT.UTF-8'}});
  const pa = await person(br, db, {ctx:{locale:'it-IT', timezoneId:'Europe/Rome', viewport:{width:1920, height:1080}, recordVideo:{dir:outDir, size:{width:1920, height:1080}}}});
  const P = pa.page; P.setDefaultTimeout(15000);
  // Servizi di mappa simulati (nei video si lavora offline): stessa forma delle risposte vere, valori plausibili
  const PLACES = [
    {k:'popolo', r:[{display_name:'Piazza del Popolo, Centro Storico, Pesaro, Pesaro e Urbino, Marche, 61121, Italia', lat:'43.9101', lon:'12.9132', address:{road:'Piazza del Popolo', city:'Pesaro', postcode:'61121'}}]},
    {k:'foglia', r:[{display_name:'Fiume Foglia, Montecchio, Vallefoglia, Pesaro e Urbino, Marche, Italia', lat:'43.8446', lon:'12.8174', address:{village:'Montecchio', county:'Pesaro e Urbino'}}]},
  ];
  await pa.ctx.route('**/nominatim.openstreetmap.org/**', r => { const q = decodeURIComponent((r.request().url().split('q=')[1] || '')).toLowerCase(); const hit = PLACES.find(p => q.includes(p.k)); r.fulfill({contentType:'application/json', body:JSON.stringify(hit ? hit.r : [])}); });
  await pa.ctx.route('**/router.project-osrm.org/**', r => { const m = r.request().url().match(/driving\/([\d.]+),([\d.]+);([\d.]+),([\d.]+)/); let d = 12000; if(m){ const [a1,o1,a2,o2] = [m[2],m[1],m[4],m[3]].map(Number); const t = Math.PI/180, R = 6371; const dl = (a2-a1)*t, dn = (o2-o1)*t; const h = Math.sin(dl/2)**2 + Math.cos(a1*t)*Math.cos(a2*t)*Math.sin(dn/2)**2; d = 2*R*Math.asin(Math.sqrt(h))*1.3*1000; } r.fulfill({contentType:'application/json', body:JSON.stringify({code:'Ok', routes:[{distance:d}]})}); });
  const errs = []; P.on('pageerror', e => errs.push(String(e).slice(0, 300)));
  await P.goto(root + 'anteprima/', {waitUntil:'domcontentloaded'}); await sleep(600);
  await P.evaluate(u => { localStorage.setItem('bussola_tour_v3', '1'); localStorage.setItem('fake_sb_session', JSON.stringify({user:{id:u.id, email:u.email, user_metadata:u.meta||{}}, access_token:'t'})); }, user);
  P.__uidv = user.id;
  await P.goto(root + 'vidstage/', {waitUntil:'domcontentloaded'});
  await sleep(2500);
  const F = P.frames().find(f => /\/anteprima\//.test(f.url()) && f !== P.mainFrame());
  if(!F) throw new Error('iframe app non trovato');
  await open(F);
  await sleep(1500);
  if(caption) await P.evaluate(c => ST.caption(c), caption);
  const R = new Rec(P, F, errs, br, pa);
  return R;
}

export class Rec {
  constructor(P, F, errs, br, pa){ this.P = P; this.F = F; this.errs = errs; this.br = br; this.pa = pa; this.log = []; this.t0 = 0; this.cx = 960; this.cy = 600; }
  async start(){ this.t0 = await this.P.evaluate(() => ST.start()); await sleep(600); }
  now(){ return Date.now() - this.t0; }
  async scene(t){ await this.P.evaluate(t => ST.scene(t), t); }
  async card(h){ await this.P.evaluate(h => ST.card(h), h); }
  loc(sel){ return typeof sel === 'string' ? this.F.locator(sel).first() : sel; }
  async box(sel, {scroll = true} = {}){
    const l = this.loc(sel);
    if(scroll) await l.evaluate(e => e.scrollIntoView({block:'center', behavior:'instant'})).catch(() => {});
    await sleep(120);
    const b = await l.boundingBox(); if(!b) throw new Error('senza box: ' + sel);
    return b;
  }
  async hl(...specs){ const it = specs.map(x => typeof x === 'string' ? {sel:x} : x); await this.P.evaluate(i => ST.hl(i), it); await sleep(150); }
  async hlAll(sel){ await this.hl({sel, all:true}); }
  async hlOff(){ await this.P.evaluate(() => ST.hlOff()); }
  async zoomTo(sel, s, sel2){ // zoom sull'elemento (o sull'unione di due elementi), coordinate app
    const rect = async q => this.loc(q).evaluate(e => { const r = e.getBoundingClientRect(); return {x:r.x, y:r.y, w:r.width, h:r.height}; });
    let b = await rect(sel);
    if(sel2){ const c = await rect(sel2); const x1 = Math.min(b.x, c.x), y1 = Math.min(b.y, c.y), x2 = Math.max(b.x + b.w, c.x + c.w), y2 = Math.max(b.y + b.h, c.y + c.h); b = {x:x1, y:y1, w:x2 - x1, h:y2 - y1}; }
    await this.P.evaluate(([b, s]) => ST.zoom(b.x, b.y, b.w, b.h, s, 1500), [b, s]); await sleep(1700);
  }
  async zoomOff(){ await this.P.evaluate(() => ST.zoomOff(1500)); await sleep(1700); }
  async moveTo(x, y, ms = 800){
    await this.P.evaluate(([x, y, ms]) => ST.cur(x - 7, y - 4, ms), [x, y, ms]);
    const n = Math.max(4, Math.round(ms / 40)); await this.P.mouse.move(x, y, {steps:n}); this.cx = x; this.cy = y; await sleep(80);
  }
  async move(sel, {dx = 0.5, dy = 0.5, ms = 800, scroll = true} = {}){ const b = await this.box(sel, {scroll}); await this.moveTo(b.x + b.width * dx, b.y + b.height * dy, ms); return b; }
  async click(sel, opt = {}){ const b = await this.move(sel, opt); await sleep(150); await this.P.evaluate(([x, y]) => ST.ripple(x, y), [this.cx, this.cy]); await this.P.mouse.click(this.cx, this.cy); await sleep(400); return b; }
  async type(sel, text, delay = 75){ await this.click(sel); await this.P.keyboard.type(text, {delay}); await sleep(300); }
  async drag(from, to, {fdx = 0.3, fdy = 0.3, tdx = 0.5, tdy = 0.5} = {}){
    const a = await this.box(from, {scroll:false}); await this.moveTo(a.x + a.width * fdx, a.y + a.height * fdy, 800);
    await sleep(150); await this.P.mouse.down(); await sleep(200);
    const b = await this.box(to, {scroll:false}); const tx = b.x + b.width * tdx, ty = b.y + b.height * tdy;
    await this.P.evaluate(([x, y]) => ST.cur(x - 7, y - 4, 1200), [tx, ty]);
    await this.P.mouse.move(tx, ty, {steps:30}); this.cx = tx; this.cy = ty; await sleep(300);
    await this.P.mouse.up(); await sleep(600);
  }
  // simula l'apertura di un menu a tendina (i menu nativi non compaiono nel video): mostra le scelte reali, le scorre, sceglie
  async openSelect(sel, pick, {hover = [], maxn = 99, dwell = 900} = {}){
    await this.move(sel, {ms:1100, scroll:false}); await sleep(250); await this.P.evaluate(([x, y]) => ST.ripple(x, y), [this.cx, this.cy]);
    const shown = await this.P.evaluate(([s, m]) => ST.menuOpen(s, m), [sel, maxn]);
    await sleep(900);
    const order = [...hover, pick].map(l => shown.findIndex(t => t === l || t.startsWith(l)));
    for(const i of order){ if(i < 0) continue; const p = await this.P.evaluate(i => ST.menuHover(i), i); await this.moveTo(p.x, p.y, 700); await sleep(dwell); }
    await this.P.evaluate(([x, y]) => ST.ripple(x, y), [this.cx, this.cy]); await sleep(250);
    await this.F.selectOption(sel, {label: pick}); await sleep(300);
    await this.P.evaluate(() => ST.menuOff()); await sleep(600);
  }
  // finestra di richiesta del nome (prompt del browser): non compare nei video, quindi la disegno sul palco e rispondo io
  async fakePrompt(title, text, trigger){
    await this.P.evaluate(t => ST.dlgShow(t), title); await sleep(700);
    for(let i = 1; i <= text.length; i++){ await this.P.evaluate(x => ST.dlgType(x), text.slice(0, i)); await sleep(90); }
    await sleep(900);
    await this.F.evaluate(v => { window.prompt = () => v; }, text);
    await this.P.evaluate(() => ST.dlgOff()); await trigger(); await sleep(500);
  }
  async scrollApp(y){ await this.F.evaluate(y => window.scrollTo({top:y, behavior:'smooth'}), y); await sleep(900); }
  // un "battito": parte la voce (a durata nota), le azioni corrono in parallelo; il battito dura almeno quanto la voce
  async beat(id, durSec, run){
    const t = this.now(); this.log.push({id, t, dur:durSec});
    let err = null; const work = (run ? Promise.resolve().then(run).catch(e => { err = e; }) : Promise.resolve());
    await Promise.all([work, sleep(Math.round(durSec * 1000) + 350)]);
    if(err){ console.log('  ✗ ' + id + ': ' + String(err).slice(0, 200)); this.log[this.log.length - 1].err = String(err).slice(0, 200); }
    await this.hlOff();
    const late = this.now() - t - (durSec * 1000 + 350); if(late > 400) console.log(`  ! ${id}: azioni oltre la voce di ${(late / 1000).toFixed(1)} s`);
  }
  sleepx(ms){ return sleep(ms); }
  // ---- sincronia voce/azioni: ogni "segmento" parte insieme alla frase che lo racconta ----
  async sbeat(id, segs, durSec){
    const t0 = this.now(); const rec = {id, t:t0, dur:0, segs:[]}; this.log.push(rec);
    for(let i = 0; i < segs.length; i++){
      const sg = segs[i]; const T = this.now(); this.cur = {T, s:sg.t};
      const last = i === segs.length - 1;
      const L = ((segs[i + 1] ? segs[i + 1].t : durSec) - sg.t) + (last ? 0.35 : 0);
      rec.segs.push({i, t:T, s:sg.t, len:L});
      if(!sg.keep) await this.hlOff();
      let err = null; const work = sg.run ? Promise.resolve().then(() => sg.run(this)).catch(e => { err = e; }) : Promise.resolve();
      await Promise.all([work, sleep(Math.round(L * 1000))]);
      if(err){ console.log('  ✗ ' + id + '.' + i + ': ' + String(err).slice(0, 200)); rec.err = String(err).slice(0, 200); }
      const late = this.now() - T - L * 1000; if(late > 500) console.log(`  ! ${id}.${i}: azioni oltre la voce di ${(late / 1000).toFixed(1)} s`);
    }
    await this.hlOff(); rec.dur = (this.now() - t0) / 1000;
  }
  // ancora dentro un segmento: aspetta che la voce arrivi a quel secondo del file
  async at(t){ const w = this.cur.T + (t - this.cur.s) * 1000 - this.now(); if(w > 0) await sleep(w); }
  // visore documenti
  async docShow(names, title, kind){ await this.P.evaluate(([n, t, k]) => ST.docShow(n.map(x => '/vidstage/docs/' + x), t, k), [names, title, kind]); await sleep(700); }
  async docHl(...l){ await this.P.evaluate(l => ST.docHl(l), l); await sleep(150); }
  async docHlOff(){ await this.P.evaluate(() => ST.docHlOff()); }
  async docZoom(i, x, y, w, h, ms = 1400){ await this.P.evaluate(a => ST.docZoom(...a), [i, x, y, w, h, ms]); await sleep(ms + 100); }
  async docZoomOff(ms = 1200){ await this.P.evaluate(m => ST.docZoomOff(m), ms); await sleep(ms + 100); }
  async docOff(){ await this.P.evaluate(() => ST.docOff()); await sleep(650); }
  async selOpen(sel, {maxn = 99, fast = false} = {}){ await this.move(sel, {ms:fast ? 600 : 900, scroll:false}); await sleep(fast ? 100 : 150); await this.P.evaluate(([x, y]) => ST.ripple(x, y), [this.cx, this.cy]); this.menu = await this.P.evaluate(([s, m]) => ST.menuOpen(s, m), [sel, maxn]); await sleep(fast ? 300 : 450); }
  async selHover(name, ms = 600){ const i = (this.menu || []).findIndex(t => t === name || t.startsWith(name)); if(i < 0) return; const p = await this.P.evaluate(i => ST.menuHover(i), i); await this.moveTo(p.x, p.y, ms); await sleep(150); }
  async selPick(sel, pick, fast = false){ await this.selHover(pick, fast ? 450 : 600); await sleep(fast ? 100 : 200); await this.P.evaluate(([x, y]) => ST.ripple(x, y), [this.cx, this.cy]); await this.F.selectOption(sel, {label: pick}); await sleep(fast ? 150 : 250); await this.P.evaluate(() => ST.menuOff()); await sleep(fast ? 150 : 250); }

  async finish(){ await sleep(1200); const vp = this.P.video(); await this.pa.ctx.close(); const path = await vp.path(); await this.br.close(); return path; }
}
