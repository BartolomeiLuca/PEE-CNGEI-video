import re,sys,subprocess
def dur(p): return float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',p],capture_output=True,text=True).stdout)
script,new,old=sys.argv[1:4]   # new=audio dir, old=audio dir (bak)
s=open(script).read()
parts=re.split(r"(?m)^(?=sb\('b\d+')",s)
out=[parts[0]]
for p in parts[1:]:
    bid=re.match(r"sb\('(b\d+)'",p).group(1)
    try: r=dur(f'{new}/{bid}.mp3')/dur(f'{old}/{bid}.mp3')
    except Exception: out.append(p); continue
    if abs(r-1)>0.015:
        p=re.sub(r"R\.at\(([0-9.]+)\)",lambda m:"R.at(%.2f)"%(float(m.group(1))*r),p)
        p=re.sub(r"\{t:([0-9.]+)",lambda m:"{t:%.2f"%(float(m.group(1))*r),p)
        print(bid,'ratio %.3f'%r)
    out.append(p)
open(script,'w').write(''.join(out))
