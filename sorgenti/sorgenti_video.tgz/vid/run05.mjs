// uso: node run.mjs <beats.mjs> [fino_a_id]
import { FakeDB, startRec, sleep } from './rec.mjs';
import { demoData } from './demo.mjs';
import fs from 'fs'; import { execSync } from 'child_process';
const mod = await import(process.argv[2]); const upTo = process.argv[3];
const AUD = new URL('./audio/' + (mod.META.n) + '/', import.meta.url).pathname;
const dur = id => { const f = AUD + id + '.mp3'; if(fs.existsSync(f)) return +execSync(`ffprobe -v error -show_entries format=duration -of csv=p=0 ${f}`).toString(); const b = mod.beats.find(x => x.id === id); return b.say.length / 13.5 + 0.4; };
const db = new FakeDB(); const {u} = demoData(db);
const out = '/home/claude/work/vid/out/' + mod.META.n; fs.rmSync(out, {recursive:true, force:true});
const R = await startRec({db, user:u, outDir:out, caption:mod.META.caption, open: mod.open || (async F => { await F.evaluate(() => shOpen('p1', 0)); await sleep(5000); })});
await R.start();
const T = [];
for(const b of mod.beats){
  if(b.scene) await R.scene(b.scene);
  if(b.cards) for(const c of b.cards) await R.card(c);
  console.log(b.id, (dur(b.id)).toFixed(1) + 's');
  if(b.segs){ if(b.setup) await b.setup(R); await R.sbeat(b.id, b.segs, dur(b.id)); } else await R.beat(b.id, dur(b.id), b.run ? () => b.run(R) : null);
  if(upTo && b.id === upTo) break;
}
const t0 = R.t0;
fs.writeFileSync(out + '/timeline.json', JSON.stringify({t0, log:R.log, meta:mod.beats.map(b => ({id:b.id, say:b.say, scene:b.scene||null}))}, null, 1));
const p = await R.finish(); fs.renameSync(p, out + '/raw.webm');
console.log('errori pagina:', R.errs.slice(0, 5)); console.log('video:', out + '/raw.webm');
process.exit(0);
