// uso: node runRV.mjs <beats.mjs>   (video della revisione: due persone, una registrata e una fuori campo)
import { FakeDB, startRec, sleep } from './rec2.mjs';
import { demoPP } from './demoPP.mjs';
import fs from 'fs'; import { execSync } from 'child_process';
const mod = await import(process.argv[2]); const upTo = process.argv[3];
const AUD = new URL('./audio/' + mod.META.n + '/', import.meta.url).pathname;
const dur = id => +execSync(`ffprobe -v error -show_entries format=duration -of csv=p=0 ${AUD}${id}.mp3`).toString();
const db = new FakeDB(); db.sql14 = true; const {u} = demoPP(db);
const { mkReviewer, REV } = await import('./rvcommon.mjs'); const L = mkReviewer(db); db.ammessi = [REV.email];
const ctx = {db, u, L};
const out = (process.env.OUTROOT || '/home/claude/work/vid/out') + '/' + mod.META.n; fs.rmSync(out, {recursive:true, force:true});
if(mod.prepare) await mod.prepare(ctx);   // (può avviare il browser fuori campo)
const R = await startRec({db, user: mod.recUser(ctx), outDir:out, caption:mod.META.caption, open: F => mod.open(F, ctx)});
R.ctx = ctx; ctx.R = R;
R.P.setDefaultTimeout(4000);
await R.start();
for(const b of mod.beats){
  if(b.scene) await R.scene(b.scene);
  console.log(b.id, dur(b.id).toFixed(1) + 's');
  await R.sbeat(b.id, b.segs, dur(b.id));
  if(upTo && b.id === upTo) break;
}
fs.writeFileSync(out + '/timeline.json', JSON.stringify({t0:R.t0, log:R.log, meta:mod.beats.map(b => ({id:b.id, say:b.say, scene:b.scene || null}))}, null, 1));
const p = await R.finish(); fs.renameSync(p, out + '/raw.webm');
console.log('errori pagina:', R.errs.slice(0, 5)); console.log('video:', out + '/raw.webm');
process.exit(0);
