import { person, loginAs, sleep } from './harness_new.mjs';
export const REV = {email:'marco.tutor@esempio.it', name:'Marco Bianchi'};
export const BASE = 'http://127.0.0.1:8080/anteprima/';
export function mkReviewer(db){ const L = db.addUser(REV.email, 'password123', REV.name); db.t.pee_profili.push({user_id:L.id, nome:REV.name, ruolo:'sis', branca:'E', sezione:'Ancona', gruppo:'Ancona 1', area_rcdf:'altoadriatico', dashboard:{}}); return L; }
export async function mkPage(br, db, user){ const p = await person(br, db, {ctx:{viewport:{width:1440, height:900}, acceptDownloads:true}}); await loginAs(p.page, BASE, user); return p.page; }
export async function prepComp(P){ // compilatore: prepara il progetto e imposta il Tutor
  await P.evaluate(() => { scheda._p2Seen = true; shOpen('pp1', 0); scheda.pp.nome = 'Anna Verdi'; }); await sleep(4500);
  await P.evaluate(() => shPP('i')); await sleep(1200);
}
export async function sendGiro(P, mail){
  await P.evaluate(m => { scheda.pp.mail = {area:'altoadriatico', tutorMail:m}; saveData(true); }, mail); await sleep(500);
  await P.evaluate(() => ppGiroForm(1)); await sleep(1000);
  await P.evaluate(() => { ppGiroDest(0, 'app', true); [0,1,2,3].forEach(i => ppGiroDest(i, 'mail', false)); }); await sleep(300);
  await P.evaluate(() => ppGiroCongela()); await sleep(2500);
}
export async function revWork(PL, db, n = 1){ // chi rivede: apre la copia, scrive una richiesta, la invia
  await PL.evaluate(() => { window.open = () => null; });
  await sleep(3000);
  let g; for(let i = 0; i < 60; i++){ g = db.t.pee_giri[n - 1]; if(g) break; await sleep(500); }
  await PL.evaluate(id => rvOpen(id), g.id);
  console.log('GIRI', JSON.stringify(db.t.pee_giri.map(x => [x.id, x.archivio_id, x.meta && x.meta.n])), JSON.stringify(db.t.pee_revisioni.map(v => [v.revisore_email, v.stato])));
  await PL.waitForFunction(() => window._rd && window._rd.anchors && window._rd.anchors.length, null, {timeout:25000}).catch(async e => { console.log('RVTXT', (await PL.evaluate(() => document.body.innerText.replace(/\n+/g, ' | ').slice(0, 400)))); throw e; }); await sleep(900);
  await PL.evaluate(() => { const a = window._rd.anchors.find(x => x.sec >= 1); rvDocOpen(a.key); }); await sleep(500);
  await PL.evaluate(() => { const t = document.querySelector('#rv-doc textarea[data-bk]'); t.value = 'Aggiungi il quartiere e un riferimento al territorio.'; document.querySelector('#rv-doc .rv-bs button').click(); }); await sleep(1200);
  await PL.evaluate(() => rvSync()); await sleep(900);
  await PL.evaluate(a => rvAzione(a, 'rimanda'), g.archivio_id); await sleep(1500);
}
export async function compWork(P, db){ // chi compila: sistema il punto e dice «ho finito»
  const aid = db.t.pee_giri[0].archivio_id;
  await P.evaluate(async () => { await rpLoad(); rpTog(); rpTog(); rpTog(); }); await sleep(300);
  await P.evaluate(() => rpGo(0)); await sleep(1500);
  await P.evaluate(() => { const t = [...document.querySelectorAll('#main-app textarea')].find(e => e.offsetParent && e.placeholder.startsWith('Quali elementi del territorio')); if(t){ t.value = 'Il quartiere è servito da due linee urbane e ha un parco a cinque minuti dalla sede.'; t.dispatchEvent(new Event('input', {bubbles:true})); } }); await sleep(300);
  await P.evaluate(() => { const b = [...document.querySelectorAll('.rp-inl .rv-st .rv-b')].find(x => /Ho fatto/.test(x.textContent)); b && b.click(); }); await sleep(600);
  await P.evaluate(a => rvAzione(a, 'ho_finito'), aid); await sleep(1500);
}
