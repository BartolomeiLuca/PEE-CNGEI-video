export default async (P, nav, sleep) => {
  await nav('Osservare','Sviluppo Personale'); await sleep(1500);
  console.log(await P.evaluate(() => ({hint: document.getElementById('kos-obs-hint')?.innerText, tags:[...document.querySelectorAll('.kos-tag')].filter(e=>e.offsetParent).map(e=>e.id+':'+e.textContent+'|'+(e.title||'').slice(0,80)), oss: typeof ossActs!=='undefined' ? JSON.stringify(ossActs).slice(0,300) : 'n/a'})));
  const h=await P.$('#kos-obs-hint'); if(h) await h.scrollIntoViewIfNeeded(); await P.screenshot({path:'/tmp/g12.png'});
};
