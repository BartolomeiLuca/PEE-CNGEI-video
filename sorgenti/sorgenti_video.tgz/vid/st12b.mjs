export default async (P, nav, sleep) => {
  const q = () => P.evaluate(() => [...document.querySelectorAll('#sh-side .sh-gh,#sh-side .sh-si')].map(e => (e.offsetParent?'+':'-')+e.innerText.trim()).join(' | '));
  console.log('A', await q());
  await P.evaluate(() => shGrp('Osservare')); await sleep(500); console.log('B', await q());
};
