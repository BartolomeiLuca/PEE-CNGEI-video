export default async (P, nav, sleep) => {
  await nav('Osservare','Come osservo'); await sleep(1500);
  console.log(await P.evaluate(() => ({sums:[...document.querySelectorAll('#main-app summary')].filter(e=>e.offsetParent).map(e=>e.innerText.trim().slice(0,60)), cbs:[...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e=>e.offsetParent).length})));
  await P.evaluate(() => { const d=[...document.querySelectorAll('#main-app summary')].find(e=>e.offsetParent&&/Apri le attività del KOS/.test(e.innerText)); d&&d.click(); }); await sleep(600);
  console.log(await P.evaluate(() => ({cbs:[...document.querySelectorAll('#main-app input[type=checkbox]')].filter(e=>e.offsetParent).map(e=>(e.closest('label')||e.parentElement).innerText.trim().slice(0,50))})));
};
