export default async (P, nav, sleep) => {
  await nav('Progettare','Obiettivi e indicatori');
  console.log(await P.evaluate(() => [...document.querySelectorAll('#main-app summary')].filter(x=>x.offsetParent).map(x=>x.innerText.trim().replace(/\s+/g,' ').slice(0,60)).join(' | ')));
  console.log(await P.evaluate(() => !!document.getElementById('card-P1')));
};
