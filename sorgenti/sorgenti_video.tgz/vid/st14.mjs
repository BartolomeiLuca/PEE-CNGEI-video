export default async (P, nav, sleep) => {
  for (const g of ['Capire','Osservare','Progettare','Realizzare','Misurare','Conservare','Condividere']) { await P.evaluate((g)=>{ try{shGrp(g)}catch(e){} }, g); await sleep(300); }
  console.log(await P.evaluate(() => [...document.querySelectorAll('#sh-side .sh-si')].map(e=>e.innerText.trim()).join(' | ')));
};
