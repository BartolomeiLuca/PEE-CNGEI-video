export default async (P, nav, sleep) => {
  await P.evaluate(()=>{ [...document.querySelectorAll('#sh-side .sh-si')].find(e=>e.innerText.trim()==='Dashboard').click(); }); await sleep(1500);
  console.log(await P.evaluate(() => [...document.querySelectorAll('#panel-dash button, #panel-dash summary')].filter(e=>e.offsetParent).map(e=>e.tagName[0]+':'+e.innerText.trim().replace(/\s+/g,' ').slice(0,40)).join(' | ')));
  await P.evaluate(() => { [...document.querySelectorAll('#panel-dash summary')].find(s=>s.offsetParent).click(); }); await sleep(800);
  console.log(await P.evaluate(() => [...document.querySelectorAll('#panel-dash input, #sh-cf select, #panel-dash select')].map(e=>(e.offsetParent?'+':'-')+e.tagName+e.type+':'+(e.id||e.value)).join(' | ')));
  console.log(await P.evaluate(() => [...document.querySelectorAll('#panel-dash [class*=vis]')].map(e=>(e.offsetParent?'+':'-')+e.className).slice(0,8).join(' | ')));
};
