export default async (P, nav, sleep) => {
  await nav('Realizzare','Calendario e attività');
  await P.evaluate(() => { const b=[...document.querySelectorAll('.cal-row[data-u="r2"] .cal-ra button')].find(x=>/^Apri/.test(x.textContent.trim())); b&&b.click(); }); await sleep(2500);
  await P.evaluate(() => { const s=document.querySelector('details.usc-pm summary'); s&&s.click(); }); await sleep(900);
  console.log(JSON.stringify(await P.evaluate(() => ({pm:document.querySelector('details.usc-pm')&&document.querySelector('details.usc-pm').innerText.slice(0,700), btns:[...document.querySelectorAll('details.usc-pm button')].map(b=>(b.offsetParent?'V:':'H:')+b.textContent.trim().slice(0,50)), cls:[...document.querySelectorAll('details.usc-pm *')].map(e=>e.className).filter(Boolean).slice(0,15)}))));
};
