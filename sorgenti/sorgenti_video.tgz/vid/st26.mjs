export default async (P, nav, sleep) => {
  await nav('Realizzare','Calendario e attività');
  await P.evaluate(() => { document.querySelector('.cal-row[data-u="r1"] .cal-ra .cal-bt2').click(); }); await sleep(2500);
  console.log(await P.evaluate(() => ({tabs:[...document.querySelectorAll('.usc-tab')].map(e=>e.innerText.trim()), pals: !!document.querySelector('.usc-pals'), pi:[...document.querySelectorAll('.usc-pi')].map(e=>e.innerText.trim().replace(/\s+/g,' ')), blks:document.querySelectorAll('.usc-blk').length, h: document.querySelector('#main-app h1,#main-app h2')?.innerText})));
  await P.screenshot({path:'/tmp/g26.png'});
};
