export default async (P, nav, sleep) => {
  await nav('Realizzare','Calendario e attività');
  await P.evaluate(() => { document.querySelector('.cal-row[data-u="r1"] .cal-ra .cal-bt2').click(); }); await sleep(2500);
  await P.evaluate(() => [...document.querySelectorAll('.usc-pi')].find(e=>/dalla programmazione/.test(e.innerText)).click()); await sleep(1500);
  await P.evaluate(() => { const b=[...document.querySelectorAll('.usc-blk')].pop(); const e=[...b.querySelectorAll('[onclick]')].find(x=>/Orientiamoci con la mappa/.test(x.innerText)); e&&e.click(); }); await sleep(1500);
  await P.evaluate(() => { const b=[...document.querySelectorAll('.usc-blk')].pop(); const sl=b.querySelectorAll('select.ax-pm-s')[0]; sl.value='Anna Verdi (CU)'; const o=[...sl.options].find(o=>/Anna/.test(o.text)); sl.value=o.value; sl.dispatchEvent(new Event('change',{bubbles:true})); }); await sleep(1200);
  console.log(JSON.stringify(await P.evaluate(() => { const b=[...document.querySelectorAll('.usc-blk')].pop(); return [...b.querySelectorAll('select.ax-pm-s')].map(s=>[(s.closest('label,div')||{}).innerText?.slice(0,60), s.options.length, s.value]); })));
};
