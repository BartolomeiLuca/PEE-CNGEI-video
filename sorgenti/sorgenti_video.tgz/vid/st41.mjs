export default async (P, nav, sleep) => {
  await nav('Osservare','Come osservo'); await sleep(1500);
  console.log(await P.evaluate(() => ({btn:[...document.querySelectorAll('#main-app button')].filter(e=>e.offsetParent).map(e=>e.innerText.trim()).filter(Boolean).slice(0,25), note:[...document.querySelectorAll('.oss-note,.oss-lead,#oss-sum')].map(e=>e.innerText.slice(0,200))})));
  await P.screenshot({path:'/tmp/g41a.png'});
  await P.evaluate(() => { const b=[...document.querySelectorAll('#main-app button')].find(e=>e.offsetParent&&/Nuova attività|Crea|Inizia/i.test(e.innerText)); b&&b.click(); }); await sleep(1500);
  console.log(await P.evaluate(() => [...document.querySelectorAll('.modal, .oss-wiz, [role=dialog]')].map(e=>e.innerText.slice(0,300))));
  await P.screenshot({path:'/tmp/g41b.png'});
};
