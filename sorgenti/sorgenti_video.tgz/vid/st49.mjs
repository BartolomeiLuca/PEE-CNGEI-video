export default async (P, nav, sleep) => {
  const dump = async (t, n=1800) => { console.log('=====', t); console.log((await P.evaluate(() => document.querySelector('#main-app').innerText.replace(/\n(Gruppo \d+|Monogruppo)\b/g,''))).slice(0,n)); };
  const btns = async () => console.log(JSON.stringify(await P.evaluate(() => [...document.querySelectorAll('#main-app button,#main-app select,#main-app textarea,#main-app input')].filter(e=>e.offsetParent).map(e=>e.tagName[0]+':'+((e.innerText||e.placeholder||'')+'').trim().replace(/\n/g,' / ').slice(0,40)).slice(0,60))));
  const clickBtn = async (rx) => P.evaluate((rx) => { const b=[...document.querySelectorAll('#main-app button')].find(b=>b.offsetParent && new RegExp(rx).test(b.innerText.trim())); if(b) b.click(); return !!b; }, rx);
  await P.evaluate(() => { shGrp('Osservare'); }); await sleep(500);
  await P.evaluate(() => { document.querySelector('#sh-side [onclick*="shStaffPage"]').click(); }); await sleep(2500);
  await clickBtn('Aggiungi persona'); await sleep(800);
  console.log(JSON.stringify(await P.evaluate(() => [...document.querySelectorAll('#main-app select')].filter(e=>e.offsetParent).map(s=>[...s.options].map(o=>o.text).slice(0,5)))));
  await P.evaluate(() => { const s=[...document.querySelectorAll('#main-app select')].filter(e=>e.offsetParent).find(s=>[...s.options].some(o=>/Marco Neri/.test(o.text))); if(s){ s.value=[...s.options].find(o=>/Marco Neri/.test(o.text)).value; s.dispatchEvent(new Event('change',{bubbles:true})); } }); await sleep(500);
  await P.evaluate(() => { [...document.querySelectorAll('#main-app button')].find(b=>b.offsetParent && b.innerText.trim()==='Aggiungi').click(); }); await sleep(1500);
  await btns();
  await P.evaluate(() => { const l=[...document.querySelectorAll('#main-app *')].filter(e=>e.offsetParent && e.children.length<4 && /Marco Neri/.test(e.innerText||'')); (l.find(e=>e.tagName==='BUTTON')||l[0]).click(); }); await sleep(1500);
  const part = async (t) => { console.log('=====', t); console.log((await P.evaluate(() => { const m=document.querySelector('#main-app'); const t=m.innerText; const i=t.indexOf('0 / 24\nSTAFF'); return t.slice(i>0?i:0).replace(/\n(Gruppo \d+|Monogruppo)\b/g,''); })).slice(0,3800)); };
  await clickBtn('^Scheda di osservazione$'); await sleep(1500); await part('SCHEDA'); await btns();
  await P.evaluate(() => { const ss=[...document.querySelectorAll('#main-app select.obs-select')].filter(e=>e.offsetParent); [3,6,5,4].forEach((v,i)=>{ if(ss[i]){ ss[i].value=String(v); ss[i].dispatchEvent(new Event('change',{bubbles:true})); } }); }); await sleep(800);
  await clickBtn('^Lettura individuale$'); await sleep(1500); await part('LETTURA');
  await clickBtn('^Evoluzione$'); await sleep(1500); await part('EVOLUZIONE'); await btns();
  await clickBtn('^Riepilogo dello staff$'); await sleep(1500); await part('RIEPILOGO'); await btns();
};
