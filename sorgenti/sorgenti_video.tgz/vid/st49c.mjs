export default async (P, nav, sleep) => {
  await P.evaluate(() => { shGrp('Osservare'); }); await sleep(400);
  await P.evaluate(() => { document.querySelector('#sh-side [onclick*="shStaffPage"]').click(); }); await sleep(2000);
  await P.evaluate(() => { stEmbGo(2); }); await sleep(1500);
  console.log(JSON.stringify(await P.evaluate(() => { const o=[]; const f=(t)=>{ const l=[...document.querySelectorAll('#main-app *')].filter(x=>x.offsetParent && x.children.length===0 && new RegExp(t,'i').test(x.textContent.trim()))[0]; if(!l) return o.push(t+': none'); let e=l; for(let i=0;i<4&&e;i++){ const b=e.getBoundingClientRect(); o.push(t+' L'+i+' '+e.tagName+'.'+e.className+' h='+Math.round(b.height)+' w='+Math.round(b.width)); e=e.parentElement; } }; f('^COPERTURA PER AMBITO'); f('^FONTI'); o.push('stmain:'+(document.querySelector('#main-app .st-main')?Math.round(document.querySelector('#main-app .st-main').getBoundingClientRect().height):'none')); o.push('proot:'+(document.getElementById('percorsi-root')?'y':'n')); return o; })));
};
