export default async (P, nav, sleep) => {
  await P.evaluate(() => { for (const g of ['Capire','Osservare','Condividere','Conservare','Misurare','Realizzare','Progettare']) { try{shGrp(g);}catch(e){} } }); await sleep(500);
  await P.evaluate(() => { document.querySelector('#sh-side [onclick*="shChk"]').click(); }); await sleep(2000);
  await P.evaluate(() => { document.querySelector('#main-app button.att-how').click(); }); await sleep(1500);
  console.log(JSON.stringify(await P.evaluate(() => [...document.querySelectorAll('[role=dialog] *, .modal *, .ov-box *, .modal-overlay *')].filter(e=>/[×✕xX]|chiud/i.test((e.innerText||'').trim()+(e.getAttribute('aria-label')||'')) && (e.innerText||'').trim().length<12).map(e=>e.tagName+'.'+e.className+'|'+(e.innerText||'').trim()+'|'+(e.getAttribute('aria-label')||'')+'|'+(e.getAttribute('onclick')||'')))));
};
