#!/bin/bash
cd /home/claude/work/vid
export SITE=/tmp/site_sh DEMO13=1 RT=1 OUTROOT=/tmp/chk
declare -A RUN=( [01s]=run01 [04s]=run04 [05s]=run05 [36s]=run36 [45s]=run45 [46s]=run46 [41s]=run47 [42s]=runCG [43s]=runCG [39s]=runPP [40s]=runPP )
for p in 27s 28s 29s 30s 31s 32s 33s 34s 35s 36s 37s 38s 42s 43s 45s 46s Ds; do
  r=${RUN[$p]:-run}
  pkill -f chrom 2>/dev/null; sleep 2
  echo "$p $r $(date +%H:%M:%S)" >> /tmp/sw/_progress
  timeout 900 node $r.mjs ./pilot$p.beats.mjs > /tmp/sw/$p.log 2>&1
  echo "$p done $(date +%H:%M:%S) fails=$(grep -c '✗' /tmp/sw/$p.log)" >> /tmp/sw/_progress
done
echo ALLDONE >> /tmp/sw/_progress
