#!/bin/bash
cd /home/claude/work/vid
export SITE=/tmp/site_sh DEMO13=1 RT=1 OUTROOT=/tmp/chk
declare -A RUN=( [43s]=runCG [39s]=runPP [40s]=runPP [41s]=runCG [45s]=run45 [46s]=run46 )
for p in 13s 14s 18s 19s 39s 40s 43s Ds 26 41s; do
  r=${RUN[$p]:-run}; pkill -f chrom 2>/dev/null; sleep 2
  echo "$p $r $(date +%H:%M:%S)" >> /tmp/sw/_progress2
  if [ $p = 14s ]; then DEMO3=1 timeout 900 node $r.mjs ./pilot$p.beats.mjs > /tmp/sw/${p}_n.log 2>&1
  else timeout 900 node $r.mjs ./pilot$p.beats.mjs > /tmp/sw/${p}_n.log 2>&1; fi
  echo "$p done $(date +%H:%M:%S) fails=$(grep -c '✗' /tmp/sw/${p}_n.log)" >> /tmp/sw/_progress2
done
echo ALLDONE >> /tmp/sw/_progress2
