import { chromium } from 'playwright';
const br = await chromium.launch({args:['--lang=it-IT'], env:{...process.env, LANGUAGE:'it_IT', LC_ALL:'it_IT.UTF-8'}});
const c = await br.newContext({locale:'it-IT'}); const p = await c.newPage();
await p.setContent('<input type="date" id="d" style="font-size:30px">'); await p.screenshot({path:'/tmp/lang.png', clip:{x:0,y:0,width:300,height:60}});
await br.close();
