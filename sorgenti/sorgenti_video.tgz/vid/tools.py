import json,subprocess,sys,os
def marker(raw):
    # cerca il primo istante in cui il fotogramma passa da nero a crema (media luminosità > 200) dopo un periodo scuro
    out=subprocess.run(['ffmpeg','-v','error','-i',raw,'-vf','fps=10,scale=32:18,format=gray','-f','rawvideo','-'],capture_output=True).stdout
    n=len(out)//(32*18); seen_dark=False
    for i in range(n):
        m=sum(out[i*576:(i+1)*576])/576
        if m<40: seen_dark=True
        if seen_dark and m>120: return i/10.0
    return None
def frames(d, picks, cols=3, w=640):
    raw=d+'/raw.webm'; tl=json.load(open(d+'/timeline.json')); Tm=marker(raw); print('marker video s',Tm)
    ts=[]
    for id,off in picks:
        b=[x for x in tl['log'] if x['id']==id][0]; ts.append(Tm+b['t']/1000+off)
    for i,t in enumerate(ts):
        subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',raw,'-frames:v','1','-vf',f'scale={w}:-1',f'{d}/f{i}.png'])
    subprocess.run(['ffmpeg','-v','error','-y']+sum([['-i',f'{d}/f{i}.png'] for i in range(len(ts))],[])+['-filter_complex',''.join(f'[{i}:v]' for i in range(len(ts)))+f'xstack=inputs={len(ts)}:layout='+'|'.join(f'{(i%cols)*w}_{(i//cols)*int(w*9/16)}' for i in range(len(ts))),d+'/sheet2.jpg'])
if __name__=='__main__':
    d=sys.argv[1]; picks=[(a.split(':')[0],float(a.split(':')[1])) for a in sys.argv[2:]]; frames(d,picks)
