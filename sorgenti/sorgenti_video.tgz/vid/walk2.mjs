import { FakeDB, serve, launch, person, sleep, loginAs } from '../harness.mjs';
import { demoData } from './demo.mjs';
process.env.SITE = '/tmp/site_sh';
const base = (await serve()) + 'anteprima/';
const db = new FakeDB(); const {u} = demoData(db); const br = await launch('chromium');
const pa = await person(br, db, {ctx:{viewport:{width:1440,height:900}}}); const P = pa.page; const ev=(f,a)=>P.evaluate(f,a);
await loginAs(P, base, u); await sleep(1500);
await ev(() => shOpen('p1', 0)); await sleep(4500);
await ev(() => { gGo('1a'); window._ctxF = 'occ'; if(window.shSync) shSync(); }); await sleep(1500);
await P.screenshot({path:'/tmp/pe_occ.png'});
console.log((await ev(() => document.getElementById('main-app').innerText.replace(/\n{2,}/g,'\n'))).slice(0,1800));
await ev(() => ossWizOpen('')); await sleep(2500);
const F = P.frames().filter(f => f !== P.mainFrame()).pop();
const clickTxt = (sel, re) => F.evaluate(([sel, re]) => { const b = [...document.querySelectorAll(sel)].find(x => new RegExp(re).test(x.textContent)); if(!b) return false; b.click(); return true; }, [sel, re]);
const next = async () => { await F.evaluate(() => document.getElementById('wnext').click()); await sleep(500); };
const info = async n => { console.log('=== passo', n); console.log((await F.evaluate(() => document.getElementById('wbody').innerText)).replace(/\n{2,}/g,'\n').slice(0,900)); await P.screenshot({path:'/tmp/pe_w'+n+'.png'}); };
const H2 = () => F.evaluate(() => (document.querySelector('#wbody h2')||{}).textContent || '');
await clickTxt('.opt', 'Ho una domanda sul gruppo'); await next();
for(let k=0;k<14;k++){ const h = await H2(); console.log('>>', k, h); await P.screenshot({path:'/tmp/pe_h'+k+'.png'}); if(/Passo 12|Ora scrivi/.test(h)) break;
  if(/Quando farai/.test(h)) await clickTxt('.opt', 'Tra i due pit stop');
  else if(/Che cosa vuoi capire/.test(h)) await F.evaluate(() => { const t = document.querySelector('#wbody textarea'); t.value = 'Quando nessuno guida il gioco, chi prende l’iniziativa o aspettano tutti?'; t.dispatchEvent(new Event('input', {bubbles:true})); });
  else if(/parla soprattutto/.test(h)) await clickTxt('.opt', 'ciò che li muove dentro');
  else if(/Su quale percorso/.test(h)) await clickTxt('.prc button', 'Scelgo questo');
  else if(/osservare anche altro/.test(h)) await clickTxt('#wbody button', 'Va bene così, continuo');
  else if(/In che situazione/.test(h)) await clickTxt('.opt', 'Attività guidata');
  else if(/Cosa vuoi guardare/.test(h)){ await clickTxt('.pronta button', 'Uso questa'); await sleep(300); await clickTxt('#wbody .btn-primary', 'Aggiungi questo focus'); }
  else if(/Quanto dura/.test(h)){ await clickTxt('#wbody .pill', '^1 ora$'); await F.evaluate(() => { const n = document.querySelector('#wbody input[type=number]'); n.value = '20'; n.dispatchEvent(new Event('input', {bubbles:true})); }); }
  else { console.log((await F.evaluate(() => document.getElementById('wbody').innerText)).replace(/\n{2,}/g,'\n').slice(0,1100)); }
  await sleep(350); await next(); }
await F.evaluate(() => { S.foc.length || S.foc.push({txt:'Osservo se, quando nessuno guida il gioco, chi prende l’iniziativa.',cls:'',pid:S.main,extra:[],tocca:[]}); });
console.log('FINAL', (await F.evaluate(() => document.getElementById('wbody').innerText)).replace(/\n{2,}/g,'\n').slice(0,1500));
await P.screenshot({path:'/tmp/pe_w12.png'});
await F.evaluate(() => { S.nome='Il gioco senza capo'; S.lan='Lancio: presento il gioco e dico che per oggi nessuno lo guida.'; S.svi='Sviluppo: giocano a squadre; io e il mio staff osserviamo senza intervenire.'; S.con='Conclusione: cerchio finale, ognuno racconta cosa ha fatto.'; salva(); }); await sleep(1500);
await P.screenshot({path:'/tmp/pe_after.png'});
console.log('AFTER', (await ev(() => document.getElementById('main-app').innerText.replace(/\n{2,}/g,'\n'))).split('Crea le tue attività osservative')[1].slice(0,1500));
console.log(await ev(() => [...document.querySelectorAll('#main-app button')].filter(b=>b.offsetParent).map(b=>b.innerText.trim()).filter(Boolean).join(' | ')).then(x=>x.slice(0,900)));
await br.close(); process.exit(0);
