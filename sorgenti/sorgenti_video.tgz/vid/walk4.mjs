import { FakeDB, serve, launch, person, sleep, loginAs } from '../harness.mjs';
import { demoData } from './demo.mjs';
process.env.SITE = '/tmp/site_sh';
const base = (await serve()) + 'anteprima/';
const db = new FakeDB(); const {u} = demoData(db); const br = await launch('chromium');
const pa = await person(br, db, {ctx:{viewport:{width:1440,height:900}}}); const P = pa.page; const ev=(f,a)=>P.evaluate(f,a);
await loginAs(P, base, u); await sleep(1500);
await ev(() => shOpen('p1', 0)); await sleep(4500);
await ev(() => { gGo('1a'); window._ctxF = 'occ'; if(window.shSync) shSync(); }); await sleep(1500);
await P.screenshot({path:'/tmp/pe_occ.png'});
console.log((await ev(() => document.getElementById('main-app').innerText.replace(/\n{2,}/g,'\n'))).slice(0,1800));
await ev(() => ossWizOpen('')); await sleep(2500);
const F = P.frames().filter(f => f !== P.mainFrame()).pop();
const clickTxt = (sel, re) => F.evaluate(([sel, re]) => { const b = [...document.querySelectorAll(sel)].find(x => new RegExp(re).test(x.textContent)); if(!b) return false; b.click(); return true; }, [sel, re]);
const next = async () => { await F.evaluate(() => document.getElementById('wnext').click()); await sleep(500); };
const info = async n => { console.log('=== passo', n); console.log((await F.evaluate(() => document.getElementById('wbody').innerText)).replace(/\n{2,}/g,'\n').slice(0,900)); await P.screenshot({path:'/tmp/pe_w'+n+'.png'}); };
const H2 = () => F.evaluate(() => (document.querySelector('#wbody h2')||{}).textContent || '');
await clickTxt('.opt', 'Ho una domanda sul gruppo'); await next();
for(let k=0;k<14;k++){ const h = await H2(); console.log('>>', k, h); await P.screenshot({path:'/tmp/pe_h'+k+'.png'}); if(/Passo 12|Ora scrivi/.test(h)) break;
  if(/Quando farai/.test(h)) await clickTxt('.opt', 'Tra i due pit stop');
  else if(/Che cosa vuoi capire/.test(h)) await F.evaluate(() => { const t = document.querySelector('#wbody textarea'); t.value = 'Quando nessuno guida il gioco, chi prende l’iniziativa o aspettano tutti?'; t.dispatchEvent(new Event('input', {bubbles:true})); });
  else if(/parla soprattutto/.test(h)) await clickTxt('.opt', 'come stanno con gli altri');
  else if(/Su quale percorso/.test(h)){ console.log('PRC', await F.evaluate(() => [...document.querySelectorAll('#wbody .prc')].map(p=>p.innerText.replace(/\n+/g,' | ')).join(' ## '))); await clickTxt('.prc button', 'Scelgo questo'); }
  else if(/osservare anche altro/.test(h)) await clickTxt('#wbody button', 'Va bene così, continuo');
  else if(/In che situazione/.test(h)) await clickTxt('.opt', 'Attività guidata');
  else if(/Cosa vuoi guardare/.test(h)){ await clickTxt('.pronta button', 'Uso questa'); await sleep(300); await clickTxt('#wbody .btn-primary', 'Aggiungi questo focus'); }
  else if(/Quanto dura/.test(h)){ await clickTxt('#wbody .pill', '^1 ora$'); await F.evaluate(() => { const n = document.querySelector('#wbody input[type=number]'); n.value = '20'; n.dispatchEvent(new Event('input', {bubbles:true})); }); }
  else { console.log((await F.evaluate(() => document.getElementById('wbody').innerText)).replace(/\n{2,}/g,'\n').slice(0,1100)); }
  await sleep(350); await next(); }
const fill = async (sel, v) => F.evaluate(([sel, v]) => { const e = document.querySelector(sel); e.value = v; e.dispatchEvent(new Event('input', {bubbles:true})); }, [sel, v]);
console.log((await F.evaluate(() => [...document.querySelectorAll('#wbody .write input, #wbody .write textarea, #wbody button')].map(e => e.tagName+':'+(e.placeholder||e.innerText||'').slice(0,50)).join(' | '))));
await F.evaluate(() => { const w = document.querySelector('#wbody .write'); w && w.scrollIntoView({block:'center'}); }); await sleep(400);
await P.screenshot({path:'/tmp/pe_w12b.png'});
const ins = await F.evaluate(() => [...document.querySelectorAll('#wbody .write input, #wbody .write textarea')].map((e,i)=>i+':'+e.tagName));
console.log(ins);
await F.evaluate(() => { const els=[...document.querySelectorAll('#wbody .write input, #wbody .write textarea')]; const v=['Il gioco senza capo','Presento il gioco e dico che per oggi nessuno lo guida.','Giocano a squadre; io e lo staff osserviamo senza intervenire.','Cerchio finale: ognuno racconta cosa ha fatto.']; els.forEach((e,i)=>{ if(v[i]){ e.value=v[i]; e.dispatchEvent(new Event('input',{bubbles:true})); } }); });
await clickTxt('#wbody .btn-primary', 'Salva l’attività'); await sleep(2000);
await P.screenshot({path:'/tmp/pe_after.png'});
console.log('AFTER', (await ev(() => document.getElementById('main-app').innerText.replace(/\n{2,}/g,'\n'))).split('Crea le tue attività osservative')[1].slice(0,1200));
console.log(await ev(() => [...document.querySelectorAll('#main-app button')].filter(b=>b.offsetParent).map(b=>b.innerText.trim()).filter(Boolean).join(' | ')).then(x=>x.slice(0,900)));
await ev(() => { const b=[...document.querySelectorAll('#main-app button')].find(b=>b.offsetParent && /^Aggiungi alle occasioni osservative/.test(b.innerText.trim())); b && b.click(); }); await sleep(1200);
await P.screenshot({path:'/tmp/pe_modal.png'});
console.log('MODAL', await ev(() => (document.getElementById('g-modal')||document.body).innerText.slice(-900)));
await ev(() => { const m=document.getElementById('g-modal')||document; const d=[...document.querySelectorAll('input[type=date]')].find(x=>x.offsetParent); if(d){ d.value='2026-11-08'; d.dispatchEvent(new Event('input',{bubbles:true})); d.dispatchEvent(new Event('change',{bubbles:true})); } });
await ev(() => { const b=[...document.querySelectorAll('button')].find(b=>b.offsetParent && b.innerText.trim()==='Conferma'); b && b.click(); }); await sleep(1500);
await P.screenshot({path:'/tmp/pe_conf.png'});
console.log('CONF', (await ev(() => document.getElementById('main-app').innerText.replace(/\n{2,}/g,'\n'))).split('Crea le tue attività osservative')[1].slice(0,1400));
await ev(() => { const b=[...document.querySelectorAll('#sh-side button, #sh-side [onclick]')].find(b=>/Sviluppo Spirituale/.test(b.innerText)); b && b.click(); }); await sleep(2000);
await P.screenshot({path:'/tmp/pe_grid.png'});
console.log('GRID', (await ev(() => document.getElementById('main-app').innerText.replace(/\n{2,}/g,'\n'))).slice(0,1500));
await br.close(); process.exit(0);
